# Problem Statement

## Executive Summary

Retail supply chains generate significant volumes of plastic packaging waste across all stages — from suppliers and manufacturing through to warehouses and stores. Despite regulatory pressure and corporate sustainability commitments, most retailers have limited visibility into how much plastic waste is produced, where it originates, what it costs to handle, and how it can be reduced.

---

## The Problem in Detail

### 1. Invisible Waste Generation

Plastic packaging waste is generated at every stage of the supply chain, yet there is no unified system to measure, track or attribute it:

- **Suppliers** ship products with varying packaging weights, material types and recyclability levels
- **Warehouses** receive, unpack and dispose of packaging without structured logging
- **Stores** generate waste from shelf-stacking, damaged goods and returns
- **Waste logs** (where they exist) are spreadsheets, siloed by site, and incomplete

**Impact**: The organisation cannot report accurate waste volumes to regulators, investors or customers.

### 2. Incomplete Supplier Packaging Data

Packaging information held by suppliers is incomplete and inconsistent:

- Plastic type (PET, HDPE, PVC, LDPE, PP, PS, Mixed) is often missing or misclassified
- Packaging weight is estimated, not measured
- Multi-layer composite packaging is not decomposed by material
- Sustainability certifications are unverified

**Impact**: Predictive models cannot run without accurate input data. Manual data collection is expensive and slow.

### 3. Manual Cost Estimation

Handling effort and costs are manually estimated using spreadsheets:

- Labor hours for sorting, compacting and disposing of plastic waste are guessed by site managers
- Disposal costs vary by plastic type and contractor but are pooled into single line items
- No correlation exists between product/packaging choices and downstream handling costs

**Impact**: Cost reduction opportunities are missed. The business cannot make data-driven packaging procurement decisions.

### 4. No Predictive Capability

The organisation reacts to waste rather than predicting it:

- Seasonal patterns in waste generation are not modelled
- New product introductions cannot be evaluated for sustainability impact before launch
- Supplier comparisons on waste intensity are not possible

**Impact**: Sustainability improvements are tactical and incremental rather than strategic.

### 5. Regulatory and Reputational Risk

Governments are introducing extended producer responsibility (EPR) regulations requiring:

- Accurate plastic packaging data by weight and polymer type
- Evidence of year-on-year reduction
- Reporting on recyclability and recycled content

**Impact**: Without this platform, the organisation faces compliance risk, potential fines and reputational damage with ESG-conscious investors.

---

## Affected Supply Chain Stages

```
Supplier → Manufacturing → Inbound Warehouse → Distribution → Store → End of Life
   ↓              ↓                ↓                  ↓           ↓
Packaging     Packaging         Unpacking           Transit     Shelf
Declaration   Generation        Waste               Damage      Waste
(incomplete)  (untracked)       (unlogged)          (lost)      (manual)
```

---

## Who Is Affected

| Persona | Pain Point |
|---|---|
| Supply Chain Analyst | Cannot identify which products or suppliers drive most waste |
| Sustainability Manager | Cannot produce accurate regulatory reports or investor disclosures |
| Procurement Lead | Cannot evaluate packaging sustainability when selecting suppliers |
| Store Manager | Cannot measure or report waste without manual counting |
| IT Admin | No platform exists; data is scattered across spreadsheets and emails |

---

## Quantified Impact (Illustrative)

| Metric | Current State | Target State |
|---|---|---|
| Waste data coverage | ~20% of sites | 100% of sites |
| Cost estimation accuracy | ±40% (manual) | ±10% (AI-predicted) |
| Time to produce waste report | 3–5 days (manual) | < 5 minutes (automated) |
| Packaging optimisation opportunities identified | Ad hoc | Continuously |
| Regulatory compliance confidence | Low | High |

---

## The Opportunity

An AI-powered platform that:

1. **Ingests** supplier packaging data, purchase orders, shipment data and waste logs
2. **Predicts** plastic waste volumes by product, supplier, location and time period
3. **Estimates** handling costs with breakdown by labor, disposal and transport
4. **Recommends** packaging optimisations with quantified savings
5. **Explains** AI predictions in plain English for non-technical users
6. **Reports** sustainability performance with regulatory alignment
7. **Learns** continuously from feedback and new data

Would transform the organisation's sustainability posture from reactive to proactive.

---

## Constraints

| Constraint | Description |
|---|---|
| Data Quality | Input data is incomplete; the system must handle missing values gracefully |
| User Literacy | End users are not data scientists; explanations must be human-readable |
| Integration | Must integrate with existing ERP/supplier portals via CSV/API |
| Compliance | Must align with UK/EU EPR regulations and GRI Standards |
| Timeline | Demo-ready within project sprint; production-ready within 3 months |

---

## Success Criteria

- [ ] Platform accurately predicts waste within ±15% of actual measured values
- [ ] Handling cost estimates align with finance-validated actuals within ±20%
- [ ] At least 3 packaging optimisation recommendations are actionable and approved
- [ ] Sustainability report generated in < 5 minutes from data to PDF
- [ ] AI Copilot answers supply chain sustainability questions with cited sources
- [ ] Platform supports 50 concurrent users without degradation
- [ ] All predictions include confidence scores and explanations
