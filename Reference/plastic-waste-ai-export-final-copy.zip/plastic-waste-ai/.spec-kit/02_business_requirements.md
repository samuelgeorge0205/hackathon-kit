# Business Requirements

## Purpose

Define measurable business outcomes the platform must deliver. Each requirement is traceable to a problem statement in [01_problem.md](01_problem.md) and maps to functional requirements in [03_functional_requirements.md](03_functional_requirements.md).

---

## Requirements

### BR-001 — Plastic Waste Visibility

**Statement**: The organisation must have a unified view of plastic waste generation across all supply chain stages (supplier → manufacturing → warehouse → store).

**Metric**: 100% of active sites reporting waste data within 6 months of deployment.

**Priority**: MUST HAVE

---

### BR-002 — Waste Prediction Accuracy

**Statement**: The AI system must predict plastic waste volumes within ±15% of actual measured values.

**Metric**: Mean Absolute Percentage Error (MAPE) ≤ 15% on held-out test data.

**Priority**: MUST HAVE

---

### BR-003 — Handling Cost Estimation

**Statement**: The platform must estimate plastic waste handling costs (labor, disposal, transport) with quantified confidence.

**Metric**: Cost estimates align with finance-validated actuals within ±20%.

**Priority**: MUST HAVE

---

### BR-004 — Supplier Packaging Transparency

**Statement**: All active suppliers must have complete packaging data (material type, weight, recyclability) captured in the system.

**Metric**: ≥ 95% of packaging SKUs have all mandatory fields populated.

**Priority**: MUST HAVE

---

### BR-005 — Regulatory Compliance Reporting

**Statement**: The platform must generate plastic waste reports aligned with UK/EU Extended Producer Responsibility (EPR) regulations and GRI 306 Waste Standard.

**Metric**: Reports accepted by compliance team without manual amendment.

**Priority**: MUST HAVE

---

### BR-006 — Packaging Optimisation Recommendations

**Statement**: The AI system must identify and recommend packaging changes that reduce plastic waste, with quantified savings estimates.

**Metric**: ≥ 3 actionable recommendations generated per analysis run; ≥ 1 approved and actioned per quarter.

**Priority**: MUST HAVE

---

### BR-007 — Explainable AI

**Statement**: Every AI prediction and recommendation must include a plain-English explanation that a non-technical user can understand and trust.

**Metric**: User satisfaction score ≥ 4/5 on explanation clarity in user testing.

**Priority**: MUST HAVE

---

### BR-008 — Time-to-Report Reduction

**Statement**: Sustainability waste reports must be generated automatically in under 5 minutes, replacing the current 3–5 day manual process.

**Metric**: Report generation time ≤ 5 minutes from data ingestion to PDF output.

**Priority**: MUST HAVE

---

### BR-009 — AI Copilot for Self-Service Insights

**Statement**: Business users must be able to ask natural language questions about waste, packaging and sustainability and receive grounded, cited answers.

**Metric**: AI Copilot answers ≥ 80% of test questions accurately without requiring human follow-up.

**Priority**: SHOULD HAVE

---

### BR-010 — Supplier Comparison and Benchmarking

**Statement**: Procurement teams must be able to compare suppliers on plastic waste intensity (kg waste per unit shipped) to inform sourcing decisions.

**Metric**: Supplier scorecard available within the platform showing relative waste intensity ranking.

**Priority**: SHOULD HAVE

---

### BR-011 — Trend Analysis and Forecasting

**Statement**: The platform must show waste generation trends over time and forecast future waste based on order volumes.

**Metric**: Trend charts available for 12-month lookback and 3-month forecast.

**Priority**: SHOULD HAVE

---

### BR-012 — Data Upload Self-Service

**Statement**: Business users (not IT) must be able to upload new supplier packaging data, purchase orders and waste logs via CSV or Excel without technical support.

**Metric**: Upload success rate ≥ 95% with clear validation error messages for failures.

**Priority**: MUST HAVE

---

### BR-013 — Role-Based Access Control

**Statement**: Access to sensitive data (cost data, supplier contracts) must be restricted by user role.

**Metric**: Role permission matrix implemented and audited. No unauthorised access in penetration testing.

**Priority**: MUST HAVE

---

### BR-014 — Audit Trail

**Statement**: All data uploads, predictions, recommendations and configuration changes must be logged with user, timestamp and change detail.

**Metric**: 100% of state-changing actions captured in audit log.

**Priority**: MUST HAVE

---

### BR-015 — Platform Performance

**Statement**: The platform must support 50 concurrent users with acceptable response times.

**Metric**: API p95 latency ≤ 200ms for non-AI endpoints; AI prediction endpoints ≤ 5 seconds.

**Priority**: MUST HAVE

---

### BR-016 — AI Cost Control

**Statement**: LLM API costs must be monitored and bounded per user and per organisation.

**Metric**: Per-user monthly LLM spend visible in admin dashboard; automatic throttling at configurable threshold.

**Priority**: SHOULD HAVE

---

### BR-017 — Feedback Loop

**Statement**: Users must be able to rate prediction accuracy and recommendation quality to improve model performance over time.

**Metric**: Feedback captured for ≥ 60% of predictions and recommendations presented to users.

**Priority**: SHOULD HAVE

---

### BR-018 — Mobile-Responsive Interface

**Statement**: The platform must be usable on tablet devices for store managers doing warehouse floor counts.

**Metric**: All key workflows functional on 768px viewport (iPad) without horizontal scrolling.

**Priority**: SHOULD HAVE

---

### BR-019 — Data Retention and Privacy

**Statement**: Personal data (user accounts) must be handled in compliance with GDPR. Waste data must be retained for a minimum of 7 years for regulatory purposes.

**Metric**: Privacy impact assessment complete; data retention policy implemented.

**Priority**: MUST HAVE

---

### BR-020 — Future Scalability

**Statement**: The platform architecture must support migration from SQLite to PostgreSQL and from single-region to multi-region deployment without application code changes.

**Metric**: Migration completed successfully in staging environment with < 2 days engineering effort.

**Priority**: SHOULD HAVE

---

## Priority Summary

| Priority | Count |
|---|---|
| MUST HAVE | 13 |
| SHOULD HAVE | 7 |
| TOTAL | 20 |

---

## Traceability Matrix

| BR | Functional Requirements |
|---|---|
| BR-001 | FR-001, FR-002, FR-003 |
| BR-002 | FR-010, FR-011, FR-012 |
| BR-003 | FR-013, FR-014 |
| BR-004 | FR-004, FR-005, FR-006 |
| BR-005 | FR-022, FR-023 |
| BR-006 | FR-015, FR-016 |
| BR-007 | FR-017, FR-018 |
| BR-008 | FR-022, FR-023 |
| BR-009 | FR-019, FR-020, FR-021 |
| BR-010 | FR-007, FR-008 |
| BR-011 | FR-009 |
| BR-012 | FR-004, FR-005, FR-006 |
| BR-013 | FR-025, FR-026, FR-027 |
| BR-014 | FR-028 |
| BR-015 | NFR-001, NFR-002 |
| BR-016 | FR-029 |
| BR-017 | FR-024 |
| BR-018 | NFR-005 |
| BR-019 | NFR-006, NFR-007 |
| BR-020 | NFR-010, NFR-011 |
