# Functional Requirements

## Purpose

Specify what the system must do. Each requirement is atomic, testable and traceable to a business requirement in [02_business_requirements.md](02_business_requirements.md).

**Format**: `FR-NNN | Name | Description | Acceptance Criteria | Priority | BR Reference`

---

## Data Management

### FR-001 — Supplier Data Ingestion

**Description**: The system must allow authorised users to upload supplier records via CSV with field mapping and validation.

**Acceptance Criteria**:
- Upload accepts CSV files up to 10MB
- Fields: supplier_id, name, country, tier (1/2/3), certifications, sustainability_score
- Validation errors returned per row with field-level detail
- Successful rows committed; failed rows reported without blocking the batch
- Duplicate supplier_id updates the existing record (upsert)

**Priority**: MUST HAVE | **BR**: BR-004, BR-012

---

### FR-002 — Product Data Ingestion

**Description**: The system must allow upload of product catalogue data with supplier linkage.

**Acceptance Criteria**:
- Upload accepts CSV/Excel
- Fields: product_id, supplier_id, sku, name, category, weight_kg, unit_of_measure
- supplier_id must exist in the system; orphan rows rejected with error
- Duplicate sku triggers upsert on existing record

**Priority**: MUST HAVE | **BR**: BR-004, BR-012

---

### FR-003 — Packaging Data Ingestion

**Description**: The system must allow upload of packaging specification data linked to products.

**Acceptance Criteria**:
- Fields: packaging_id, product_id, material_type (PET/HDPE/PVC/LDPE/PP/PS/Mixed), weight_g, recyclable (bool), layers (int), description
- product_id must exist
- material_type validated against allowed enum
- Weight_g must be > 0

**Priority**: MUST HAVE | **BR**: BR-004, BR-012

---

### FR-004 — Purchase Order Ingestion

**Description**: The system must accept purchase order data including line items.

**Acceptance Criteria**:
- PO header: po_id, supplier_id, order_date, status, currency
- PO line: line_id, po_id, product_id, quantity, unit_price, packaging_id
- Referential integrity validated on ingest
- PO status must be in (DRAFT, CONFIRMED, SHIPPED, RECEIVED, CANCELLED)

**Priority**: MUST HAVE | **BR**: BR-001, BR-012

---

### FR-005 — Waste Log Ingestion

**Description**: The system must allow upload and manual entry of plastic waste log records.

**Acceptance Criteria**:
- Fields: log_id, source_type (WAREHOUSE/STORE/SUPPLIER), source_id, product_id, packaging_id, log_date, plastic_type, weight_kg, disposal_method (RECYCLED/LANDFILL/INCINERATED/UNKNOWN)
- Weight_kg must be > 0
- Log_date must not be in the future
- Auto-link to product and packaging if IDs provided

**Priority**: MUST HAVE | **BR**: BR-001, BR-012

---

### FR-006 — Shipment Data Ingestion

**Description**: The system must accept shipment records linking purchase orders to warehouses or stores.

**Acceptance Criteria**:
- Fields: shipment_id, po_id, shipped_date, received_date, destination_type (WAREHOUSE/STORE), destination_id, status
- Destination_id must match a warehouse_id or store_id depending on destination_type

**Priority**: MUST HAVE | **BR**: BR-001

---

## Analytics and Reporting Views

### FR-007 — Supplier Waste Intensity Dashboard

**Description**: The system must display a supplier comparison showing waste intensity (kg waste per unit shipped) for all active suppliers.

**Acceptance Criteria**:
- Ranked list of suppliers by waste intensity
- Filterable by time period, category, region
- Drill-down to product level
- Export to CSV

**Priority**: SHOULD HAVE | **BR**: BR-010

---

### FR-008 — Product-Level Waste Attribution

**Description**: The system must show waste attributable to each product SKU.

**Acceptance Criteria**:
- Table showing product_id, sku, name, total_waste_kg, packaging_type, waste_intensity
- Sortable by all columns
- Filter by supplier, category, time period
- Highlight top 10 waste contributors

**Priority**: SHOULD HAVE | **BR**: BR-010

---

### FR-009 — Waste Trend Analysis

**Description**: The system must display time-series waste trends at organisational, supplier and site levels.

**Acceptance Criteria**:
- Line chart with 12-month lookback
- Selectable granularity: day, week, month, quarter
- Plastic type breakdown (stacked chart)
- Downloadable as PNG/SVG

**Priority**: SHOULD HAVE | **BR**: BR-011

---

## AI Prediction

### FR-010 — Waste Volume Prediction

**Description**: The AI system must predict future plastic waste volumes given a set of input parameters.

**Acceptance Criteria**:
- Inputs: supplier_id (optional), product_id (optional), location (optional), time_period, order_volume
- Outputs: predicted_waste_kg, confidence_score (0–1), prediction_interval (low, high), plastic_type_breakdown
- Prediction includes a natural language explanation
- Response time ≤ 5 seconds

**Priority**: MUST HAVE | **BR**: BR-002

---

### FR-011 — Prediction Confidence Score

**Description**: Every AI prediction must include a calibrated confidence score.

**Acceptance Criteria**:
- Confidence score in range [0.0, 1.0]
- Scores < 0.5 flagged as "low confidence" with visual warning
- Confidence score methodology documented in XAI explanation
- Score reflects data quality and model uncertainty

**Priority**: MUST HAVE | **BR**: BR-002, BR-007

---

### FR-012 — Prediction History

**Description**: All predictions must be stored and retrievable with their inputs, outputs and feedback.

**Acceptance Criteria**:
- Prediction persisted with: input_params, output_json, model_version, confidence_score, timestamp, user_id
- Paginated list endpoint
- Filter by user, date range, confidence level
- Download as CSV

**Priority**: MUST HAVE | **BR**: BR-002

---

## Cost Estimation

### FR-013 — Handling Cost Estimation

**Description**: The system must estimate handling costs for predicted or actual waste volumes.

**Acceptance Criteria**:
- Inputs: waste_volume_kg, plastic_type, location, period
- Outputs: labor_cost, disposal_cost, transport_cost, total_cost, cost_per_kg
- Cost rates configurable by admin
- Outputs include confidence interval

**Priority**: MUST HAVE | **BR**: BR-003

---

### FR-014 — Cost Breakdown Visualisation

**Description**: Cost estimates must be displayed as an itemised breakdown.

**Acceptance Criteria**:
- Pie/donut chart showing labor/disposal/transport split
- Trend line showing cost over time
- Comparison against industry benchmark (configurable)
- Export to PDF/CSV

**Priority**: MUST HAVE | **BR**: BR-003

---

## Recommendations

### FR-015 — Packaging Optimisation Recommendations

**Description**: The AI system must generate packaging change recommendations that reduce plastic waste.

**Acceptance Criteria**:
- Recommendation includes: product_id, current_packaging, suggested_packaging, estimated_waste_reduction_kg, estimated_cost_saving, confidence_score, rationale
- Recommendations ranked by estimated impact
- Each recommendation grounded in retrieved knowledge (RAG)
- User can accept, reject or defer with comment

**Priority**: MUST HAVE | **BR**: BR-006

---

### FR-016 — Recommendation Tracking

**Description**: The system must track the status and outcome of recommendations.

**Acceptance Criteria**:
- Status transitions: PENDING → ACCEPTED/REJECTED/DEFERRED → IMPLEMENTED/CANCELLED
- Implemented recommendations fed back to model as positive training signal
- Dashboard showing recommendation pipeline and value-at-stake

**Priority**: MUST HAVE | **BR**: BR-006

---

## Explainable AI

### FR-017 — Prediction Explanation

**Description**: Every prediction must include a plain-English explanation of the key factors driving the result.

**Acceptance Criteria**:
- Explanation generated by Explanation Agent
- Cites top 3 factors influencing prediction (e.g. "High PET usage from Supplier X drove 40% of predicted waste")
- Readable by non-technical user
- Shown alongside prediction in UI

**Priority**: MUST HAVE | **BR**: BR-007

---

### FR-018 — RAG Source Citations

**Description**: AI Copilot and recommendation responses must cite the specific sources used to generate the answer.

**Acceptance Criteria**:
- Each response includes citations: [1] source_title, page/section, relevance_score
- User can click citation to view source excerpt
- Sources drawn from ChromaDB knowledge base

**Priority**: MUST HAVE | **BR**: BR-007

---

## AI Copilot

### FR-019 — Natural Language Q&A

**Description**: Users must be able to ask supply chain and sustainability questions in natural language.

**Acceptance Criteria**:
- Chat interface with message history (session-scoped)
- Responses grounded in organisational data via RAG
- Response includes cited sources
- Ambiguous queries handled with clarifying question

**Priority**: SHOULD HAVE | **BR**: BR-009

---

### FR-020 — Contextual Follow-up

**Description**: The AI Copilot must maintain conversation context for multi-turn interactions.

**Acceptance Criteria**:
- Session context maintained for up to 20 turns
- References to "it", "that supplier", "last month" resolved correctly
- Context cleared on new session

**Priority**: SHOULD HAVE | **BR**: BR-009

---

### FR-021 — Copilot Safety Filter

**Description**: The Copilot must detect and reject prompt injection, PII and out-of-scope queries.

**Acceptance Criteria**:
- Prompt injection patterns detected and blocked
- PII (email, phone, NI number) detected and masked before LLM submission
- Off-topic queries (non-supply chain / non-sustainability) returned with polite scope message
- Guardrail trigger logged to audit

**Priority**: MUST HAVE | **BR**: BR-009, BR-013

---

## Reports

### FR-022 — Automated Sustainability Report Generation

**Description**: The system must generate a structured sustainability waste report from data.

**Acceptance Criteria**:
- Report covers: executive summary, waste by plastic type, waste by supplier, waste by site, trend analysis, YoY comparison, recommendations summary
- Generated in < 5 minutes
- Output format: PDF and JSON
- Aligned with GRI 306 and UK EPR reporting categories

**Priority**: MUST HAVE | **BR**: BR-005, BR-008

---

### FR-023 — Report Scheduling

**Description**: Reports must be schedulable for automatic generation (monthly, quarterly).

**Acceptance Criteria**:
- Admin can set report schedule (daily/weekly/monthly/quarterly)
- Report stored and available for download
- Email notification on report completion (configurable)

**Priority**: SHOULD HAVE | **BR**: BR-005

---

## User and System Management

### FR-024 — Prediction Feedback Collection

**Description**: Users must be able to rate prediction accuracy and recommendation quality.

**Acceptance Criteria**:
- Thumbs up/down on predictions and recommendations
- Optional free-text comment
- Rating stored linked to prediction_id/recommendation_id and user_id
- Feedback visible to admin

**Priority**: SHOULD HAVE | **BR**: BR-017

---

### FR-025 — User Management

**Description**: Admin users must be able to create, update, deactivate and role-assign users.

**Acceptance Criteria**:
- CRUD operations on users
- Roles: viewer, analyst, manager, admin
- Deactivated users cannot log in
- Role changes logged to audit

**Priority**: MUST HAVE | **BR**: BR-013

---

### FR-026 — Role-Based Access Control

**Description**: All API endpoints must enforce role-based access.

**Acceptance Criteria**:
- viewer: read-only (dashboard, analytics, copilot)
- analyst: viewer + upload + predictions + reports
- manager: analyst + recommendations approval + configuration
- admin: full access including user management
- Unauthenticated requests return HTTP 401
- Unauthorised role requests return HTTP 403

**Priority**: MUST HAVE | **BR**: BR-013

---

### FR-027 — Authentication

**Description**: The system must authenticate users via JWT with refresh token support.

**Acceptance Criteria**:
- Access token TTL: 15 minutes
- Refresh token TTL: 7 days
- Refresh token rotation on use
- Logout invalidates refresh token
- Brute-force protection: 5 failed attempts triggers 15-minute lockout

**Priority**: MUST HAVE | **BR**: BR-013

---

### FR-028 — Audit Logging

**Description**: All state-changing actions must be logged to an immutable audit trail.

**Acceptance Criteria**:
- Events logged: login, logout, upload, prediction, recommendation status change, user management, configuration change
- Log fields: event_type, user_id, timestamp, entity_type, entity_id, before_json, after_json, ip_address
- Audit log is read-only (append-only)
- Exportable by admin for compliance review

**Priority**: MUST HAVE | **BR**: BR-014

---

### FR-029 — LLM Cost Monitoring

**Description**: Admin must be able to view LLM token usage and estimated cost per user and organisation.

**Acceptance Criteria**:
- Dashboard showing: tokens_in, tokens_out, estimated_cost by user, by model, by date
- Configurable monthly budget alert threshold
- Automatic throttling when threshold reached (configurable)

**Priority**: SHOULD HAVE | **BR**: BR-016

---

### FR-030 — System Configuration Management

**Description**: Admins must be able to update system configuration without code deployment.

**Acceptance Criteria**:
- Configurable: cost rates, model parameters, report templates, LLM model selection, budget thresholds
- Configuration changes versioned and audited
- Invalid values rejected with validation error

**Priority**: MUST HAVE | **BR**: BR-020

---

## Requirements Summary

| Category | Count | MUST HAVE | SHOULD HAVE |
|---|---|---|---|
| Data Management | 6 | 6 | 0 |
| Analytics | 3 | 0 | 3 |
| AI Prediction | 3 | 3 | 0 |
| Cost Estimation | 2 | 2 | 0 |
| Recommendations | 2 | 2 | 0 |
| Explainable AI | 2 | 2 | 0 |
| AI Copilot | 3 | 1 | 2 |
| Reports | 2 | 1 | 1 |
| User/System Mgmt | 6 | 5 | 1 |
| **Total** | **30** | **22** | **8** |
