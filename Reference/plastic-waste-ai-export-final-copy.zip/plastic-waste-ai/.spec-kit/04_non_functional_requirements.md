# Non-Functional Requirements

## Purpose

Define quality attributes the system must exhibit — independent of specific features. Each NFR includes a measurable target and verification method.

---

## Performance

### NFR-001 — API Response Time

**Category**: Performance

**Requirement**: Standard API endpoints (non-AI) must respond within 200ms at p95 under normal load.

**Target**: p95 ≤ 200ms, p99 ≤ 500ms

**Load Profile**: 50 concurrent users, 100 requests/second

**Verification**: Load test with Locust or k6; measure p95/p99 from API gateway

**Priority**: MUST HAVE

---

### NFR-002 — AI Endpoint Response Time

**Category**: Performance

**Requirement**: AI prediction endpoints must respond within 5 seconds for 95% of requests.

**Target**: p95 ≤ 5s for waste prediction; p95 ≤ 10s for report generation

**Verification**: Load test; Langfuse latency tracking

**Priority**: MUST HAVE

---

### NFR-003 — Throughput

**Category**: Performance

**Requirement**: The system must handle peak traffic without degradation.

**Target**: 100 requests/second sustained; 200 requests/second burst (30 seconds)

**Verification**: Load test with gradual ramp-up

**Priority**: SHOULD HAVE

---

### NFR-004 — Data Upload Performance

**Category**: Performance

**Requirement**: CSV uploads of up to 10,000 rows must complete within 30 seconds.

**Target**: ≤ 30 seconds for 10,000 row CSV ingestion including validation

**Verification**: Benchmark test with synthetic datasets

**Priority**: MUST HAVE

---

## Availability and Reliability

### NFR-005 — Availability

**Category**: Reliability

**Requirement**: The platform must be available 99.5% of the time during business hours (07:00–22:00 GMT weekdays).

**Target**: 99.5% uptime = < 3.65 hours downtime per month

**Verification**: Uptime monitoring; SLA reporting

**Priority**: MUST HAVE

---

### NFR-006 — Graceful Degradation

**Category**: Reliability

**Requirement**: If the LLM API is unavailable, non-AI features (data upload, analytics, reports from cached data) must remain functional.

**Target**: Core CRUD and analytics features available during LLM outage

**Verification**: Chaos test: disable LLM API; verify analytics endpoints return 200

**Priority**: MUST HAVE

---

### NFR-007 — Data Durability

**Category**: Reliability

**Requirement**: No data loss for committed waste logs, predictions or audit records.

**Target**: Zero data loss on planned restarts; automated daily backup with ≤ 24h recovery point objective (RPO)

**Verification**: Backup restore test; transaction log review

**Priority**: MUST HAVE

---

## Scalability

### NFR-008 — Horizontal API Scaling

**Category**: Scalability

**Requirement**: The API layer must be stateless to enable horizontal scaling.

**Target**: API instances can be added without configuration change; JWT validated without shared session state

**Verification**: Deploy 2 API instances behind load balancer; verify session continuity

**Priority**: SHOULD HAVE

---

### NFR-009 — Database Migration Path

**Category**: Scalability

**Requirement**: The system must support migration from SQLite to PostgreSQL without application code changes.

**Target**: Only `DATABASE_URL` configuration change required for migration

**Verification**: Run full test suite against PostgreSQL instance

**Priority**: SHOULD HAVE

---

### NFR-010 — Vector Store Scalability

**Category**: Scalability

**Requirement**: ChromaDB must support ingestion of up to 100,000 document chunks without query performance degradation.

**Target**: Vector similarity query ≤ 500ms at 100,000 chunks

**Verification**: Load test ChromaDB with synthetic embeddings

**Priority**: SHOULD HAVE

---

## Security

### NFR-011 — Authentication Security

**Category**: Security

**Requirement**: The system must use industry-standard JWT authentication with secure token handling.

**Target**: JWT signed with RS256 (asymmetric); access token TTL 15 minutes; refresh token TTL 7 days; tokens never stored in localStorage (use httpOnly cookies or memory)

**Verification**: OWASP JWT security checklist; penetration test

**Priority**: MUST HAVE

---

### NFR-012 — OWASP Top 10 Compliance

**Category**: Security

**Requirement**: The application must not be vulnerable to OWASP Top 10 security risks.

**Target**: Zero critical findings on automated OWASP scan (OWASP ZAP or equivalent)

**Verification**: Automated security scan in CI pipeline

**Priority**: MUST HAVE

---

### NFR-013 — Input Validation

**Category**: Security

**Requirement**: All user inputs must be validated and sanitised before processing.

**Target**: All API inputs validated with Pydantic v2; SQL injection impossible (ORM only); file uploads validated by content type and size

**Verification**: Unit tests for edge cases; SAST scan

**Priority**: MUST HAVE

---

### NFR-014 — Secrets Management

**Category**: Security

**Requirement**: No secrets (API keys, passwords, connection strings) may be committed to the repository.

**Target**: Zero secrets in git history; all secrets via environment variables

**Verification**: `git-secrets` or `trufflehog` scan in CI pipeline; `.env.example` with placeholder values

**Priority**: MUST HAVE

---

### NFR-015 — Transport Security

**Category**: Security

**Requirement**: All communication must use TLS 1.2 or higher in production.

**Target**: HTTP automatically redirected to HTTPS; TLS 1.2+ enforced

**Verification**: TLS scan (SSL Labs Grade A)

**Priority**: MUST HAVE

---

## Maintainability

### NFR-016 — Code Coverage

**Category**: Maintainability

**Requirement**: Automated test coverage must meet minimum thresholds.

**Target**: Domain layer ≥ 90% coverage; Application layer ≥ 80%; AI layer ≥ 70%; Overall ≥ 75%

**Verification**: `pytest --cov` in CI pipeline; coverage badge in README

**Priority**: SHOULD HAVE

---

### NFR-017 — Code Quality

**Category**: Maintainability

**Requirement**: Python code must pass linting and type checking.

**Target**: Zero `ruff` linting errors; zero `mypy --strict` type errors in domain and application layers

**Verification**: CI pipeline gate on lint + type check

**Priority**: MUST HAVE

---

### NFR-018 — Documentation

**Category**: Maintainability

**Requirement**: All public functions in the domain and application layers must have docstrings; API endpoints must have OpenAPI descriptions.

**Target**: FastAPI auto-generated OpenAPI spec is complete and accurate

**Verification**: `pydocstyle` scan; OpenAPI spec reviewed by non-author

**Priority**: SHOULD HAVE

---

## Observability

### NFR-019 — Structured Logging

**Category**: Observability

**Requirement**: All log events must be emitted as structured JSON with consistent fields.

**Target**: All logs contain: timestamp, level, correlation_id, layer, event, duration_ms (where applicable)

**Verification**: Log sampling in staging environment

**Priority**: MUST HAVE

---

### NFR-020 — LLM Traceability

**Category**: Observability

**Requirement**: Every LLM call must be traceable end-to-end via Langfuse.

**Target**: 100% of LLM calls captured; trace includes: model, tokens_in, tokens_out, latency_ms, cost_usd, agent_name, trace_id

**Verification**: Langfuse dashboard review; trace sampling

**Priority**: MUST HAVE

---

## Compliance

### NFR-021 — GDPR Compliance

**Category**: Compliance

**Requirement**: Personal data must be processed in compliance with GDPR.

**Target**: Privacy notice implemented; right to erasure supported for user accounts; data processing register maintained

**Verification**: Legal review; DPIA completed

**Priority**: MUST HAVE

---

### NFR-022 — Data Retention

**Category**: Compliance

**Requirement**: Waste log data must be retained for a minimum of 7 years.

**Target**: Automated archival; no deletion before 7-year retention period

**Verification**: Retention policy implemented and tested

**Priority**: MUST HAVE

---

## Usability

### NFR-023 — Mobile Responsiveness

**Category**: Usability

**Requirement**: All key workflows must be functional on tablet-sized viewports.

**Target**: 768px viewport (iPad landscape) — no horizontal scroll; all forms usable; tables use responsive collapse

**Verification**: Playwright viewport tests at 768px

**Priority**: SHOULD HAVE

---

### NFR-024 — Accessibility

**Category**: Usability

**Requirement**: The frontend must meet WCAG 2.1 Level AA accessibility standards.

**Target**: Zero critical accessibility violations on axe-core scan

**Verification**: Automated accessibility scan with axe-core in Playwright tests

**Priority**: SHOULD HAVE

---

## NFR Summary

| Category | Count | MUST HAVE | SHOULD HAVE |
|---|---|---|---|
| Performance | 4 | 3 | 1 |
| Availability | 3 | 3 | 0 |
| Scalability | 3 | 0 | 3 |
| Security | 5 | 5 | 0 |
| Maintainability | 3 | 1 | 2 |
| Observability | 2 | 2 | 0 |
| Compliance | 2 | 2 | 0 |
| Usability | 2 | 0 | 2 |
| **Total** | **24** | **16** | **8** |
