# User Personas

## Purpose

Define the five primary users of the platform. Each persona drives UI design decisions, feature priorities and user journey design in [06_user_journeys.md](06_user_journeys.md).

---

## Persona 1 — Supply Chain Analyst

**Name**: Sarah Chen

**Role**: Supply Chain Data Analyst

**Department**: Supply Chain & Logistics

**Tech Literacy**: High — comfortable with data tools, Excel power user, some SQL knowledge

**Age**: 32

---

### Goals

- Identify which products and suppliers generate the most plastic waste
- Run waste predictions before major promotional events to pre-plan disposal capacity
- Compare supplier waste intensity for quarterly supplier review meetings
- Export data for reports without needing IT support

### Frustrations

- Waste data is scattered across 12 different spreadsheets maintained by different sites
- Has to manually request packaging weights from suppliers and often gets incomplete responses
- Prediction requests to the data science team take 2 weeks to fulfil
- Cannot easily answer "which supplier is the most sustainable?" without hours of data prep

### Behaviours

- Logs in daily; primary user of Dashboard, Predictions and Analytics pages
- Uses AI Copilot to quickly answer ad hoc questions during supplier calls
- Exports data to Excel for further analysis and presentations

### Key Scenarios

1. Before a new product launch: runs waste prediction to assess packaging sustainability impact
2. Monthly supplier review: compares waste intensity across top 20 suppliers
3. Quarterly board report prep: generates sustainability report with trend data

### Success Metrics

- Waste report produced in < 30 minutes (down from 3 days)
- Supplier waste ranking available on demand
- Predictions available without IT support

---

## Persona 2 — Sustainability Manager

**Name**: James Okafor

**Role**: Head of Sustainability

**Department**: Corporate Responsibility

**Tech Literacy**: Medium — comfortable with dashboards and reports; not a coder

**Age**: 45

---

### Goals

- Demonstrate year-on-year plastic waste reduction to the board and external stakeholders
- Ensure regulatory compliance with UK EPR and EU Packaging Regulation
- Identify the highest-impact packaging changes to include in annual sustainability plan
- Respond to investor ESG questionnaires accurately and quickly

### Frustrations

- Current waste data is unreliable and cannot be used in regulatory submissions without manual verification
- Recommendations from the supply chain team are not quantified — cannot prioritise without guesswork
- No way to model the impact of proposed packaging changes before committing budget

### Behaviours

- Logs in weekly or before key reporting periods
- Primary user of Reports and Recommendations pages
- Reviews AI Copilot responses for narrative content in sustainability reports

### Key Scenarios

1. Annual sustainability report preparation: generates GRI 306-aligned waste report
2. Regulatory submission: exports waste data by plastic type for EPR notification
3. Board presentation: uses trend charts and recommendation savings estimates

### Success Metrics

- Regulatory report generated in < 1 hour
- Recommendation pipeline shows ≥ £100k annualised savings opportunity
- YoY waste reduction measurable and defensible

---

## Persona 3 — Procurement Lead

**Name**: Priya Sharma

**Role**: Senior Procurement Manager

**Department**: Procurement & Supplier Management

**Tech Literacy**: Medium — comfortable with procurement systems, limited data analysis background

**Age**: 38

---

### Goals

- Evaluate supplier sustainability credentials as part of supplier selection and renewal
- Use packaging sustainability data as a factor in contract negotiations
- Track whether suppliers are improving their packaging sustainability over time
- Identify alternative packaging options before issuing new RFPs

### Frustrations

- Packaging sustainability is not currently part of the supplier scorecard
- Supplier packaging data is self-reported and unverified
- No tool to model the cost impact of switching to a more sustainable packaging option
- Regulatory requirements are changing fast and she cannot keep up

### Behaviours

- Logs in during supplier selection cycles and contract renewals
- Primary user of Supplier Comparison (Analytics) and Recommendations pages
- Uses AI Copilot to ask about packaging regulations relevant to specific suppliers

### Key Scenarios

1. Supplier RFP evaluation: compares packaging waste intensity for shortlisted suppliers
2. Contract renewal: pulls trend data to assess supplier improvement trajectory
3. Packaging alternative assessment: asks Copilot "what is the most sustainable alternative to PET trays for chilled ready meals?"

### Success Metrics

- Supplier waste ranking included in supplier scorecard by next review cycle
- Packaging sustainability factored into ≥ 3 supplier contracts per year

---

## Persona 4 — Store Manager

**Name**: David Walsh

**Role**: Store Operations Manager

**Department**: Retail Operations

**Tech Literacy**: Low-Medium — comfortable with mobile apps and simple dashboards; not a data user

**Age**: 51

---

### Goals

- Log plastic waste easily without using spreadsheets
- Understand how his store compares to other stores on waste generation
- Act on recommendations to reduce waste at store level
- Demonstrate to staff that sustainability actions make a difference

### Frustrations

- Current waste logging is done on paper then manually entered into a spreadsheet
- Never sees the results of waste data — it disappears into head office systems
- Receives one-size-fits-all sustainability targets that don't reflect his store format
- No visibility into which products are driving the most packaging waste at his site

### Behaviours

- Logs in weekly to submit waste log entries
- Views Store dashboard to compare against last week
- Uses tablet in the warehouse to log waste as staff sort packaging

### Key Scenarios

1. Weekly waste logging: enters packaging waste collected during goods receipt
2. Monthly review: checks store waste against site target
3. Staff briefing: shows waste trend chart to team on tablet

### Success Metrics

- Waste log entry time < 5 minutes per session (down from 30 minutes)
- Can access his store's performance on a tablet without frustration

---

## Persona 5 — IT Administrator

**Name**: Rachel Kim

**Role**: IT Systems Administrator

**Department**: Information Technology

**Tech Literacy**: High — infrastructure, security and system administration background; not an ML engineer

**Age**: 40

---

### Goals

- Maintain a secure, reliable and auditable platform
- Manage user accounts and role assignments without developer involvement
- Monitor system health and LLM costs
- Ensure the platform integrates cleanly with existing IT security policies

### Frustrations

- AI applications are a new category — she needs clear observability to trust them
- Current ad hoc data flows (emails, spreadsheets) are impossible to audit
- Concerned about prompt injection and data leakage risks from AI components
- Needs to demonstrate GDPR compliance but has no tooling to support it

### Behaviours

- Logs in when user management tasks arise or when there is an alert
- Primary user of Settings page (user management, configuration, audit log)
- Reviews Langfuse dashboard periodically for LLM cost trends

### Key Scenarios

1. New user onboarding: creates accounts, assigns roles, sends access instructions
2. Security review: exports audit log for specific time period
3. Cost control: reviews LLM token usage and adjusts budget threshold
4. Incident response: traces a specific prediction request end-to-end via Langfuse

### Success Metrics

- User provisioning completed in < 5 minutes
- Full audit trail available for any event within 30 seconds of query
- LLM costs stay within approved budget
