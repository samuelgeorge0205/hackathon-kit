# User Journeys

## Purpose

Map the end-to-end experience for each persona. Each journey covers: trigger, steps, touchpoints, system interactions, emotional state and success outcome. These journeys drive UI/UX decisions in [15_frontend_spec.md](15_frontend_spec.md).

---

## Journey 1 — Supply Chain Analyst: Pre-Launch Waste Assessment

**Persona**: Sarah Chen — Supply Chain Analyst

**Trigger**: New product launch in 6 weeks. Sarah needs to assess the plastic waste impact before the product goes live.

**Goal**: Predict waste volume for the new product, understand cost implications, and get recommendations.

---

### Steps

| # | Step | Page | Action | System Response | Emotional State |
|---|---|---|---|---|---|
| 1 | Sarah receives new product brief with packaging spec from supplier | — | Email notification | — | Curious, slightly concerned |
| 2 | Logs into platform | Login | Enters email + password | JWT issued, Dashboard loads | Neutral |
| 3 | Checks Dashboard for baseline waste context | Dashboard | Views current week KPIs | KPI cards load with last 30 days data | Oriented |
| 4 | Navigates to Upload to add new product and packaging data | Upload | Drags CSV with product + packaging details | Validation preview shows 2 warnings (missing recycled_content_pct) | Slight concern |
| 5 | Reviews validation warnings | Upload | Decides to proceed — fields are optional | Partial upload accepted; 1 product, 1 packaging record created | Confident |
| 6 | Navigates to Predictions | Predictions | Sets: product_id=new_product, period=next_30_days, order_volume=8000 | Prediction job submitted | Anticipating |
| 7 | Waits ~5 seconds for prediction | Predictions | Loading spinner with "AI is analysing…" | Prediction result returned | Engaged |
| 8 | Reviews prediction | Predictions | Reads: 2,840 kg predicted waste, 78% confidence, PET = 62% | Confidence badge shows Amber (0.78) | Concerned about PET volume |
| 9 | Opens XAI explanation | Predictions | Clicks "Why this prediction?" | Explanation panel opens with 3 key factors | Informed |
| 10 | Asks Copilot about PET alternatives | AI Copilot | Types: "What's the best sustainable alternative to 45g PET trays for chilled ready meals?" | Grounded answer with 3 citations | Interested |
| 11 | Reviews recommendations | Predictions → Recommendations | Clicks "View Recommendations" for this product | 2 recommendations generated | Hopeful |
| 12 | Exports prediction to Excel | Predictions | Clicks Export CSV | CSV downloaded | Satisfied |
| 13 | Shares with sustainability manager | — | Sends link to prediction + recommendation | — | Task complete |

### Pain Points Resolved
- ✅ No more waiting 2 weeks for data science team prediction
- ✅ Packaging recommendations available immediately
- ✅ Export available for presentation

### Success Outcome
Sarah has a waste prediction, cost estimate and recommendations ready within 30 minutes — before the product goes live.

---

## Journey 2 — Sustainability Manager: H1 Regulatory Report

**Persona**: James Okafor — Head of Sustainability

**Trigger**: H1 sustainability report due to board in 5 days. James needs accurate plastic waste data for UK EPR submission.

**Goal**: Generate a regulatory-grade waste report for H1 2026, validate the data, and download for submission.

---

### Steps

| # | Step | Page | Action | System Response | Emotional State |
|---|---|---|---|---|---|
| 1 | James logs in | Login | | Dashboard loads | Slightly stressed (deadline) |
| 2 | Reviews Dashboard YTD summary | Dashboard | Views YTD KPI cards + trend chart | 94,820 kg total; -12.4% vs H1 2025 | Cautiously positive |
| 3 | Checks data completeness before report | Dashboard | Clicks "Data Quality" indicator | Warning: 3 sites have incomplete waste logs for May | Concerned |
| 4 | Contacts site managers via email (outside platform) | — | — | — | Resolving manually |
| 5 | Returns next day after sites upload data | Upload | Sites upload missing May data | Data now complete for all sites | Relieved |
| 6 | Navigates to Reports | Reports | | Report template library shown | Ready |
| 7 | Selects "H1 Sustainability Waste Report — GRI 306" template | Reports | Clicks template | Report config form shown | Focused |
| 8 | Configures report scope | Reports | Period: Jan–Jun 2026, Scope: Organisation, Framework: GRI 306 | Config saved | |
| 9 | Generates report | Reports | Clicks "Generate Report" | Progress bar: "Generating AI narrative… 35%" | Waiting (tense) |
| 10 | Report completes in 2 minutes | Reports | Progress bar completes | Report preview shown in-page | Impressed |
| 11 | Reviews executive summary | Reports | Reads 3-paragraph summary | Numbers match manual estimates | Satisfied |
| 12 | Reviews regulatory alignment section | Reports | Reads GRI 306 alignment statements | Sources cited from retrieved regulations | Confident |
| 13 | Downloads PDF | Reports | Clicks "Download PDF" | PDF downloaded (formatted, branded) | Task complete |
| 14 | Submits to board and compliance team | — | Emails PDF | — | Accomplished |

### Pain Points Resolved
- ✅ 5-day manual process replaced by 2-minute AI generation
- ✅ GRI 306 alignment built in
- ✅ Data quality warnings catch gaps before report run

### Success Outcome
James generates and downloads a board-ready, GRI-aligned waste report in under 5 minutes of active work.

---

## Journey 3 — Procurement Lead: Supplier Selection

**Persona**: Priya Sharma — Senior Procurement Manager

**Trigger**: Reviewing 4 shortlisted suppliers for a new ready meal range contract. Wants to include packaging sustainability as a selection criterion.

**Goal**: Compare suppliers on waste intensity and get a packaging recommendation to include in the RFP.

---

### Steps

| # | Step | Page | Action | System Response | Emotional State |
|---|---|---|---|---|---|
| 1 | Priya logs in | Login | | Dashboard | Purposeful |
| 2 | Reviews supplier comparison | Analytics | Selects "Supplier Comparison" view | Table of suppliers with waste intensity (kg/100 units) | Scanning |
| 3 | Filters to 4 shortlisted suppliers | Analytics | Applies supplier filter | Filtered table showing 4 suppliers | Focused |
| 4 | Exports supplier comparison | Analytics | Clicks "Export CSV" | CSV downloaded | Organised |
| 5 | Clicks into top-ranked supplier | Analytics | Clicks supplier name | Supplier drill-down: products, waste by type, trend | Impressed by detail |
| 6 | Asks Copilot about packaging regulations for chilled ready meals | AI Copilot | Types: "What plastic packaging regulations apply to chilled ready meal trays in the UK and EU?" | Answer with citations to EPR and PPWR | Informed |
| 7 | Navigates to Recommendations | Recommendations | Filters by category=Chilled, type=MATERIAL_CHANGE | 4 recommendations shown | Engaged |
| 8 | Reviews top recommendation (rPET tray switch) | Recommendations | Opens recommendation detail | Full rationale with sources, savings estimate | Convinced |
| 9 | Copies recommendation details for RFP | Recommendations | Highlights text in recommendation detail | — | Efficient |
| 10 | Creates new RFP with packaging requirement included | — (external system) | — | — | Confident |

### Success Outcome
Priya has a supplier sustainability comparison, regulatory context and specific packaging requirement for the RFP — all sourced from one platform.

---

## Journey 4 — Store Manager: Weekly Waste Logging

**Persona**: David Walsh — Store Operations Manager

**Trigger**: Monday morning goods receipt complete. David needs to log plastic waste from weekend deliveries.

**Goal**: Log 3 waste categories quickly on a tablet, then view store performance vs last week.

---

### Steps

| # | Step | Page | Action | System Response | Emotional State |
|---|---|---|---|---|---|
| 1 | David opens platform on warehouse tablet | Login | Taps login | Dashboard loads (mobile-responsive) | Routine |
| 2 | Navigates to Upload | Upload | Taps "Log Waste" quick action on Dashboard | Waste log form opens | Ready |
| 3 | Logs PET waste | Upload | Selects source=STORE, source_id=his_store, plastic_type=PET, weight=42.5, disposal=RECYCLED | Row added to pending list | Quick |
| 4 | Logs HDPE waste | Upload | Adds second row: HDPE, 18.2kg, RECYCLED | | |
| 5 | Logs Mixed waste | Upload | Adds third row: MIXED, 8.5kg, LANDFILL | | Slight guilt about landfill |
| 6 | Submits | Upload | Taps "Submit 3 records" | Success: "3 waste records logged" | Done |
| 7 | Checks store dashboard | Dashboard | Taps "My Store" tab | Store KPIs: this week vs last week vs site average | Engaged |
| 8 | Sees mixed plastic is 20% above average | Dashboard | Views breakdown | Warning badge: "Mixed Plastic above site average" | Motivated |
| 9 | Taps AI suggestion | Dashboard | Taps "See suggestion" on warning | Short recommendation: "Consider adding PVC film sorting at goods receipt" | Informed |
| 10 | Logs out | — | Taps logout | Session cleared | Satisfied |

### Success Outcome
David logs 3 waste entries in under 5 minutes and gets an actionable suggestion for improvement.

---

## Journey 5 — IT Admin: User Provisioning and Security Audit

**Persona**: Rachel Kim — IT Systems Administrator

**Trigger**: 3 new analysts joining the sustainability team next week. CISO asks for audit log export covering last quarter's AI prediction activity.

**Goal**: Create 3 user accounts with correct roles and export audit log.

---

### Steps

| # | Step | Page | Action | System Response | Emotional State |
|---|---|---|---|---|---|
| 1 | Rachel logs in as admin | Login | | Dashboard | Professional |
| 2 | Navigates to Settings → Users | Settings | Clicks "User Management" | User list shown | Organised |
| 3 | Creates first user | Settings | Clicks "+ New User" → fills form: email, name, role=analyst | User created; welcome email sent | Efficient |
| 4 | Repeats for 2 more users | Settings | | 3 users created | Done |
| 5 | Reviews LLM cost dashboard | Settings | Clicks "AI Cost Monitor" | Token usage chart by user and model | Monitoring |
| 6 | Sees one analyst has high token usage | Settings | Identifies account | Usage is 3x average | Concerned |
| 7 | Sets budget alert threshold | Settings | Clicks "Set Alert" → enters £50/month per user | Threshold saved | In control |
| 8 | Navigates to Audit Log | Settings | Clicks "Audit Log" | Paginated audit log shown | Focused |
| 9 | Filters to last quarter, event_type=PREDICTION | Settings | Applies filters | 1,240 prediction events shown | |
| 10 | Exports to CSV | Settings | Clicks "Export Audit Log" | CSV downloaded | Done |
| 11 | Emails CSV to CISO | — | Sends email | — | Task complete |

### Success Outcome
Rachel provisions 3 users and exports 3 months of audit data in under 15 minutes — without raising a ticket to the development team.
