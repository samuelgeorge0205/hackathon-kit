# Data Architecture

## Purpose

Define how data flows through the system — from ingestion to storage, AI processing, and presentation. Establishes data lineage, classification, and storage strategy.

---

## Data Flow Overview

```
External Sources           Ingestion           Storage            AI Processing         Presentation
─────────────────         ─────────           ───────            ──────────────        ─────────────
Supplier CSV/Excel    →   Validation     →   SQLite DB      →   LangGraph          →   API Response
ERP System (future)   →   Field Mapping  →   ChromaDB       →   Agents             →   Dashboard
Manual UI Entry       →   Deduplication  →   Redis Cache    →   RAG Pipeline       →   Charts
PDF/DOCX Documents    →   Embedding      →   File Storage   →                      →   Reports
                                                                                    →   AI Copilot
```

---

## Data Classification

| Class | Examples | Storage | Retention | Encryption at Rest |
|---|---|---|---|---|
| **Operational** | Waste logs, predictions, orders | SQLite | 7 years | Yes (production) |
| **Personal** | User accounts, email, IP address | SQLite | Until account deletion (GDPR) | Yes |
| **AI Context** | Document chunks, embeddings | ChromaDB | Until replaced | Yes (production) |
| **Cache** | LLM responses, session state | Redis | TTL-based | Yes |
| **Audit** | Audit log entries | SQLite | 7 years | Yes |
| **Configuration** | System settings, cost rates | SQLite | Until superseded | Yes |

---

## Data Lineage

### Waste Log Lineage

```
[CSV Upload by User]
        │
        ▼
[Validation Layer]  ← validates against domain rules (weight > 0, date not future, enum checks)
        │
        ▼
[plastic_waste_logs table]
        │
    ┌───┴───────────────────┐
    │                       │
    ▼                       ▼
[AI Prediction          [Dashboard
 Pipeline]               Analytics]
    │                       │
    ▼                       ▼
[predictions table]   [Aggregation
    │                  Queries]
    ▼                       │
[handling_costs         [Redis Cache]
 table]                     │
    │                       ▼
    ▼               [Frontend Charts]
[recommendations
 table]
    │
    ▼
[Reports]
```

### Document Lineage (RAG)

```
[Admin uploads PDF/DOCX]
        │
        ▼
[Document Loader]  → extract text
        │
        ▼
[Text Chunker]  → 512-token chunks
        │
        ▼
[Embedder]  → text-embedding-3-small → 1536-dim vectors
        │
        ▼
[ChromaDB Collection]
        │
        ▼
[Retriever Agent]  ← triggered by prediction/recommendation/chat request
        │
        ▼
[Context passed to downstream agents]
        │
        ▼
[Response with citations]
```

---

## Storage Architecture

### SQLite (Primary Relational Store)

- **Location**: `./data/plastic_waste.db` (dev/demo)
- **Access Pattern**: Read-heavy; write on upload and prediction
- **Connection**: aiosqlite async connection pool
- **Migration**: Alembic; all schema changes via versioned migration files
- **Backup**: Daily file copy to `./data/backups/plastic_waste_{date}.db`
- **Production Migration Path**: Change `DATABASE_URL` to PostgreSQL connection string; run `alembic upgrade head`

### ChromaDB (Vector Store)

- **Location**: `./data/chroma/` (persistent directory)
- **Collections**: 5 (see [10_rag_design.md](10_rag_design.md))
- **Access Pattern**: Write on document ingestion; read on every AI request
- **Embedding Model**: text-embedding-3-small (1536 dims)
- **Index Type**: HNSW (cosine similarity)

### Redis (Cache)

- **Location**: `redis://localhost:6379` (dev); managed Redis (production)
- **Databases**: DB 0 = application cache; DB 1 = session; DB 2 = LLM cache
- **Eviction Policy**: `allkeys-lru` (evict least recently used when memory full)
- **Max Memory**: 512MB (configurable)

### File Storage

- **Location**: `./data/uploads/` (dev); S3-compatible bucket (production)
- **Stored**: Original upload files (CSV/Excel), generated reports (PDF)
- **Naming**: `uploads/{upload_id}/{original_filename}`, `reports/{report_id}/report.pdf`
- **Retention**: Upload files 90 days; reports 7 years

---

## Data Validation Rules

### At Ingestion Boundary (API Layer)
- File size ≤ 10MB
- Allowed MIME types: `text/csv`, `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`
- Maximum rows per upload: 50,000

### At Domain Layer
- `weight_kg > 0`
- `log_date ≤ today()`
- `plastic_type ∈ {PET, HDPE, PVC, LDPE, PP, PS, MIXED}`
- `confidence_score ∈ [0.0, 1.0]`
- `supplier_id` → supplier must exist (referential integrity)
- `product_id` → product must exist

### At Database Layer (SQLite CHECK constraints)
- All enum columns have CHECK constraints
- All positive-value columns have CHECK > 0

---

## Data Aggregation Strategy

Dashboard queries are expensive — they aggregate across potentially millions of waste log rows. Strategy:

1. **Materialized summaries** (not a DB view — stored in `dashboard_cache` Redis key)
2. **Cache TTL**: 5 minutes for organisation-wide summaries; 1 minute for real-time indicators
3. **Cache invalidation**: On new waste_log insert or update, invalidate affected summary keys
4. **Fallback**: If Redis unavailable, run aggregation query directly on SQLite

### Key Aggregation Queries

```sql
-- Organisation-wide waste by plastic type (last 30 days)
SELECT plastic_type, SUM(weight_kg) as total_kg
FROM plastic_waste_logs
WHERE log_date >= date('now', '-30 days')
  AND deleted_at IS NULL
GROUP BY plastic_type;

-- Supplier waste intensity (kg per unit shipped)
SELECT s.name, 
       SUM(wl.weight_kg) as total_waste_kg,
       SUM(poli.quantity) as total_units,
       SUM(wl.weight_kg) / NULLIF(SUM(poli.quantity), 0) as waste_intensity
FROM plastic_waste_logs wl
JOIN products p ON wl.product_id = p.id
JOIN suppliers s ON p.supplier_id = s.id
JOIN po_line_items poli ON poli.product_id = p.id
WHERE wl.log_date >= date('now', '-30 days')
GROUP BY s.id, s.name
ORDER BY waste_intensity DESC;
```

---

## Async Data Processing

Uploads and AI predictions are asynchronous:

```
POST /upload/products
    → 202 Accepted + upload_id
    → Background task: validate + ingest rows
    → Redis: upload:{upload_id}:status = PROCESSING → COMPLETE/FAILED
    → Client polls: GET /upload/{upload_id}/status

POST /predictions/waste
    → 202 Accepted + prediction_id
    → Background task: run LangGraph workflow
    → Redis: prediction:{prediction_id}:status = PROCESSING → COMPLETE/FAILED
    → Client polls: GET /predictions/waste/{prediction_id}
```

FastAPI `BackgroundTasks` for demo; ARQ or Celery for production.
