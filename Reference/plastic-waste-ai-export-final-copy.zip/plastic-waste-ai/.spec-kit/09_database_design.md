# Database Design

## Purpose

Define the complete relational data model for the platform. This is the canonical reference for the Data Layer implementation in Milestone 3.

---

## Design Principles

- **Repository Pattern**: all data access via repository interfaces; no direct SQL in application or domain code
- **UUID Primary Keys**: all tables use UUID primary keys for portability and security
- **Soft Delete**: no hard deletes on business entities; `deleted_at` timestamp used
- **Audit by Default**: all mutations tracked via the audit_logs table
- **SQLite First**: all queries must be SQLite-compatible; migration path to PostgreSQL via SQLAlchemy
- **Async**: all repository methods are async (aiosqlite)

---

## Entity Relationship Overview

```
users
  └── audit_logs (user_id FK)
  └── predictions (user_id FK)

suppliers
  └── products (supplier_id FK)
  └── purchase_orders (supplier_id FK)

products
  └── packaging (product_id FK)
  └── po_line_items (product_id FK)
  └── plastic_waste_logs (product_id FK)
  └── recommendations (product_id FK)

packaging
  └── po_line_items (packaging_id FK)
  └── plastic_waste_logs (packaging_id FK)

purchase_orders
  └── po_line_items (po_id FK)
  └── shipments (po_id FK)

shipments → warehouses (destination_id when WAREHOUSE)
shipments → stores (destination_id when STORE)

plastic_waste_logs
  └── handling_costs (waste_log_id FK)

configurations (standalone — keyed lookup)
```

---

## Tables

---

### `users`

Stores authenticated platform users.

| Column | Type | Nullable | Default | Notes |
|---|---|---|---|---|
| id | UUID | NO | gen_random_uuid() | PK |
| email | TEXT | NO | — | UNIQUE, lowercase |
| hashed_password | TEXT | NO | — | bcrypt hash |
| full_name | TEXT | NO | — | |
| role | TEXT | NO | 'viewer' | ENUM: viewer/analyst/manager/admin |
| department | TEXT | YES | NULL | |
| is_active | BOOLEAN | NO | TRUE | |
| failed_login_attempts | INTEGER | NO | 0 | Reset on success |
| locked_until | TIMESTAMP | YES | NULL | Brute-force lock |
| last_login_at | TIMESTAMP | YES | NULL | |
| created_at | TIMESTAMP | NO | NOW() | |
| updated_at | TIMESTAMP | NO | NOW() | |
| deleted_at | TIMESTAMP | YES | NULL | Soft delete |

**Indexes**: `idx_users_email` UNIQUE on `email`

---

### `suppliers`

Packaging suppliers in the supply chain.

| Column | Type | Nullable | Default | Notes |
|---|---|---|---|---|
| id | UUID | NO | gen_random_uuid() | PK |
| external_id | TEXT | YES | NULL | ERP supplier code |
| name | TEXT | NO | — | |
| country | TEXT | NO | — | ISO 3166-1 alpha-2 |
| region | TEXT | YES | NULL | e.g. EMEA, APAC |
| tier | INTEGER | NO | 2 | 1=Strategic, 2=Preferred, 3=Approved |
| certifications | TEXT | YES | NULL | JSON array of strings |
| sustainability_score | REAL | YES | NULL | 0.0–100.0 |
| contact_email | TEXT | YES | NULL | |
| created_at | TIMESTAMP | NO | NOW() | |
| updated_at | TIMESTAMP | NO | NOW() | |
| deleted_at | TIMESTAMP | YES | NULL | Soft delete |

**Indexes**: `idx_suppliers_external_id`, `idx_suppliers_country`, `idx_suppliers_tier`

---

### `products`

Product catalogue entries linked to suppliers.

| Column | Type | Nullable | Default | Notes |
|---|---|---|---|---|
| id | UUID | NO | gen_random_uuid() | PK |
| supplier_id | UUID | NO | — | FK → suppliers.id |
| sku | TEXT | NO | — | UNIQUE per supplier |
| name | TEXT | NO | — | |
| category | TEXT | NO | — | e.g. Chilled, Ambient, Frozen |
| sub_category | TEXT | YES | NULL | |
| weight_kg | REAL | YES | NULL | Net product weight |
| unit_of_measure | TEXT | NO | 'EACH' | EACH/KG/LITRE |
| is_active | BOOLEAN | NO | TRUE | |
| created_at | TIMESTAMP | NO | NOW() | |
| updated_at | TIMESTAMP | NO | NOW() | |
| deleted_at | TIMESTAMP | YES | NULL | |

**Indexes**: `idx_products_supplier_id`, `idx_products_sku`, `idx_products_category`

**Constraints**: UNIQUE(`supplier_id`, `sku`)

---

### `packaging`

Packaging specifications linked to products.

| Column | Type | Nullable | Default | Notes |
|---|---|---|---|---|
| id | UUID | NO | gen_random_uuid() | PK |
| product_id | UUID | NO | — | FK → products.id |
| material_type | TEXT | NO | — | ENUM: PET/HDPE/PVC/LDPE/PP/PS/MIXED |
| weight_g | REAL | NO | — | Must be > 0 |
| description | TEXT | YES | NULL | |
| recyclable | BOOLEAN | NO | FALSE | |
| recycled_content_pct | REAL | YES | NULL | 0.0–100.0 |
| layers | INTEGER | NO | 1 | Number of material layers |
| layers_detail | TEXT | YES | NULL | JSON: [{material, weight_g}] |
| is_primary | BOOLEAN | NO | TRUE | Primary vs secondary packaging |
| supplier_declared | BOOLEAN | NO | FALSE | Supplier self-declared vs verified |
| created_at | TIMESTAMP | NO | NOW() | |
| updated_at | TIMESTAMP | NO | NOW() | |
| deleted_at | TIMESTAMP | YES | NULL | |

**Indexes**: `idx_packaging_product_id`, `idx_packaging_material_type`, `idx_packaging_recyclable`

**Constraints**: CHECK(`material_type` IN ('PET','HDPE','PVC','LDPE','PP','PS','MIXED')), CHECK(`weight_g` > 0), CHECK(`recycled_content_pct` BETWEEN 0 AND 100)

---

### `purchase_orders`

Purchase orders placed with suppliers.

| Column | Type | Nullable | Default | Notes |
|---|---|---|---|---|
| id | UUID | NO | gen_random_uuid() | PK |
| external_po_number | TEXT | YES | NULL | ERP reference |
| supplier_id | UUID | NO | — | FK → suppliers.id |
| order_date | DATE | NO | — | |
| expected_delivery_date | DATE | YES | NULL | |
| status | TEXT | NO | 'DRAFT' | ENUM: DRAFT/CONFIRMED/SHIPPED/RECEIVED/CANCELLED |
| currency | TEXT | NO | 'GBP' | ISO 4217 |
| total_value | REAL | YES | NULL | |
| notes | TEXT | YES | NULL | |
| created_by | UUID | YES | NULL | FK → users.id |
| created_at | TIMESTAMP | NO | NOW() | |
| updated_at | TIMESTAMP | NO | NOW() | |

**Indexes**: `idx_po_supplier_id`, `idx_po_status`, `idx_po_order_date`

---

### `po_line_items`

Individual product lines within a purchase order.

| Column | Type | Nullable | Default | Notes |
|---|---|---|---|---|
| id | UUID | NO | gen_random_uuid() | PK |
| po_id | UUID | NO | — | FK → purchase_orders.id |
| product_id | UUID | NO | — | FK → products.id |
| packaging_id | UUID | YES | NULL | FK → packaging.id |
| quantity | INTEGER | NO | — | Must be > 0 |
| unit_price | REAL | YES | NULL | |
| currency | TEXT | YES | NULL | ISO 4217 |
| created_at | TIMESTAMP | NO | NOW() | |

**Indexes**: `idx_poli_po_id`, `idx_poli_product_id`

**Constraints**: CHECK(`quantity` > 0)

---

### `warehouses`

Distribution centre / warehouse locations.

| Column | Type | Nullable | Default | Notes |
|---|---|---|---|---|
| id | UUID | NO | gen_random_uuid() | PK |
| external_id | TEXT | YES | NULL | |
| name | TEXT | NO | — | |
| location | TEXT | NO | — | City or address |
| region | TEXT | YES | NULL | |
| country | TEXT | NO | 'GB' | ISO 3166-1 |
| capacity_m3 | REAL | YES | NULL | Storage capacity |
| is_active | BOOLEAN | NO | TRUE | |
| created_at | TIMESTAMP | NO | NOW() | |

**Indexes**: `idx_warehouses_region`, `idx_warehouses_country`

---

### `stores`

Retail store locations.

| Column | Type | Nullable | Default | Notes |
|---|---|---|---|---|
| id | UUID | NO | gen_random_uuid() | PK |
| external_id | TEXT | YES | NULL | |
| name | TEXT | NO | — | |
| format | TEXT | NO | — | HYPERMARKET/SUPERMARKET/EXPRESS/ONLINE |
| location | TEXT | NO | — | |
| region | TEXT | YES | NULL | |
| country | TEXT | NO | 'GB' | |
| is_active | BOOLEAN | NO | TRUE | |
| created_at | TIMESTAMP | NO | NOW() | |

**Indexes**: `idx_stores_region`, `idx_stores_format`

---

### `shipments`

Shipment records linking purchase orders to destinations.

| Column | Type | Nullable | Default | Notes |
|---|---|---|---|---|
| id | UUID | NO | gen_random_uuid() | PK |
| po_id | UUID | NO | — | FK → purchase_orders.id |
| shipped_date | DATE | YES | NULL | |
| received_date | DATE | YES | NULL | |
| destination_type | TEXT | NO | — | ENUM: WAREHOUSE/STORE |
| destination_id | UUID | NO | — | FK → warehouses.id or stores.id |
| status | TEXT | NO | 'IN_TRANSIT' | IN_TRANSIT/DELIVERED/FAILED |
| tracking_reference | TEXT | YES | NULL | |
| created_at | TIMESTAMP | NO | NOW() | |
| updated_at | TIMESTAMP | NO | NOW() | |

**Indexes**: `idx_shipments_po_id`, `idx_shipments_destination_id`, `idx_shipments_status`

---

### `plastic_waste_logs`

Core waste measurement records — the primary data source for AI predictions.

| Column | Type | Nullable | Default | Notes |
|---|---|---|---|---|
| id | UUID | NO | gen_random_uuid() | PK |
| source_type | TEXT | NO | — | ENUM: WAREHOUSE/STORE/SUPPLIER/MANUFACTURING |
| source_id | UUID | NO | — | FK → warehouses.id or stores.id |
| product_id | UUID | YES | NULL | FK → products.id |
| packaging_id | UUID | YES | NULL | FK → packaging.id |
| log_date | DATE | NO | — | |
| plastic_type | TEXT | NO | — | ENUM: PET/HDPE/PVC/LDPE/PP/PS/MIXED |
| weight_kg | REAL | NO | — | Must be > 0 |
| unit_count | INTEGER | YES | NULL | Number of units |
| disposal_method | TEXT | NO | 'UNKNOWN' | RECYCLED/LANDFILL/INCINERATED/UNKNOWN |
| verified | BOOLEAN | NO | FALSE | Manually verified by manager |
| notes | TEXT | YES | NULL | |
| uploaded_by | UUID | YES | NULL | FK → users.id |
| created_at | TIMESTAMP | NO | NOW() | |
| updated_at | TIMESTAMP | NO | NOW() | |

**Indexes**: `idx_waste_source`, `idx_waste_log_date`, `idx_waste_product_id`, `idx_waste_plastic_type`

**Constraints**: CHECK(`weight_kg` > 0), CHECK(`plastic_type` IN ('PET','HDPE','PVC','LDPE','PP','PS','MIXED'))

---

### `handling_costs`

Cost breakdown for processing plastic waste at a location.

| Column | Type | Nullable | Default | Notes |
|---|---|---|---|---|
| id | UUID | NO | gen_random_uuid() | PK |
| waste_log_id | UUID | YES | NULL | FK → plastic_waste_logs.id (if actual) |
| prediction_id | UUID | YES | NULL | FK → predictions.id (if estimated) |
| source_type | TEXT | NO | — | ACTUAL/ESTIMATED |
| labor_hours | REAL | YES | NULL | |
| labor_rate_per_hour | REAL | YES | NULL | GBP |
| labor_cost | REAL | YES | NULL | |
| disposal_cost | REAL | YES | NULL | |
| transport_cost | REAL | YES | NULL | |
| total_cost | REAL | NO | 0 | Computed: labor + disposal + transport |
| cost_per_kg | REAL | YES | NULL | |
| currency | TEXT | NO | 'GBP' | |
| created_at | TIMESTAMP | NO | NOW() | |

**Indexes**: `idx_handling_waste_log_id`, `idx_handling_prediction_id`

---

### `predictions`

Stored AI prediction results.

| Column | Type | Nullable | Default | Notes |
|---|---|---|---|---|
| id | UUID | NO | gen_random_uuid() | PK |
| user_id | UUID | NO | — | FK → users.id |
| prediction_type | TEXT | NO | — | WASTE_VOLUME/HANDLING_COST |
| input_params | TEXT | NO | — | JSON |
| output_json | TEXT | NO | — | JSON |
| predicted_value | REAL | YES | NULL | Primary numeric output |
| confidence_score | REAL | NO | — | 0.0–1.0 |
| model_version | TEXT | NO | — | e.g. gpt-4o-2024-11-20 |
| explanation | TEXT | YES | NULL | Plain-English explanation |
| feedback_rating | INTEGER | YES | NULL | 1=thumbs up, -1=thumbs down |
| feedback_comment | TEXT | YES | NULL | |
| created_at | TIMESTAMP | NO | NOW() | |

**Indexes**: `idx_predictions_user_id`, `idx_predictions_type`, `idx_predictions_created_at`

**Constraints**: CHECK(`confidence_score` BETWEEN 0.0 AND 1.0)

---

### `recommendations`

AI-generated packaging optimisation recommendations.

| Column | Type | Nullable | Default | Notes |
|---|---|---|---|---|
| id | UUID | NO | gen_random_uuid() | PK |
| product_id | UUID | NO | — | FK → products.id |
| recommendation_type | TEXT | NO | — | MATERIAL_CHANGE/WEIGHT_REDUCTION/RECYCLABILITY/CONSOLIDATION |
| current_packaging_id | UUID | YES | NULL | FK → packaging.id |
| description | TEXT | NO | — | |
| rationale | TEXT | NO | — | XAI explanation |
| estimated_waste_reduction_kg | REAL | YES | NULL | Per year |
| estimated_cost_saving | REAL | YES | NULL | GBP per year |
| confidence_score | REAL | NO | — | 0.0–1.0 |
| status | TEXT | NO | 'PENDING' | PENDING/ACCEPTED/REJECTED/DEFERRED/IMPLEMENTED/CANCELLED |
| status_changed_by | UUID | YES | NULL | FK → users.id |
| status_changed_at | TIMESTAMP | YES | NULL | |
| status_reason | TEXT | YES | NULL | |
| sources | TEXT | YES | NULL | JSON array of RAG source citations |
| created_at | TIMESTAMP | NO | NOW() | |
| updated_at | TIMESTAMP | NO | NOW() | |

**Indexes**: `idx_recommendations_product_id`, `idx_recommendations_status`, `idx_recommendations_created_at`

---

### `audit_logs`

Immutable audit trail for all state-changing events.

| Column | Type | Nullable | Default | Notes |
|---|---|---|---|---|
| id | UUID | NO | gen_random_uuid() | PK — append only |
| event_type | TEXT | NO | — | LOGIN/LOGOUT/UPLOAD/PREDICT/RECOMMEND/CONFIG_CHANGE/USER_CHANGE |
| user_id | UUID | YES | NULL | FK → users.id (NULL for system events) |
| entity_type | TEXT | YES | NULL | e.g. WasteLog, Prediction |
| entity_id | UUID | YES | NULL | |
| before_json | TEXT | YES | NULL | State before change |
| after_json | TEXT | YES | NULL | State after change |
| ip_address | TEXT | YES | NULL | Request IP |
| user_agent | TEXT | YES | NULL | |
| correlation_id | UUID | YES | NULL | Request correlation ID |
| created_at | TIMESTAMP | NO | NOW() | |

**Indexes**: `idx_audit_user_id`, `idx_audit_created_at`, `idx_audit_entity_type`, `idx_audit_event_type`

**Note**: This table is append-only. No UPDATE or DELETE operations permitted.

---

### `configurations`

System configuration key-value store.

| Column | Type | Nullable | Default | Notes |
|---|---|---|---|---|
| id | UUID | NO | gen_random_uuid() | PK |
| key | TEXT | NO | — | UNIQUE dotted key: `ai.model.default` |
| value | TEXT | NO | — | JSON-encoded value |
| value_type | TEXT | NO | 'string' | string/integer/float/boolean/json |
| category | TEXT | NO | — | ai/costs/reports/security/notifications |
| description | TEXT | YES | NULL | Human-readable description |
| updated_by | UUID | YES | NULL | FK → users.id |
| updated_at | TIMESTAMP | NO | NOW() | |
| created_at | TIMESTAMP | NO | NOW() | |

**Indexes**: `idx_config_key` UNIQUE on `key`, `idx_config_category`

---

## Repository Pattern

Each table has a corresponding repository interface in the Domain Layer and a SQLite implementation in the Data Layer.

### Interface Example

```python
# domain/repositories/i_waste_log_repository.py
from abc import ABC, abstractmethod
from domain.entities.waste_log import WasteLog

class IWasteLogRepository(ABC):
    @abstractmethod
    async def save(self, waste_log: WasteLog) -> WasteLog: ...

    @abstractmethod
    async def get_by_id(self, id: UUID) -> WasteLog | None: ...

    @abstractmethod
    async def list_by_source(self, source_type: str, source_id: UUID, limit: int, offset: int) -> list[WasteLog]: ...

    @abstractmethod
    async def get_by_product(self, product_id: UUID, from_date: date, to_date: date) -> list[WasteLog]: ...
```

---

## Redis Cache Design

### Cache Strategy

| Cache | Key Pattern | TTL | Invalidation |
|---|---|---|---|
| LLM Response | `llm:{model_hash}:{prompt_hash}` | 1h | On model config change |
| Session | `session:{session_id}` | 24h | On logout |
| Workflow State | `workflow:{workflow_id}` | 30m | On completion |
| Dashboard KPIs | `dashboard:{org}:summary` | 5m | On waste log upload |
| Prediction Result | `prediction:{prediction_id}` | 1h | On feedback |
| Supplier List | `suppliers:list:{page}:{filter_hash}` | 15m | On supplier update |

### Key Naming Convention

`{namespace}:{entity_type}:{identifier}[:{variant}]`

Examples:
- `llm:gpt-4o:sha256_abc123` — LLM response cache
- `session:sess_xyz789` — User session
- `dashboard:org_001:summary` — Dashboard KPIs
- `workflow:wf_pred_001:state` — LangGraph workflow state

### Session Cache Schema

```json
{
  "user_id": "uuid",
  "email": "user@example.com",
  "role": "analyst",
  "expires_at": "ISO8601",
  "last_activity": "ISO8601"
}
```

### LLM Cache Schema

```json
{
  "model": "gpt-4o",
  "prompt_hash": "sha256",
  "response": "...",
  "tokens_in": 450,
  "tokens_out": 280,
  "cached_at": "ISO8601"
}
```
