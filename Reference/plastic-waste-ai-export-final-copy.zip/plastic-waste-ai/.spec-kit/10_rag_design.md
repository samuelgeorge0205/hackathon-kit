# RAG Design

## Purpose

Define the complete Retrieval-Augmented Generation (RAG) architecture — knowledge sources, ingestion pipeline, retrieval strategy, reranking, and grounded response generation. This is the blueprint for the RAG sub-module within Milestone 4 (AI Layer).

---

## Knowledge Sources

The RAG system is grounded in five categories of authoritative documents:

| # | Category | Examples | Format | Update Frequency |
|---|---|---|---|---|
| 1 | Packaging Standards | ISO 18603, ISO 15270, BS EN 13428, ASTM D5511 | PDF | Annually |
| 2 | Internal Policies | Packaging Procurement Policy, Waste Management SOP, Sustainability Strategy 2030 | PDF/DOCX | Quarterly |
| 3 | Supplier Documentation | Supplier packaging declarations, material safety data sheets, audit reports | PDF/CSV | Per supplier onboarding |
| 4 | Sustainability Guidelines | GRI 306 Waste Standard, Ellen MacArthur Foundation Circular Economy guidelines, WRAP Plastics Pact | PDF | Bi-annually |
| 5 | Government Regulations | UK Plastic Packaging Tax guidance, UK EPR regulations, EU Packaging and Packaging Waste Regulation (PPWR), EU Single-Use Plastics Directive | PDF | On regulation change |

---

## Ingestion Pipeline

```
Document Input
     │
     ▼
┌──────────────────┐
│  Document Loader │  Detect format (PDF/DOCX/TXT/CSV) → extract raw text
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  Text Cleaner    │  Remove headers/footers, fix encoding, normalise whitespace
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  Text Chunker    │  Semantic chunking: 512 tokens, 50-token overlap
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  Metadata Tagger │  source_category, doc_id, title, page, section, date_ingested
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  Embedder        │  text-embedding-3-small (OpenAI) → 1536-dim vector
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  ChromaDB Write  │  Store embedding + metadata + raw chunk text
└──────────────────┘
```

### Document Loader

Supported formats:
- PDF: `pypdf` or `pymupdf` (handles multi-column layouts)
- DOCX: `python-docx`
- TXT/MD: native Python
- CSV: `pandas` (tabular data as text representation)

### Text Chunker

**Strategy**: Recursive character text splitter with semantic boundary awareness

```python
# Chunking parameters (config/ai.yaml)
chunking:
  chunk_size: 512          # tokens
  chunk_overlap: 50        # tokens
  separators:
    - "\n\n"               # paragraph boundary (highest priority)
    - "\n"                 # line boundary
    - ". "                 # sentence boundary
    - " "                  # word boundary (fallback)
  length_function: tiktoken  # count tokens, not characters
```

**Why 512 tokens**: Balances context completeness (tables, clauses) with retrieval precision. Larger chunks reduce precision; smaller chunks lose context.

### Embedder

```python
# Embedding configuration (config/ai.yaml)
embedding:
  model: text-embedding-3-small
  dimensions: 1536
  batch_size: 100
  retry_attempts: 3
  retry_backoff: 1.0
```

**Embedding cache**: Embeddings cached in ChromaDB permanently. Re-embedding only triggered on document update.

### Metadata Schema per Chunk

```json
{
  "doc_id": "uuid",
  "source_category": "packaging_standards|internal_policies|supplier_docs|sustainability_guidelines|regulations",
  "title": "Document title",
  "author": "Author or organisation",
  "date_published": "YYYY-MM-DD",
  "date_ingested": "ISO8601",
  "page_number": 12,
  "section": "Section 4.2 Material Requirements",
  "chunk_index": 3,
  "total_chunks": 45,
  "supplier_id": "uuid or null",
  "plastic_types": ["PET", "HDPE"],
  "language": "en"
}
```

---

## ChromaDB Collections

| Collection | Purpose | Estimated Documents |
|---|---|---|
| `packaging_standards` | ISO, ASTM, BS EN standards | 500–2,000 chunks |
| `internal_policies` | Company SOPs and strategies | 200–800 chunks |
| `supplier_docs` | Per-supplier packaging declarations | 1,000–10,000 chunks |
| `sustainability_guidelines` | GRI, WRAP, Ellen MacArthur | 500–2,000 chunks |
| `regulations` | UK/EU legislation | 1,000–5,000 chunks |

---

## Retrieval Pipeline

```
User Query
     │
     ▼
┌───────────────────┐
│ Query Formulation │  LLM generates semantic_query + keyword_query + filters
└────────┬──────────┘
         │
    ┌────┴──────────────────────┐
    │                           │
    ▼                           ▼
┌─────────────┐          ┌──────────────┐
│ Dense Search│          │ Sparse Search│
│ (ChromaDB)  │          │ (BM25)       │
│ top_k = 15  │          │ top_k = 15   │
└─────┬───────┘          └──────┬───────┘
      │                         │
      └──────────┬──────────────┘
                 │
                 ▼
        ┌────────────────┐
        │ Reciprocal     │
        │ Rank Fusion    │  RRF merges two ranked lists → deduplicated top 20
        └───────┬────────┘
                │
                ▼
        ┌────────────────┐
        │ Cross-Encoder  │  Reranker scores each chunk vs query → top 5
        │ Reranker       │  (cross-encoder/ms-marco-MiniLM-L-6-v2)
        └───────┬────────┘
                │
                ▼
        ┌────────────────┐
        │ Context        │  Extract most relevant sentences from top 5 chunks
        │ Compression    │  Reduces token count before LLM call
        └───────┬────────┘
                │
                ▼
        ┌────────────────┐
        │ Grounded LLM   │  LLM generates answer grounded in compressed context
        │ Response       │  Citations automatically extracted
        └────────────────┘
```

### Dense Retrieval (ChromaDB)

```python
# Cosine similarity search across relevant collections
results = chroma_collection.query(
    query_embeddings=[query_embedding],
    n_results=15,
    where={"source_category": {"$in": relevant_categories}},
    include=["documents", "metadatas", "distances"]
)
```

### Sparse Retrieval (BM25)

BM25 implemented via `rank_bm25` library on in-memory document index. Index rebuilt on ingestion.

BM25 is particularly effective for:
- Plastic type codes (PET, HDPE, PP) — exact term matching
- Regulation references (e.g., "Schedule 2 PPWR Article 7(3)")
- Supplier names and product codes

### Reciprocal Rank Fusion

```python
def reciprocal_rank_fusion(dense_results, sparse_results, k=60):
    """
    RRF merges two ranked lists. k=60 is standard default.
    score = Σ 1/(k + rank_i)
    """
    scores = defaultdict(float)
    for rank, doc_id in enumerate(dense_results):
        scores[doc_id] += 1 / (k + rank + 1)
    for rank, doc_id in enumerate(sparse_results):
        scores[doc_id] += 1 / (k + rank + 1)
    return sorted(scores, key=scores.get, reverse=True)[:20]
```

### Cross-Encoder Reranking

```python
# ai/rag/retrieval/reranker.py
from sentence_transformers import CrossEncoder

model = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")

def rerank(query: str, chunks: list[str], top_n: int = 5) -> list[tuple[float, str]]:
    pairs = [(query, chunk) for chunk in chunks]
    scores = model.predict(pairs)
    ranked = sorted(zip(scores, chunks), reverse=True)
    return ranked[:top_n]
```

**Why reranking**: Bi-encoder embeddings optimise for recall; cross-encoder optimises for precision. Combining both maximises quality.

### Context Compression

After reranking, extract only the most relevant sentences:
- Use LLM to extract 2–3 most relevant sentences per chunk
- Reduces total context from ~2,500 tokens to ~800 tokens
- Preserves citation metadata

---

## Grounded Response Generation

### Response Template

```python
GROUNDED_RESPONSE_PROMPT = """
You are an expert in plastic waste management and packaging sustainability.

Answer the following question using ONLY the provided context.
If the context does not contain enough information to answer, say so clearly.
Do NOT use your general knowledge for specific claims — cite only from context.

Question: {query}

Context:
{compressed_context}

Instructions:
1. Answer the question directly and concisely
2. For every factual claim, add a citation: [1], [2], etc.
3. At the end, list all citations with: source title, section, page
4. If the context is insufficient, state: "Based on available information: ..." and note what is missing

Answer:
"""
```

### Citation Format

```json
{
  "answer": "PET packaging generates approximately 0.4–0.8 kg of waste per 100 units [1]. For ready meal trays, rPET alternatives reduce waste by 30% while maintaining food-contact compliance [2].",
  "citations": [
    {
      "index": 1,
      "title": "UK Plastics Pact Roadmap 2025",
      "section": "Chapter 3: PET in Food Contact Applications",
      "page": 18,
      "relevance_score": 0.92,
      "source_category": "sustainability_guidelines"
    },
    {
      "index": 2,
      "title": "ISO 15270 — Plastics Recycling Guidelines",
      "section": "Section 5.4 rPET Food Grade",
      "page": 34,
      "relevance_score": 0.87,
      "source_category": "packaging_standards"
    }
  ]
}
```

---

## Retrieval Quality Evaluation

### Metrics

| Metric | Target | Measurement |
|---|---|---|
| Retrieval Precision@5 | ≥ 0.75 | Manually labelled test set |
| Retrieval Recall@10 | ≥ 0.80 | Manually labelled test set |
| Reranker MRR | ≥ 0.70 | Mean Reciprocal Rank on test queries |
| Hallucination Rate | < 5% | LLM-as-judge evaluation |
| Citation Accuracy | ≥ 90% | Cited source exists in retrieved context |

### Test Query Set

Located at: `synthetic-data/rag_test_queries.json`

50 test queries covering:
- Plastic type identification questions
- Packaging weight estimation queries
- Regulatory compliance questions
- Supplier-specific queries
- Trend and comparison questions

---

## Ingestion Trigger Points

| Trigger | Action |
|---|---|
| Admin uploads document via Settings page | Run full ingestion pipeline for new document |
| Supplier data updated | Re-embed supplier-specific chunks |
| Regulation update detected (manual flag) | Re-embed regulation collection |
| Scheduled job (weekly) | Check for document updates; re-embed changed documents |

---

## ChromaDB Configuration

```yaml
# config/ai.yaml
chroma:
  persist_directory: ./data/chroma
  collection_metadata:
    hnsw:space: cosine
    hnsw:construction_ef: 200
    hnsw:M: 16
  embedding_function: openai
  batch_size: 100
```
