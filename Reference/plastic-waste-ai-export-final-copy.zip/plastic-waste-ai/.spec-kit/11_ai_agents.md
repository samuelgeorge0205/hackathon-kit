# AI Agents Specification

## Purpose

Define all seven AI agents in the LangGraph multi-agent system. Each agent is a node in the LangGraph StateGraph. This document is the blueprint for Milestone 4 (AI Layer).

---

## Agent Orchestration Architecture

```
User Request
     │
     ▼
┌─────────────┐
│   PLANNER   │ ← Decomposes request into subtask sequence
└──────┬──────┘
       │ routes to appropriate subgraph
  ┌────┴──────────────────────────┐
  │                               │
  ▼                               ▼
Prediction Workflow          Chat Workflow
  │                               │
  ├── RETRIEVER                   ├── RETRIEVER
  ├── WASTE_PREDICTION            ├── EXPLANATION
  ├── HANDLING_COST               └── REPORT_GENERATOR
  ├── RECOMMENDATION
  └── EXPLANATION
```

---

## LangGraph State Schema

```python
# ai/state/workflow_state.py
from typing import TypedDict, Annotated
from langgraph.graph.message import add_messages

class PredictionWorkflowState(TypedDict):
    # Input
    user_query: str
    user_id: str
    prediction_type: str           # WASTE_VOLUME | HANDLING_COST
    input_params: dict

    # Intermediate
    retrieved_context: list[dict]  # RAG results
    historical_data: list[dict]    # Database query results
    messages: Annotated[list, add_messages]

    # Output
    prediction: dict | None
    handling_cost: dict | None
    recommendation: dict | None
    explanation: str | None
    confidence_score: float
    sources: list[dict]            # RAG citations

    # Metadata
    workflow_id: str
    retry_count: int
    errors: list[str]
```

---

## Agent 1 — Planner Agent

### Purpose
Decomposes a user request into an ordered sequence of agent tasks. Acts as the orchestrator node in the LangGraph graph. Does not call external tools — it routes only.

### Inputs
- `user_query`: str — natural language request
- `input_params`: dict — structured parameters (supplier_id, product_id, time_period)
- `prediction_type`: str — WASTE_VOLUME | HANDLING_COST | RECOMMENDATION | REPORT | CHAT

### Outputs
- `task_sequence`: list[str] — ordered list of agent names to invoke
- `routing_decision`: str — which subgraph to enter
- `query_intent`: str — classified intent for downstream agents

### System Prompt
```
You are a Supply Chain AI Planner. Your role is to analyse user requests and determine 
the optimal sequence of AI agents to invoke.

Available agents:
- retriever: Fetches relevant context from the knowledge base and database
- waste_prediction: Predicts plastic waste volumes
- handling_cost: Estimates waste handling costs
- recommendation: Generates packaging optimisation recommendations
- explanation: Generates human-readable explanations of predictions
- report_generator: Produces structured sustainability reports

Rules:
1. Always include retriever first for any knowledge-dependent task
2. Always include explanation last for any prediction or recommendation task
3. For handling_cost, always include waste_prediction first
4. For report_generator, include waste_prediction and handling_cost first

Return a JSON object with: task_sequence (array), routing_decision (string), query_intent (string).
```

### Failure Handling
- If intent is unclear: return `task_sequence: ["retriever", "explanation"]` with clarifying prompt
- If input_params are missing required fields: return validation error before routing

### Retry Strategy
- No LLM calls — routing logic is deterministic for known intent types
- Unknown intent falls back to RAG + explanation path

### Confidence Score
- Not applicable (orchestration node)

### Dependencies
- Input: user request only
- Output: consumed by graph router

---

## Agent 2 — Retriever Agent

### Purpose
Retrieves relevant context from ChromaDB (dense vector search) and SQLite (structured data). Performs hybrid search and reranking to return the highest-quality context for downstream agents.

### Inputs
- `user_query`: str
- `input_params`: dict (filters: supplier_id, product_id, plastic_type, date_range)
- `top_k`: int (default: 10)
- `rerank_top_n`: int (default: 5)

### Outputs
- `retrieved_context`: list[dict] — ranked document chunks with metadata
- `historical_data`: list[dict] — relevant database records
- `retrieval_score`: float — quality signal for downstream agents

### System Prompt
```
You are a Retrieval Specialist for a plastic waste management platform.

Your task is to formulate the best possible search query to retrieve:
1. Relevant packaging standards and sustainability guidelines
2. Supplier-specific packaging documentation
3. Government regulations on plastic packaging
4. Internal waste management policies

Given the user's request, generate:
- A semantic search query (for vector store retrieval)
- A keyword query (for sparse BM25 retrieval)
- A list of metadata filters to apply

Return as JSON: {semantic_query: string, keyword_query: string, filters: object}
```

### RAG Retrieval Strategy
1. **Dense Search**: ChromaDB cosine similarity, top_k=15
2. **Sparse Search**: BM25 on document text, top_k=15
3. **Fusion**: Reciprocal Rank Fusion (RRF) to merge ranked lists
4. **Reranking**: Cross-encoder reranker (sentence-transformers), top_n=5
5. **Context Compression**: extract most relevant sentences from top chunks

### Failure Handling
- If ChromaDB unavailable: fallback to structured DB data only; log degraded mode
- If no results found: return empty context with low retrieval_score (0.1)
- If reranker fails: use raw fusion ranking

### Retry Strategy
- Vector store query: 2 retries with 0.5s backoff
- Reranker: 1 retry; fallback to raw results on failure

### Confidence Score
- Retrieval score = max cross-encoder similarity of top result
- Passed to downstream agents to weight their own confidence

### Dependencies
- ChromaDB (vector store)
- SQLite repositories (historical waste data)
- Redis (retrieval cache TTL 15min for identical queries)

---

## Agent 3 — Waste Prediction Agent

### Purpose
Predicts future plastic waste volumes given historical data and input parameters. Uses LLM for pattern recognition and extrapolation, grounded by retrieved context and historical data.

### Inputs
- `historical_data`: list[dict] — waste logs, packaging data, order volumes (from Retriever)
- `retrieved_context`: list[dict] — relevant documents (from Retriever)
- `input_params`: dict — supplier_id, product_id, period, order_volume

### Outputs
- `prediction`: dict
  - `predicted_waste_kg`: float
  - `prediction_interval`: dict — `{low: float, high: float, confidence_pct: int}`
  - `plastic_type_breakdown`: dict — `{PET: float, HDPE: float, ...}`
  - `key_factors`: list[str] — top factors driving prediction
  - `confidence_score`: float (0.0–1.0)
  - `model_reasoning`: str — internal chain-of-thought

### System Prompt
```
You are an expert in plastic waste prediction for retail supply chains.

You will receive:
1. Historical plastic waste data for the requested scope
2. Relevant packaging standards and supplier documentation
3. Input parameters specifying the prediction scope

Your task is to predict the plastic waste volume (in kg) for the specified period.

Follow this reasoning process:
1. Analyse historical waste patterns and trends
2. Identify seasonal patterns if visible in data
3. Apply supplier-specific packaging weights from the data
4. Adjust for the given order volume
5. Factor in any relevant regulatory or operational context from documents

Return a JSON object matching this schema:
{
  "predicted_waste_kg": <float>,
  "prediction_interval": {"low": <float>, "high": <float>, "confidence_pct": <int>},
  "plastic_type_breakdown": {"PET": <float>, "HDPE": <float>, "PVC": <float>, "LDPE": <float>, "PP": <float>, "PS": <float>, "MIXED": <float>},
  "key_factors": [<string>, ...],
  "confidence_score": <float between 0 and 1>,
  "model_reasoning": <string>
}

If data is insufficient, set confidence_score below 0.5 and note the data gaps in key_factors.
```

### Failure Handling
- If historical data is empty: set confidence_score = 0.2; use industry average estimates with clear caveat
- If LLM returns malformed JSON: retry once; on second failure raise PredictionError
- If predicted_waste_kg is negative: reject and retry with explicit constraint in prompt

### Retry Strategy
- LLM call: up to 3 attempts, exponential backoff (1s, 2s, 4s)
- Prompt injection on retry: adds `IMPORTANT: Return valid JSON only. Predicted value must be >= 0.`

### Confidence Score Calibration
| Scenario | Score Range |
|---|---|
| ≥ 12 months historical data, complete packaging data | 0.80–0.95 |
| 6–12 months historical data, partial packaging data | 0.60–0.80 |
| < 6 months data or new product | 0.40–0.60 |
| No historical data (new supplier) | 0.20–0.40 |

### Dependencies
- Retriever Agent (historical_data, retrieved_context)
- LLM (gpt-4o, fallback gpt-4o-mini)
- Langfuse (trace every call)

---

## Agent 4 — Handling Cost Agent

### Purpose
Estimates the labor, disposal and transport costs associated with predicted or actual plastic waste volumes.

### Inputs
- `prediction`: dict — waste prediction output (from Waste Prediction Agent)
- `input_params`: dict — location, cost_rates override (optional)
- `retrieved_context`: list[dict]

### Outputs
- `handling_cost`: dict
  - `labor_cost`: float
  - `disposal_cost`: float
  - `transport_cost`: float
  - `total_cost`: float
  - `cost_per_kg`: float
  - `currency`: str
  - `cost_breakdown_pct`: dict
  - `confidence_score`: float

### System Prompt
```
You are a waste handling cost estimation expert for retail supply chains.

You will receive:
1. A plastic waste volume prediction with plastic type breakdown
2. Location context (warehouse or store)
3. Cost rate information (labor rates, disposal rates by plastic type, transport rates)
4. Relevant industry benchmarks from retrieved documents

Estimate the handling costs for this waste volume.

Use these cost components:
- Labor cost = labor_hours × labor_rate_per_hour
  (labor_hours = weight_kg × handling_minutes_per_kg / 60)
- Disposal cost = weight_kg × disposal_rate_per_kg (varies by plastic type)
- Transport cost = weight_kg × transport_rate_per_kg

Return a JSON object:
{
  "labor_cost": <float>,
  "disposal_cost": <float>,
  "transport_cost": <float>,
  "total_cost": <float>,
  "cost_per_kg": <float>,
  "currency": "GBP",
  "cost_breakdown_pct": {"labor": <pct>, "disposal": <pct>, "transport": <pct>},
  "confidence_score": <float>,
  "assumptions": [<string>]
}
```

### Failure Handling
- Missing cost rates: use default rates from configuration; flag as assumption
- LLM failure: calculate deterministically from cost rate table (no LLM needed)
- Negative cost output: reject and recalculate

### Retry Strategy
- 2 retries with 1s backoff
- Deterministic fallback: pure calculation from cost_rates config (no LLM)

### Confidence Score
- Inherits base from Waste Prediction Agent confidence
- Reduced by 10% if default cost rates used
- Reduced by 20% if no location-specific rates available

### Dependencies
- Waste Prediction Agent (prediction output)
- Configurations repository (cost rates)
- LLM (optional — deterministic fallback available)

---

## Agent 5 — Recommendation Agent

### Purpose
Generates packaging optimisation recommendations to reduce plastic waste, grounded in retrieved standards, regulations and supplier documentation.

### Inputs
- `product_id`: UUID
- `current_packaging`: dict — current packaging specification
- `waste_data`: dict — historical waste data for this product
- `retrieved_context`: list[dict] — sustainability guidelines, regulations, alternative materials

### Outputs
- `recommendations`: list[dict]
  - `recommendation_type`: str
  - `description`: str
  - `rationale`: str (XAI grounded in sources)
  - `estimated_waste_reduction_kg`: float
  - `estimated_cost_saving`: float
  - `confidence_score`: float
  - `sources`: list[dict] — RAG citations
  - `implementation_effort`: str (LOW/MEDIUM/HIGH)

### System Prompt
```
You are a Packaging Sustainability Expert specialising in plastic waste reduction for retail supply chains.

You will receive:
1. Current packaging specification for a product (material type, weight, recyclability)
2. Historical waste data showing actual waste volumes generated
3. Retrieved documents: packaging standards, sustainability guidelines, regulations, alternative materials

Your task is to generate up to 5 specific, actionable packaging optimisation recommendations.

For each recommendation:
- Be specific about WHAT to change (e.g., "Replace 45g PET tray with 28g rPET tray")
- Quantify the benefit (estimated waste reduction in kg/year and cost saving in GBP/year)
- Ground the rationale in the retrieved documents (cite which document supports this)
- Assess implementation effort (LOW = drop-in replacement, MEDIUM = supplier negotiation needed, HIGH = redesign required)
- Assign a confidence score reflecting data quality and evidence strength

Return a JSON array of recommendation objects.

IMPORTANT: Only recommend changes that are grounded in the retrieved context. Do not invent standards or regulations.
```

### Failure Handling
- Insufficient retrieved context (retrieval_score < 0.3): do not generate recommendations; return empty list with explanation
- LLM hallucination guard: verify all cited documents exist in retrieved_context before returning
- No historical waste data: reduce confidence scores by 30%; add caveat

### Retry Strategy
- 2 retries; reduce temperature on retry (0.3 → 0.1) for more conservative output
- If hallucination detected (citation not in context): regenerate with explicit instruction

### Confidence Score
- Based on: retrieval score, historical data quality, specificity of retrieved standards
- HIGH: 0.75–0.95 (grounded in specific standard with quantified data)
- MEDIUM: 0.50–0.75 (grounded in general guideline)
- LOW: < 0.50 (limited evidence, data gaps)

### Dependencies
- Retriever Agent
- Waste Prediction Agent (for waste volume context)
- LLM (gpt-4o for quality)

---

## Agent 6 — Explanation Agent

### Purpose
Generates plain-English, non-technical explanations of AI predictions and recommendations. Ensures every output is explainable and trustworthy for non-technical users.

### Inputs
- `prediction`: dict (from Waste Prediction or Handling Cost Agent)
- `recommendation`: dict (from Recommendation Agent, optional)
- `retrieved_context`: list[dict]
- `persona`: str — ANALYST/MANAGER/PROCUREMENT/STORE (adapts language complexity)

### Outputs
- `explanation`: str — natural language explanation (2–4 paragraphs)
- `key_points`: list[str] — 3–5 bullet points summarising the finding
- `confidence_explanation`: str — plain-language description of confidence level
- `data_gaps`: list[str] — any data limitations the user should know about

### System Prompt
```
You are an AI Transparency Officer. Your role is to translate AI predictions into clear, honest, and useful explanations for business users.

You will receive:
1. An AI prediction or recommendation result
2. The key factors that drove the prediction
3. Retrieved context used to ground the prediction
4. The persona of the user (adjust language complexity accordingly)

Generate an explanation that:
- States the main finding in one sentence
- Explains the top 3 factors driving the result in plain English
- Acknowledges any data limitations or uncertainties honestly
- Avoids technical jargon (no "cosine similarity", "embeddings", "temperature")
- Uses language appropriate for the stated persona
- Is accurate — do not overstate confidence

Also provide:
- 3–5 key bullet points
- One sentence explaining the confidence level in everyday terms
- Any important caveats the user should know

Persona guidance:
- ANALYST: technical detail acceptable, include methodology hints
- MANAGER: focus on business impact and strategic implications
- PROCUREMENT: focus on supplier comparisons and contract implications
- STORE: simple language, focus on what the store can do
```

### Failure Handling
- If input prediction is empty: generate explanation noting insufficient data
- LLM failure: return pre-templated explanation with key values substituted

### Retry Strategy
- 1 retry with more explicit formatting instructions
- Fallback: template-based explanation (no LLM)

### Confidence Score
- Not applicable (explanatory agent, not predictive)

### Dependencies
- Waste Prediction Agent or Handling Cost Agent output
- LLM (gpt-4o-mini acceptable for cost efficiency)

---

## Agent 7 — Report Generator Agent

### Purpose
Compiles a structured, regulatory-aligned sustainability report from data and predictions. Produces narrative text, data summaries and actionable insights in report format.

### Inputs
- `report_params`: dict — period, scope (supplier/site/org), report_type
- `prediction_data`: list[dict] — waste predictions
- `handling_cost_data`: list[dict]
- `recommendations`: list[dict]
- `historical_data`: list[dict]
- `retrieved_context`: list[dict] — regulatory context for alignment statements

### Outputs
- `report`: dict
  - `title`: str
  - `executive_summary`: str (2–3 paragraphs)
  - `sections`: list[dict] — structured sections
  - `data_tables`: list[dict] — tabular data for rendering
  - `key_metrics`: dict — headline KPIs
  - `regulatory_alignment`: str — GRI 306 / EPR alignment statement
  - `recommendations_summary`: str

### System Prompt
```
You are a Sustainability Report Writer for a major UK retailer.

You will receive structured data covering:
- Plastic waste volumes by type, supplier and location for the reporting period
- Handling cost estimates
- AI-generated recommendations
- Historical comparison data
- Relevant regulatory context (GRI 306, UK EPR requirements)

Generate a professional sustainability waste report with these sections:
1. Executive Summary (highlight total waste, YoY change, top 3 actions)
2. Plastic Waste by Type (table + narrative)
3. Waste by Supplier (top 10 contributors, waste intensity ranking)
4. Waste by Location (warehouse vs store breakdown)
5. Trend Analysis (compare to prior period)
6. Handling Cost Summary
7. Recommendations (top 5 with estimated savings)
8. Regulatory Alignment Statement (GRI 306 / UK EPR)
9. Data Quality Notes

Write in a professional, factual tone appropriate for a board report.
Use specific numbers — do not use vague language like "significant increase".
Acknowledge data limitations honestly in the Data Quality Notes section.
```

### Failure Handling
- Partial data: generate report with data quality notes indicating gaps
- LLM failure on any section: substitute with template section + raw data table
- Report exceeds token limit: split into sections, generate each independently

### Retry Strategy
- Section-by-section generation (not full report in one call)
- 2 retries per section; fallback to template

### Confidence Score
- Not applicable (report compilation)
- Data coverage percentage reported as metadata

### Dependencies
- All upstream agents
- Historical data repository
- Configuration repository (report templates)
- LLM (gpt-4o for quality)
