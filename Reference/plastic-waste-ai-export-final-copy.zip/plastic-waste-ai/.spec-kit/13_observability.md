# Observability Specification

## Purpose

Define the complete observability strategy covering structured logging, LLM tracing, metrics, audit logging and performance monitoring.

---

## Observability Stack

| Concern | Tool | Layer |
|---|---|---|
| LLM Tracing | Langfuse | AI Layer + Observability Layer |
| Structured Logging | structlog | All layers |
| Application Metrics | Prometheus-compatible counters | Observability Layer |
| Audit Trail | SQLite audit_logs table | Observability Layer |
| Performance Monitoring | Request middleware + structlog | API Layer |
| Error Reporting | structlog + Langfuse | All layers |
| Cost Monitoring | Langfuse usage metrics | AI Layer |

---

## Structured Logging

### Log Format

All log events are emitted as JSON via structlog.

```json
{
  "timestamp": "2026-07-30T14:30:00.123456Z",
  "level": "info",
  "logger": "plastic_waste_ai",
  "correlation_id": "550e8400-e29b-41d4-a716-446655440000",
  "user_id": "usr_abc123",
  "layer": "application",
  "event": "prediction_completed",
  "prediction_id": "pred_xyz789",
  "prediction_type": "WASTE_VOLUME",
  "confidence_score": 0.87,
  "duration_ms": 1240,
  "model": "gpt-4o",
  "tokens_in": 450,
  "tokens_out": 280
}
```

### Required Fields (All Events)
| Field | Type | Notes |
|---|---|---|
| timestamp | ISO8601 | UTC, microsecond precision |
| level | string | debug / info / warning / error / critical |
| correlation_id | UUID | Propagated from request; generated if absent |
| layer | string | api / application / domain / ai / data / infrastructure |
| event | string | snake_case event name |

### Optional Fields (Context-Dependent)
| Field | Notes |
|---|---|
| user_id | Present on authenticated requests |
| duration_ms | Present on timed operations |
| entity_type | Present on entity operations |
| entity_id | Present on entity operations |
| error | Present on error events |
| stack_trace | Present on exceptions |
| model | Present on LLM calls |
| tokens_in / tokens_out | Present on LLM calls |

### Log Events Catalogue

| Event | Level | Layer | Triggered By |
|---|---|---|---|
| `request_received` | info | api | Every HTTP request |
| `request_completed` | info | api | Every HTTP response |
| `authentication_success` | info | api | Successful login |
| `authentication_failure` | warning | api | Failed login attempt |
| `account_locked` | warning | api | Brute-force threshold hit |
| `upload_started` | info | application | File upload begins |
| `upload_completed` | info | application | File upload finished |
| `upload_failed` | error | application | Validation or DB error |
| `prediction_started` | info | ai | LangGraph workflow starts |
| `prediction_completed` | info | ai | Workflow completes |
| `prediction_failed` | error | ai | Workflow error |
| `llm_call_started` | info | ai | LLM API call begins |
| `llm_call_completed` | info | ai | LLM API call returns |
| `llm_call_failed` | error | ai | LLM API error |
| `rag_retrieval_started` | info | ai | ChromaDB query begins |
| `rag_retrieval_completed` | info | ai | ChromaDB query returns |
| `cache_hit` | debug | infrastructure | Redis cache hit |
| `cache_miss` | debug | infrastructure | Redis cache miss |
| `pii_detected` | warning | ai | PII guardrail triggered |
| `injection_attempt` | warning | ai | Injection guardrail triggered |
| `db_query_slow` | warning | data | Query > 100ms |

---

## Langfuse LLM Tracing

### Configuration

```python
# observability/tracing.py
from langfuse import Langfuse

langfuse = Langfuse(
    public_key=settings.LANGFUSE_PUBLIC_KEY,
    secret_key=settings.LANGFUSE_SECRET_KEY,
    host=settings.LANGFUSE_HOST,
)
```

### Trace Structure

Every user request that triggers an AI workflow creates a **Langfuse Trace**:

```
Trace: waste_prediction_request
  ├── Span: planner_agent (duration, input, output)
  ├── Span: retriever_agent
  │   ├── Event: chroma_query (collection, n_results, duration_ms)
  │   └── Event: reranker (n_input, n_output, duration_ms)
  ├── Generation: waste_prediction_llm_call
  │   ├── model: gpt-4o
  │   ├── input: {prompt, context}  ← truncated for storage
  │   ├── output: {prediction_json}
  │   ├── usage: {input_tokens, output_tokens, total_tokens}
  │   ├── latency_ms: 1240
  │   └── cost_usd: 0.0042
  ├── Generation: explanation_llm_call
  └── Span: result_persistence
```

### Required Langfuse Metadata per Generation

```python
langfuse.generation(
    trace_id=trace_id,
    name="waste_prediction_llm_call",
    model="gpt-4o",
    model_parameters={"temperature": 0.2, "max_tokens": 1024},
    input={"messages": [...]},
    output={"content": "..."},
    usage={"input": 450, "output": 280, "unit": "TOKENS"},
    metadata={
        "agent": "WastePredictionAgent",
        "prediction_id": prediction_id,
        "user_id": user_id,
        "confidence_score": 0.87,
        "correlation_id": correlation_id,
    }
)
```

### Cost Tracking

Langfuse calculates cost per generation using model pricing tables.

**Custom metrics available in Langfuse**:
- `cost_usd` per user per day
- `tokens_in` / `tokens_out` per agent per day
- `latency_p95` per agent
- `error_rate` per agent
- `cache_hit_rate` for LLM cache

---

## Application Metrics

Metrics exposed as Prometheus-compatible counters and histograms (future: Grafana integration).

### Counters

```python
# observability/metrics.py
from prometheus_client import Counter, Histogram, Gauge

# HTTP
http_requests_total = Counter("http_requests_total", "Total HTTP requests", ["method", "endpoint", "status"])
http_request_duration = Histogram("http_request_duration_seconds", "HTTP request duration", ["endpoint"])

# AI
llm_calls_total = Counter("llm_calls_total", "Total LLM API calls", ["model", "agent", "status"])
llm_tokens_total = Counter("llm_tokens_total", "Total LLM tokens", ["model", "direction"])
llm_cost_usd_total = Counter("llm_cost_usd_total", "Total LLM cost in USD", ["model"])
predictions_total = Counter("predictions_total", "Total predictions", ["type", "status"])
rag_retrievals_total = Counter("rag_retrievals_total", "Total RAG retrievals", ["collection"])

# Data
uploads_total = Counter("uploads_total", "Total file uploads", ["type", "status"])
waste_logs_ingested_total = Counter("waste_logs_ingested_total", "Total waste log records ingested")

# Cache
cache_hits_total = Counter("cache_hits_total", "Cache hits", ["cache_type"])
cache_misses_total = Counter("cache_misses_total", "Cache misses", ["cache_type"])

# Guardrails
guardrail_triggers_total = Counter("guardrail_triggers_total", "Guardrail triggers", ["guardrail_type"])
```

### Key Dashboards (Future Grafana)
- Request rate and error rate by endpoint
- AI cost per day / per user / per model
- Prediction volume and confidence distribution
- RAG retrieval quality over time
- Cache hit rates

---

## Audit Logging

All state-changing events are written to the `audit_logs` table (append-only).

### Audit Events

| Event Type | Triggered By | Before/After |
|---|---|---|
| `LOGIN` | Successful authentication | No (new session) |
| `LOGOUT` | User logout | No |
| `FAILED_LOGIN` | Failed authentication | No |
| `USER_CREATED` | Admin creates user | No / user record |
| `USER_UPDATED` | Admin updates user | user record / user record |
| `USER_DEACTIVATED` | Admin deactivates user | user record / user record |
| `ROLE_CHANGED` | Admin changes user role | {role: old} / {role: new} |
| `UPLOAD` | Data file uploaded | No / {rows_created, rows_updated} |
| `PREDICTION_CREATED` | Prediction run | No / prediction summary |
| `RECOMMENDATION_STATUS` | Status change | {status: old} / {status: new} |
| `CONFIG_CHANGED` | Configuration update | {value: old} / {value: new} |
| `REPORT_GENERATED` | Report created | No / {report_id, period} |
| `GUARDRAIL_PII` | PII detected | No (no PII stored) |
| `GUARDRAIL_INJECTION` | Injection attempt | No (no content stored) |

### Audit Writer

```python
# observability/audit.py
async def write_audit_log(
    event_type: str,
    user_id: str | None,
    entity_type: str | None = None,
    entity_id: str | None = None,
    before_json: dict | None = None,
    after_json: dict | None = None,
    ip_address: str | None = None,
    correlation_id: str | None = None,
) -> None:
    # Writes to audit_logs table — never raises exception (fire-and-forget)
    ...
```

---

## Request Middleware

FastAPI middleware applies to every request:

```python
# observability/middleware.py
class ObservabilityMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        correlation_id = request.headers.get("X-Correlation-ID", str(uuid4()))
        start_time = time.monotonic()
        
        # Set correlation_id in context var (propagates to all log calls)
        correlation_id_ctx.set(correlation_id)
        
        response = await call_next(request)
        
        duration_ms = (time.monotonic() - start_time) * 1000
        log.info("request_completed",
            method=request.method,
            path=request.url.path,
            status_code=response.status_code,
            duration_ms=round(duration_ms, 2),
        )
        
        response.headers["X-Correlation-ID"] = correlation_id
        return response
```

---

## Error Reporting

### Error Severity Levels

| Level | Examples | Action |
|---|---|---|
| **Critical** | Database down, Redis down | Immediate alert; circuit breaker open |
| **Error** | LLM API failure, upload failed | Log + Langfuse error trace; retry |
| **Warning** | Slow query, low confidence prediction, PII detected | Log; monitor for pattern |
| **Info** | Successful request, cache hit | Log only |

### Error Response Envelope
All unhandled errors are caught by FastAPI exception handlers and returned as RFC 7807 Problem Details with the `correlation_id` to enable trace lookup in Langfuse.

---

## Performance Monitoring

### Slow Query Detection

```python
# data/database.py
SLOW_QUERY_THRESHOLD_MS = 100

async def execute_query(query: str, params: dict) -> Any:
    start = time.monotonic()
    result = await session.execute(query, params)
    duration_ms = (time.monotonic() - start) * 1000
    if duration_ms > SLOW_QUERY_THRESHOLD_MS:
        log.warning("db_query_slow", query=query[:100], duration_ms=duration_ms)
    return result
```

### SLO Tracking

| SLO | Target | Measurement |
|---|---|---|
| API p95 latency | ≤ 200ms | Middleware histogram |
| AI prediction p95 | ≤ 5s | Langfuse trace duration |
| Upload 10k rows | ≤ 30s | Background task timer |
| Report generation | ≤ 120s | Background task timer |
| LLM cost per day | ≤ $50 | Langfuse cost metrics |
