# API Contract

## Purpose

Define all 16 REST API endpoints with complete request and response schemas. This is the contract between the Frontend (Layer 1) and the API Layer (Layer 2). All endpoints are versioned under `/api/v1`.

---

## Conventions

### Base URL
`https://api.plasticwaste.internal/api/v1`

### Authentication
All endpoints except `/health` and `/auth/login` require a JWT Bearer token:
```
Authorization: Bearer <access_token>
```

### Standard Response Envelope
```json
{
  "data": { ... },
  "meta": {
    "correlation_id": "uuid",
    "timestamp": "2026-07-30T14:30:00Z",
    "page": 1,
    "page_size": 20,
    "total": 150
  },
  "error": null
}
```

### Error Response (RFC 7807)
```json
{
  "type": "https://api.plasticwaste.internal/errors/validation-error",
  "title": "Validation Error",
  "status": 422,
  "detail": "weight_kg must be greater than zero",
  "correlation_id": "uuid",
  "errors": [
    { "field": "weight_kg", "message": "Must be > 0", "value": -5.2 }
  ]
}
```

### HTTP Status Codes
| Code | Meaning |
|---|---|
| 200 | Success |
| 201 | Created |
| 202 | Accepted (async task started) |
| 400 | Bad Request |
| 401 | Unauthenticated |
| 403 | Forbidden (insufficient role) |
| 404 | Not Found |
| 409 | Conflict (duplicate) |
| 422 | Validation Error |
| 429 | Rate Limited |
| 500 | Internal Server Error |
| 503 | Service Unavailable |

---

## Endpoints

---

### POST `/auth/login`

**Purpose**: Authenticate user and return JWT tokens.

**Auth Required**: No

**Role Required**: None

#### Request
```json
{
  "email": "sarah.chen@company.com",
  "password": "securepassword123"
}
```

#### Response 200
```json
{
  "data": {
    "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refresh_token": "rt_abc123...",
    "token_type": "bearer",
    "expires_in": 900,
    "user": {
      "id": "usr_abc123",
      "email": "sarah.chen@company.com",
      "full_name": "Sarah Chen",
      "role": "analyst"
    }
  }
}
```

#### Response 401
```json
{
  "title": "Authentication Failed",
  "status": 401,
  "detail": "Invalid email or password"
}
```

#### Response 429 (Brute-Force Lock)
```json
{
  "title": "Account Temporarily Locked",
  "status": 429,
  "detail": "Too many failed attempts. Try again in 15 minutes."
}
```

---

### POST `/auth/refresh`

**Purpose**: Exchange refresh token for new access token.

**Auth Required**: No (refresh token in body)

#### Request
```json
{ "refresh_token": "rt_abc123..." }
```

#### Response 200
```json
{
  "data": {
    "access_token": "eyJhbGci...",
    "refresh_token": "rt_newtoken...",
    "expires_in": 900
  }
}
```

---

### POST `/auth/logout`

**Purpose**: Invalidate refresh token.

**Auth Required**: Yes

#### Request
```json
{ "refresh_token": "rt_abc123..." }
```

#### Response 200
```json
{ "data": { "message": "Logged out successfully" } }
```

---

### POST `/upload/products`

**Purpose**: Bulk upload product catalogue records from CSV.

**Auth Required**: Yes

**Role Required**: analyst, manager, admin

#### Request
`Content-Type: multipart/form-data`

| Field | Type | Required | Notes |
|---|---|---|---|
| file | File | YES | CSV, max 10MB |
| upsert | boolean | NO | Default false. If true, update existing records |

#### Response 202 (Accepted — async processing)
```json
{
  "data": {
    "upload_id": "upl_abc123",
    "status": "PROCESSING",
    "filename": "products_july_2026.csv",
    "row_count": 342,
    "estimated_completion_seconds": 15
  }
}
```

#### Response 200 (Completed — polling result)
`GET /upload/{upload_id}/status`
```json
{
  "data": {
    "upload_id": "upl_abc123",
    "status": "COMPLETE",
    "rows_processed": 340,
    "rows_failed": 2,
    "rows_created": 305,
    "rows_updated": 35,
    "errors": [
      { "row": 45, "field": "supplier_id", "message": "Supplier not found: SUP_UNKNOWN" },
      { "row": 112, "field": "weight_kg", "message": "Must be a positive number" }
    ]
  }
}
```

---

### POST `/upload/packaging`

**Purpose**: Bulk upload packaging specification records.

**Auth Required**: Yes | **Role**: analyst, manager, admin

Same upload pattern as `/upload/products`. 

**CSV Column Requirements**: packaging_id, product_id, material_type, weight_g, recyclable, layers, description

---

### POST `/upload/waste-logs`

**Purpose**: Bulk upload waste log records.

**Auth Required**: Yes | **Role**: analyst, manager, admin

**CSV Column Requirements**: log_id (optional), source_type, source_id, product_id, packaging_id (optional), log_date, plastic_type, weight_kg, disposal_method

---

### GET `/dashboard/summary`

**Purpose**: Return KPI summary for the dashboard header cards.

**Auth Required**: Yes | **Role**: All

**Query Parameters**:
| Param | Type | Default | Notes |
|---|---|---|---|
| period | string | `last_30_days` | last_7_days / last_30_days / last_90_days / ytd / custom |
| from_date | date | — | Required if period=custom |
| to_date | date | — | Required if period=custom |

#### Response 200
```json
{
  "data": {
    "total_waste_kg": 48520.4,
    "waste_change_pct": -8.3,
    "total_handling_cost": 62450.00,
    "cost_change_pct": -5.1,
    "active_recommendations": 12,
    "recommendations_value": 185000,
    "prediction_accuracy_pct": 87.4,
    "waste_by_plastic_type": {
      "PET": 18420.5,
      "HDPE": 12340.2,
      "PVC": 2180.1,
      "LDPE": 6750.8,
      "PP": 4920.3,
      "PS": 1840.1,
      "MIXED": 2068.4
    },
    "period": "last_30_days",
    "from_date": "2026-07-01",
    "to_date": "2026-07-30"
  }
}
```

---

### GET `/dashboard/trends`

**Purpose**: Return time-series waste and cost trend data for charts.

**Auth Required**: Yes | **Role**: All

**Query Parameters**:
| Param | Type | Notes |
|---|---|---|
| granularity | string | day / week / month (default: week) |
| from_date | date | |
| to_date | date | |
| group_by | string | plastic_type / supplier / location (optional) |

#### Response 200
```json
{
  "data": {
    "series": [
      {
        "date": "2026-07-07",
        "total_waste_kg": 11240.5,
        "handling_cost": 14580.00,
        "breakdown": {
          "PET": 4200.1, "HDPE": 3100.0, "PP": 1800.4, "MIXED": 2140.0
        }
      }
    ],
    "granularity": "week"
  }
}
```

---

### POST `/predictions/waste`

**Purpose**: Trigger an AI waste volume prediction.

**Auth Required**: Yes | **Role**: analyst, manager, admin

#### Request
```json
{
  "supplier_id": "sup_abc123",
  "product_id": "prod_xyz789",
  "location_type": "WAREHOUSE",
  "location_id": "wh_001",
  "period_start": "2026-08-01",
  "period_end": "2026-08-31",
  "order_volume": 15000
}
```

_All fields optional except period_start/period_end. Wider scope = lower confidence._

#### Response 202
```json
{
  "data": {
    "prediction_id": "pred_abc123",
    "status": "PROCESSING",
    "estimated_seconds": 5
  }
}
```

---

### GET `/predictions/waste/{prediction_id}`

**Purpose**: Retrieve completed prediction result.

**Auth Required**: Yes | **Role**: All (own predictions) / admin (all)

#### Response 200
```json
{
  "data": {
    "prediction_id": "pred_abc123",
    "status": "COMPLETE",
    "prediction_type": "WASTE_VOLUME",
    "predicted_waste_kg": 4280.5,
    "prediction_interval": { "low": 3650.0, "high": 4910.0, "confidence_pct": 80 },
    "plastic_type_breakdown": {
      "PET": 1820.3, "HDPE": 1240.1, "PP": 820.4, "MIXED": 399.7
    },
    "confidence_score": 0.82,
    "explanation": "The prediction is driven primarily by high PET packaging usage from Supplier ABC (42% of estimated waste). Historical data from July–September 2025 shows consistent seasonal uplift of 15% in this period due to summer promotion volumes...",
    "key_factors": [
      "High PET packaging weight from Supplier ABC (42%)",
      "15% seasonal uplift based on prior year patterns",
      "3 new product lines added in this period"
    ],
    "sources": [
      { "title": "UK Plastics Pact 2025 Data", "section": "PET Packaging Benchmarks", "relevance": 0.88 }
    ],
    "created_at": "2026-07-30T14:30:00Z"
  }
}
```

---

### POST `/predictions/handling-cost`

**Purpose**: Estimate handling costs for a waste volume (actual or predicted).

**Auth Required**: Yes | **Role**: analyst, manager, admin

#### Request
```json
{
  "waste_volume_kg": 4280.5,
  "plastic_type_breakdown": { "PET": 1820.3, "HDPE": 1240.1 },
  "location_id": "wh_001",
  "period_start": "2026-08-01",
  "period_end": "2026-08-31"
}
```

#### Response 200
```json
{
  "data": {
    "labor_cost": 18420.00,
    "disposal_cost": 28640.00,
    "transport_cost": 6840.00,
    "total_cost": 53900.00,
    "cost_per_kg": 12.59,
    "currency": "GBP",
    "cost_breakdown_pct": { "labor": 34.2, "disposal": 53.1, "transport": 12.7 },
    "confidence_score": 0.78,
    "assumptions": ["Default labor rate £18.50/hr applied — no site-specific rate configured"]
  }
}
```

---

### GET `/recommendations`

**Purpose**: List packaging optimisation recommendations.

**Auth Required**: Yes | **Role**: All

**Query Parameters**:
| Param | Type | Notes |
|---|---|---|
| status | string | PENDING / ACCEPTED / REJECTED / DEFERRED / IMPLEMENTED |
| product_id | uuid | Filter by product |
| supplier_id | uuid | Filter by supplier |
| min_confidence | float | 0.0–1.0 |
| page | int | Default 1 |
| page_size | int | Default 20, max 100 |

#### Response 200
```json
{
  "data": [
    {
      "id": "rec_abc123",
      "product_id": "prod_xyz789",
      "product_name": "Ready Meal Chicken Tikka 400g",
      "recommendation_type": "MATERIAL_CHANGE",
      "description": "Replace 45g virgin PET tray with 28g rPET tray",
      "estimated_waste_reduction_kg": 840.0,
      "estimated_cost_saving": 12600.00,
      "confidence_score": 0.88,
      "status": "PENDING",
      "implementation_effort": "MEDIUM",
      "created_at": "2026-07-28T09:15:00Z"
    }
  ]
}
```

---

### POST `/recommendations/{recommendation_id}/feedback`

**Purpose**: Update recommendation status (accept/reject/defer).

**Auth Required**: Yes | **Role**: manager, admin

#### Request
```json
{
  "status": "ACCEPTED",
  "reason": "Supplier confirmed rPET tray available Q4 2026. Procurement raising PO."
}
```

#### Response 200
```json
{
  "data": {
    "id": "rec_abc123",
    "status": "ACCEPTED",
    "status_changed_at": "2026-07-30T14:32:00Z"
  }
}
```

---

### POST `/reports/generate`

**Purpose**: Trigger AI-powered sustainability report generation.

**Auth Required**: Yes | **Role**: analyst, manager, admin

#### Request
```json
{
  "report_type": "SUSTAINABILITY_WASTE",
  "period_start": "2026-01-01",
  "period_end": "2026-06-30",
  "scope": "ORGANISATION",
  "scope_id": null,
  "include_recommendations": true,
  "regulatory_framework": "GRI_306"
}
```

#### Response 202
```json
{
  "data": {
    "report_id": "rpt_abc123",
    "status": "GENERATING",
    "estimated_seconds": 45
  }
}
```

---

### GET `/reports/{report_id}`

**Purpose**: Retrieve completed report.

**Auth Required**: Yes | **Role**: All

#### Response 200
```json
{
  "data": {
    "report_id": "rpt_abc123",
    "status": "COMPLETE",
    "title": "Plastic Waste Sustainability Report — H1 2026",
    "period": "2026-01-01 to 2026-06-30",
    "executive_summary": "Total plastic waste for H1 2026 was 94,820 kg...",
    "sections": [ { "title": "...", "content": "..." } ],
    "key_metrics": {
      "total_waste_kg": 94820,
      "yoy_change_pct": -12.4,
      "recycling_rate_pct": 64.2
    },
    "download_url": "/reports/rpt_abc123/download/pdf",
    "created_at": "2026-07-30T14:35:00Z"
  }
}
```

---

### POST `/chat`

**Purpose**: Send a message to the AI Copilot.

**Auth Required**: Yes | **Role**: All

#### Request
```json
{
  "session_id": "sess_abc123",
  "message": "Which of our suppliers has the highest plastic waste intensity per unit shipped?",
  "context": {
    "current_page": "analytics",
    "active_filters": { "period": "last_30_days" }
  }
}
```

#### Response 200
```json
{
  "data": {
    "session_id": "sess_abc123",
    "message_id": "msg_abc456",
    "response": "Based on the last 30 days, Supplier GlobalFoods Ltd has the highest waste intensity at 4.8g per unit shipped — 62% above the supplier average of 2.96g/unit [1]. This is primarily driven by their use of non-recyclable PVC film on three chilled product lines...",
    "citations": [
      {
        "index": 1,
        "title": "Internal Waste Log Data — July 2026",
        "relevance": 0.95,
        "source_category": "internal_data"
      }
    ],
    "suggested_follow_ups": [
      "Show me the top 3 GlobalFoods products by waste intensity",
      "What packaging optimisations are recommended for GlobalFoods?"
    ],
    "confidence_score": 0.91
  }
}
```

---

### POST `/feedback`

**Purpose**: Submit user feedback on a prediction or recommendation.

**Auth Required**: Yes | **Role**: All

#### Request
```json
{
  "entity_type": "PREDICTION",
  "entity_id": "pred_abc123",
  "rating": 1,
  "comment": "Prediction was accurate — actual waste came in at 4,150kg vs 4,280kg predicted."
}
```

#### Response 201
```json
{
  "data": { "feedback_id": "fb_abc123", "recorded": true }
}
```

---

### GET `/health`

**Purpose**: System health and readiness check.

**Auth Required**: No

#### Response 200 (Healthy)
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "timestamp": "2026-07-30T14:30:00Z",
  "checks": {
    "database": "ok",
    "redis": "ok",
    "chroma": "ok",
    "llm_api": "ok"
  }
}
```

#### Response 503 (Degraded)
```json
{
  "status": "degraded",
  "checks": {
    "database": "ok",
    "redis": "ok",
    "chroma": "ok",
    "llm_api": "timeout"
  },
  "message": "LLM API unavailable. AI features are temporarily disabled."
}
```
