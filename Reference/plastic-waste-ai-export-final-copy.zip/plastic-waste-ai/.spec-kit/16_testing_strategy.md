# Testing Strategy

## Pyramid

```
          ┌──────────────┐
          │  E2E / UI    │  Playwright  (10%)
          │  Tests       │
        ┌─┴──────────────┴─┐
        │  Integration     │  HTTPX + Pytest  (30%)
        │  Tests           │
      ┌─┴──────────────────┴─┐
      │  Unit Tests          │  Pytest  (60%)
      │  Domain · App · AI   │
      └──────────────────────┘
```

---

## Unit Tests — Domain Layer (target ≥ 90% coverage)

### What to test
- Entity invariants: `WasteLog(weight_kg=-1)` raises `ValueError`
- Value object equality and validation: `PlasticType("INVALID")` raises
- Domain calculations: `waste_intensity` returns correct float
- Factory methods: `WasteLog.create(...)` sets all required fields

### Example
```python
def test_waste_log_rejects_negative_weight():
    with pytest.raises(ValueError, match="weight_kg must be greater than zero"):
        WasteLog(source_type="WAREHOUSE", weight_kg=-5.0, ...)

def test_waste_log_rejects_future_date():
    with pytest.raises(ValueError, match="cannot be in the future"):
        WasteLog(log_date=date.today() + timedelta(days=1), ...)
```

### Location: `backend/tests/unit/domain/`

---

## Unit Tests — Application Layer (target ≥ 80% coverage)

### What to test
- Use cases with mocked repositories and AI services
- DTO mapping: domain entity → DTO → back
- Error propagation: repository raises `NotFoundError` → use case raises `ResourceNotFoundError`

### Example
```python
async def test_run_prediction_saves_result():
    mock_ai = AsyncMock(return_value=WastePredictionOutput(predicted_waste_kg=4280.5, confidence_score=0.82))
    mock_prediction_repo = AsyncMock()
    use_case = RunWastePredictionUseCase(waste_repo=..., ai_service=mock_ai, prediction_repo=mock_prediction_repo)
    result = await use_case.execute(dto=valid_dto, user_id="usr_001")
    mock_prediction_repo.save.assert_called_once()
    assert result.predicted_waste_kg == 4280.5
```

### Location: `backend/tests/unit/application/`

---

## Repository Tests — Data Layer

### What to test
- CRUD operations against in-memory SQLite (`:memory:`)
- Upsert behaviour: second insert with same ID updates record
- Query filters: `get_by_product` returns only matching records
- Soft delete: deleted records not returned by default queries

### Setup
```python
@pytest.fixture
async def db():
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield AsyncSessionLocal(engine)
```

### Location: `backend/tests/integration/repositories/`

---

## API Tests — FastAPI Endpoints

### What to test
- Happy path: correct input → expected response shape and status code
- Auth: unauthenticated request → 401; wrong role → 403
- Validation: missing required field → 422 with field-level errors
- Rate limiting: 6th failed login → 429

### Tool: HTTPX `AsyncClient` with `app` dependency override

```python
async def test_create_prediction_returns_202(client, analyst_token):
    response = await client.post(
        "/api/v1/predictions/waste",
        json={"period_start": "2026-08-01", "period_end": "2026-08-31"},
        headers={"Authorization": f"Bearer {analyst_token}"}
    )
    assert response.status_code == 202
    assert "prediction_id" in response.json()["data"]

async def test_viewer_cannot_upload(client, viewer_token):
    response = await client.post("/api/v1/upload/products", headers={"Authorization": f"Bearer {viewer_token}"})
    assert response.status_code == 403
```

### Location: `backend/tests/integration/api/`

---

## Agent Tests — AI Layer

### What to test
- Agent returns output matching expected Pydantic schema
- Agent confidence score is within [0.0, 1.0]
- Retry: mock LLM to fail twice then succeed — verify 3 calls made
- Fallback: mock LLM total failure — verify deterministic fallback output returned
- Hallucination guard: citation not in context → recommendation rejected

### Tool: Mock LiteLLM client; no real API calls in unit tests

```python
async def test_waste_prediction_agent_returns_valid_schema(mock_llm):
    mock_llm.return_value = VALID_PREDICTION_JSON
    agent = WastePredictionAgent(llm=mock_llm)
    result = await agent.run(state=sample_state)
    assert 0.0 <= result.prediction.confidence_score <= 1.0
    assert result.prediction.predicted_waste_kg >= 0

async def test_agent_retries_on_json_error(mock_llm):
    mock_llm.side_effect = [INVALID_JSON, INVALID_JSON, VALID_PREDICTION_JSON]
    agent = WastePredictionAgent(llm=mock_llm)
    result = await agent.run(state=sample_state)
    assert mock_llm.call_count == 3
```

### Location: `backend/tests/unit/ai/`

---

## Prompt Tests

### What to test
- Prompt renders correctly with all variables substituted
- Required sections present in rendered prompt (e.g., "Return a JSON object")
- Prompt length within model token limits (< 4000 tokens for mini model)
- Few-shot examples correctly formatted

```python
def test_waste_prediction_prompt_contains_json_instruction():
    prompt = get_waste_prediction_prompt(historical_data=[...], query="...")
    assert "Return a JSON object" in prompt
    assert "confidence_score" in prompt

def test_prompt_within_token_limit():
    prompt = get_waste_prediction_prompt(historical_data=large_dataset, query="...")
    token_count = count_tokens(prompt)
    assert token_count < 4000
```

### Location: `backend/tests/unit/ai/prompts/`

---

## RAG Tests

### What to test
- Ingestion: document chunked into correct number of chunks
- Embedding: embedding vector has correct dimensionality (3072 for text-embedding-3-large)
- Retrieval: query returns top_k results in correct format
- Reranking: reranker output sorted by descending score
- Citation accuracy: cited source exists in retrieved_context
- Hallucination: grounded_response_prompt refuses out-of-context claims

```python
def test_chunker_produces_512_token_chunks():
    chunks = chunk_document(long_document, chunk_size=512, overlap=50)
    for chunk in chunks:
        assert count_tokens(chunk) <= 512

def test_retriever_returns_top_k_results(mock_chroma):
    results = retriever.retrieve("PET packaging weight standards", top_k=5)
    assert len(results) == 5
    assert all("text" in r and "metadata" in r for r in results)
```

### Location: `backend/tests/unit/ai/rag/`

---

## Playwright E2E Tests

### Scope
- Critical user journeys only (not every UI element)
- Run against local dev server with seeded test database

### Test Cases

| ID | Journey | Steps | Assertion |
|---|---|---|---|
| E2E-001 | Login and view dashboard | Login → navigate to `/` | Dashboard KPI cards visible |
| E2E-002 | Upload waste log CSV | Login → Upload → drop CSV → submit | "2 records saved" message |
| E2E-003 | Run waste prediction | Login → Predictions → fill form → Run | Result card with confidence badge |
| E2E-004 | AI Copilot chat | Login → Copilot → type question → send | Response with citation |
| E2E-005 | Generate report | Login → Reports → configure → Generate | Report preview renders |
| E2E-006 | Viewer cannot access upload | Login as viewer → navigate to `/upload` | Redirected with 403 message |
| E2E-007 | Mobile viewport | Resize to 768px → navigate to dashboard | No horizontal scroll; KPIs visible |

### Setup
```typescript
// playwright.config.ts
export default defineConfig({
  testDir: './tests/e2e',
  use: { baseURL: 'http://localhost:3000', viewport: { width: 1280, height: 720 } },
  projects: [
    { name: 'Desktop', use: { ...devices['Desktop Chrome'] } },
    { name: 'Tablet', use: { viewport: { width: 768, height: 1024 } } },
  ]
});
```

### Location: `frontend/tests/e2e/`

---

## Synthetic Data Validation Tests

### What to test
- All JSON files validate against their JSON Schema
- Referential integrity: every `supplier_id` in `products.json` exists in `suppliers.json`
- Value ranges: all `weight_kg` > 0; all `confidence_score` in [0,1]
- Completeness: required fields non-null in ≥ 95% of records

```python
def test_products_validate_against_schema():
    with open("synthetic-data/products.json") as f:
        data = json.load(f)
    with open("schemas/domain/product.json") as f:
        schema = json.load(f)
    for record in data:
        jsonschema.validate(record, schema)

def test_waste_logs_reference_valid_products():
    product_ids = {p["id"] for p in load_json("synthetic-data/products.json")}
    waste_logs = load_json("synthetic-data/waste_logs.json")
    for log in waste_logs:
        if log.get("product_id"):
            assert log["product_id"] in product_ids
```

### Location: `backend/tests/synthetic/`

---

## CI Pipeline Gates

```yaml
# .github/workflows/ci.yaml
test:
  - pytest --cov=backend --cov-report=xml --cov-fail-under=75
  - mypy backend/domain backend/application --strict
  - ruff check backend/
  - playwright test --project=Desktop
  - python -m pytest backend/tests/synthetic/
```

### Coverage Thresholds
| Layer | Threshold |
|---|---|
| Domain | 90% |
| Application | 80% |
| AI | 70% |
| API | 75% |
| Overall | 75% |
