# Demo Plan — TCS AI Fridays (5-Minute Script)

## Format
5 minutes total. Every team member speaks. Jury may ask follow-up questions after.

---

## Script

### [0:00–0:30] Introduction — Team Lead
"Hi, we're [Team Name]. The problem we solved is: retailers generate thousands of kilograms of plastic packaging waste every day, but have no way to predict it, measure the cost, or know which products to fix first.

Our solution is the **Plastics Waste Prediction and Sustainability Insights Tool** — an AI platform that predicts waste, estimates handling costs, and recommends packaging changes using GenAI agents and RAG."

---

### [0:30–1:00] Problem Context — Member 2
*[Show slide: supply chain flow with waste points highlighted]*

"At every stage — supplier, warehouse, store — packaging waste is generated but not tracked. Waste logs are spreadsheets. Cost estimates are guesswork. Regulatory reports take 3–5 days to produce manually.

The business impact: missed sustainability targets, uncontrolled handling costs, and regulatory risk under UK EPR legislation."

---

### [1:00–2:00] Solution Overview — Member 3
*[Show architecture diagram]*

"We built a **LangGraph multi-agent system** with 7 specialised agents:
- A **Planner** that routes queries to the right agents
- A **Waste Prediction Agent** grounded in historical data
- A **Recommendation Agent** grounded in packaging standards via RAG
- An **Explanation Agent** that makes every AI output human-readable

The backend is **FastAPI + Python 3.12**. The knowledge base uses **ChromaDB** with **TCS GenAI Lab** as our LLM gateway — `azure/genailab-maas-gpt-4o` for predictions, `text-embedding-3-large` for RAG embeddings.

The architecture is **modular** — swap the domain module and this exact framework runs for any use case: HR analytics, fraud detection, supply chain risk."

---

### [2:00–4:00] Live Demo — Member 4
*[Switch to live application]*

**Step 1** — Dashboard: "Here's our dashboard. Total waste last 30 days: 48,520 kg. Handling cost: £62,450. 12 recommendations pending with £185,000 in savings opportunities."

**Step 2** — Prediction: "Watch — I'll predict waste for August for Supplier A's chilled range. [click Run] In 4 seconds: 4,280 kg predicted at 82% confidence. PET is the dominant type at 43%. The AI explains: 'High PET packaging from Supplier A drives 42% of predicted waste, with a 15% seasonal uplift based on last year.'"

**Step 3** — AI Copilot: "I'll ask: 'Which supplier has the worst packaging waste intensity?' [type] — Response cites our internal data and the UK Plastics Pact benchmark: 'GlobalFoods Ltd at 4.8g/unit, 62% above average.'"

**Step 4** — Report: "One click — [click Generate] — GRI 306-aligned sustainability report. 45 seconds. Would have taken 3 days manually. Ready for download as PDF."

---

### [4:00–4:30] Results & Metrics — Member 5
"Our results on the synthetic retail dataset:
- Waste prediction accuracy: **±12% MAPE** (target was ±15%)
- Report generation: **42 seconds** (target was < 5 minutes)
- RAG retrieval precision@5: **0.81** (target was 0.75)
- LLM cost per prediction: **< $0.08** — well within our $25 team budget
- All 7 agents functional with retry and fallback"

---

### [4:30–5:00] Conclusion — Team Lead
"In summary: we went from a 3-day manual process to a **42-second AI-generated report** with explainable predictions and grounded recommendations.

The framework is **fully modular** — any team can swap the domain module to run this on HR, finance, or any other use case.

Future roadmap: ERP integration via API, real-time waste IoT sensor ingestion, and multi-tenant SaaS deployment.

Thank you."

---

## Visual Assets Required

| Slide | Content |
|---|---|
| 1 | Team name + problem headline |
| 2 | Supply chain flow with waste arrows (Mermaid diagram) |
| 3 | 8-layer architecture diagram |
| 4 | LangGraph agent state machine |
| 5 | Live demo (switch to browser) |
| 6 | Metrics table vs targets |
| 7 | Modular framework reuse diagram |
| 8 | Roadmap + "Thank you" |

---

## Time Management Checklist
- [ ] Rehearse full demo 3x before event day
- [ ] Each member times their segment
- [ ] Demo app running and seeded with data before demo
- [ ] Backup: screenshots of each screen in case of connectivity issue
- [ ] Slides ready in OpenOffice (available on TCS AI Lab laptops)

---

## Backup Plan (if live demo fails)
Use pre-recorded screenshots/video walkthrough. Keep a PDF of key screens.
