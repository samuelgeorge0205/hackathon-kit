# Judge Expectations — TCS AI Fridays Season 2

## Scoring Dimensions (from Handbook Section 8.8)

| Dimension | Weight | What Judges Look For |
|---|---|---|
| Participation & Engagement | 20% | All team members spoke; active collaboration visible |
| Completion of Working Application | 30% | App runs end-to-end without critical errors during demo |
| Creativity & Innovation | 25% | Novel approach; effective use of GenAI beyond simple Q&A |
| Hands-on Activity Completion | 15% | All required components built (LLM, RAG, data pipeline) |
| Budget Efficiency | 10% | LLM cost < $25; efficient use of model tiers |

---

## Evidence Checklist

For each scoring dimension, prepare tangible evidence:

### Participation (20%)
- [ ] All 5 team members have a speaking role in the demo
- [ ] Each member can answer questions about their assigned component
- [ ] No single member dominates the presentation

### Working Application (30%)
- [ ] App starts without errors: `uvicorn main:app` and `npm run dev`
- [ ] All 7 AI agents execute without exception in demo flow
- [ ] Prediction returns result in < 5 seconds during live demo
- [ ] Report generates in < 60 seconds during live demo
- [ ] Gogs repository accessible with README and all source files
- [ ] No hardcoded API keys in source code

### Creativity & Innovation (25%)
- [ ] Multi-agent LangGraph workflow demonstrated (not single LLM call)
- [ ] RAG pipeline with citations demonstrated in Copilot
- [ ] XAI explanation shown alongside prediction (non-technical language)
- [ ] Modular framework described — reuse potential for other domains
- [ ] At least 2 models used (e.g., gpt-4o for prediction + gpt-4o-mini for explanation)

### Hands-on Activity (15%)
- [ ] SQLite database with all 14 tables seeded with synthetic data
- [ ] ChromaDB vector store indexed with at least 1 knowledge document
- [ ] LiteLLM gateway (`https://genailab.tcs.in`) used for all LLM calls
- [ ] Synthetic data generated and validated against schemas
- [ ] At least 1 Playwright E2E test passing

### Budget Efficiency (10%)
- [ ] Track total LLM spend via Langfuse dashboard
- [ ] Mini model (`gpt-4o-mini`) used for Explanation Agent (lower cost)
- [ ] Redis LLM response cache implemented (reduces repeated calls)
- [ ] Total spend < $20 (leaves buffer; $25 limit per team)

---

## Judge Questions to Prepare For

| Question | Prepared Answer Location |
|---|---|
| "How does your AI make predictions?" | [.spec-kit/11_ai_agents.md — Waste Prediction Agent] |
| "How do you prevent hallucinations?" | [.spec-kit/12_guardrails.md] |
| "How does RAG work in your system?" | [.spec-kit/10_rag_design.md] |
| "How would this scale to production?" | [.spec-kit/07_architecture.md — NFR section] |
| "What's the most creative part of your solution?" | Modular reusable framework + XAI explanation agent |
| "How much did the AI cost to run?" | Langfuse dashboard — show token cost per call |
| "Can this work for other use cases?" | [.spec-kit/ARCHITECT.md — modularity section] |
| "How is this different from a simple chatbot?" | LangGraph multi-agent state machine + RAG + structured prediction |

---

## Demo Quality Bar

| Aspect | Minimum | Target |
|---|---|---|
| Demo runs without crash | Required | Required |
| Prediction returns in demo | Required | < 5 seconds |
| Report generates in demo | Required | < 60 seconds |
| Citations shown in Copilot | Required | ≥ 2 sources cited |
| Confidence score visible | Required | Colour-coded badge |
| All team members speak | Required | Each covers their component |
| Architecture diagram shown | Recommended | Mermaid diagram rendered |
| Metrics vs targets presented | Recommended | Table with actual vs target |
