# Build Tasks — Milestone Breakdown

## M1: Folder Structure + Environments

```
Tasks:
T1.1  Create backend/ folder structure (all subdirs)
T1.2  Create frontend/ folder structure
T1.3  python -m venv backend/.venv
T1.4  Create backend/requirements.txt (see config/app.yaml for versions)
T1.5  pip install -r requirements.txt
T1.6  Create frontend/package.json with React+TS+Vite+Tailwind
T1.7  npm install in frontend/
T1.8  Create .env.example with all required variables
T1.9  Verify: python -c "import fastapi, langgraph, chromadb, langfuse" exits 0
T1.10 Verify: npm run build exits 0
```

## M2: Domain + Application

```
Tasks:
T2.1  Implement all 13 domain entities (dataclasses with validation)
T2.2  Implement all 6 value objects (PlasticType, Money, ConfidenceScore, etc.)
T2.3  Implement all 5+ repository interfaces (ABCs)
T2.4  Write unit tests for all entities (target: 90% coverage)
T2.5  Implement all use case classes with DI constructor
T2.6  Implement all DTOs (Pydantic v2)
T2.7  Write unit tests for all use cases with mocks
T2.8  Verify: pytest tests/unit/ exits 0
```

## M3: Database + Repositories

```
Tasks:
T3.1  Create SQLAlchemy ORM models for all 14 tables
T3.2  Create Alembic initial migration
T3.3  Run migration: alembic upgrade head
T3.4  Implement SQLite repositories for all interfaces
T3.5  Implement entity-to-model mappers
T3.6  Create seed_db.py script loading synthetic-data/*.json
T3.7  Run seed: python seed_db.py
T3.8  Implement Redis client + LLM/session/workflow cache
T3.9  Implement ChromaDB document repository
T3.10 Write repository integration tests against :memory: SQLite
T3.11 Verify: pytest tests/integration/repositories/ exits 0
```

## M4: AI Layer

```
Tasks:
T4.1  Create ai/state/workflow_state.py (TypedDict schemas)
T4.2  Implement all 7 agent classes (LangGraph nodes)
T4.3  Implement PredictionWorkflow StateGraph (Planner→Retriever→WastePrediction→HandlingCost→Explanation)
T4.4  Implement ChatWorkflow StateGraph (Retriever→Explanation)
T4.5  Implement RAG ingestion pipeline (loader→chunker→embedder→ChromaDB write)
T4.6  Implement dense retriever (ChromaDB)
T4.7  Implement BM25 sparse retriever
T4.8  Implement RRF fusion + cross-encoder reranker
T4.9  Load prompt files from prompts/ directory into prompt_registry.py
T4.10 Configure Langfuse tracing (all LLM calls)
T4.11 Index sample knowledge documents into ChromaDB
T4.12 Write agent unit tests with mock LLM
T4.13 Verify: all 7 agents return valid structured output against synthetic data
```

## M5: API Layer

```
Tasks:
T5.1  Configure FastAPI app (CORS, middleware, exception handlers)
T5.2  Implement JWT auth (login, refresh, logout endpoints)
T5.3  Implement require_role dependency
T5.4  Implement all DI provider functions (get_*_service)
T5.5  Implement upload routers (products, packaging, waste-logs)
T5.6  Implement predictions routers (waste, handling-cost)
T5.7  Implement recommendations router
T5.8  Implement dashboard router (summary, trends)
T5.9  Implement reports router
T5.10 Implement chat router
T5.11 Implement feedback router
T5.12 Implement health endpoint
T5.13 Wire observability middleware (correlation ID, request logging)
T5.14 Write API tests for all 16 endpoints
T5.15 Verify: pytest tests/integration/api/ exits 0; Swagger UI accessible at /docs
```

## M6: Frontend

```
Tasks:
T6.1  Set up React Router with 7 routes
T6.2  Set up Axios API client with base URL and auth interceptor
T6.3  Set up Zustand auth store (token + user)
T6.4  Implement auth flow (login page, token storage, auto-refresh)
T6.5  Implement Dashboard page (KPI cards + Recharts line + donut)
T6.6  Implement Upload page (drag-drop + field mapping + progress)
T6.7  Implement Predictions page (form + result card + XAI panel + history table)
T6.8  Implement Analytics page (trend chart + supplier table + breakdown chart)
T6.9  Implement Copilot page (chat thread + citation panel + suggested follow-ups)
T6.10 Implement Reports page (builder form + preview + PDF download)
T6.11 Implement Settings page (users + config + knowledge base + audit log tabs)
T6.12 Implement loading states and error states on all pages
T6.13 Verify 768px responsive layout (no horizontal scroll)
T6.14 Write Playwright E2E tests for 7 critical journeys
T6.15 Verify: npm run test:e2e exits 0
```

## M7: Testing

```
Tasks:
T7.1  Run pytest --cov — fix until overall ≥ 75%
T7.2  Run mypy --strict on domain/ and application/
T7.3  Run ruff check — fix all errors
T7.4  Run synthetic data validation tests
T7.5  Run full Playwright suite
T7.6  Verify Langfuse traces appear for all LLM calls
T7.7  Check total LLM spend in Langfuse < $20
```

## M8: Documentation + Demo Prep

```
Tasks:
T8.1  Update README with accurate setup instructions (Python 3.12.8)
T8.2  Create .env.example with all variables and placeholder values
T8.3  Write demo-guide.md (step-by-step demo instructions)
T8.4  Seed production-realistic demo data
T8.5  Rehearse 5-minute demo against script in 17_demo_plan.md
T8.6  Prepare 8 presentation slides
T8.7  Push all code to Gogs repository
T8.8  Final check: zero secrets in Gogs repo
```
