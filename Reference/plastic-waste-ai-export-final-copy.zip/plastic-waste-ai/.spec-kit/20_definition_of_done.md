# Definition of Done

## Per Layer

### Domain Layer
- [ ] All 13 entities implemented as Python dataclasses with invariant validation
- [ ] All value objects implemented with equality by value
- [ ] All repository interfaces defined as ABCs
- [ ] Domain layer has zero third-party imports (except Pydantic)
- [ ] Unit test coverage ≥ 90%

### Application Layer
- [ ] All use cases implemented with constructor DI
- [ ] All DTOs defined with Pydantic v2
- [ ] No direct DB or HTTP imports
- [ ] Unit test coverage ≥ 80%

### AI Layer
- [ ] All 7 agents implemented as LangGraph nodes
- [ ] Prediction and Chat workflows defined as StateGraphs
- [ ] RAG pipeline: ingestion + retrieval + reranking functional
- [ ] All agents use `azure/genailab-maas-gpt-4o` via LiteLLM gateway
- [ ] All LLM calls emit Langfuse traces
- [ ] Retry logic (3 attempts, exponential backoff) implemented
- [ ] Deterministic fallback for cost estimation agent

### Data Layer
- [ ] All 14 SQLite tables created via Alembic migration
- [ ] All repository interfaces implemented
- [ ] Synthetic data seeded via `seed_db.py` script
- [ ] ChromaDB initialised with ≥ 1 knowledge document indexed

### API Layer
- [ ] All 16 endpoints implemented and return correct status codes
- [ ] JWT auth enforced on all protected endpoints
- [ ] RBAC enforced (4 roles)
- [ ] OpenAPI spec auto-generated and accurate
- [ ] API tests passing for all endpoints

### Frontend
- [ ] All 7 pages implemented and routing functional
- [ ] All API integrations wired
- [ ] Loading and error states implemented on all pages
- [ ] Mobile-responsive at 768px viewport
- [ ] Playwright E2E tests passing for 7 critical journeys

### Infrastructure
- [ ] Redis cache operational for LLM responses and sessions
- [ ] `.env.example` present with all required variables
- [ ] No secrets in source code

### Observability
- [ ] Structured JSON logging on all API requests
- [ ] Correlation ID propagated through all layers
- [ ] Langfuse dashboard showing traces from demo run

---

## Per Milestone

| Milestone | Done When |
|---|---|
| M1 | Folder structure matches spec; venv created; dependencies install clean |
| M2 | Domain + Application layers pass all unit tests |
| M3 | `pytest tests/integration/repositories` passes; DB seeded |
| M4 | All 7 agents return valid structured output; RAG retrieves from ChromaDB |
| M5 | All 16 API endpoints return correct status codes; Swagger UI accessible |
| M6 | All 7 pages render; E2E happy paths pass |
| M7 | `pytest --cov` reports ≥ 75% overall; Playwright tests all pass |
| M8 | README accurate; `docker-compose up` (or manual start) works end-to-end |

---

## Overall Project Done When
- [ ] Demo runs end-to-end in < 5 minutes
- [ ] Prediction accuracy ≤ ±15% MAPE on test data
- [ ] Report generated in < 60 seconds
- [ ] All 7 agents functional with retry
- [ ] LLM spend tracked in Langfuse < $25 total
- [ ] All source code in Gogs repository
- [ ] README includes setup instructions for Python 3.12.8
- [ ] Zero hardcoded secrets
- [ ] All team members can explain their component
