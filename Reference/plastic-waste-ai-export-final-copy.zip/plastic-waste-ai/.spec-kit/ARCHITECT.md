# ARCHITECT.md — Architecture Decision Records

## ADR-001: TCS GenAI Lab LiteLLM Gateway

**Status**: Accepted
**Date**: 2026-07-30

**Context**: TCS AI Fridays requires use of infrastructure provided at the hackathon. External APIs and Model-as-a-Service are not permitted for the primary solution (Handbook §13.12.19).

**Decision**: All LLM calls route through `https://genailab.tcs.in` using the LiteLLM gateway. Models used:
- Primary: `azure/genailab-maas-gpt-4o`
- Mini/cost-efficient: `azure/genailab-maas-gpt-4o-mini`
- Embeddings: `azure/genailab-maas-text-embedding-3-large`
- Reasoning (complex analysis): `azure_ai/genailab-maas-DeepSeek-V3-0324`

**Consequences**: SSL verification disabled for internal gateway (`verify=False` on httpx client). This is acceptable in the lab environment. Production deployment would use proper certificates.

---

## ADR-002: LangGraph over Simple LangChain LCEL

**Status**: Accepted

**Context**: The AI system requires multiple agents with conditional routing, retry logic, and state persistence. Simple chains cannot represent this.

**Decision**: Use LangGraph `StateGraph` for all multi-step AI workflows.

**Consequences**: More complex setup than simple chains. Benefit: explicit state management, conditional edges, human-in-the-loop support, better observability. Each agent is a node — easy to add/remove agents without changing other nodes.

---

## ADR-003: SQLite for Demo, PostgreSQL Migration Path

**Status**: Accepted

**Context**: SQLite is zero-config for demo/hackathon. Production would need PostgreSQL.

**Decision**: Use SQLAlchemy with `aiosqlite` driver. `DATABASE_URL` environment variable controls the DB. Switching to PostgreSQL requires only `DATABASE_URL=postgresql+asyncpg://...` — no code changes.

**Consequences**: SQLite has concurrency limitations. Acceptable for demo with < 10 concurrent users.

---

## ADR-004: Modular Domain-Plugin Architecture

**Status**: Accepted

**Context**: TCS AI Fridays runs multiple rounds with different use cases. The same infrastructure should be reusable across hackathon iterations.

**Decision**: Isolate all domain-specific logic in:
- `domain/` — entities specific to current use case
- `prompts/` — prompt files (text, not code)
- `config/app.yaml` — domain parameters
- `synthetic-data/` — domain datasets

The remaining layers (API, Application, AI pipeline, Data, Infrastructure, Observability) are domain-agnostic and can be reused verbatim.

**Consequences**: Slightly more abstraction overhead. Benefit: any team can fork this repo and swap the domain module in < 1 day.

---

## ADR-005: Hybrid RAG (Dense + BM25 + Reranker)

**Status**: Accepted

**Context**: Domain-specific terms (PET, HDPE, ISO 18603, UK EPR) are exact-match terms that bi-encoder embeddings miss. Pure vector search has poor recall for such terms.

**Decision**: Hybrid retrieval: ChromaDB dense search + BM25 sparse search, fused with RRF, reranked with cross-encoder.

**Consequences**: Higher retrieval quality at the cost of added complexity. BM25 index must be maintained in memory. Cross-encoder adds ~200ms latency per query — acceptable for chat use case.

---

## ADR-006: $25 Budget Management

**Status**: Accepted

**Context**: Each team has a $25 budget (Handbook §13.9). Budget efficiency is an evaluation criterion.

**Decision**:
- Use `gpt-4o` only for prediction and recommendation (high-stakes)
- Use `gpt-4o-mini` for explanation and report sections (lower-stakes)
- Cache LLM responses in Redis (1h TTL) — cache hit = $0 cost
- Use local `gte-large` SLM for embeddings during development
- Track spend via Langfuse; alert when cumulative spend > $20

**Consequences**: Slightly lower output quality on mini model sections. Acceptable trade-off.

---

## Architecture Weaknesses Identified and Mitigated

| Weakness | Mitigation |
|---|---|
| SQLite write contention | Sequential writes only; async session per request |
| LLM latency in sync requests | All LLM endpoints are async with 202 Accepted pattern |
| ChromaDB single-node | Acceptable for demo; persistent directory backed up |
| No message queue for async jobs | Simple asyncio background tasks sufficient for demo scale |
| Single Redis instance | No persistence needed for demo; restart-tolerant |
| SSL disabled for internal gateway | Acceptable in lab; document clearly in README |
