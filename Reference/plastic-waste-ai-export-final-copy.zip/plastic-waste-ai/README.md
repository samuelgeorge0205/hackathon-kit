# Plastics Waste Prediction and Sustainability Insights Tool

> **Enterprise AI Platform** — Predicts plastics waste, handling effort, handling costs and sustainability insights across the retail supply chain.

---

## Overview

Retail supply chains generate significant volumes of plastic packaging waste across suppliers, manufacturing, warehouses and stores. This platform provides:

- **Waste Prediction** — AI-powered forecasting of plastic waste by product, supplier, location and period
- **Handling Cost Estimation** — Labor, disposal and transport cost modelling
- **Sustainability Insights** — Trend analysis, benchmarking and reduction opportunity identification
- **Packaging Recommendations** — AI-generated suggestions for packaging optimization
- **AI Copilot** — Natural language Q&A grounded in organizational data and regulations

---

## Status

```
Phase      Status
──────────────────────────────────────────────────────────
Architecture     ✅ Complete
Specifications   ✅ Complete
Schemas          ✅ Complete
Diagrams         ✅ Complete
Prompts          ✅ Complete
Synthetic Data   ✅ Complete
Implementation   🔲 Awaiting M1 kickoff
```

---

## Repository Structure

```
plastic-waste-ai/
├── README.md                        ← This file
│
├── .spec-kit/                       ← Complete specification library (22 files)
│   ├── 00_project.yaml              ← Project metadata and tech stack
│   ├── 01_problem.md                ← Problem statement and business context
│   ├── 02_business_requirements.md  ← BR-001..BR-020
│   ├── 03_functional_requirements.md← FR-001..FR-030
│   ├── 04_non_functional_requirements.md ← NFR: performance, security, scale
│   ├── 05_personas.md               ← 5 user personas
│   ├── 06_user_journeys.md          ← 5 end-to-end journey flows
│   ├── 07_architecture.md           ← 8-layer architecture (master spec)
│   ├── 08_data_architecture.md      ← Data flows and lineage
│   ├── 09_database_design.md        ← 14 tables, all columns, indexes, relationships
│   ├── 10_rag_design.md             ← RAG pipeline architecture
│   ├── 11_ai_agents.md              ← 7 AI agents with prompts and contracts
│   ├── 12_guardrails.md             ← Responsible AI and safety controls
│   ├── 13_observability.md          ← Langfuse, logging, metrics, audit
│   ├── 14_api_contract.md           ← 16 REST endpoints with full schemas
│   ├── 15_frontend_spec.md          ← 7 pages with widget and API specs
│   ├── 16_testing_strategy.md       ← Full testing pyramid specification
│   ├── 17_demo_plan.md              ← 5-minute demo script
│   ├── 18_judge_expectations.md     ← AI Friday scoring guide
│   ├── 19_build_tasks.md            ← Granular tasks per milestone
│   ├── 20_definition_of_done.md     ← DoD per layer and milestone
│   ├── copilot.instructions.md      ← GitHub Copilot code generation rules
│   └── ARCHITECT.md                 ← ADRs and architectural decisions
│
├── docs/                            ← Reference guides
│   ├── IMPLEMENTATION_PLAN.md       ← Phased milestone guide for coding agents
│   ├── LOCAL_SETUP.md               ← Local machine setup guide
│   ├── architecture-guide.md
│   ├── api-guide.md
│   ├── database-guide.md
│   ├── ai-guide.md
│   ├── deployment-guide.md
│   ├── demo-guide.md
│   └── troubleshooting-guide.md
│
├── config/                          ← Configuration specifications
│   ├── app.yaml
│   ├── ai.yaml
│   ├── database.yaml
│   ├── redis.yaml
│   ├── observability.yaml
│   └── security.yaml
│
├── docs/templates/                  ← Reusable code templates for agents
│   ├── agent-template.md
│   ├── api-endpoint-template.md
│   ├── repository-template.md
│   └── test-template.md
│
├── docs/diagrams/                   ← Mermaid architecture diagrams
│   ├── system-architecture.mermaid
│   ├── data-flow.mermaid
│   ├── ai-workflow.mermaid
│   ├── rag-pipeline.mermaid
│   ├── database-erd.mermaid
│   └── deployment-topology.mermaid
│
├── prompts/                         ← AI agent prompt specifications
│   ├── planner-agent.md
│   ├── retriever-agent.md
│   ├── waste-prediction-agent.md
│   ├── handling-cost-agent.md
│   ├── recommendation-agent.md
│   ├── explanation-agent.md
│   └── report-generator-agent.md
│
├── input-data/                      ← Runtime inputs for DB seed and RAG
│   ├── structured/                  ← Synthetic structured JSON datasets
│   │   ├── suppliers.json
│   │   ├── products.json
│   │   ├── packaging.json
│   │   ├── warehouses.json
│   │   ├── stores.json
│   │   ├── waste_logs.json
│   │   └── README.md
│   └── knowledge-base/              ← RAG source markdown documents
│       ├── gri-306-waste-reporting-standard.md
│       ├── plastic-polymer-recyclability-guide.md
│       └── ...
│
├── schemas/                         ← JSON Schema definitions
│   ├── api/
│   │   ├── upload-request.json
│   │   ├── prediction-request.json
│   │   └── recommendation-request.json
│   ├── domain/
│   │   ├── supplier.json
│   │   ├── product.json
│   │   ├── packaging.json
│   │   └── waste-log.json
│   └── ai/
│       ├── agent-input.json
│       └── agent-output.json
│
```

---

## Technology Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, TypeScript 5, Vite, Tailwind CSS |
| Backend | FastAPI, Python 3.12, Pydantic v2 |
| AI Orchestration | LangGraph, LangChain |
| RAG / Vector Store | ChromaDB, text-embedding-3-small |
| Database | SQLite (dev/demo), PostgreSQL migration path |
| Cache | Redis 7 |
| Observability | Langfuse, structlog |
| Testing | Pytest, Playwright, HTTPX |
| Auth | JWT (python-jose), bcrypt |

---

## Architecture Principle

```
Frontend → API → Application → Domain → AI → Data → Infrastructure → Observability
```

Dependencies flow **inward only**. The Domain Layer has **zero external dependencies**.

See [.spec-kit/07_architecture.md](.spec-kit/07_architecture.md) for the full specification.

---

## Enterprise Framework Layout

The repository now includes a canonical enterprise architecture layout for reuse across future AI products while preserving current runtime behavior:

- `docs/architecture/` — Architecture, coding standards, and contributor guidance
- `docs/decision-records/` — ADRs for key technical decisions
- `docs/contracts/` — API, database, event, agent, and prompt contract surfaces
- `docs/deployment/` — Deployment and operational runbooks
- `docs/scripts/` — Automation scripts namespace
- `docs/datasets/` — Dataset catalog and governance namespace

Backend domain-aligned namespaces are also present for enterprise clarity:

- `backend/ai/coordinator`
- `backend/ai/retrieval`
- `backend/ai/memory`
- `backend/ai/guardrails`
- `backend/ai/evaluation`
- `backend/ai/prompt_library`
- `backend/shared/{utils,constants,exceptions,middleware}`
- `backend/tests/{api,ai,performance,security}`

Transitional compatibility note:

- Existing runtime paths (including `input-data/structured/`, `input-data/knowledge-base/`, `schemas/`, and current backend module imports) are intentionally preserved to avoid functional regressions during incremental refactoring.

---

## Quick Start (Post-Implementation)

```bash
# Clone and enter
git clone <repo> plastic-waste-ai
cd plastic-waste-ai

# Backend
cd backend
uv sync
uv run uvicorn main:app --reload

# Frontend
cd frontend
npm install && npm run dev
```

---

## Milestones

| # | Milestone | Est. Effort |
|---|---|---|
| M1 | Folder Structure + Environments | 0.5 day |
| M2 | Backend Domain + Application Layers | 2 days |
| M3 | Database + Repositories | 1.5 days |
| M4 | AI Layer (LangGraph + RAG) | 3 days |
| M5 | API Layer (FastAPI) | 2 days |
| M6 | Frontend (React + TypeScript) | 3 days |
| M7 | Testing | 2 days |
| M8 | Documentation + Deployment | 1 day |

See [docs/IMPLEMENTATION_PLAN.md](docs/IMPLEMENTATION_PLAN.md) for full details.

---

## Key Documents

| Need | Go to |
|---|---|
| Understand the problem | [.spec-kit/01_problem.md](.spec-kit/01_problem.md) |
| Understand the architecture | [.spec-kit/07_architecture.md](.spec-kit/07_architecture.md) |
| Understand the data model | [.spec-kit/09_database_design.md](.spec-kit/09_database_design.md) |
| Understand the AI agents | [.spec-kit/11_ai_agents.md](.spec-kit/11_ai_agents.md) |
| Understand the APIs | [.spec-kit/14_api_contract.md](.spec-kit/14_api_contract.md) |
| Start coding | [docs/IMPLEMENTATION_PLAN.md](docs/IMPLEMENTATION_PLAN.md) |
| Configure GitHub Copilot | [.spec-kit/copilot.instructions.md](.spec-kit/copilot.instructions.md) |
| Set up on a new machine | [docs/LOCAL_SETUP.md](docs/LOCAL_SETUP.md) |
| Repurpose this for a new use case | [docs/REUSABLE_PATTERNS.md](docs/REUSABLE_PATTERNS.md) |

---

*This repository is a Spec-Driven Development blueprint. All application code is generated from these specifications in subsequent milestones.*
