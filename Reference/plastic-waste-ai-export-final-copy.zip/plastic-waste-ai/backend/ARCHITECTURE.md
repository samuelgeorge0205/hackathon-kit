# Backend Architecture

The backend is separated into enterprise modules:

- api/: transport and validation
- application/: use-case orchestration
- domain/: business model and rules
- ai/: agentic intelligence platform
- data/: persistence and data ingestion/indexing
- llm/: model provider boundary wrappers
- infrastructure/: config and external adapters
- observability/: logging, tracing, metrics and audit namespace
- shared/: cross-cutting utilities and middleware
- tests/: unit, integration, api, ai, performance, security

Global deciding factors:
- Runtime environment variables and profile mode in infrastructure/config/settings.py
- Global design-time defaults in config/*.yaml
