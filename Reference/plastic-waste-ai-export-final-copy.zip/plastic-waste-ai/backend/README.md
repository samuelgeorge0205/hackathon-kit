# Backend Module Structure

This backend follows an incremental enterprise architecture model:

- Keep current runtime behavior stable.
- Organize modules by clear architectural responsibility.
- Migrate refactors in compatibility-safe phases.

## Canonical Structure

```
backend/
├── main.py                        # FastAPI app factory
├── requirements.txt               # Python dependencies
├── alembic.ini                    # Alembic migration config
├── (uses ../config/runtime.env)   # Central runtime environment file
│
├── api/
│   └── v1/
│       ├── routers/               # One file per resource
│       ├── dependencies.py        # DI: get_current_user, require_role
│       ├── middleware.py          # CORS, correlation ID, request logging
│       └── models/                # Pydantic request/response schemas
│           ├── requests/
│           └── responses/
│
├── application/
│   ├── use_cases/                 # One class per use case
│   ├── services/                  # Service interfaces + implementations
│   ├── dtos/                      # Data Transfer Objects
│   └── interfaces/                # AI service and notification interfaces
│
├── domain/
│   ├── entities/                  # 13 domain entities
│   ├── value_objects/             # PlasticType, Money, ConfidenceScore etc.
│   ├── events/                    # Domain events
│   └── repositories/              # Repository interfaces (ABCs)
│
├── ai/
│   ├── agents/                    # 7 LangGraph agent nodes
│   ├── coordinator/               # Workflow routing/orchestration policies
│   ├── retrieval/                 # Retrieval strategy composition
│   ├── guardrails/                # AI safety/policy modules
│   ├── evaluation/                # Quality and cost evaluation modules
│   ├── memory/                    # Conversation/workflow memory modules
│   ├── prompt_library/            # Prompt assets + registry
│   ├── workflows/                 # LangGraph StateGraphs
│   ├── rag/                       # RAG pipeline
│   │   ├── ingestion/
│   │   └── retrieval/
│   └── state/
│       └── workflow_state.py      # TypedDict state schemas
│
├── data/
│   ├── repositories/
│   │   ├── sqlite/                # SQLite implementations
│   │   └── chroma/                # ChromaDB implementation
│   ├── models/                    # SQLAlchemy ORM models
│   ├── migrations/                # Alembic migrations
│   │   └── versions/
│   └── mappers/                   # ORM ↔ Domain entity mappers
│
├── infrastructure/
│   ├── cache/                     # Redis client + cache strategies
│   ├── storage/                   # File storage adapters
│   └── config/
│       └── settings.py            # Pydantic Settings (reads config/runtime.env)

├── shared/
│   ├── utils/                     # Cross-layer utilities
│   ├── constants/                 # Shared constants
│   ├── exceptions/                # Shared exception taxonomy
│   └── middleware/                # Shared middleware helpers
│
├── observability/
│   ├── logging.py                 # structlog JSON configuration
│   ├── tracing.py                 # Langfuse init + correlation ID
│   ├── metrics.py                 # Prometheus counters
│   └── audit.py                   # Audit log writer
│
└── tests/
    ├── unit/
    │   ├── domain/
    │   ├── application/
    │   └── ai/
    ├── integration/
    │   ├── repositories/
    │   └── api/
    ├── api/                       # Endpoint/contract-focused tests
    ├── ai/                        # Agent/workflow-focused tests
    ├── performance/               # Latency and throughput tests
    └── security/                  # Auth and abuse-case tests
```

## Key Implementation Files (read spec before implementing)

| File | Read spec first |
|---|---|
| `domain/entities/*.py` | `.spec-kit/09_database_design.md` |
| `ai/agents/*.py` | `.spec-kit/11_ai_agents.md` |
| `ai/rag/` | `.spec-kit/10_rag_design.md` |
| `api/v1/routers/*.py` | `.spec-kit/14_api_contract.md` |
| `infrastructure/config/settings.py` | `config/app.yaml` |
| All LLM calls | `.spec-kit/copilot.instructions.md` — LLM client pattern |

## Runtime Compatibility

- Existing module imports remain valid.
- Existing API routes remain unchanged.
- Runtime inputs are consolidated under `input-data/{structured,knowledge-base}`.

## Clear Distinction Map

- `api/`: HTTP boundary only.
- `application/`: use-case orchestration.
- `domain/`: business model and policies.
- `ai/`: agents, workflows, retrieval, guardrails, evaluation.
- `llm/`: model provider boundary wrappers.
- `data/`: input data, databases, schemas, database files, and data-side RAG concerns.
- `infrastructure/`: external adapters and runtime settings.
- `observability/`: logging, metrics, tracing, health namespace.
- `shared/`: cross-cutting utilities and middleware.

Global deciding factors live in:
- `config/runtime.env.example`
- `config/llm.yaml`
- `config/application.yaml`
- `backend/infrastructure/config/settings.py`

## Environment Variables Required

```bash
# config/runtime.env
LLM_API_KEY=your_tcs_genai_lab_api_key
LLM_GATEWAY_URL=https://genailab.tcs.in
LANGFUSE_PUBLIC_KEY=your_langfuse_key
LANGFUSE_SECRET_KEY=your_langfuse_secret
SECRET_KEY=your_jwt_secret_32chars_minimum
DATABASE_URL=sqlite+aiosqlite:///./data/database_files/app.db
REDIS_URL=redis://localhost:6379/0
```
