# Agents Section

Purpose:
- Business-facing AI agent capability boundary.

Runtime source modules:
- ai/agents/
- ai/workflows/

This section documents the boundary and can host future facades.
