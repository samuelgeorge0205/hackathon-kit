from __future__ import annotations

# Compatibility adapter: canonical LLM client now lives in llm.client.
from llm.client import get_embeddings, get_llm

__all__ = ["get_embeddings", "get_llm"]
