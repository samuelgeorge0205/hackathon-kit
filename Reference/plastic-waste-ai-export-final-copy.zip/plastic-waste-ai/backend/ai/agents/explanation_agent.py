from __future__ import annotations

import json

import structlog

from ai.guardrails.groundedness import confidence_tier, score_groundedness, verify_citations
from ai.prompt_library.loader import get_prompt
from ai.state.workflow_state import ChatWorkflowState, PredictionWorkflowState
from llm.providers import get_llm
from observability.tracing import trace_agent

logger = structlog.get_logger(__name__)

_SYSTEM_PROMPT = get_prompt("explanation-agent")
_CHAT_SYSTEM_PROMPT = get_prompt("chat-response-agent")

_NO_CONTEXT_RESPONSE = (
    "I don't have information about that in my knowledge base. I can answer questions about "
    "plastic packaging waste, handling costs, supplier sustainability, and the regulatory "
    "guidance that's been loaded (GRI 306, UK EPR, WRAP UK Plastics Pact, and related documents)."
)


@trace_agent("explanation_agent")
async def explanation_node(state: PredictionWorkflowState) -> PredictionWorkflowState:
    prediction = state.get("prediction", {})
    llm = get_llm(mini=True)  # Use mini model — cost-efficient for explanations

    user_prompt = (
        f"Prediction result: {prediction}\n"
        f"Key factors: {prediction.get('key_factors', [])}\n"
        "Explain this prediction in plain English for a Supply Chain Analyst."
    )

    messages = [{"role": "system", "content": _SYSTEM_PROMPT}, {"role": "user", "content": user_prompt}]

    try:
        response = await llm.ainvoke(messages)
        result = json.loads(response.content)
        explanation = result.get("explanation", "Prediction completed successfully.")
    except Exception as exc:
        logger.warning("explanation_fallback", error=str(exc))
        kg = prediction.get("predicted_waste_kg", 0)
        confidence = prediction.get("confidence_score", 0)
        explanation = (
            f"The AI predicts {kg:.1f} kg of plastic waste for this period. "
            f"Confidence level: {'high' if confidence > 0.7 else 'medium' if confidence > 0.4 else 'low'} ({confidence:.0%}). "
            f"Key drivers: {', '.join(prediction.get('key_factors', ['insufficient data'])[:2])}."
        )

    return {**state, "explanation": explanation}


@trace_agent("chat_explanation_agent")
async def chat_explanation_node(state: ChatWorkflowState) -> ChatWorkflowState:
    """Explanation node for the chat workflow — generates a grounded, cited
    response and verifies its own grounding before returning it."""
    context = state.get("retrieved_context", [])

    # No relevant context retrieved — the single biggest anti-hallucination
    # lever is to never let the model answer freeform when it has nothing to
    # ground itself in.
    if not context:
        return {
            **state,
            "response": _NO_CONTEXT_RESPONSE,
            "citations": [],
            "groundedness_score": 1.0,
            "confidence_tier": "HIGH",
            "confidence_score": 1.0,
        }

    llm = get_llm(mini=True)
    context_text = "\n\n".join(
        f"[{i + 1}] {doc.get('text', '')[:500]}" for i, doc in enumerate(context[:5])
    )

    messages = [
        {"role": "system", "content": _CHAT_SYSTEM_PROMPT},
        {"role": "user", "content": f"Context:\n{context_text}\n\nQuestion: {state.get('user_message', '')}"},
    ]

    try:
        response = await llm.ainvoke(messages)
        text = response.content
    except Exception as exc:
        logger.warning("chat_explanation_fallback", error=str(exc))
        return {
            **state,
            "response": "I'm unable to answer right now. Please try again shortly.",
            "citations": [],
            "groundedness_score": 0.0,
            "confidence_tier": "VERY_LOW",
            "confidence_score": 0.0,
        }

    citations = verify_citations(text, context)
    groundedness = score_groundedness(text, context)

    return {
        **state,
        "response": text,
        "citations": citations,
        "groundedness_score": groundedness,
        "confidence_tier": confidence_tier(groundedness),
        "confidence_score": groundedness,
    }
