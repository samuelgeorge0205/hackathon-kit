from __future__ import annotations

import json
import logging

from ai.prompt_library.loader import get_prompt
from llm.providers import get_llm
from ai.state.workflow_state import PredictionWorkflowState
from observability.tracing import trace_agent

logger = logging.getLogger(__name__)

# Not currently invoked (routing below is deterministic) — kept in the prompt
# library so a future LLM-based router can pick it straight up.
_SYSTEM_PROMPT = get_prompt("planner-agent")


@trace_agent("planner_agent")
async def planner_node(state: PredictionWorkflowState) -> PredictionWorkflowState:
    prediction_type = state.get("prediction_type", "WASTE_VOLUME")

    # Deterministic routing for known prediction types — no LLM call needed
    routes = {
        "WASTE_VOLUME": ["retriever", "waste_prediction", "handling_cost", "explanation"],
        "HANDLING_COST": ["retriever", "handling_cost", "explanation"],
        "RECOMMENDATION": ["retriever", "waste_prediction", "recommendation", "explanation"],
        "REPORT": ["retriever", "waste_prediction", "handling_cost", "recommendation", "report_generator"],
        "CHAT": ["retriever", "explanation"],
    }

    return {**state, "task_sequence": routes.get(prediction_type, routes["WASTE_VOLUME"])}
