from __future__ import annotations

import json
import structlog

from ai.guardrails.groundedness import score_groundedness_against_sources
from ai.prompt_library.loader import get_prompt
from llm.providers import get_llm
from ai.state.workflow_state import PredictionWorkflowState
from observability.tracing import trace_agent

logger = structlog.get_logger(__name__)

_SYSTEM_PROMPT = get_prompt("recommendation-agent")

_MIN_GROUNDEDNESS = 0.2


@trace_agent("recommendation_agent")
async def recommendation_node(state: PredictionWorkflowState) -> PredictionWorkflowState:
    llm = get_llm(mini=False)
    context = state.get("retrieved_context", [])
    params = state.get("input_params", {})
    prediction = state.get("prediction", {})

    # Skip recommendations if retrieval quality is too low
    if not context:
        return {**state, "recommendations": []}

    context_text = "\n\n".join(
        f"[{doc.get('metadata', {}).get('title', 'Doc')}]: {doc.get('text', '')[:400]}"
        for doc in context[:5]
    )

    user_prompt = (
        f"Product: {params.get('product_name', 'Unknown')} (ID: {params.get('product_id', 'N/A')})\n"
        f"Historical waste: {prediction.get('predicted_waste_kg', 0):.1f}kg predicted\n"
        f"Plastic type breakdown: {json.dumps(prediction.get('plastic_type_breakdown', {}))}\n\n"
        f"Retrieved context:\n{context_text}\n\n"
        "Generate packaging optimisation recommendations."
    )

    messages = [{"role": "system", "content": _SYSTEM_PROMPT}, {"role": "user", "content": user_prompt}]

    for attempt in range(2):
        try:
            response = await llm.ainvoke(messages)
            recs = json.loads(response.content)
            if not isinstance(recs, list):
                raise ValueError("Expected JSON array")

            # Hallucination guard: every recommendation must cite a source that
            # literally exists in the retrieved context, and its rationale text
            # must actually be lexically supported by the cited chunk(s).
            title_to_text: dict[str, list[str]] = {}
            for doc in context:
                title = doc.get("metadata", {}).get("title", "")
                title_to_text.setdefault(title, []).append(doc.get("text", ""))

            verified = []
            for r in recs:
                sources = r.get("sources") or []
                matched_texts = [
                    text
                    for s in sources
                    for text in title_to_text.get(s.get("title", ""), [])
                ]
                if not matched_texts:
                    continue  # no verifiable source — drop rather than trust an unverifiable claim
                groundedness = score_groundedness_against_sources(r.get("rationale", ""), matched_texts)
                if groundedness < _MIN_GROUNDEDNESS:
                    continue
                verified.append({**r, "groundedness_score": round(groundedness, 3)})

            return {**state, "recommendations": verified}
        except Exception as exc:
            logger.warning("recommendation_retry", attempt=attempt, error=str(exc))
            if attempt == 1:
                return {**state, "recommendations": []}
            messages[-1]["content"] += "\n\nReturn ONLY a valid JSON array."

    return state
