from __future__ import annotations

import asyncio
import json
import structlog

from ai.prompt_library.loader import get_prompt
from llm.providers import get_llm
from observability.tracing import trace_agent

logger = structlog.get_logger(__name__)

_SYSTEM_PROMPT = get_prompt("report-generator-agent")


async def _generate_section(user_prompt: str, fallback: dict) -> dict:
    llm = get_llm(mini=True)
    messages = [
        {"role": "system", "content": _SYSTEM_PROMPT},
        {"role": "user", "content": user_prompt},
    ]
    try:
        response = await llm.ainvoke(messages)
        section = json.loads(response.content)
        if not isinstance(section, dict) or "content" not in section:
            raise ValueError("Malformed section response")
        return section
    except Exception as exc:
        logger.warning("report_section_fallback", error=str(exc))
        return fallback


async def _executive_summary(summary_data: dict) -> dict:
    prompt = (
        f"Data: {json.dumps(summary_data)}\n"
        "Write an executive summary (3 paragraphs) covering: total waste, period-over-period change, top 3 actions.\n"
        'Return: {"title": "Executive Summary", "content": "<text>", "key_metrics": {}}'
    )
    total = summary_data.get("total_waste_kg", 0.0)
    change_pct = summary_data.get("change_pct")
    if change_pct is None:
        change_text = "an amount that cannot yet be compared against a prior period due to insufficient historical data"
    else:
        direction = "reduction" if change_pct < 0 else "increase"
        change_text = f"a {abs(change_pct):.1f}% {direction} compared with the preceding period of equal length"

    fallback = {
        "title": "Executive Summary",
        "content": (
            f"Total plastic waste for the period was {total:.0f} kg, representing {change_text}. "
            f"The recycling rate for this period was {summary_data.get('recycling_rate_pct', 0):.1f}%. "
            f"{summary_data.get('active_recommendations', 0)} packaging optimisation recommendations remain "
            f"pending, with estimated annual savings of £{summary_data.get('recommendations_value', 0):,.0f}."
        ),
        "key_metrics": summary_data,
    }
    return await _generate_section(prompt, fallback)


async def _waste_by_type(breakdown: dict) -> dict:
    prompt = (
        f"Data: {json.dumps(breakdown)}\n"
        "Write a section analysing waste by polymer type. Include a data table.\n"
        'Return: {"title": "Plastic Waste by Type", "content": "<text>", "table": []}'
    )
    total = sum(breakdown.values()) or 1.0
    table = [
        {"plastic_type": plastic_type, "weight_kg": weight, "pct_of_total": round(weight / total * 100, 1)}
        for plastic_type, weight in sorted(breakdown.items(), key=lambda kv: -kv[1])
    ]
    fallback = {
        "title": "Plastic Waste by Type",
        "content": (
            "Waste by polymer type for the period, ranked by contribution: "
            + ", ".join(f"{row['plastic_type']} ({row['pct_of_total']:.0f}%)" for row in table)
            + "."
            if table
            else "No waste logs were recorded for this period."
        ),
        "table": table,
    }
    return await _generate_section(prompt, fallback)


async def _regulatory_alignment(regs_context: list[dict], period_data: dict) -> dict:
    context_text = "\n".join(doc.get("text", "")[:300] for doc in regs_context[:3])
    prompt = (
        f"Regulatory context: {context_text or 'No regulatory guidance documents retrieved.'}\n"
        f"Period data: {json.dumps(period_data)}\n"
        "Write a GRI 306 / UK EPR alignment statement.\n"
        'Return: {"title": "Regulatory Alignment", "content": "<text>", "frameworks": ["GRI 306", "UK EPR"]}'
    )
    if regs_context:
        content = (
            "This report is structured to align with GRI 306 (Waste) disclosure principles and UK "
            "Extended Producer Responsibility (EPR) reporting requirements, drawing on the retrieved "
            "regulatory guidance for this period."
        )
    else:
        content = (
            "This report is structured to align with GRI 306 (Waste) disclosure principles and the UK "
            "Extended Producer Responsibility (EPR) reporting requirements. No specific regulatory guidance "
            "documents were retrieved for this period — alignment claims should be independently verified "
            "against current regulatory text before external publication."
        )
    fallback = {"title": "Regulatory Alignment", "content": content, "frameworks": ["GRI 306", "UK EPR"]}
    return await _generate_section(prompt, fallback)


@trace_agent("report_generator_agent")
async def generate_report_sections(
    summary_data: dict, breakdown: dict, regs_context: list[dict], period_data: dict
) -> list[dict]:
    return list(
        await asyncio.gather(
            _executive_summary(summary_data),
            _waste_by_type(breakdown),
            _regulatory_alignment(regs_context, period_data),
        )
    )
