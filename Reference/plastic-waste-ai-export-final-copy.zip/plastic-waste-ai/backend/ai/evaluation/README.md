# AI Evaluation

Quality evaluation modules for latency, groundedness, cost, and output validation.
