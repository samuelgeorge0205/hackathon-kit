from __future__ import annotations

import json
import time
import uuid
from pathlib import Path

import structlog

logger = structlog.get_logger(__name__)

_GOLDEN_SET_PATH = Path(__file__).resolve().parent / "golden_queries.json"


def load_golden_queries() -> list[dict]:
    return json.loads(_GOLDEN_SET_PATH.read_text(encoding="utf-8"))


async def _run_query(chat_workflow, query: dict) -> dict:
    started = time.perf_counter()
    state = {
        "user_id": "eval-runner",
        "session_id": f"eval_{uuid.uuid4().hex[:8]}",
        "user_message": query["query"],
        "retrieved_context": [],
        "messages": [],
    }
    try:
        result = await chat_workflow.ainvoke(state)
    except Exception as exc:
        logger.warning("eval_query_failed", query_id=query["id"], error=str(exc))
        result = {"retrieved_context": [], "citations": [], "groundedness_score": 0.0, "response": ""}
    latency_ms = round((time.perf_counter() - started) * 1000, 1)

    retrieved_doc_ids = {
        doc.get("metadata", {}).get("doc_id", "") for doc in result.get("retrieved_context", [])
    }
    retrieved_doc_ids.discard("")

    expected_doc_id = query.get("expected_doc_id")
    if expected_doc_id is None:
        precision_hit = len(retrieved_doc_ids) == 0
    else:
        precision_hit = expected_doc_id in retrieved_doc_ids

    return {
        "id": query["id"],
        "query": query["query"],
        "expected_doc_id": expected_doc_id,
        "retrieved_doc_ids": sorted(retrieved_doc_ids),
        "precision_hit": precision_hit,
        "groundedness": result.get("groundedness_score", 0.0),
        "citations": result.get("citations", []),
        "latency_ms": latency_ms,
    }


async def run_evaluation() -> dict:
    """Runs the golden query set through the full chat workflow (retrieval +
    grounded generation), scoring retrieval precision@5 and the same
    lexical-groundedness check production chat responses go through."""
    from ai.workflows.prediction_workflow import chat_workflow

    queries = load_golden_queries()
    results = [await _run_query(chat_workflow, q) for q in queries]

    n = len(results)
    avg_precision = sum(r["precision_hit"] for r in results) / n if n else 0.0
    avg_groundedness = sum(r["groundedness"] for r in results) / n if n else 0.0
    avg_latency = sum(r["latency_ms"] for r in results) / n if n else 0.0

    return {
        "n_queries": n,
        "avg_retrieval_precision": round(avg_precision, 3),
        "avg_groundedness": round(avg_groundedness, 3),
        "avg_latency_ms": round(avg_latency, 1),
        "pass_rate": round(avg_precision, 3),
        "results": results,
    }
