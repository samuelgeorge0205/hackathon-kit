# AI Guardrails

Reusable safety and policy checks (prompt-injection, schema validation, confidence bounds).
