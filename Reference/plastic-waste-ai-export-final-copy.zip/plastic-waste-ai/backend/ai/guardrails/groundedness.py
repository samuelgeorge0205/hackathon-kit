from __future__ import annotations

import re
from typing import Literal

_CITATION_RE = re.compile(r"\[(\d+)\]")
_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")

_STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "if", "of", "to", "in", "on", "for",
    "is", "are", "was", "were", "be", "been", "being", "this", "that", "it",
    "as", "at", "by", "with", "from", "your", "you", "we", "our", "their",
    "will", "can", "could", "should", "would", "not", "no", "do", "does",
}

_REFUSAL_MARKERS = (
    "don't have information",
    "do not have information",
    "no information",
    "unable to answer",
    "not in my knowledge base",
    "cannot find",
    "couldn't find",
    "insufficient context",
    "insufficient data",
)

ConfidenceTier = Literal["HIGH", "MEDIUM", "LOW", "VERY_LOW"]


def _tokenize(text: str) -> set[str]:
    words = re.findall(r"[a-z0-9]+", text.lower())
    return {w for w in words if w not in _STOPWORDS and len(w) > 2}


def lexical_overlap(text: str, reference_text: str) -> float:
    """Fraction of `text`'s meaningful vocabulary that also appears in
    `reference_text` — a cheap, no-extra-LLM-call proxy for "is this claim
    actually supported by this source"."""
    text_tokens = _tokenize(text)
    if not text_tokens:
        return 0.0
    reference_tokens = _tokenize(reference_text)
    return len(text_tokens & reference_tokens) / len(text_tokens)


def score_groundedness_against_sources(claim_text: str, source_texts: list[str]) -> float:
    """Like `lexical_overlap`, but against several source chunks at once —
    used for citation styles that reference sources by title/section (e.g.
    the recommendation agent) rather than inline [n] markers."""
    if not source_texts:
        return 0.0
    return lexical_overlap(claim_text, " ".join(source_texts))


def extract_cited_indices(answer_text: str) -> set[int]:
    """Return the set of [n] citation markers the model actually wrote, 1-indexed."""
    return {int(m) for m in _CITATION_RE.findall(answer_text)}


def verify_citations(answer_text: str, context: list[dict]) -> list[dict]:
    """Build the citation list from what the model actually cited in `answer_text`,
    dropping any [n] marker that doesn't correspond to a retrieved context item.
    This replaces trusting the model's citations blindly."""
    cited = extract_cited_indices(answer_text)
    citations = []
    for index in sorted(cited):
        if index < 1 or index > len(context):
            continue
        doc = context[index - 1]
        meta = doc.get("metadata", {})
        citations.append(
            {
                "index": index,
                "title": meta.get("title", "Internal data"),
                "doc_id": meta.get("doc_id", ""),
                "section": meta.get("section", ""),
                "source_category": meta.get("source_category", ""),
                "relevance": round(float(doc.get("score", 0.0)), 3),
            }
        )
    return citations


def score_groundedness(answer_text: str, context: list[dict]) -> float:
    """Aggregate lexical-overlap grounding score in [0, 1].

    For each sentence that carries a citation marker, measures how much of the
    sentence's vocabulary is actually present in the chunk it cites. Sentences
    with no citation don't penalize the score directly, but an answer that makes
    claims (i.e. is non-trivial) without citing anything at all is scored low.
    """
    if not context:
        return 1.0 if any(marker in answer_text.lower() for marker in _REFUSAL_MARKERS) else 0.0

    sentences = [s for s in _SENTENCE_SPLIT_RE.split(answer_text) if s.strip()]
    cited_sentence_scores = []
    for sentence in sentences:
        indices = extract_cited_indices(sentence)
        valid_indices = [i for i in indices if 1 <= i <= len(context)]
        if not valid_indices:
            continue
        if not _tokenize(sentence):
            continue
        cited_text = " ".join(context[i - 1].get("text", "") for i in valid_indices)
        cited_sentence_scores.append(lexical_overlap(sentence, cited_text))

    if not cited_sentence_scores:
        # Non-trivial answer, real context available, nothing cited — under-grounded.
        return 0.3 if len(answer_text.strip()) > 20 else 0.0

    return round(sum(cited_sentence_scores) / len(cited_sentence_scores), 3)


def confidence_tier(score: float) -> ConfidenceTier:
    if score >= 0.80:
        return "HIGH"
    if score >= 0.60:
        return "MEDIUM"
    if score >= 0.40:
        return "LOW"
    return "VERY_LOW"


def check_numeric_plausibility(predicted: float, historical_values: list[float]) -> bool:
    """Sanity bound, not a statistical test — catches unit errors and invented
    numbers, not meant to second-guess a reasonable trend-based estimate."""
    if predicted < 0:
        return False
    if not historical_values:
        return True
    total_historical = sum(historical_values)
    if total_historical <= 0:
        return predicted <= 1.0
    return predicted <= total_historical * 10
