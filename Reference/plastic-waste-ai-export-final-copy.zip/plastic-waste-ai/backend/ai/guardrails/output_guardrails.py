from __future__ import annotations

import re

from ai.guardrails.groundedness import (  # noqa: F401 - re-exported for callers
    check_numeric_plausibility,
    confidence_tier,
    score_groundedness,
    score_groundedness_against_sources,
    verify_citations,
)

# Internal ML/AI jargon that should never leak into a business-user-facing
# explanation — the explanation agent is instructed not to use these, this is
# the backstop in case it does anyway.
_BANNED_TERMS = [
    "embedding", "cosine similarity", "temperature", "token", "vector",
    "neural network", "model inference", "llm", "gpt", "transformer",
    "hyperparameter", "fine-tun",
]

_BANNED_TERMS_RE = re.compile(r"\b(" + "|".join(re.escape(t) for t in _BANNED_TERMS) + r")\b", re.IGNORECASE)


def contains_banned_terms(text: str) -> list[str]:
    return sorted({m.lower() for m in _BANNED_TERMS_RE.findall(text)})


def strip_banned_terms(text: str) -> str:
    return _BANNED_TERMS_RE.sub("[technical detail]", text)
