from __future__ import annotations

from functools import lru_cache
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parents[3]
_PROMPTS_DIR = _PROJECT_ROOT / "prompts"

_SECTION_MARKER = "## System Prompt"
_CODE_FENCE = "```"


def _prompt_path(name: str) -> Path:
    return _PROMPTS_DIR / f"{name}.md"


def _extract_system_prompt(markdown: str) -> str:
    """Prompt files are authored as markdown docs with a fenced '## System
    Prompt' code block — extract just that block so agents run the prompt
    text, not the surrounding markdown."""
    marker_idx = markdown.find(_SECTION_MARKER)
    search_from = marker_idx if marker_idx != -1 else 0
    fence_start = markdown.find(_CODE_FENCE, search_from)
    if fence_start == -1:
        return markdown.strip()
    content_start = markdown.find("\n", fence_start) + 1
    fence_end = markdown.find(_CODE_FENCE, content_start)
    if fence_end == -1:
        return markdown[content_start:].strip()
    return markdown[content_start:fence_end].strip()


@lru_cache(maxsize=64)
def _load_cached(name: str, mtime: float) -> str:
    path = _prompt_path(name)
    return _extract_system_prompt(path.read_text(encoding="utf-8"))


def get_prompt(name: str) -> str:
    """Load an agent's system prompt from prompts/{name}.md.

    Cached per (name, file mtime) so an edit to the .md file is picked up on
    the next call without restarting the process."""
    path = _prompt_path(name)
    if not path.exists():
        raise FileNotFoundError(f"Prompt '{name}' not found at {path}")
    return _load_cached(name, path.stat().st_mtime)


def preview_prompt(name: str, chars: int = 220) -> str:
    try:
        text = get_prompt(name)
    except FileNotFoundError:
        return ""
    return text[:chars] + ("…" if len(text) > chars else "")
