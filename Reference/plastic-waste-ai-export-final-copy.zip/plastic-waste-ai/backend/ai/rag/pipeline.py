from __future__ import annotations

import math
import re
from pathlib import Path

import chromadb
import structlog
import tiktoken
from chromadb.config import Settings as ChromaSettings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from rank_bm25 import BM25Okapi

from llm.providers import get_embeddings

logger = structlog.get_logger(__name__)

_CHROMA_DIR = Path("./data/database_files/chroma")
_COLLECTION_NAME = "knowledge_base"

_CHUNK_SIZE_TOKENS = 512
_CHUNK_OVERLAP_TOKENS = 50
_DENSE_CANDIDATES = 15
_SPARSE_CANDIDATES = 15
_RRF_K = 60
_RERANK_CANDIDATES = 20
_MIN_RELEVANCE_SCORE = 0.15  # post-sigmoid cross-encoder score below this is treated as "not relevant"

_HEADING_RE = re.compile(r"^#{1,6}\s+(.*)$", flags=re.MULTILINE)

_SOURCE_CATEGORY_KEYWORDS = {
    "regulations": ["regulation", "epr", "gri-306", "gri_306", "compliance"],
    "supplier_docs": ["supplier"],
    "sustainability_guidelines": ["best-practices", "best_practices", "pact", "targets", "sustainability"],
    "packaging_standards": ["polymer", "recyclab", "packaging"],
}

_cross_encoder = None  # lazy-loaded singleton — loading the model is expensive, do it once per process


def _get_cross_encoder():
    global _cross_encoder
    if _cross_encoder is None:
        from sentence_transformers import CrossEncoder

        _cross_encoder = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")
    return _cross_encoder


def _tiktoken_len(text: str) -> int:
    encoding = tiktoken.get_encoding("cl100k_base")
    return len(encoding.encode(text))


def _infer_source_category(doc_id: str, title: str) -> str:
    haystack = f"{doc_id} {title}".lower()
    for category, keywords in _SOURCE_CATEGORY_KEYWORDS.items():
        if any(kw in haystack for kw in keywords):
            return category
    return "internal_policies"


def _extract_headings(text: str) -> list[tuple[int, str]]:
    return [(m.start(), m.group(1).strip()) for m in _HEADING_RE.finditer(text)]


def _nearest_heading(headings: list[tuple[int, str]], offset: int) -> str:
    section = ""
    for pos, title in headings:
        if pos <= offset:
            section = title
        else:
            break
    return section


def _sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))


def _tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


class RAGPipeline:
    def __init__(self) -> None:
        _CHROMA_DIR.mkdir(parents=True, exist_ok=True)
        self._client = chromadb.PersistentClient(
            path=str(_CHROMA_DIR),
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        self._collection = self._client.get_or_create_collection(
            name=_COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )
        self._embedder = get_embeddings()
        self._splitter = RecursiveCharacterTextSplitter(
            chunk_size=_CHUNK_SIZE_TOKENS,
            chunk_overlap=_CHUNK_OVERLAP_TOKENS,
            length_function=_tiktoken_len,
            separators=["\n\n", "\n", ". ", " ", ""],
        )

    async def ingest(self, text: str, metadata: dict, doc_id: str | None = None) -> None:
        chunks = self._chunk(text)
        if not chunks:
            return

        headings = _extract_headings(text)
        title = metadata.get("title", doc_id or "")
        source_category = _infer_source_category(doc_id or "", title)

        search_from = 0
        sections = []
        for chunk in chunks:
            idx = text.find(chunk, search_from)
            if idx == -1:
                idx = text.find(chunk)
            if idx == -1:
                idx = search_from
            else:
                search_from = idx + 1
            sections.append(_nearest_heading(headings, idx))

        embeddings = self._embedder.embed_documents(chunks)
        ids = [f"{doc_id or 'doc'}_{i}" for i in range(len(chunks))]
        metas = [
            {
                **metadata,
                "chunk_index": i,
                "total_chunks": len(chunks),
                "section": sections[i],
                "source_category": source_category,
                "doc_id": doc_id or "doc",
            }
            for i in range(len(chunks))
        ]
        self._collection.upsert(ids=ids, embeddings=embeddings, documents=chunks, metadatas=metas)
        logger.info("rag_ingested", doc_id=doc_id, chunks=len(chunks), source_category=source_category)

    async def retrieve(self, query: str, top_k: int = 5) -> list[dict]:
        count = self._collection.count()
        if count == 0:
            return []

        try:
            dense_ranked_ids = await self._dense_search(query, count)
            sparse_ranked_ids = self._sparse_search(query, count)
        except Exception as exc:
            logger.warning("rag_retrieve_error", error=str(exc))
            return []

        fused_ids = self._reciprocal_rank_fusion(dense_ranked_ids, sparse_ranked_ids)
        candidate_ids = fused_ids[:_RERANK_CANDIDATES]
        if not candidate_ids:
            return []

        candidates = self._collection.get(ids=candidate_ids, include=["documents", "metadatas"])
        by_id = {
            cid: {"text": doc, "metadata": meta}
            for cid, doc, meta in zip(candidates["ids"], candidates["documents"], candidates["metadatas"])
        }

        try:
            reranked = self._rerank(query, [by_id[cid] for cid in candidate_ids if cid in by_id])
        except Exception as exc:
            logger.warning("rag_rerank_error", error=str(exc))
            # Degrade gracefully to fusion order with a neutral score rather than failing retrieval entirely
            reranked = [{**by_id[cid], "score": 0.5} for cid in candidate_ids if cid in by_id]

        relevant = [r for r in reranked if r["score"] >= _MIN_RELEVANCE_SCORE]
        return relevant[:top_k]

    async def _dense_search(self, query: str, count: int) -> list[str]:
        query_embedding = self._embedder.embed_query(query)
        results = self._collection.query(
            query_embeddings=[query_embedding],
            n_results=min(_DENSE_CANDIDATES, count),
            include=[],
        )
        return list(results["ids"][0])

    def _sparse_search(self, query: str, count: int) -> list[str]:
        corpus = self._collection.get(include=["documents"])
        ids = corpus["ids"]
        documents = corpus["documents"]
        if not ids:
            return []
        tokenized_corpus = [_tokenize(doc) for doc in documents]
        bm25 = BM25Okapi(tokenized_corpus)
        scores = bm25.get_scores(_tokenize(query))
        ranked = sorted(zip(ids, scores), key=lambda pair: pair[1], reverse=True)
        return [doc_id for doc_id, _ in ranked[: min(_SPARSE_CANDIDATES, count)]]

    @staticmethod
    def _reciprocal_rank_fusion(*ranked_lists: list[str]) -> list[str]:
        scores: dict[str, float] = {}
        for ranked in ranked_lists:
            for rank, doc_id in enumerate(ranked):
                scores[doc_id] = scores.get(doc_id, 0.0) + 1.0 / (_RRF_K + rank + 1)
        return [doc_id for doc_id, _ in sorted(scores.items(), key=lambda pair: pair[1], reverse=True)]

    @staticmethod
    def _rerank(query: str, candidates: list[dict]) -> list[dict]:
        if not candidates:
            return []
        cross_encoder = _get_cross_encoder()
        pairs = [(query, c["text"]) for c in candidates]
        raw_scores = cross_encoder.predict(pairs)
        scored = [{**c, "score": _sigmoid(float(s))} for c, s in zip(candidates, raw_scores)]
        return sorted(scored, key=lambda r: r["score"], reverse=True)

    def _chunk(self, text: str) -> list[str]:
        if not text.strip():
            return []
        return [c for c in self._splitter.split_text(text) if c.strip()]
