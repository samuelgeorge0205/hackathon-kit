# AI Retrieval

Retrieval strategy composition (dense/sparse, reranking, context compression).
