from __future__ import annotations

from datetime import datetime, timedelta, timezone
from uuid import UUID

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from passlib.context import CryptContext

from domain.entities.user import User
from infrastructure.config.settings import get_settings

_bearer = HTTPBearer()
_pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

ALGORITHM = "HS256"


def hash_password(password: str) -> str:
    return _pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    return _pwd_context.verify(plain, hashed)


def create_access_token(user_id: str, role: str) -> str:
    settings = get_settings()
    expire = datetime.now(timezone.utc) + timedelta(minutes=settings.access_token_expire_minutes)
    return jwt.encode({"sub": user_id, "role": role, "exp": expire}, settings.secret_key, algorithm=ALGORITHM)


def create_refresh_token(user_id: str) -> str:
    settings = get_settings()
    expire = datetime.now(timezone.utc) + timedelta(days=settings.refresh_token_expire_days)
    return jwt.encode({"sub": user_id, "type": "refresh", "exp": expire}, settings.secret_key, algorithm=ALGORITHM)


def decode_token(token: str) -> dict:
    settings = get_settings()
    try:
        return jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])
    except JWTError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token") from exc


async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(_bearer)) -> User:
    from data.databases import get_session_factory
    from data.repositories.sqlite.user_repository import SQLiteUserRepository

    payload = decode_token(credentials.credentials)

    async with get_session_factory()() as session:
        repo = SQLiteUserRepository(session)
        user = await repo.get_by_id(UUID(payload["sub"]))

    if not user or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found or inactive")
    return user


def require_role(*roles: str):
    async def dependency(user: User = Depends(get_current_user)) -> User:
        if user.role not in roles:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient permissions")
        return user
    return dependency


def enforce_rate_limit(scope: str, limit: int, window_seconds: int):
    """Per-user sliding-window rate limit, e.g. Depends(enforce_rate_limit("chat", 20, 3600))."""

    async def dependency(user: User = Depends(get_current_user)) -> None:
        from infrastructure.cache.redis_cache import RateLimiter

        allowed = await RateLimiter().check(f"{scope}:{user.id}", limit, window_seconds)
        if not allowed:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Rate limit exceeded — max {limit} requests per {window_seconds // 60} minutes",
            )

    return dependency
