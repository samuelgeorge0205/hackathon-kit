from __future__ import annotations

from pathlib import Path
from uuid import UUID, uuid4

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from api.v1.dependencies import get_current_user, hash_password, require_role
from data.databases import get_db_session
from data.models.models import AuditLogModel, ConfigurationModel
from data.repositories.sqlite.user_repository import SQLiteUserRepository
from domain.entities.user import User
from infrastructure.config.paths import get_knowledge_base_dir
from ai.prompt_library.loader import preview_prompt
from shared.utils.audit import write_audit_event

router = APIRouter()
_PROJECT_ROOT = Path(__file__).resolve().parents[4]
_PROMPTS_DIR = _PROJECT_ROOT / "prompts"


class UpdateUserRequest(BaseModel):
    role: str | None = None
    status: str | None = None


class UpdatePromptRequest(BaseModel):
    version: str | None = None
    owner: str | None = None
    status: str | None = None


class CreateUserRequest(BaseModel):
    email: EmailStr
    full_name: str
    role: str = "viewer"
    department: str | None = None
    password: str = "Demo1234!"


_VALID_ROLES = {"viewer", "analyst", "manager", "admin"}
_VALID_USER_STATUS = {"active", "inactive"}
_VALID_PROMPT_STATUS = {"active", "inactive", "draft", "archived"}


def _prompt_meta_key(name: str, field: str) -> str:
    return f"prompt_meta.{name}.{field}"


@router.get("/users")
async def list_users(
    limit: int = 100,
    offset: int = 0,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(require_role("admin")),
):
    repo = SQLiteUserRepository(session)
    users = await repo.list(limit=limit, offset=offset)

    return {
        "data": [
            {
                "id": str(user.id),
                "full_name": user.full_name,
                "email": user.email,
                "role": user.role,
                "status": "active" if user.is_active else "inactive",
            }
            for user in users
        ]
    }


@router.get("/prompt-library")
async def list_prompt_library(
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(require_role("manager", "admin")),
):
    if not _PROMPTS_DIR.exists():
        return {"data": []}

    result = await session.execute(
        select(ConfigurationModel).where(ConfigurationModel.key.like("prompt_meta.%"))
    )
    rows = result.scalars().all()
    metadata = {row.key: row.value for row in rows}

    assets = []
    for prompt_file in sorted(_PROMPTS_DIR.glob("*.md")):
        prompt_name = prompt_file.stem
        assets.append(
            {
                "name": prompt_name,
                "version": metadata.get(_prompt_meta_key(prompt_name, "version"), "v1.0"),
                "owner": metadata.get(_prompt_meta_key(prompt_name, "owner"), "AI Team"),
                "status": metadata.get(_prompt_meta_key(prompt_name, "status"), "active"),
                "content_preview": preview_prompt(prompt_name),
            }
        )

    return {"data": assets}


@router.get("/knowledge-center")
async def list_knowledge_assets(
    current_user: User = Depends(get_current_user),
):
    kb_dir = get_knowledge_base_dir()
    if not kb_dir.exists():
        return {"data": []}

    assets = []
    for doc in sorted(kb_dir.glob("*.md")):
        title = doc.stem.replace("-", " ").replace("_", " ").title()
        assets.append(
            {
                "title": title,
                "category": "Regulatory" if "gri" in doc.stem.lower() else "Operational",
                "note": f"Knowledge asset sourced from {doc.name}",
            }
        )

    return {"data": assets}


@router.get("/audit")
async def list_audit_logs(
    limit: int = 100,
    entity_type: str | None = None,
    entity_id: str | None = None,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(require_role("admin")),
):
    stmt = select(AuditLogModel)
    if entity_type:
        stmt = stmt.where(AuditLogModel.entity_type == entity_type)
    if entity_id:
        stmt = stmt.where(AuditLogModel.entity_id == entity_id)
    stmt = stmt.order_by(desc(AuditLogModel.created_at)).limit(limit)

    result = await session.execute(stmt)
    rows = result.scalars().all()

    return {
        "data": [
            {
                "id": row.id,
                "action": row.event_type,
                "actor": row.user_id or "system",
                "target": f"{row.entity_type or 'entity'}:{row.entity_id or 'n/a'}",
                "created_at": row.created_at,
                "before_json": row.before_json,
                "after_json": row.after_json,
            }
            for row in rows
        ]
    }


@router.post("/users", status_code=201)
async def create_user(
    payload: CreateUserRequest,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(require_role("admin")),
):
    role = payload.role.lower().strip()
    if role not in _VALID_ROLES:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid role")

    repo = SQLiteUserRepository(session)
    existing = await repo.get_by_email(payload.email.lower())
    if existing:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email already exists")

    new_user = User(
        email=payload.email.lower(),
        hashed_password=hash_password(payload.password),
        full_name=payload.full_name.strip(),
        role=role,
        department=payload.department,
        is_active=True,
    )
    await repo.save(new_user)

    await write_audit_event(
        session,
        event_type="ADMIN_USER_CREATED",
        actor_user_id=str(current_user.id),
        entity_type="user",
        entity_id=str(new_user.id),
        after_json=str({"email": new_user.email, "role": new_user.role}),
    )
    await session.commit()

    return {
        "data": {
            "id": str(new_user.id),
            "full_name": new_user.full_name,
            "email": new_user.email,
            "role": new_user.role,
            "status": "active",
        }
    }


@router.patch("/users/{user_id}")
async def update_user(
    user_id: str,
    payload: UpdateUserRequest,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(require_role("admin")),
):
    repo = SQLiteUserRepository(session)
    try:
        user = await repo.get_by_id(UUID(user_id))
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user id") from exc

    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    before = {
        "role": user.role,
        "status": "active" if user.is_active else "inactive",
    }

    if payload.role is not None:
        role = payload.role.lower().strip()
        if role not in _VALID_ROLES:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid role")
        user.role = role

    if payload.status is not None:
        status_value = payload.status.lower().strip()
        if status_value not in _VALID_USER_STATUS:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid status")
        user.is_active = status_value == "active"

    if str(user.id) == str(current_user.id) and not user.is_active:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Cannot deactivate current user")

    await repo.update(user)

    await write_audit_event(
        session,
        event_type="ADMIN_USER_UPDATED",
        actor_user_id=str(current_user.id),
        entity_type="user",
        entity_id=str(user.id),
        before_json=str(before),
        after_json=str({"role": user.role, "status": "active" if user.is_active else "inactive"}),
    )
    await session.commit()

    return {
        "data": {
            "id": str(user.id),
            "full_name": user.full_name,
            "email": user.email,
            "role": user.role,
            "status": "active" if user.is_active else "inactive",
        }
    }


@router.patch("/prompt-library/{prompt_name}")
async def update_prompt_metadata(
    prompt_name: str,
    payload: UpdatePromptRequest,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(require_role("manager", "admin")),
):
    prompt_path = _PROMPTS_DIR / f"{prompt_name}.md"
    if not prompt_path.exists():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Prompt not found")

    updates: dict[str, str] = {}
    if payload.version is not None:
        updates["version"] = payload.version.strip()
    if payload.owner is not None:
        updates["owner"] = payload.owner.strip()
    if payload.status is not None:
        status_value = payload.status.lower().strip()
        if status_value not in _VALID_PROMPT_STATUS:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid prompt status")
        updates["status"] = status_value

    for field, value in updates.items():
        key = _prompt_meta_key(prompt_name, field)
        existing = await session.execute(select(ConfigurationModel).where(ConfigurationModel.key == key))
        row = existing.scalar_one_or_none()
        if row:
            row.value = value
            row.value_type = "string"
            row.category = "prompt_meta"
            row.updated_by = str(current_user.id)
        else:
            session.add(
                ConfigurationModel(
                    id=str(uuid4()),
                    key=key,
                    value=value,
                    value_type="string",
                    category="prompt_meta",
                    description=f"Prompt metadata field {field} for {prompt_name}",
                    updated_by=str(current_user.id),
                )
            )

    await write_audit_event(
        session,
        event_type="PROMPT_METADATA_UPDATED",
        actor_user_id=str(current_user.id),
        entity_type="prompt",
        entity_id=prompt_name,
        after_json=str(updates),
    )
    await session.commit()

    current = {
        "name": prompt_name,
        "version": "v1.0",
        "owner": "AI Team",
        "status": "active",
    }
    for field in ["version", "owner", "status"]:
        key = _prompt_meta_key(prompt_name, field)
        value_row = await session.execute(select(ConfigurationModel).where(ConfigurationModel.key == key))
        entry = value_row.scalar_one_or_none()
        if entry:
            current[field] = entry.value

    return {"data": current}


@router.delete("/users/{user_id}")
async def delete_user(
    user_id: str,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(require_role("admin")),
):
    repo = SQLiteUserRepository(session)
    try:
        user = await repo.get_by_id(UUID(user_id))
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user id") from exc

    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    if str(user.id) == str(current_user.id):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Cannot delete current user")

    user.is_active = False
    await repo.update(user)

    await write_audit_event(
        session,
        event_type="ADMIN_USER_DEACTIVATED",
        actor_user_id=str(current_user.id),
        entity_type="user",
        entity_id=str(user.id),
        after_json=str({"status": "inactive"}),
    )
    await session.commit()

    return {"data": {"id": str(user.id), "status": "inactive"}}
