from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr
from sqlalchemy.ext.asyncio import AsyncSession

from api.v1.dependencies import (
    create_access_token,
    create_refresh_token,
    decode_token,
    verify_password,
)
from data.databases import get_db_session
from data.repositories.sqlite.user_repository import SQLiteUserRepository

router = APIRouter()


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


@router.post("/login")
async def login(payload: LoginRequest, session: AsyncSession = Depends(get_db_session)):
    repo = SQLiteUserRepository(session)
    user = await repo.get_by_email(payload.email.lower())
    if not user or not user.is_active or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid email or password")

    return {
        "data": {
            "access_token": create_access_token(str(user.id), user.role),
            "refresh_token": create_refresh_token(str(user.id)),
            "token_type": "bearer",
            "expires_in": 900,
            "user": {"id": str(user.id), "email": user.email, "full_name": user.full_name, "role": user.role},
        }
    }


@router.post("/refresh")
async def refresh(payload: RefreshRequest, session: AsyncSession = Depends(get_db_session)):
    claims = decode_token(payload.refresh_token)
    if claims.get("type") != "refresh":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid refresh token")
    user_id = claims["sub"]
    repo = SQLiteUserRepository(session)
    user = await repo.get_by_id(UUID(user_id))
    if not user or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User no longer active")
    return {
        "data": {
            "access_token": create_access_token(user_id, user.role),
            "refresh_token": create_refresh_token(user_id),
            "expires_in": 900,
        }
    }


@router.post("/logout")
async def logout():
    return {"data": {"message": "Logged out successfully"}}
