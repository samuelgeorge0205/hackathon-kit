from __future__ import annotations

import asyncio
import hashlib
import json
import uuid

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ai.guardrails.input_guardrails import GuardrailViolation, check_input_guardrails, mask_pii
from api.v1.dependencies import enforce_rate_limit, get_current_user
from data.databases import get_db_session
from data.repositories.sqlite.chat_repository import SQLiteChatRepository
from domain.entities.user import User
from infrastructure.config.settings import get_settings
from observability import live_progress
from observability.tracing import estimate_tokens
from shared.utils.audit import write_audit_event

router = APIRouter()


class ChatRequest(BaseModel):
    session_id: str | None = None
    message: str
    context: dict | None = None


def _cache_key(payload: ChatRequest, history: list[dict], multimodal_memory: dict) -> str:
    cache_payload = {
        "message": payload.message,
        "context": payload.context or {},
        "history": [{"role": m.get("role"), "content": m.get("content")} for m in history[-6:]],
        "memory": multimodal_memory,
    }
    raw = json.dumps(cache_payload, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode()).hexdigest()[:24]


def _cache_key_relaxed(payload: ChatRequest, multimodal_memory: dict) -> str:
    cache_payload = {
        "message": payload.message,
        "memory": multimodal_memory,
    }
    raw = json.dumps(cache_payload, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode()).hexdigest()[:24]


def _extract_multimodal_memory(context: dict | None) -> dict:
    if not context:
        return {}
    attachments = context.get("attachments") if isinstance(context, dict) else None
    image_descriptions = context.get("image_descriptions") if isinstance(context, dict) else None
    return {
        "attachments": attachments if isinstance(attachments, list) else [],
        "image_descriptions": image_descriptions if isinstance(image_descriptions, list) else [],
        "source": context.get("source", "chat") if isinstance(context, dict) else "chat",
    }


def _merge_multimodal_memory(base: dict, incoming: dict) -> dict:
    merged_attachments = (base.get("attachments") or []) + (incoming.get("attachments") or [])
    merged_images = (base.get("image_descriptions") or []) + (incoming.get("image_descriptions") or [])

    deduped_attachments = []
    seen_attachments = set()
    for item in merged_attachments:
        if not isinstance(item, dict):
            continue
        key = (
            item.get("name"),
            item.get("type"),
            item.get("size"),
            item.get("last_modified"),
        )
        if key in seen_attachments:
            continue
        seen_attachments.add(key)
        deduped_attachments.append(item)

    deduped_images = []
    seen_images = set()
    for text in merged_images:
        if not isinstance(text, str):
            continue
        if text in seen_images:
            continue
        seen_images.add(text)
        deduped_images.append(text)

    return {
        "attachments": deduped_attachments[-20:],
        "image_descriptions": deduped_images[-20:],
        "source": incoming.get("source") or base.get("source", "chat"),
    }


def _memory_from_history(history: list[dict]) -> dict:
    merged = {"attachments": [], "image_descriptions": [], "source": "chat"}
    for message in history:
        mem = message.get("memory")
        if isinstance(mem, dict):
            merged = _merge_multimodal_memory(merged, mem)
    return merged


def _history_response_cache_lookup(history: list[dict], message: str) -> dict | None:
    # Scan latest Q/A pairs first so we reuse the freshest matching answer.
    for i in range(len(history) - 2, -1, -1):
        current = history[i]
        nxt = history[i + 1]
        if current.get("role") != "user" or nxt.get("role") != "assistant":
            continue
        if (current.get("content") or "") != message:
            continue
        return {
            "response": nxt.get("content", ""),
            "citations": nxt.get("citations", []),
            "suggested_follow_ups": [
                "Show me the top suppliers by waste intensity",
                "What packaging changes would reduce PET waste most?",
                "Generate a waste report for last month",
            ],
            "confidence_score": 0.7,
        }
    return None


async def _prompt_version(session: AsyncSession, prompt_name: str) -> str:
    from data.models.models import ConfigurationModel

    key = f"prompt_meta.{prompt_name}.version"
    result = await session.execute(select(ConfigurationModel).where(ConfigurationModel.key == key))
    row = result.scalar_one_or_none()
    return row.value if row else "v1.0"


async def _run_guardrails(payload: ChatRequest, session: AsyncSession, current_user: User) -> ChatRequest:
    """Shared by /chat and /chat/stream. Raises HTTPException on a blocked
    message; otherwise returns the payload with PII redacted from the
    message if any was found."""
    try:
        findings = await check_input_guardrails(payload.message)
    except GuardrailViolation as violation:
        await write_audit_event(
            session,
            event_type=f"GUARDRAIL_{violation.category.upper()}_BLOCKED",
            actor_user_id=str(current_user.id),
            entity_type="chat_message",
            entity_id=hashlib.sha256(payload.message.encode()).hexdigest()[:16],
        )
        await session.commit()
        raise HTTPException(status_code=400, detail=violation.message) from violation

    if findings["pii_found"]:
        await write_audit_event(
            session,
            event_type="GUARDRAIL_PII_REDACTED",
            actor_user_id=str(current_user.id),
            entity_type="chat_message",
            entity_id=hashlib.sha256(payload.message.encode()).hexdigest()[:16],
            after_json=json.dumps({"pii_types": findings["pii_found"]}),
        )
        await session.commit()
        # Redact PII from the message itself before it ever reaches the LLM,
        # gets cached, or gets persisted to chat history.
        payload = payload.model_copy(update={"message": mask_pii(payload.message)})
    return payload


async def _build_final_payload(session: AsyncSession, result: dict, payload: ChatRequest) -> dict:
    """Builds the response payload shape shared by /chat and /chat/stream
    once the workflow has produced a result (i.e. not a cache hit)."""
    model = get_settings().active_llm_mini_model
    prompt_version = await _prompt_version(session, "chat-response-agent")
    token_usage = {
        "prompt_tokens": estimate_tokens(
            {"context": result.get("retrieved_context", []), "message": payload.message}
        ),
        "completion_tokens": estimate_tokens(result.get("response", "")),
    }

    return {
        "response": result.get("response", "I was unable to process your request."),
        "citations": result.get("citations", []),
        "suggested_follow_ups": [
            "Show me the top suppliers by waste intensity",
            "What packaging changes would reduce PET waste most?",
            "Generate a waste report for last month",
        ],
        "confidence_score": result.get("confidence_score", 0.7),
        "groundedness_score": result.get("groundedness_score", result.get("confidence_score", 0.7)),
        "confidence_tier": result.get("confidence_tier", "MEDIUM"),
        "model": model,
        "prompt_version": prompt_version,
        "token_usage": token_usage,
    }


@router.post("")
async def chat(
    payload: ChatRequest,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(get_current_user),
    _rate_limit: None = Depends(enforce_rate_limit("chat", 20, 3600)),
):
    from infrastructure.cache.redis_cache import SessionCache

    session_id = payload.session_id or f"sess_{uuid.uuid4().hex[:8]}"
    payload = await _run_guardrails(payload, session, current_user)

    from ai.workflows.prediction_workflow import chat_workflow

    chat_repo = SQLiteChatRepository(session)
    history = await chat_repo.get_history(session_id, limit=10)
    session_cache = SessionCache()

    multimodal_memory = _extract_multimodal_memory(payload.context)
    cached_session = await session_cache.get(session_id)
    if cached_session and isinstance(cached_session.get("multimodal_memory"), dict):
        persisted = cached_session.get("multimodal_memory", {})
        multimodal_memory = _merge_multimodal_memory(persisted, multimodal_memory)
    else:
        multimodal_memory = _merge_multimodal_memory(_memory_from_history(history), multimodal_memory)

    request_cache_key = _cache_key(payload, history, multimodal_memory)
    relaxed_cache_key = _cache_key_relaxed(payload, multimodal_memory)

    if cached_session and isinstance(cached_session.get("responses"), dict):
        response_map = cached_session["responses"]
        cached_response = response_map.get(request_cache_key) or response_map.get(relaxed_cache_key)
        if cached_response:
            await chat_repo.add_message(
                session_id,
                str(current_user.id),
                "user",
                payload.message,
                memory=multimodal_memory,
            )
            await chat_repo.add_message(
                session_id,
                str(current_user.id),
                "assistant",
                cached_response.get("response", ""),
                cached_response.get("citations", []),
                memory=multimodal_memory,
            )
            return {
                "data": {
                    "session_id": session_id,
                    "message_id": f"msg_{uuid.uuid4().hex[:8]}",
                    "response": cached_response.get("response", "I was unable to process your request."),
                    "citations": cached_response.get("citations", []),
                    "suggested_follow_ups": cached_response.get("suggested_follow_ups", []),
                    "confidence_score": cached_response.get("confidence_score", 0.7),
                    "groundedness_score": cached_response.get("groundedness_score", 0.7),
                    "confidence_tier": cached_response.get("confidence_tier", "MEDIUM"),
                    "model": cached_response.get("model", get_settings().active_llm_mini_model),
                    "prompt_version": cached_response.get("prompt_version", "v1.0"),
                    "token_usage": cached_response.get("token_usage", {}),
                    "cache_hit": True,
                    "multimodal_memory": multimodal_memory,
                }
            }

    history_cached_response = _history_response_cache_lookup(history, payload.message)
    if history_cached_response:
        await chat_repo.add_message(
            session_id,
            str(current_user.id),
            "user",
            payload.message,
            memory=multimodal_memory,
        )
        await chat_repo.add_message(
            session_id,
            str(current_user.id),
            "assistant",
            history_cached_response.get("response", ""),
            history_cached_response.get("citations", []),
            memory=multimodal_memory,
        )
        return {
            "data": {
                "session_id": session_id,
                "message_id": f"msg_{uuid.uuid4().hex[:8]}",
                "response": history_cached_response.get("response", "I was unable to process your request."),
                "citations": history_cached_response.get("citations", []),
                "suggested_follow_ups": history_cached_response.get("suggested_follow_ups", []),
                "confidence_score": history_cached_response.get("confidence_score", 0.7),
                "groundedness_score": history_cached_response.get("confidence_score", 0.7),
                "confidence_tier": "MEDIUM",
                "model": get_settings().active_llm_mini_model,
                "prompt_version": "v1.0",
                "token_usage": {},
                "cache_hit": True,
                "multimodal_memory": multimodal_memory,
            }
        }

    state = {
        "user_id": str(current_user.id),
        "session_id": session_id,
        "user_message": payload.message,
        "retrieved_context": [],
        "multimodal_memory": multimodal_memory,
        "messages": history,
    }

    try:
        result = await chat_workflow.ainvoke(state)
    except Exception:
        result = {
            "response": "Sorry, I'm unable to respond right now. Please try again.",
            "citations": [],
            "confidence_score": 0.2,
            "groundedness_score": 0.2,
            "confidence_tier": "VERY_LOW",
        }

    msg_id = f"msg_{uuid.uuid4().hex[:8]}"
    await chat_repo.add_message(session_id, str(current_user.id), "user", payload.message)
    await chat_repo.add_message(
        session_id,
        str(current_user.id),
        "assistant",
        result.get("response", ""),
        result.get("citations"),
        memory=multimodal_memory,
    )

    cached_payload = await _build_final_payload(session, result, payload)

    responses = {}
    if cached_session and isinstance(cached_session.get("responses"), dict):
        responses = dict(cached_session.get("responses", {}))
    responses[request_cache_key] = cached_payload
    responses[relaxed_cache_key] = cached_payload

    await session_cache.set(
        session_id,
        {
            "multimodal_memory": multimodal_memory,
            "responses": dict(list(responses.items())[-30:]),
        },
    )

    return {
        "data": {
            "session_id": session_id,
            "message_id": msg_id,
            **cached_payload,
            "cache_hit": False,
            "multimodal_memory": multimodal_memory,
        }
    }


@router.post("/stream")
async def chat_stream(
    payload: ChatRequest,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(get_current_user),
    _rate_limit: None = Depends(enforce_rate_limit("chat", 20, 3600)),
):
    """Same behavior as POST /chat, but streams live agent progress (SSE)
    while the workflow runs, ending with a `done` event carrying the same
    payload shape /chat returns. On a cache hit, there's no agent execution
    to show, so it emits a single `done` event immediately."""
    from ai.workflows.prediction_workflow import chat_workflow
    from infrastructure.cache.redis_cache import SessionCache

    session_id = payload.session_id or f"sess_{uuid.uuid4().hex[:8]}"
    payload = await _run_guardrails(payload, session, current_user)

    chat_repo = SQLiteChatRepository(session)
    history = await chat_repo.get_history(session_id, limit=10)
    session_cache = SessionCache()

    multimodal_memory = _extract_multimodal_memory(payload.context)
    cached_session = await session_cache.get(session_id)
    if cached_session and isinstance(cached_session.get("multimodal_memory"), dict):
        persisted = cached_session.get("multimodal_memory", {})
        multimodal_memory = _merge_multimodal_memory(persisted, multimodal_memory)
    else:
        multimodal_memory = _merge_multimodal_memory(_memory_from_history(history), multimodal_memory)

    request_cache_key = _cache_key(payload, history, multimodal_memory)
    relaxed_cache_key = _cache_key_relaxed(payload, multimodal_memory)

    cached_response = None
    if cached_session and isinstance(cached_session.get("responses"), dict):
        response_map = cached_session["responses"]
        cached_response = response_map.get(request_cache_key) or response_map.get(relaxed_cache_key)
    if not cached_response:
        cached_response = _history_response_cache_lookup(history, payload.message)

    msg_id = f"msg_{uuid.uuid4().hex[:8]}"

    async def event_generator():
        if cached_response:
            await chat_repo.add_message(
                session_id, str(current_user.id), "user", payload.message, memory=multimodal_memory
            )
            await chat_repo.add_message(
                session_id,
                str(current_user.id),
                "assistant",
                cached_response.get("response", ""),
                cached_response.get("citations", []),
                memory=multimodal_memory,
            )
            yield live_progress.format_sse({
                "type": "done",
                "data": {
                    "session_id": session_id,
                    "message_id": msg_id,
                    "response": cached_response.get("response", "I was unable to process your request."),
                    "citations": cached_response.get("citations", []),
                    "suggested_follow_ups": cached_response.get("suggested_follow_ups", []),
                    "confidence_score": cached_response.get("confidence_score", 0.7),
                    "groundedness_score": cached_response.get(
                        "groundedness_score", cached_response.get("confidence_score", 0.7)
                    ),
                    "confidence_tier": cached_response.get("confidence_tier", "MEDIUM"),
                    "model": cached_response.get("model", get_settings().active_llm_mini_model),
                    "prompt_version": cached_response.get("prompt_version", "v1.0"),
                    "token_usage": cached_response.get("token_usage", {}),
                    "cache_hit": True,
                    "multimodal_memory": multimodal_memory,
                },
            })
            return

        run_id = f"run_{uuid.uuid4().hex[:10]}"
        queue = live_progress.register(run_id)
        state = {
            "user_id": str(current_user.id),
            "session_id": session_id,
            "run_id": run_id,
            "user_message": payload.message,
            "retrieved_context": [],
            "multimodal_memory": multimodal_memory,
            "messages": history,
        }

        task = asyncio.create_task(chat_workflow.ainvoke(state))
        try:
            while not task.done():
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=0.3)
                    yield live_progress.format_sse(event)
                except asyncio.TimeoutError:
                    continue
            while not queue.empty():
                yield live_progress.format_sse(queue.get_nowait())

            try:
                result = task.result()
            except Exception:
                result = {
                    "response": "Sorry, I'm unable to respond right now. Please try again.",
                    "citations": [],
                    "confidence_score": 0.2,
                    "groundedness_score": 0.2,
                    "confidence_tier": "VERY_LOW",
                }

            await chat_repo.add_message(session_id, str(current_user.id), "user", payload.message)
            await chat_repo.add_message(
                session_id,
                str(current_user.id),
                "assistant",
                result.get("response", ""),
                result.get("citations"),
                memory=multimodal_memory,
            )

            final_payload = await _build_final_payload(session, result, payload)

            responses = {}
            if cached_session and isinstance(cached_session.get("responses"), dict):
                responses = dict(cached_session.get("responses", {}))
            responses[request_cache_key] = final_payload
            responses[relaxed_cache_key] = final_payload
            await session_cache.set(
                session_id,
                {
                    "multimodal_memory": multimodal_memory,
                    "responses": dict(list(responses.items())[-30:]),
                },
            )

            yield live_progress.format_sse({
                "type": "done",
                "data": {
                    "session_id": session_id,
                    "message_id": msg_id,
                    **final_payload,
                    "cache_hit": False,
                    "multimodal_memory": multimodal_memory,
                },
            })
        finally:
            live_progress.unregister(run_id)

    return StreamingResponse(event_generator(), media_type="text/event-stream")
