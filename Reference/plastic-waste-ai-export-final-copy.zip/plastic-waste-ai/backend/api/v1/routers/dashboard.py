from __future__ import annotations

from collections import defaultdict
from datetime import date

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.v1.dependencies import get_current_user
from data.databases import get_db_session
from data.models.models import PredictionModel, WasteLogModel
from data.repositories.sqlite.recommendation_repository import SQLiteRecommendationRepository
from data.repositories.sqlite.waste_log_repository import SQLiteWasteLogRepository
from domain.entities.user import User

router = APIRouter()

_PERIOD_DAYS = {"last_7_days": 7, "last_30_days": 30, "last_90_days": 90, "last_365_days": 365}


@router.get("/summary")
async def get_summary(
    period: str = "last_30_days",
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(get_current_user),
):
    days = _PERIOD_DAYS.get(period, 30)
    period_end = date.today()
    period_start = date(period_end.year, 1, 1) if days >= 365 else date.fromordinal(period_end.toordinal() - days)
    prior_period_end = date.fromordinal(period_start.toordinal() - 1)
    prior_period_start = date.fromordinal(prior_period_end.toordinal() - days)

    waste_repo = SQLiteWasteLogRepository(session)
    summary = await waste_repo.get_summary(period_start, period_end)
    prior_summary = await waste_repo.get_summary(prior_period_start, prior_period_end)

    total_waste_kg = summary["total_waste_kg"]
    prior_total_waste_kg = prior_summary["total_waste_kg"]
    total_handling_cost = round(total_waste_kg * 12.59, 2)
    prior_handling_cost = round(prior_total_waste_kg * 12.59, 2)

    waste_change_pct = None
    if prior_total_waste_kg > 0:
        waste_change_pct = round((total_waste_kg - prior_total_waste_kg) / prior_total_waste_kg * 100, 1)

    cost_change_pct = None
    if prior_handling_cost > 0:
        cost_change_pct = round((total_handling_cost - prior_handling_cost) / prior_handling_cost * 100, 1)

    rec_repo = SQLiteRecommendationRepository(session)
    pending_recs = await rec_repo.list(status="PENDING", limit=100)
    recommendations_value = sum(r.estimated_cost_saving or 0 for r in pending_recs)

    rated = await session.execute(
        select(PredictionModel.feedback_rating).where(PredictionModel.feedback_rating.isnot(None))
    )
    ratings = [r for (r,) in rated.all()]
    prediction_accuracy_pct = (
        round(sum(1 for r in ratings if r == 1) / len(ratings) * 100, 1) if ratings else None
    )

    return {
        "data": {
            "total_waste_kg": total_waste_kg,
            "total_handling_cost": total_handling_cost,
            "waste_change_pct": waste_change_pct,
            "cost_change_pct": cost_change_pct,
            "active_recommendations": len(pending_recs),
            "recommendations_value": round(recommendations_value, 2),
            "recycling_rate_pct": summary["recycling_rate_pct"],
            "waste_by_plastic_type": summary["waste_by_type"],
            "prediction_accuracy_pct": prediction_accuracy_pct,
            "prediction_feedback_count": len(ratings),
            "period": period,
        }
    }


@router.get("/trends")
async def get_trends(
    granularity: str = "week",
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(get_current_user),
):
    result = await session.execute(select(WasteLogModel))
    logs = result.scalars().all()

    by_month: dict = defaultdict(lambda: {"total_waste_kg": 0.0, "breakdown": {}})
    for log in logs:
        month = log.log_date[:7]  # YYYY-MM
        by_month[month]["total_waste_kg"] += log.weight_kg
        by_month[month]["breakdown"][log.plastic_type] = (
            by_month[month]["breakdown"].get(log.plastic_type, 0.0) + log.weight_kg
        )

    series = [
        {
            "date": f"{m}-01",
            "total_waste_kg": round(v["total_waste_kg"], 1),
            "breakdown": {k: round(vv, 1) for k, vv in v["breakdown"].items()},
        }
        for m, v in sorted(by_month.items())
    ]
    return {"data": {"series": series, "granularity": granularity}}
