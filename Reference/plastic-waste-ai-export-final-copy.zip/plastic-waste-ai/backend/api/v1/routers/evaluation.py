from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime

from fastapi import APIRouter, Depends
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from api.v1.dependencies import get_current_user, require_role
from data.databases import get_db_session
from data.models.models import EvalRunModel
from domain.entities.user import User

router = APIRouter()


@router.get("/golden-set")
async def get_golden_set(current_user: User = Depends(get_current_user)):
    from ai.evaluation.runner import load_golden_queries

    return {"data": load_golden_queries()}


@router.post("/run", status_code=201)
async def run_eval(
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(require_role("manager", "admin")),
):
    from ai.evaluation.runner import run_evaluation

    started_at = datetime.now(UTC).isoformat()
    summary = await run_evaluation()
    finished_at = datetime.now(UTC).isoformat()

    row = EvalRunModel(
        id=str(uuid.uuid4()),
        started_at=started_at,
        finished_at=finished_at,
        n_queries=summary["n_queries"],
        avg_retrieval_precision=summary["avg_retrieval_precision"],
        avg_groundedness=summary["avg_groundedness"],
        avg_latency_ms=summary["avg_latency_ms"],
        pass_rate=summary["pass_rate"],
        results_json=json.dumps(summary["results"], default=str),
        triggered_by=str(current_user.id),
    )
    session.add(row)
    await session.commit()

    return {"data": {"id": row.id, **summary}}


@router.get("/runs")
async def list_runs(
    limit: int = 20,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(get_current_user),
):
    stmt = select(EvalRunModel).order_by(desc(EvalRunModel.created_at)).limit(min(limit, 100))
    rows = (await session.execute(stmt)).scalars().all()
    return {
        "data": [
            {
                "id": row.id,
                "started_at": row.started_at,
                "finished_at": row.finished_at,
                "n_queries": row.n_queries,
                "avg_retrieval_precision": row.avg_retrieval_precision,
                "avg_groundedness": row.avg_groundedness,
                "avg_latency_ms": row.avg_latency_ms,
                "pass_rate": row.pass_rate,
                "triggered_by": row.triggered_by,
                "created_at": row.created_at,
            }
            for row in rows
        ]
    }


@router.get("/runs/{run_id}")
async def get_run(
    run_id: str,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(require_role("manager", "admin")),
):
    stmt = select(EvalRunModel).where(EvalRunModel.id == run_id)
    row = (await session.execute(stmt)).scalar_one_or_none()
    if not row:
        return {"data": None}
    return {
        "data": {
            "id": row.id,
            "started_at": row.started_at,
            "finished_at": row.finished_at,
            "n_queries": row.n_queries,
            "avg_retrieval_precision": row.avg_retrieval_precision,
            "avg_groundedness": row.avg_groundedness,
            "avg_latency_ms": row.avg_latency_ms,
            "pass_rate": row.pass_rate,
            "results": json.loads(row.results_json or "[]"),
        }
    }
