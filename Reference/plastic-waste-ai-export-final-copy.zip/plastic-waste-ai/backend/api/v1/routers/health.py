from __future__ import annotations

from fastapi import APIRouter

router = APIRouter()


@router.get("/health")
async def health():
    from observability.health import health_payload

    return await health_payload()
