from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from api.v1.dependencies import get_current_user, require_role
from data.databases import get_db_session
from data.models.models import AITraceModel
from domain.entities.user import User
from observability import metrics
from observability.langfuse_runtime import get_langfuse_status

router = APIRouter()


@router.get("/summary")
async def get_summary(
    since_hours: int = 24,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(get_current_user),
):
    since = datetime.now(UTC) - timedelta(hours=since_hours)

    agents = await metrics.agent_summary(session, since)
    latency = await metrics.latency_percentiles(session, since)
    guardrail_triggers = await metrics.guardrail_trigger_counts(session, since)

    return {
        "data": {
            "since_hours": since_hours,
            "agents": agents,
            "total_calls": sum(a["calls"] for a in agents),
            "total_errors": sum(a["errors"] for a in agents),
            "total_cost_usd": round(sum(a["total_cost_usd"] for a in agents), 4),
            "total_tokens": sum(a["total_tokens"] for a in agents),
            "latency_ms": latency,
            "guardrail_triggers": guardrail_triggers,
            "langfuse": get_langfuse_status(),
        }
    }


@router.get("/traces")
async def list_traces(
    agent: str | None = None,
    status: str | None = None,
    limit: int = 100,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(require_role("manager", "admin")),
):
    stmt = select(AITraceModel)
    if agent:
        stmt = stmt.where(AITraceModel.agent_name == agent)
    if status:
        stmt = stmt.where(AITraceModel.status == status)
    stmt = stmt.order_by(desc(AITraceModel.created_at)).limit(min(limit, 500))

    rows = (await session.execute(stmt)).scalars().all()
    return {
        "data": [
            {
                "id": row.id,
                "agent_name": row.agent_name,
                "workflow_id": row.workflow_id,
                "correlation_id": row.correlation_id,
                "latency_ms": row.latency_ms,
                "model": row.model,
                "input_tokens": row.input_tokens,
                "output_tokens": row.output_tokens,
                "cost_usd": row.cost_usd,
                "status": row.status,
                "confidence_score": row.confidence_score,
                "error_message": row.error_message,
                "created_at": row.created_at,
            }
            for row in rows
        ]
    }


def _parse_json(raw: str | None):
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return raw


@router.get("/traces/{trace_id}")
async def get_trace_detail(
    trace_id: str,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(require_role("manager", "admin")),
):
    row = (
        await session.execute(select(AITraceModel).where(AITraceModel.id == trace_id))
    ).scalar_one_or_none()
    if not row:
        raise HTTPException(status_code=404, detail="Trace not found")

    return {
        "data": {
            "id": row.id,
            "agent_name": row.agent_name,
            "workflow_id": row.workflow_id,
            "correlation_id": row.correlation_id,
            "started_at": row.started_at,
            "ended_at": row.ended_at,
            "latency_ms": row.latency_ms,
            "model": row.model,
            "input_tokens": row.input_tokens,
            "output_tokens": row.output_tokens,
            "cost_usd": row.cost_usd,
            "status": row.status,
            "confidence_score": row.confidence_score,
            "error_message": row.error_message,
            "input_summary": _parse_json(row.input_summary),
            "output_summary": _parse_json(row.output_summary),
            "created_at": row.created_at,
        }
    }
