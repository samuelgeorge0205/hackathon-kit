from __future__ import annotations

from datetime import date
from uuid import UUID

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from api.v1.dependencies import get_current_user, require_role
from data.databases import get_db_session, get_session_factory
from data.repositories.sqlite.prediction_repository import SQLitePredictionRepository
from domain.entities.prediction import Prediction
from domain.entities.user import User
from infrastructure.config.settings import get_settings
from observability import live_progress

router = APIRouter()


class WastePredictionRequest(BaseModel):
    supplier_id: str | None = None
    product_id: str | None = None
    location_type: str = "ALL"
    location_id: str | None = None
    period_start: date
    period_end: date
    order_volume: int | None = None


def _serialize_prediction(prediction: Prediction) -> dict:
    """Shared by GET /waste/{id} and the SSE `workflow_complete` event so
    both surfaces return the exact same flattened shape the frontend expects."""
    body = {"prediction_id": str(prediction.id), "status": prediction.output_json.get("status", "UNKNOWN")}
    body.update(prediction.output_json.get("prediction", {}))
    body["confidence_score"] = prediction.confidence_score
    body["explanation"] = prediction.explanation
    body["handling_cost"] = prediction.output_json.get("handling_cost")
    body["recommendations"] = prediction.output_json.get("recommendations", [])
    body["sources"] = prediction.output_json.get("sources", [])
    if "error" in prediction.output_json:
        body["error"] = prediction.output_json["error"]
    return body


async def _run_prediction(prediction_id: UUID, params: dict, user_id: str) -> None:
    from ai.workflows.prediction_workflow import prediction_workflow

    session_factory = get_session_factory()
    async with session_factory() as session:
        repo = SQLitePredictionRepository(session)
        prediction = await repo.get_by_id(prediction_id)
        if prediction is None:
            return

        state = {
            "user_id": user_id,
            "workflow_id": str(prediction_id),
            "prediction_type": "WASTE_VOLUME",
            "input_params": params,
            "user_query": f"Predict waste for period {params.get('period_start')} to {params.get('period_end')}",
            "retrieved_context": [],
            "historical_data": await _get_historical_data(session, params),
        }

        run_id = str(prediction_id)
        try:
            result = await prediction_workflow.ainvoke(state)
            prediction.output_json = {
                "status": "COMPLETE",
                "prediction": result.get("prediction", {}),
                "handling_cost": result.get("handling_cost"),
                "recommendations": result.get("recommendations", []),
                "sources": result.get("sources", []),
            }
            prediction.confidence_score = result.get("confidence_score", 0.0)
            prediction.explanation = result.get("explanation", "")
            prediction.predicted_value = (result.get("prediction") or {}).get("predicted_waste_kg")
            prediction.model_version = get_settings().active_llm_primary_model
            await repo.save(prediction)
            live_progress.publish(run_id, {
                "type": "workflow_complete",
                "data": _serialize_prediction(prediction),
            })
        except Exception as exc:
            prediction.output_json = {"status": "ERROR", "error": str(exc)}
            await repo.save(prediction)
            live_progress.publish(run_id, {"type": "workflow_error", "error": str(exc)})


async def _get_historical_data(session: AsyncSession, params: dict) -> list[dict]:
    """Load relevant historical waste logs for context — a list of individual
    log records (not an aggregate), since the prediction agent's fallback
    calculation averages weight_kg per record."""
    from sqlalchemy import select

    from data.models.models import WasteLogModel
    from data.repositories.sqlite.waste_log_repository import SQLiteWasteLogRepository

    earliest = date(2000, 1, 1)
    if params.get("product_id"):
        repo = SQLiteWasteLogRepository(session)
        logs = await repo.get_by_product(params["product_id"], earliest, date.today())
        records = logs[:20]
        return [
            {
                "id": log.id,
                "log_date": log.log_date.isoformat(),
                "plastic_type": log.plastic_type,
                "weight_kg": log.weight_kg,
                "disposal_method": log.disposal_method,
            }
            for log in records
        ]

    result = await session.execute(
        select(WasteLogModel).order_by(WasteLogModel.log_date.desc()).limit(20)
    )
    return [
        {
            "id": row.id,
            "log_date": row.log_date,
            "plastic_type": row.plastic_type,
            "weight_kg": row.weight_kg,
            "disposal_method": row.disposal_method,
        }
        for row in result.scalars().all()
    ]


@router.post("/waste", status_code=202)
async def create_waste_prediction(
    payload: WastePredictionRequest,
    background_tasks: BackgroundTasks,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(require_role("analyst", "manager", "admin")),
):
    params = payload.model_dump(mode="json")
    prediction = Prediction(
        user_id=current_user.id,
        prediction_type="WASTE_VOLUME",
        input_params=params,
        output_json={"status": "PROCESSING"},
        confidence_score=0.0,
        model_version="pending",
    )
    repo = SQLitePredictionRepository(session)
    await repo.save(prediction)
    # Register the live-progress channel before the background task starts,
    # so agent_start events are buffered even if the client hasn't opened its
    # /stream connection yet.
    live_progress.register(str(prediction.id))
    background_tasks.add_task(_run_prediction, prediction.id, params, str(current_user.id))
    return {"data": {"prediction_id": str(prediction.id), "status": "PROCESSING", "estimated_seconds": 5}}


@router.get("/waste/{prediction_id}/stream")
async def stream_waste_prediction(
    prediction_id: str,
    current_user: User = Depends(get_current_user),
):
    run_id = prediction_id

    async def event_generator():
        queue = live_progress.subscribe(run_id)
        try:
            while True:
                event = await queue.get()
                yield live_progress.format_sse(event)
                if event.get("type") in live_progress.TERMINAL_EVENT_TYPES:
                    break
        finally:
            live_progress.unregister(run_id)

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@router.get("/waste/{prediction_id}")
async def get_waste_prediction(
    prediction_id: str,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(get_current_user),
):
    repo = SQLitePredictionRepository(session)
    try:
        prediction = await repo.get_by_id(UUID(prediction_id))
    except ValueError:
        prediction = None
    if not prediction:
        raise HTTPException(status_code=404, detail="Prediction not found")

    return {"data": _serialize_prediction(prediction)}
