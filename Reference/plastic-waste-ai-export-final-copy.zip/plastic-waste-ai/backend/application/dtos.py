from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from uuid import UUID


@dataclass
class PredictionInputDto:
    user_id: UUID
    period_start: date
    period_end: date
    supplier_id: str | None = None
    product_id: str | None = None
    location_type: str = "ALL"
    location_id: str | None = None
    order_volume: int | None = None


@dataclass
class PredictionOutputDto:
    prediction_id: UUID
    status: str
    predicted_waste_kg: float | None = None
    confidence_score: float | None = None
    explanation: str | None = None
    handling_cost: dict | None = None
    plastic_type_breakdown: dict = field(default_factory=dict)
    sources: list[dict] = field(default_factory=list)


@dataclass
class UploadResultDto:
    accepted: int
    rejected: int
    errors: list[str] = field(default_factory=list)


@dataclass
class RecommendationDto:
    id: str
    product_id: str
    recommendation_type: str
    description: str
    confidence_score: float
    estimated_waste_reduction_kg: float | None = None
    estimated_cost_saving: float | None = None
    status: str = "PENDING"
    implementation_effort: str = "MEDIUM"
