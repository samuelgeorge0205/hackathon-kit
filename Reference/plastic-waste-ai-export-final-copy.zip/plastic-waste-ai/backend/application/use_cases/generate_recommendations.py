from __future__ import annotations

import structlog
from uuid import UUID

from application.dtos import RecommendationDto
from domain.entities.recommendation import Recommendation
from domain.repositories.i_recommendation_repository import IRecommendationRepository

logger = structlog.get_logger(__name__)


class GenerateRecommendationsUseCase:
    """Persists AI-generated recommendations from the prediction workflow."""

    def __init__(self, recommendation_repo: IRecommendationRepository) -> None:
        self._repo = recommendation_repo

    async def execute(self, raw_recommendations: list[dict], product_id: str) -> list[RecommendationDto]:
        saved: list[RecommendationDto] = []

        for raw in raw_recommendations:
            try:
                rec = Recommendation(
                    product_id=product_id,
                    recommendation_type=raw.get("recommendation_type", "MATERIAL_CHANGE"),
                    description=raw.get("description", ""),
                    rationale=raw.get("rationale", ""),
                    confidence_score=float(raw.get("confidence_score", 0.5)),
                    estimated_waste_reduction_kg=raw.get("estimated_waste_reduction_kg"),
                    estimated_cost_saving=raw.get("estimated_cost_saving"),
                    implementation_effort=raw.get("implementation_effort", "MEDIUM"),
                    sources=raw.get("sources", []),
                )
                await self._repo.save(rec)
                saved.append(
                    RecommendationDto(
                        id=rec.id,
                        product_id=rec.product_id,
                        recommendation_type=rec.recommendation_type,
                        description=rec.description,
                        confidence_score=rec.confidence_score,
                        estimated_waste_reduction_kg=rec.estimated_waste_reduction_kg,
                        estimated_cost_saving=rec.estimated_cost_saving,
                        status=rec.status,
                        implementation_effort=rec.implementation_effort,
                    )
                )
            except (KeyError, ValueError, TypeError) as exc:
                logger.warning("recommendation_skipped", error=str(exc))

        logger.info("recommendations_generated", count=len(saved))
        return saved
