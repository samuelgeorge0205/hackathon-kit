from __future__ import annotations

import structlog
from datetime import date

from application.dtos import UploadResultDto
from domain.entities.waste_log import WasteLog
from domain.repositories.i_waste_log_repository import IWasteLogRepository

logger = structlog.get_logger(__name__)


class IngestWasteLogsUseCase:
    """Validates and persists a batch of waste log records."""

    def __init__(self, waste_log_repo: IWasteLogRepository) -> None:
        self._repo = waste_log_repo

    async def execute(self, records: list[dict], uploaded_by: str) -> UploadResultDto:
        accepted, rejected, errors = 0, 0, []

        for i, record in enumerate(records):
            try:
                log = WasteLog(
                    source_type=record["source_type"],
                    source_id=record["source_id"],
                    log_date=date.fromisoformat(record["log_date"]),
                    plastic_type=record["plastic_type"],
                    weight_kg=float(record["weight_kg"]),
                    disposal_method=record["disposal_method"],
                    product_id=record.get("product_id"),
                    packaging_id=record.get("packaging_id"),
                    unit_count=record.get("unit_count"),
                    notes=record.get("notes"),
                    uploaded_by=uploaded_by,
                )
                await self._repo.save(log)
                accepted += 1
            except (KeyError, ValueError, TypeError) as exc:
                rejected += 1
                errors.append(f"Row {i + 1}: {exc}")
                logger.warning("waste_log_rejected", row=i + 1, error=str(exc))

        logger.info("waste_logs_ingested", accepted=accepted, rejected=rejected)
        return UploadResultDto(accepted=accepted, rejected=rejected, errors=errors)
