from __future__ import annotations

import structlog
from datetime import date
from uuid import UUID

from application.dtos import PredictionInputDto, PredictionOutputDto
from domain.entities.prediction import Prediction
from domain.repositories.i_prediction_repository import IPredictionRepository

logger = structlog.get_logger(__name__)


class RunWastePredictionUseCase:
    """Persists a pending prediction and enqueues the AI workflow as a background task."""

    def __init__(self, prediction_repo: IPredictionRepository) -> None:
        self._repo = prediction_repo

    async def execute(self, dto: PredictionInputDto) -> PredictionOutputDto:
        prediction = Prediction(
            user_id=dto.user_id,
            prediction_type="WASTE_VOLUME",
            input_params={
                "supplier_id": dto.supplier_id,
                "product_id": dto.product_id,
                "location_type": dto.location_type,
                "location_id": dto.location_id,
                "period_start": dto.period_start.isoformat(),
                "period_end": dto.period_end.isoformat(),
                "order_volume": dto.order_volume,
            },
            output_json={"status": "PROCESSING"},
            confidence_score=0.0,
            model_version="pending",
        )
        await self._repo.save(prediction)
        logger.info("prediction_created", prediction_id=str(prediction.id))
        return PredictionOutputDto(
            prediction_id=prediction.id,
            status="PROCESSING",
        )
