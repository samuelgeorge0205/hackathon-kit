# Data Layer

This folder owns runtime data concerns.

- databases/: database session, engines, and model entry points
- database_files/: physical DB and vector-store runtime assets
- models/: SQLAlchemy ORM models
- repositories/: persistence implementations
- seed_db.py, seed_rag.py: bootstrap and ingestion scripts

Notes:
- Structured seed inputs live at repository root in `input-data/structured/`.
- Knowledge base markdown inputs live at repository root in `input-data/knowledge-base/`.
