# Database Files Section

Purpose:
- Runtime storage assets.

Current files:
- data/database_files/app.db
- data/database_files/chroma/

Operational guidance:
- Treat these as environment artifacts, not source-controlled schema.
