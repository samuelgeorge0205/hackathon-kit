# Databases Section

Purpose:
- Clear entry points for database engines, sessions, and model registry.

Current runtime ownership:
- data/databases/engine.py
- data/models/models.py

Use imports from `data.databases` in new code.
