from __future__ import annotations

import json
from uuid import uuid4

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from data.models.models import ChatMessageModel


class SQLiteChatRepository:
    """Lightweight session-history store — chat messages aren't a domain entity, just a transcript."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add_message(
        self,
        session_id: str,
        user_id: str | None,
        role: str,
        content: str,
        citations: list[dict] | None = None,
        memory: dict | None = None,
    ) -> None:
        payload = {
            "citations": citations or [],
            "memory": memory or {},
        }
        row = ChatMessageModel(
            id=str(uuid4()),
            session_id=session_id,
            user_id=user_id,
            role=role,
            content=content,
            citations=json.dumps(payload),
        )
        self._session.add(row)
        await self._session.commit()

    async def get_history(self, session_id: str, limit: int = 10) -> list[dict]:
        result = await self._session.execute(
            select(ChatMessageModel)
            .where(ChatMessageModel.session_id == session_id)
            .order_by(ChatMessageModel.created_at.desc())
            .limit(limit)
        )
        rows = list(reversed(result.scalars().all()))
        history = []
        for row in rows:
            payload = {}
            if row.citations:
                try:
                    payload = json.loads(row.citations)
                except Exception:
                    payload = {}
            history.append(
                {
                    "role": row.role,
                    "content": row.content,
                    "citations": payload.get("citations", []),
                    "memory": payload.get("memory", {}),
                }
            )
        return history
