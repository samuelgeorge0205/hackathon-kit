from __future__ import annotations

import json
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from data.models.models import PredictionModel
from domain.entities.prediction import Prediction
from domain.repositories.i_prediction_repository import IPredictionRepository


def _to_entity(row: PredictionModel) -> Prediction:
    return Prediction(
        id=UUID(row.id),
        user_id=UUID(row.user_id),
        prediction_type=row.prediction_type,
        input_params=json.loads(row.input_params),
        output_json=json.loads(row.output_json),
        predicted_value=row.predicted_value,
        confidence_score=row.confidence_score,
        model_version=row.model_version,
        explanation=row.explanation,
        feedback_rating=row.feedback_rating,
        feedback_comment=row.feedback_comment,
    )


class SQLitePredictionRepository(IPredictionRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, prediction: Prediction) -> Prediction:
        row = await self._session.get(PredictionModel, str(prediction.id))
        if row is None:
            row = PredictionModel(id=str(prediction.id))
            self._session.add(row)
        row.user_id = str(prediction.user_id)
        row.prediction_type = prediction.prediction_type
        row.input_params = json.dumps(prediction.input_params, default=str)
        row.output_json = json.dumps(prediction.output_json, default=str)
        row.predicted_value = prediction.predicted_value
        row.confidence_score = prediction.confidence_score
        row.model_version = prediction.model_version
        row.explanation = prediction.explanation
        row.feedback_rating = prediction.feedback_rating
        row.feedback_comment = prediction.feedback_comment
        await self._session.commit()
        return prediction

    async def get_by_id(self, id: UUID) -> Prediction | None:
        row = await self._session.get(PredictionModel, str(id))
        return _to_entity(row) if row else None

    async def list_by_user(
        self, user_id: UUID, limit: int = 20, offset: int = 0
    ) -> list[Prediction]:
        result = await self._session.execute(
            select(PredictionModel)
            .where(PredictionModel.user_id == str(user_id))
            .order_by(PredictionModel.created_at.desc())
            .offset(offset)
            .limit(limit)
        )
        return [_to_entity(row) for row in result.scalars().all()]

    async def update_feedback(self, id: UUID, rating: int, comment: str | None) -> None:
        row = await self._session.get(PredictionModel, str(id))
        if row is None:
            return
        row.feedback_rating = rating
        row.feedback_comment = comment
        await self._session.commit()
