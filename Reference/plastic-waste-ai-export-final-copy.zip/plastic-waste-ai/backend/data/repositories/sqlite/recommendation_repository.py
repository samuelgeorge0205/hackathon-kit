from __future__ import annotations

import json

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from data.models.models import RecommendationModel
from domain.entities.recommendation import Recommendation
from domain.repositories.i_recommendation_repository import IRecommendationRepository


def _to_entity(row: RecommendationModel) -> Recommendation:
    return Recommendation(
        id=row.id,
        product_id=row.product_id,
        recommendation_type=row.recommendation_type,
        description=row.description,
        rationale=row.rationale,
        confidence_score=row.confidence_score,
        estimated_waste_reduction_kg=row.estimated_waste_reduction_kg,
        estimated_cost_saving=row.estimated_cost_saving,
        status=row.status,
        implementation_effort=row.implementation_effort,
        status_changed_by=row.status_changed_by,
        status_reason=row.status_reason,
        sources=json.loads(row.sources) if row.sources else [],
    )


class SQLiteRecommendationRepository(IRecommendationRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, recommendation: Recommendation) -> Recommendation:
        row = await self._session.get(RecommendationModel, str(recommendation.id))
        if row is None:
            row = RecommendationModel(id=str(recommendation.id))
            self._session.add(row)
        row.product_id = str(recommendation.product_id)
        row.recommendation_type = recommendation.recommendation_type
        row.description = recommendation.description
        row.rationale = recommendation.rationale
        row.estimated_waste_reduction_kg = recommendation.estimated_waste_reduction_kg
        row.estimated_cost_saving = recommendation.estimated_cost_saving
        row.confidence_score = recommendation.confidence_score
        row.status = recommendation.status
        row.implementation_effort = recommendation.implementation_effort
        row.status_changed_by = (
            str(recommendation.status_changed_by) if recommendation.status_changed_by else None
        )
        row.status_reason = recommendation.status_reason
        row.sources = json.dumps(recommendation.sources)
        await self._session.commit()
        return recommendation

    async def get_by_id(self, id: str) -> Recommendation | None:
        row = await self._session.get(RecommendationModel, str(id))
        return _to_entity(row) if row else None

    async def list(
        self,
        status: str | None = None,
        product_id: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> list[Recommendation]:
        query = select(RecommendationModel)
        if status:
            query = query.where(RecommendationModel.status == status)
        if product_id:
            query = query.where(RecommendationModel.product_id == str(product_id))
        query = query.order_by(RecommendationModel.created_at.desc()).offset(offset).limit(limit)
        result = await self._session.execute(query)
        return [_to_entity(row) for row in result.scalars().all()]

    async def update_status(self, recommendation: Recommendation) -> None:
        row = await self._session.get(RecommendationModel, str(recommendation.id))
        if row is None:
            return
        row.status = recommendation.status
        row.status_changed_by = (
            str(recommendation.status_changed_by) if recommendation.status_changed_by else None
        )
        row.status_reason = recommendation.status_reason
        await self._session.commit()
