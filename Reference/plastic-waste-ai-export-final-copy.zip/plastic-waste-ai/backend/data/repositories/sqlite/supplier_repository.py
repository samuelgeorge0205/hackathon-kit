from __future__ import annotations

import json

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from data.models.models import SupplierModel
from domain.entities.supplier import Supplier
from domain.repositories.i_supplier_repository import ISupplierRepository


def _to_entity(row: SupplierModel) -> Supplier:
    return Supplier(
        id=row.id,
        name=row.name,
        country=row.country,
        external_id=row.external_id,
        region=row.region,
        tier=row.tier,
        certifications=json.loads(row.certifications) if row.certifications else [],
        sustainability_score=row.sustainability_score,
        contact_email=row.contact_email,
    )


class SQLiteSupplierRepository(ISupplierRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, supplier: Supplier) -> Supplier:
        row = await self._session.get(SupplierModel, str(supplier.id))
        if row is None:
            row = SupplierModel(id=str(supplier.id))
            self._session.add(row)
        row.external_id = supplier.external_id
        row.name = supplier.name
        row.country = supplier.country
        row.region = supplier.region
        row.tier = supplier.tier
        row.certifications = json.dumps(supplier.certifications)
        row.sustainability_score = supplier.sustainability_score
        row.contact_email = supplier.contact_email
        await self._session.commit()
        return supplier

    async def get_by_id(self, id: str) -> Supplier | None:
        row = await self._session.get(SupplierModel, str(id))
        return _to_entity(row) if row else None

    async def get_by_external_id(self, external_id: str) -> Supplier | None:
        result = await self._session.execute(
            select(SupplierModel).where(SupplierModel.external_id == external_id)
        )
        row = result.scalar_one_or_none()
        return _to_entity(row) if row else None

    async def list(self, limit: int = 20, offset: int = 0) -> list[Supplier]:
        result = await self._session.execute(select(SupplierModel).offset(offset).limit(limit))
        return [_to_entity(row) for row in result.scalars().all()]
