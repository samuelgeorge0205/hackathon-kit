from __future__ import annotations

from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from data.models.models import UserModel
from domain.entities.user import User
from domain.repositories.i_user_repository import IUserRepository


def _to_entity(row: UserModel) -> User:
    return User(
        id=UUID(row.id),
        email=row.email,
        hashed_password=row.hashed_password,
        full_name=row.full_name,
        role=row.role,
        department=row.department,
        is_active=row.is_active,
        failed_login_attempts=row.failed_login_attempts or 0,
    )


class SQLiteUserRepository(IUserRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, user: User) -> User:
        row = UserModel(
            id=str(user.id),
            email=user.email,
            hashed_password=user.hashed_password,
            full_name=user.full_name,
            role=user.role,
            department=user.department,
            is_active=user.is_active,
            failed_login_attempts=user.failed_login_attempts,
        )
        self._session.add(row)
        await self._session.commit()
        return user

    async def get_by_id(self, id: UUID) -> User | None:
        row = await self._session.get(UserModel, str(id))
        return _to_entity(row) if row else None

    async def get_by_email(self, email: str) -> User | None:
        result = await self._session.execute(
            select(UserModel).where(UserModel.email == email.lower())
        )
        row = result.scalar_one_or_none()
        return _to_entity(row) if row else None

    async def list(self, limit: int = 20, offset: int = 0) -> list[User]:
        result = await self._session.execute(select(UserModel).offset(offset).limit(limit))
        return [_to_entity(row) for row in result.scalars().all()]

    async def update(self, user: User) -> User:
        row = await self._session.get(UserModel, str(user.id))
        if row is None:
            return await self.save(user)
        row.full_name = user.full_name
        row.role = user.role
        row.department = user.department
        row.is_active = user.is_active
        row.failed_login_attempts = user.failed_login_attempts
        row.hashed_password = user.hashed_password
        await self._session.commit()
        return user
