from __future__ import annotations

from datetime import date

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from data.models.models import WasteLogModel
from domain.entities.waste_log import WasteLog
from domain.repositories.i_waste_log_repository import IWasteLogRepository


def _to_entity(row: WasteLogModel) -> WasteLog:
    return WasteLog(
        id=row.id,
        source_type=row.source_type,
        source_id=row.source_id,
        log_date=date.fromisoformat(row.log_date),
        plastic_type=row.plastic_type,
        weight_kg=row.weight_kg,
        disposal_method=row.disposal_method,
        product_id=row.product_id,
        packaging_id=row.packaging_id,
        unit_count=row.unit_count,
        verified=row.verified,
        notes=row.notes,
        uploaded_by=row.uploaded_by,
    )


class SQLiteWasteLogRepository(IWasteLogRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, waste_log: WasteLog) -> WasteLog:
        row = await self._session.get(WasteLogModel, str(waste_log.id))
        if row is None:
            row = WasteLogModel(id=str(waste_log.id))
            self._session.add(row)
        row.source_type = waste_log.source_type
        row.source_id = str(waste_log.source_id)
        row.product_id = str(waste_log.product_id) if waste_log.product_id else None
        row.packaging_id = str(waste_log.packaging_id) if waste_log.packaging_id else None
        row.log_date = waste_log.log_date.isoformat()
        row.plastic_type = waste_log.plastic_type
        row.weight_kg = waste_log.weight_kg
        row.unit_count = waste_log.unit_count
        row.disposal_method = waste_log.disposal_method
        row.verified = waste_log.verified
        row.notes = waste_log.notes
        row.uploaded_by = str(waste_log.uploaded_by) if waste_log.uploaded_by else None
        await self._session.commit()
        return waste_log

    async def get_by_id(self, id: str) -> WasteLog | None:
        row = await self._session.get(WasteLogModel, str(id))
        return _to_entity(row) if row else None

    async def list_by_source(
        self, source_type: str, source_id: str, limit: int = 20, offset: int = 0
    ) -> list[WasteLog]:
        result = await self._session.execute(
            select(WasteLogModel)
            .where(
                WasteLogModel.source_type == source_type,
                WasteLogModel.source_id == str(source_id),
            )
            .order_by(WasteLogModel.log_date.desc())
            .offset(offset)
            .limit(limit)
        )
        return [_to_entity(row) for row in result.scalars().all()]

    async def get_by_product(
        self, product_id: str, from_date: date, to_date: date
    ) -> list[WasteLog]:
        result = await self._session.execute(
            select(WasteLogModel).where(
                WasteLogModel.product_id == str(product_id),
                WasteLogModel.log_date >= from_date.isoformat(),
                WasteLogModel.log_date <= to_date.isoformat(),
            )
        )
        return [_to_entity(row) for row in result.scalars().all()]

    async def get_summary(self, from_date: date, to_date: date) -> dict:
        result = await self._session.execute(
            select(WasteLogModel).where(
                WasteLogModel.log_date >= from_date.isoformat(),
                WasteLogModel.log_date <= to_date.isoformat(),
            )
        )
        rows = result.scalars().all()
        total_waste_kg = sum(row.weight_kg for row in rows)
        by_type: dict[str, float] = {}
        by_disposal: dict[str, float] = {}
        for row in rows:
            by_type[row.plastic_type] = by_type.get(row.plastic_type, 0.0) + row.weight_kg
            by_disposal[row.disposal_method] = by_disposal.get(row.disposal_method, 0.0) + row.weight_kg
        recycled_kg = by_disposal.get("RECYCLED", 0.0)
        return {
            "total_waste_kg": round(total_waste_kg, 1),
            "log_count": len(rows),
            "waste_by_type": {k: round(v, 1) for k, v in by_type.items()},
            "waste_by_disposal_method": {k: round(v, 1) for k, v in by_disposal.items()},
            "recycling_rate_pct": round(recycled_kg / total_waste_kg * 100, 1) if total_waste_kg else 0.0,
            "from_date": from_date.isoformat(),
            "to_date": to_date.isoformat(),
        }
