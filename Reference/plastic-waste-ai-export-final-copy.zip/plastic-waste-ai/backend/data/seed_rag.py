from __future__ import annotations

from infrastructure.config.paths import get_knowledge_base_dir

_KB_DIR = get_knowledge_base_dir()


async def seed_rag_knowledge_base() -> None:
    """Ingest baseline reference documents into the RAG vector store.

    Idempotent: RAGPipeline.ingest() upserts chunks keyed by doc_id + chunk
    index, so re-running this on every startup just overwrites the same
    entries rather than duplicating them.
    """
    from ai.rag.pipeline import RAGPipeline

    if not _KB_DIR.exists():
        return

    pipeline = RAGPipeline()
    for doc_path in sorted(_KB_DIR.glob("*.md")):
        text = doc_path.read_text(encoding="utf-8")
        title = doc_path.stem.replace("-", " ").title()
        await pipeline.ingest(text, metadata={"title": title}, doc_id=doc_path.stem)

    print(f"Ingested {len(list(_KB_DIR.glob('*.md')))} knowledge-base documents from {_KB_DIR}")
