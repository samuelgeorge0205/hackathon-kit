from __future__ import annotations

from dataclasses import dataclass, field
from uuid import UUID, uuid4


@dataclass
class AuditLog:
    event_type: str
    id: UUID = field(default_factory=uuid4)
    user_id: UUID | None = None
    entity_type: str | None = None
    entity_id: UUID | None = None
    before_json: dict | None = None
    after_json: dict | None = None
    ip_address: str | None = None
    user_agent: str | None = None
    correlation_id: str | None = None
