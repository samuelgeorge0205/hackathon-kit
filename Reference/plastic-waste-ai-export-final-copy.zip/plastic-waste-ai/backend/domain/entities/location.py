from __future__ import annotations

from dataclasses import dataclass, field
from uuid import UUID, uuid4


@dataclass
class Warehouse:
    name: str
    location: str
    country: str = "GB"
    id: UUID = field(default_factory=uuid4)
    external_id: str | None = None
    region: str | None = None
    capacity_m3: float | None = None
    is_active: bool = True


@dataclass
class Store:
    name: str
    format: str
    location: str
    country: str = "GB"
    id: UUID = field(default_factory=uuid4)
    external_id: str | None = None
    region: str | None = None
    is_active: bool = True

    _VALID_FORMATS = frozenset({"HYPERMARKET", "SUPERMARKET", "EXPRESS", "ONLINE"})

    def __post_init__(self) -> None:
        if self.format not in self._VALID_FORMATS:
            raise ValueError(f"format must be one of {self._VALID_FORMATS}")
