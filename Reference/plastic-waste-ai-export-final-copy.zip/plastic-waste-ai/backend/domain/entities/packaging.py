from __future__ import annotations

from dataclasses import dataclass, field
from uuid import UUID, uuid4

_VALID_MATERIAL_TYPES = frozenset({"PET", "HDPE", "PVC", "LDPE", "PP", "PS", "MIXED"})


@dataclass
class Packaging:
    product_id: UUID
    material_type: str
    weight_g: float
    id: UUID = field(default_factory=uuid4)
    description: str | None = None
    recyclable: bool = False
    recycled_content_pct: float | None = None
    layers: int = 1
    layers_detail: list[dict] | None = None
    is_primary: bool = True
    supplier_declared: bool = False

    def __post_init__(self) -> None:
        if self.material_type not in _VALID_MATERIAL_TYPES:
            raise ValueError(f"material_type must be one of {_VALID_MATERIAL_TYPES}")
        if self.weight_g <= 0:
            raise ValueError("weight_g must be greater than zero")
        if self.recycled_content_pct is not None and not (0 <= self.recycled_content_pct <= 100):
            raise ValueError("recycled_content_pct must be between 0 and 100")
