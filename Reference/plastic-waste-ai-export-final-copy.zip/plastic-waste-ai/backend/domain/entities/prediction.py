from __future__ import annotations

from dataclasses import dataclass, field
from uuid import UUID, uuid4


@dataclass
class Prediction:
    user_id: UUID
    prediction_type: str
    input_params: dict
    output_json: dict
    confidence_score: float
    model_version: str
    id: UUID = field(default_factory=uuid4)
    predicted_value: float | None = None
    explanation: str | None = None
    feedback_rating: int | None = None
    feedback_comment: str | None = None

    _VALID_TYPES = frozenset({"WASTE_VOLUME", "HANDLING_COST"})

    def __post_init__(self) -> None:
        if self.prediction_type not in self._VALID_TYPES:
            raise ValueError(f"prediction_type must be one of {self._VALID_TYPES}")
        if not (0.0 <= self.confidence_score <= 1.0):
            raise ValueError("confidence_score must be between 0.0 and 1.0")
        if self.feedback_rating is not None and self.feedback_rating not in (-1, 1):
            raise ValueError("feedback_rating must be 1 (positive) or -1 (negative)")
