from __future__ import annotations

from dataclasses import dataclass, field
from uuid import UUID, uuid4


@dataclass
class Product:
    supplier_id: UUID
    sku: str
    name: str
    category: str
    id: UUID = field(default_factory=uuid4)
    sub_category: str | None = None
    weight_kg: float | None = None
    unit_of_measure: str = "EACH"
    is_active: bool = True

    def __post_init__(self) -> None:
        if not self.sku.strip():
            raise ValueError("sku cannot be empty")
        if self.weight_kg is not None and self.weight_kg <= 0:
            raise ValueError("weight_kg must be greater than zero")
