from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from uuid import UUID, uuid4

_VALID_STATUSES = frozenset({"DRAFT", "CONFIRMED", "SHIPPED", "RECEIVED", "CANCELLED"})


@dataclass
class PurchaseOrder:
    supplier_id: UUID
    order_date: date
    id: UUID = field(default_factory=uuid4)
    external_po_number: str | None = None
    expected_delivery_date: date | None = None
    status: str = "DRAFT"
    currency: str = "GBP"
    total_value: float | None = None
    notes: str | None = None
    created_by: UUID | None = None

    def __post_init__(self) -> None:
        if self.status not in _VALID_STATUSES:
            raise ValueError(f"status must be one of {_VALID_STATUSES}")


@dataclass
class POLineItem:
    po_id: UUID
    product_id: UUID
    quantity: int
    id: UUID = field(default_factory=uuid4)
    packaging_id: UUID | None = None
    unit_price: float | None = None
    currency: str | None = None

    def __post_init__(self) -> None:
        if self.quantity <= 0:
            raise ValueError("quantity must be greater than zero")
