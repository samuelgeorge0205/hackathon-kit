from __future__ import annotations

from dataclasses import dataclass, field
from uuid import uuid4

_VALID_STATUSES = frozenset({"PENDING", "ACCEPTED", "REJECTED", "DEFERRED", "IMPLEMENTED", "CANCELLED"})
_VALID_TYPES = frozenset({"MATERIAL_CHANGE", "WEIGHT_REDUCTION", "RECYCLABILITY", "CONSOLIDATION"})
_VALID_EFFORT = frozenset({"LOW", "MEDIUM", "HIGH"})


@dataclass
class Recommendation:
    product_id: str
    recommendation_type: str
    description: str
    rationale: str
    confidence_score: float
    id: str = field(default_factory=lambda: str(uuid4()))
    current_packaging_id: str | None = None
    estimated_waste_reduction_kg: float | None = None
    estimated_cost_saving: float | None = None
    status: str = "PENDING"
    implementation_effort: str = "MEDIUM"
    status_changed_by: str | None = None
    status_reason: str | None = None
    sources: list[dict] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.recommendation_type not in _VALID_TYPES:
            raise ValueError(f"recommendation_type must be one of {_VALID_TYPES}")
        if self.status not in _VALID_STATUSES:
            raise ValueError(f"status must be one of {_VALID_STATUSES}")
        if not (0.0 <= self.confidence_score <= 1.0):
            raise ValueError("confidence_score must be between 0.0 and 1.0")

    def accept(self, user_id: str, reason: str | None = None) -> None:
        self.status = "ACCEPTED"
        self.status_changed_by = user_id
        self.status_reason = reason

    def reject(self, user_id: str, reason: str | None = None) -> None:
        self.status = "REJECTED"
        self.status_changed_by = user_id
        self.status_reason = reason
