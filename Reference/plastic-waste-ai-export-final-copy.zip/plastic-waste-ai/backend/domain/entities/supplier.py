from __future__ import annotations

from dataclasses import dataclass, field
from uuid import uuid4


@dataclass
class Supplier:
    name: str
    country: str
    id: str = field(default_factory=lambda: str(uuid4()))
    external_id: str | None = None
    region: str | None = None
    tier: int = 2
    certifications: list[str] = field(default_factory=list)
    sustainability_score: float | None = None
    contact_email: str | None = None

    def __post_init__(self) -> None:
        if self.tier not in (1, 2, 3):
            raise ValueError("tier must be 1, 2, or 3")
        if self.sustainability_score is not None and not (0 <= self.sustainability_score <= 100):
            raise ValueError("sustainability_score must be between 0 and 100")
