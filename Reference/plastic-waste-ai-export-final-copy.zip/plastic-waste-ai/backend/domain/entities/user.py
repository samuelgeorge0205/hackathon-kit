from __future__ import annotations

from dataclasses import dataclass, field
from uuid import UUID, uuid4

_VALID_ROLES = frozenset({"viewer", "analyst", "manager", "admin"})


@dataclass
class User:
    email: str
    hashed_password: str
    full_name: str
    role: str = "viewer"
    id: UUID = field(default_factory=uuid4)
    department: str | None = None
    is_active: bool = True
    failed_login_attempts: int = 0

    def __post_init__(self) -> None:
        if self.role not in _VALID_ROLES:
            raise ValueError(f"role must be one of {_VALID_ROLES}")
        if not self.email.strip():
            raise ValueError("email cannot be empty")

    def can(self, *roles: str) -> bool:
        return self.role in roles and self.is_active

    def increment_failed_attempts(self) -> None:
        self.failed_login_attempts += 1

    def reset_failed_attempts(self) -> None:
        self.failed_login_attempts = 0
