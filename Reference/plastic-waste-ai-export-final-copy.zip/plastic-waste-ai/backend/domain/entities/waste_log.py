from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from uuid import uuid4


@dataclass
class WasteLog:
    source_type: str
    source_id: str
    log_date: date
    plastic_type: str
    weight_kg: float
    disposal_method: str
    id: str = field(default_factory=lambda: str(uuid4()))
    product_id: str | None = None
    packaging_id: str | None = None
    unit_count: int | None = None
    verified: bool = False
    notes: str | None = None
    uploaded_by: str | None = None

    _VALID_SOURCE_TYPES = frozenset({"WAREHOUSE", "STORE", "SUPPLIER", "MANUFACTURING"})
    _VALID_PLASTIC_TYPES = frozenset({"PET", "HDPE", "PVC", "LDPE", "PP", "PS", "MIXED"})
    _VALID_DISPOSAL_METHODS = frozenset({"RECYCLED", "LANDFILL", "INCINERATED", "UNKNOWN"})

    def __post_init__(self) -> None:
        if self.weight_kg <= 0:
            raise ValueError("weight_kg must be greater than zero")
        if self.log_date > date.today():
            raise ValueError("log_date cannot be in the future")
        if self.source_type not in self._VALID_SOURCE_TYPES:
            raise ValueError(f"source_type must be one of {self._VALID_SOURCE_TYPES}")
        if self.plastic_type not in self._VALID_PLASTIC_TYPES:
            raise ValueError(f"plastic_type must be one of {self._VALID_PLASTIC_TYPES}")
        if self.disposal_method not in self._VALID_DISPOSAL_METHODS:
            raise ValueError(f"disposal_method must be one of {self._VALID_DISPOSAL_METHODS}")
