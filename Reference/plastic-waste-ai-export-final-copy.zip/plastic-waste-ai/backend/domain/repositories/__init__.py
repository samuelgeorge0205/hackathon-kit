from domain.repositories.i_prediction_repository import IPredictionRepository
from domain.repositories.i_recommendation_repository import IRecommendationRepository
from domain.repositories.i_supplier_repository import ISupplierRepository
from domain.repositories.i_user_repository import IUserRepository
from domain.repositories.i_waste_log_repository import IWasteLogRepository

__all__ = [
    "IPredictionRepository",
    "IRecommendationRepository",
    "ISupplierRepository",
    "IUserRepository",
    "IWasteLogRepository",
]
