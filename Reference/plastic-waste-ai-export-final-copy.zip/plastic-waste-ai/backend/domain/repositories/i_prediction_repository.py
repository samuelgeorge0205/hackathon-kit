from __future__ import annotations

from abc import ABC, abstractmethod
from uuid import UUID

from domain.entities.prediction import Prediction


class IPredictionRepository(ABC):
    @abstractmethod
    async def save(self, prediction: Prediction) -> Prediction: ...

    @abstractmethod
    async def get_by_id(self, id: UUID) -> Prediction | None: ...

    @abstractmethod
    async def list_by_user(
        self, user_id: UUID, limit: int = 20, offset: int = 0
    ) -> list[Prediction]: ...

    @abstractmethod
    async def update_feedback(self, id: UUID, rating: int, comment: str | None) -> None: ...
