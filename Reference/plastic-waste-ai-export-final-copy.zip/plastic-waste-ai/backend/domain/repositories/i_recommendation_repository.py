from __future__ import annotations

from abc import ABC, abstractmethod

from domain.entities.recommendation import Recommendation


class IRecommendationRepository(ABC):
    @abstractmethod
    async def save(self, recommendation: Recommendation) -> Recommendation: ...

    @abstractmethod
    async def get_by_id(self, id: str) -> Recommendation | None: ...

    @abstractmethod
    async def list(
        self,
        status: str | None = None,
        product_id: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> list[Recommendation]: ...

    @abstractmethod
    async def update_status(self, recommendation: Recommendation) -> None: ...
