from __future__ import annotations

from abc import ABC, abstractmethod

from domain.entities.supplier import Supplier


class ISupplierRepository(ABC):
    @abstractmethod
    async def save(self, supplier: Supplier) -> Supplier: ...

    @abstractmethod
    async def get_by_id(self, id: str) -> Supplier | None: ...

    @abstractmethod
    async def get_by_external_id(self, external_id: str) -> Supplier | None: ...

    @abstractmethod
    async def list(self, limit: int = 20, offset: int = 0) -> list[Supplier]: ...
