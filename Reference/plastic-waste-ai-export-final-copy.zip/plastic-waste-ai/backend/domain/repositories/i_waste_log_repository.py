from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date

from domain.entities.waste_log import WasteLog


class IWasteLogRepository(ABC):
    @abstractmethod
    async def save(self, waste_log: WasteLog) -> WasteLog: ...

    @abstractmethod
    async def get_by_id(self, id: str) -> WasteLog | None: ...

    @abstractmethod
    async def list_by_source(
        self, source_type: str, source_id: str, limit: int = 20, offset: int = 0
    ) -> list[WasteLog]: ...

    @abstractmethod
    async def get_by_product(
        self, product_id: str, from_date: date, to_date: date
    ) -> list[WasteLog]: ...

    @abstractmethod
    async def get_summary(self, from_date: date, to_date: date) -> dict: ...
