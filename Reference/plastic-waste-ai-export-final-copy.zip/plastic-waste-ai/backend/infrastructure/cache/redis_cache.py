from __future__ import annotations

import hashlib
import json
from typing import Any

import structlog

from infrastructure.config.settings import get_settings

logger = structlog.get_logger(__name__)

_LLM_TTL = 3600      # 1 hour — LLM response cache
_SESSION_TTL = 86400  # 24 hours — user session cache

# Probed once per process, then cached — avoids re-attempting a real Redis
# connection (and its connect-timeout delay) on every single request.
_backend: str | None = None  # "redis" | "fakeredis" | "unavailable"
_client: Any | None = None


async def _resolve_client() -> Any | None:
    """Real Redis if reachable, else an in-process fakeredis fallback (no
    server required — same "just works locally" experience as SQLite/Chroma),
    else None if even that import is unavailable."""
    global _backend, _client

    if _backend is not None:
        return _client

    settings = get_settings()
    try:
        import redis.asyncio as aioredis

        candidate = aioredis.from_url(settings.redis_url, decode_responses=True, socket_connect_timeout=2)
        await candidate.ping()
        _backend, _client = "redis", candidate
        logger.info("redis_connected", url=settings.redis_url)
        return _client
    except Exception as exc:
        logger.warning("redis_unavailable_using_fakeredis", url=settings.redis_url, error=str(exc))

    try:
        import fakeredis.aioredis

        _backend, _client = "fakeredis", fakeredis.aioredis.FakeRedis(decode_responses=True)
        return _client
    except Exception as exc:
        logger.warning("fakeredis_unavailable", error=str(exc))
        _backend, _client = "unavailable", None
        return None


async def get_cache_backend_status() -> dict:
    """For health/observability reporting — which backend is actually serving
    cache/session/rate-limit calls right now."""
    await _resolve_client()
    return {"backend": _backend or "unavailable"}


class LLMCache:
    """Cache LLM responses keyed by model + prompt hash to avoid repeat API calls."""

    def _key(self, model: str, prompt: str) -> str:
        digest = hashlib.sha256(prompt.encode()).hexdigest()[:16]
        return f"llm:{model}:{digest}"

    async def get(self, model: str, prompt: str) -> str | None:
        client = await _resolve_client()
        if client is None:
            return None
        try:
            return await client.get(self._key(model, prompt))
        except Exception as exc:
            logger.warning("llm_cache_get_error", error=str(exc))
            return None

    async def set(self, model: str, prompt: str, response: str) -> None:
        client = await _resolve_client()
        if client is None:
            return
        try:
            await client.setex(self._key(model, prompt), _LLM_TTL, response)
        except Exception as exc:
            logger.warning("llm_cache_set_error", error=str(exc))


class RateLimiter:
    """Fixed-window rate limiter. Degrades to always-allow only if neither
    real Redis nor the fakeredis fallback is available — matches this
    codebase's "degrade gracefully" pattern rather than hard-failing requests."""

    async def check(self, scope: str, limit: int, window_seconds: int) -> bool:
        """Returns True if this call is within the limit (and counts it),
        False if the caller has exceeded `limit` calls within the window."""
        client = await _resolve_client()
        if client is None:
            return True
        key = f"ratelimit:{scope}:{window_seconds}"
        try:
            count = await client.incr(key)
            if count == 1:
                await client.expire(key, window_seconds)
            return count <= limit
        except Exception as exc:
            logger.warning("rate_limit_check_error", error=str(exc))
            return True


class SessionCache:
    """Store conversation session state keyed by session ID."""

    def _key(self, session_id: str) -> str:
        return f"session:{session_id}"

    async def get(self, session_id: str) -> dict | None:
        client = await _resolve_client()
        if client is None:
            return None
        try:
            raw = await client.get(self._key(session_id))
            return json.loads(raw) if raw else None
        except Exception as exc:
            logger.warning("session_cache_get_error", error=str(exc))
            return None

    async def set(self, session_id: str, data: dict) -> None:
        client = await _resolve_client()
        if client is None:
            return
        try:
            await client.setex(self._key(session_id), _SESSION_TTL, json.dumps(data))
        except Exception as exc:
            logger.warning("session_cache_set_error", error=str(exc))

    async def delete(self, session_id: str) -> None:
        client = await _resolve_client()
        if client is None:
            return
        try:
            await client.delete(self._key(session_id))
        except Exception as exc:
            logger.warning("session_cache_delete_error", error=str(exc))
