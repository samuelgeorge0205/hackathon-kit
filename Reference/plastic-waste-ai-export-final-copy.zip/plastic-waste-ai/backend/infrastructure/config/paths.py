from __future__ import annotations

from pathlib import Path

from infrastructure.config.settings import get_settings

_PROJECT_ROOT = Path(__file__).resolve().parents[3]


def resolve_project_path(path_setting: str) -> Path:
    p = Path(path_setting)
    return p if p.is_absolute() else _PROJECT_ROOT / p


def _resolve_with_fallback(primary: str, fallbacks: list[str]) -> Path:
    primary_path = resolve_project_path(primary)
    if primary_path.exists():
        return primary_path

    for candidate in fallbacks:
        candidate_path = resolve_project_path(candidate)
        if candidate_path.exists():
            return candidate_path

    # Preserve current behavior when nothing exists: return the configured path.
    return primary_path


def get_input_data_dir() -> Path:
    s = get_settings()
    return _resolve_with_fallback(
        s.input_data_dir,
        [
            "input-data/structured",
            "synthetic-data",
        ],
    )


def get_knowledge_base_dir() -> Path:
    s = get_settings()
    return _resolve_with_fallback(
        s.knowledge_base_dir,
        [
            "input-data/knowledge-base",
            "knowledge-base",
        ],
    )
