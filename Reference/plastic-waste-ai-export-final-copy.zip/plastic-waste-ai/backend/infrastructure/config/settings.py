from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # LLM mode switch: set LLM_MODE to "local" or "hackathon"
    llm_mode: Literal["local", "hackathon"] = "local"

    # Optional explicit overrides (if unset, selected profile values are used)
    llm_gateway_url: str | None = None
    llm_api_key: str | None = None
    llm_primary_model: str | None = None
    llm_mini_model: str | None = None
    embedding_model: str | None = None
    llm_verify_ssl: bool | None = None

    # Local profile defaults (Ollama)
    local_llm_gateway_url: str = "http://localhost:11434/v1"
    local_llm_api_key: str = "ollama"
    local_llm_primary_model: str = "llama3.2:latest"
    local_llm_mini_model: str = "llama3.2:latest"
    local_embedding_model: str = "nomic-embed-text:latest"
    local_llm_verify_ssl: bool = True

    # Hackathon profile defaults (TCS GenAI Lab)
    hackathon_llm_gateway_url: str = "https://genailab.tcs.in"
    hackathon_llm_api_key: str = "placeholder"
    hackathon_llm_primary_model: str = "azure/genailab-maas-gpt-4o"
    hackathon_llm_mini_model: str = "azure/genailab-maas-gpt-4o-mini"
    hackathon_embedding_model: str = "azure/genailab-maas-text-embedding-3-large"
    hackathon_llm_verify_ssl: bool = False

    # Budget guard (TCS AI Fridays: $25/team)
    budget_alert_usd: float = 20.0
    budget_limit_usd: float = 25.0

    # Auth
    secret_key: str = "dev-secret-key-replace-in-production"
    access_token_expire_minutes: int = 15
    refresh_token_expire_days: int = 7

    # Database
    database_url: str = "sqlite+aiosqlite:///./data/database_files/app.db"

    # Global path deciding factors
    input_data_dir: str = "input-data/structured"
    knowledge_base_dir: str = "input-data/knowledge-base"

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # Langfuse (optional)
    langfuse_public_key: str = ""
    langfuse_secret_key: str = ""
    langfuse_host: str = "https://cloud.langfuse.com"

    # App
    app_env: str = "development"
    app_debug: bool = True
    cors_origins: list[str] = ["http://localhost:3000", "http://127.0.0.1:3000"]

    model_config = {
        "env_file": str(Path(__file__).resolve().parents[3] / "config" / "runtime.env"),
        "env_file_encoding": "utf-8",
        "extra": "ignore",
    }

    @staticmethod
    def _normalize_optional(value: str | None) -> str | None:
        # Empty env assignments like KEY= should behave as unset.
        if value is None:
            return None
        stripped = value.strip()
        return stripped if stripped else None

    @classmethod
    def _first_non_empty(cls, *values: str | None, fallback: str) -> str:
        for value in values:
            normalized = cls._normalize_optional(value)
            if normalized is not None:
                return normalized
        return fallback

    @property
    def active_llm_gateway_url(self) -> str:
        override = self._normalize_optional(self.llm_gateway_url)
        if override is not None:
            return override
        if self.llm_mode == "hackathon":
            return self._first_non_empty(
                self.hackathon_llm_gateway_url,
                self.local_llm_gateway_url,
                fallback="http://localhost:11434/v1",
            )
        return self._first_non_empty(
            self.local_llm_gateway_url,
            fallback="http://localhost:11434/v1",
        )

    @property
    def active_llm_api_key(self) -> str:
        override = self._normalize_optional(self.llm_api_key)
        if override is not None:
            return override
        if self.llm_mode == "hackathon":
            return self._first_non_empty(
                self.hackathon_llm_api_key,
                self.local_llm_api_key,
                fallback="ollama",
            )
        return self._first_non_empty(
            self.local_llm_api_key,
            fallback="ollama",
        )

    @property
    def active_llm_primary_model(self) -> str:
        override = self._normalize_optional(self.llm_primary_model)
        if override is not None:
            return override
        if self.llm_mode == "hackathon":
            return self._first_non_empty(
                self.hackathon_llm_primary_model,
                self.local_llm_primary_model,
                fallback="llama3.2:latest",
            )
        return self._first_non_empty(
            self.local_llm_primary_model,
            fallback="llama3.2:latest",
        )

    @property
    def active_llm_mini_model(self) -> str:
        override = self._normalize_optional(self.llm_mini_model)
        if override is not None:
            return override
        if self.llm_mode == "hackathon":
            return self._first_non_empty(
                self.hackathon_llm_mini_model,
                self.local_llm_mini_model,
                fallback="llama3.2:latest",
            )
        return self._first_non_empty(
            self.local_llm_mini_model,
            fallback="llama3.2:latest",
        )

    @property
    def active_embedding_model(self) -> str:
        override = self._normalize_optional(self.embedding_model)
        if override is not None:
            return override
        if self.llm_mode == "hackathon":
            return self._first_non_empty(
                self.hackathon_embedding_model,
                self.local_embedding_model,
                fallback="nomic-embed-text:latest",
            )
        return self._first_non_empty(
            self.local_embedding_model,
            fallback="nomic-embed-text:latest",
        )

    @property
    def active_llm_verify_ssl(self) -> bool:
        if self.llm_verify_ssl is not None:
            return self.llm_verify_ssl
        return self.hackathon_llm_verify_ssl if self.llm_mode == "hackathon" else self.local_llm_verify_ssl


@lru_cache
def get_settings() -> Settings:
    return Settings()
