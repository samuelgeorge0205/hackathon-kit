# LLM Section

Purpose:
- Centralized LLM provider access and profile-aware model selection.

Runtime source of truth:
- infrastructure/config/settings.py
- ai/agents/_base.py

This section exposes stable wrappers for enterprise clarity.
