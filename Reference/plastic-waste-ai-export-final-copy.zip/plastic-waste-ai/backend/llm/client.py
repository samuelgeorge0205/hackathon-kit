from __future__ import annotations

from functools import lru_cache

import httpx
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

from infrastructure.config.settings import get_settings


@lru_cache
def _get_async_http_client(verify_ssl: bool) -> httpx.AsyncClient:
    return httpx.AsyncClient(verify=verify_ssl)


@lru_cache
def _get_sync_http_client(verify_ssl: bool) -> httpx.Client:
    return httpx.Client(verify=verify_ssl)


def get_llm(mini: bool = False) -> ChatOpenAI:
    s = get_settings()
    model = s.active_llm_mini_model if mini else s.active_llm_primary_model
    return ChatOpenAI(
        base_url=s.active_llm_gateway_url,
        model=model,
        api_key=s.active_llm_api_key,
        http_async_client=_get_async_http_client(s.active_llm_verify_ssl),
        temperature=0.2,
    )


def get_embeddings() -> OpenAIEmbeddings:
    s = get_settings()
    return OpenAIEmbeddings(
        base_url=s.active_llm_gateway_url,
        model=s.active_embedding_model,
        api_key=s.active_llm_api_key,
        http_client=_get_sync_http_client(s.active_llm_verify_ssl),
        # Ollama's OpenAI-compatible /v1/embeddings endpoint rejects the
        # pre-tokenized integer-array input langchain_openai sends by default
        # ("invalid input type") — this makes it send raw strings instead,
        # which every OpenAI-compatible embedding server accepts.
        check_embedding_ctx_length=False,
    )
