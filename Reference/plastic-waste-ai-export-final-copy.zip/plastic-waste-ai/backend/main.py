from __future__ import annotations

import ssl_patch  # noqa: F401

from infrastructure.config.settings import get_settings

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware


@asynccontextmanager
async def lifespan(app: FastAPI):
    from data.databases import create_tables
    from data.seed_db import seed_database
    from data.seed_rag import seed_rag_knowledge_base
    from observability.langfuse_runtime import initialize_langfuse, shutdown_langfuse

    initialize_langfuse()

    await create_tables()
    await seed_database()
    try:
        await seed_rag_knowledge_base()
    except Exception as exc:
        # Don't let a flaky embedding call take down the whole app — RAG
        # retrieval already degrades gracefully to empty context on error.
        print(f"RAG knowledge-base ingestion skipped: {exc}")
    try:
        yield
    finally:
        shutdown_langfuse()


def create_app() -> FastAPI:
    settings = get_settings()

    app = FastAPI(
        title="Plastics Waste AI",
        version="1.0.0",
        description="Enterprise AI Platform for plastic waste prediction and sustainability insights",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    from api.v1.routers import (
        admin,
        auth,
        chat,
        dashboard,
        evaluation,
        feedback,
        health,
        observability,
        predictions,
        recommendations,
        reports,
        upload,
    )

    app.include_router(auth.router, prefix="/api/v1/auth", tags=["auth"])
    app.include_router(upload.router, prefix="/api/v1/upload", tags=["upload"])
    app.include_router(predictions.router, prefix="/api/v1/predictions", tags=["predictions"])
    app.include_router(dashboard.router, prefix="/api/v1/dashboard", tags=["dashboard"])
    app.include_router(recommendations.router, prefix="/api/v1/recommendations", tags=["recommendations"])
    app.include_router(reports.router, prefix="/api/v1/reports", tags=["reports"])
    app.include_router(chat.router, prefix="/api/v1/chat", tags=["chat"])
    app.include_router(feedback.router, prefix="/api/v1/feedback", tags=["feedback"])
    app.include_router(health.router, prefix="/api/v1", tags=["health"])
    app.include_router(admin.router, prefix="/api/v1/admin", tags=["admin"])
    app.include_router(observability.router, prefix="/api/v1/observability", tags=["observability"])
    app.include_router(evaluation.router, prefix="/api/v1/evaluation", tags=["evaluation"])

    return app


app = create_app()
