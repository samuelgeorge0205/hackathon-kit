# Observability Section

Purpose:
- Unified place for logging, tracing, metrics, health and audit modules.

Current config references:
- config/observability.yaml
- .spec-kit/13_observability.md

This section is now the canonical backend namespace for observability modules.
