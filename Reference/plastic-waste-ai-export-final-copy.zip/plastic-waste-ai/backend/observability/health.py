from __future__ import annotations

from pathlib import Path

import structlog

from infrastructure.config.settings import get_settings
from observability.langfuse_runtime import get_langfuse_status

logger = structlog.get_logger(__name__)

_CHROMA_DIR = Path("./data/database_files/chroma")


async def _check_database() -> bool:
    try:
        from sqlalchemy import text

        from data.databases import get_engine

        async with get_engine().connect() as conn:
            await conn.execute(text("SELECT 1"))
        return True
    except Exception as exc:
        logger.warning("health_check_database_failed", error=str(exc))
        return False


async def _check_cache_backend() -> str:
    """Reports which cache backend is actually serving requests: "redis" (real
    server), "fakeredis" (in-process fallback — no server reachable), or
    "unavailable" (neither)."""
    from infrastructure.cache.redis_cache import get_cache_backend_status

    status = await get_cache_backend_status()
    return status["backend"]


async def _check_chroma() -> bool:
    try:
        import chromadb
        from chromadb.config import Settings as ChromaSettings

        client = chromadb.PersistentClient(
            path=str(_CHROMA_DIR), settings=ChromaSettings(anonymized_telemetry=False)
        )
        client.heartbeat()
        return True
    except Exception as exc:
        logger.warning("health_check_chroma_failed", error=str(exc))
        return False


async def _check_llm_gateway() -> bool:
    try:
        import httpx

        settings = get_settings()
        async with httpx.AsyncClient(verify=settings.active_llm_verify_ssl, timeout=3.0) as client:
            response = await client.get(
                f"{settings.active_llm_gateway_url.rstrip('/')}/models",
                headers={"Authorization": f"Bearer {settings.active_llm_api_key}"},
            )
        return response.status_code < 500
    except Exception as exc:
        logger.warning("health_check_llm_gateway_failed", error=str(exc))
        return False


async def health_payload() -> dict:
    db_ok, cache_backend, chroma_ok, llm_ok = (
        await _check_database(),
        await _check_cache_backend(),
        await _check_chroma(),
        await _check_llm_gateway(),
    )

    langfuse = get_langfuse_status()
    langfuse_ok = (not langfuse.get("configured")) or bool(langfuse.get("initialized"))

    # The cache backend and the LLM gateway degrade gracefully elsewhere in
    # the app (cache miss / guardrail fail-open) — only DB and Chroma are
    # hard-required for the app to function, so only they affect the overall status.
    all_ok = db_ok and chroma_ok

    return {
        "status": "healthy" if all_ok else "degraded",
        "version": "1.0.0",
        "checks": {
            "database": "ok" if db_ok else "error",
            "redis": cache_backend,  # "redis" | "fakeredis" | "unavailable"
            "chroma": "ok" if chroma_ok else "error",
            "llm_api": "ok" if llm_ok else "unavailable",
            "langfuse": {"status": "ok" if langfuse_ok else "error", **langfuse},
        },
    }
