from __future__ import annotations

from typing import Any

from infrastructure.config.settings import get_settings

_langfuse_client: Any | None = None
_langfuse_status: dict[str, Any] = {
    "configured": False,
    "enabled": False,
    "initialized": False,
    "host": "",
    "last_error": None,
}


def initialize_langfuse() -> dict[str, Any]:
    global _langfuse_client

    settings = get_settings()
    public_key = (settings.langfuse_public_key or "").strip()
    secret_key = (settings.langfuse_secret_key or "").strip()
    host = (settings.langfuse_host or "https://cloud.langfuse.com").strip()

    configured = bool(public_key and secret_key)
    _langfuse_status.update(
        {
            "configured": configured,
            "enabled": False,
            "initialized": False,
            "host": host,
            "last_error": None,
        }
    )

    if not configured:
        return get_langfuse_status()

    try:
        from langfuse import Langfuse

        _langfuse_client = Langfuse(
            public_key=public_key,
            secret_key=secret_key,
            host=host,
        )

        _langfuse_status.update(
            {
                "enabled": True,
                "initialized": True,
            }
        )
    except Exception as exc:  # pragma: no cover - defensive runtime fallback
        _langfuse_client = None
        _langfuse_status.update(
            {
                "enabled": False,
                "initialized": False,
                "last_error": str(exc),
            }
        )

    return get_langfuse_status()


def shutdown_langfuse() -> None:
    global _langfuse_client

    if _langfuse_client is None:
        return

    # Flush queued observations/traces before process exit when available.
    for method_name in ("flush", "shutdown"):
        method = getattr(_langfuse_client, method_name, None)
        if callable(method):
            try:
                method()
            except Exception:
                pass

    _langfuse_client = None
    _langfuse_status["initialized"] = False


def get_langfuse_status() -> dict[str, Any]:
    return dict(_langfuse_status)
