from __future__ import annotations

import asyncio
import json
import time

import structlog

logger = structlog.get_logger(__name__)

_CHANNEL_TTL_SECONDS = 900  # 15 minutes — safety valve against leaked/abandoned channels

_channels: dict[str, asyncio.Queue] = {}
_created_at: dict[str, float] = {}


def _sweep_stale() -> None:
    now = time.monotonic()
    stale = [run_id for run_id, ts in _created_at.items() if now - ts > _CHANNEL_TTL_SECONDS]
    for run_id in stale:
        unregister(run_id)


def register(run_id: str) -> asyncio.Queue:
    """Create a channel for `run_id` before the workflow starts, so events
    published during the run are buffered even if the client hasn't opened
    its stream connection yet (asyncio.Queue buffers put() regardless of
    whether get() has been called)."""
    _sweep_stale()
    queue: asyncio.Queue = asyncio.Queue()
    _channels[run_id] = queue
    _created_at[run_id] = time.monotonic()
    return queue


def subscribe(run_id: str) -> asyncio.Queue:
    """Get the channel for `run_id`, creating one defensively if it doesn't
    exist yet (e.g. a client that connects before the producer calls register())."""
    existing = _channels.get(run_id)
    if existing is not None:
        return existing
    return register(run_id)


def publish(run_id: str | None, event: dict) -> None:
    if not run_id:
        return
    queue = _channels.get(run_id)
    if queue is None:
        return
    try:
        queue.put_nowait(event)
    except Exception as exc:  # pragma: no cover - defensive, queues are unbounded here
        logger.warning("live_progress_publish_failed", run_id=run_id, error=str(exc))


def unregister(run_id: str) -> None:
    _channels.pop(run_id, None)
    _created_at.pop(run_id, None)


def format_sse(event: dict) -> str:
    return f"data: {json.dumps(event, default=str)}\n\n"


TERMINAL_EVENT_TYPES = {"done", "workflow_complete", "workflow_error", "error"}
