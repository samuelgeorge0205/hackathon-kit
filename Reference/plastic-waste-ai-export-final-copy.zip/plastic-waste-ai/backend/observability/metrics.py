from __future__ import annotations

from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from data.models.models import AITraceModel, AuditLogModel


async def agent_summary(session: AsyncSession, since: datetime | None = None) -> list[dict]:
    stmt = select(
        AITraceModel.agent_name,
        func.count(AITraceModel.id).label("calls"),
        func.avg(AITraceModel.latency_ms).label("avg_latency_ms"),
        func.sum(AITraceModel.cost_usd).label("total_cost_usd"),
        func.sum(AITraceModel.input_tokens + AITraceModel.output_tokens).label("total_tokens"),
    ).group_by(AITraceModel.agent_name)
    if since:
        stmt = stmt.where(AITraceModel.created_at >= since.isoformat())
    rows = (await session.execute(stmt)).all()

    error_stmt = (
        select(AITraceModel.agent_name, func.count(AITraceModel.id))
        .where(AITraceModel.status == "error")
        .group_by(AITraceModel.agent_name)
    )
    if since:
        error_stmt = error_stmt.where(AITraceModel.created_at >= since.isoformat())
    error_counts = dict((await session.execute(error_stmt)).all())

    return [
        {
            "agent_name": row.agent_name,
            "calls": row.calls,
            "errors": error_counts.get(row.agent_name, 0),
            "avg_latency_ms": round(row.avg_latency_ms or 0, 1),
            "total_cost_usd": round(row.total_cost_usd or 0, 4),
            "total_tokens": int(row.total_tokens or 0),
        }
        for row in rows
    ]


async def latency_percentiles(session: AsyncSession, since: datetime | None = None) -> dict:
    stmt = select(AITraceModel.latency_ms).where(AITraceModel.latency_ms.is_not(None))
    if since:
        stmt = stmt.where(AITraceModel.created_at >= since.isoformat())
    values = sorted(v for (v,) in (await session.execute(stmt)).all() if v is not None)
    if not values:
        return {"p50": 0.0, "p95": 0.0}

    def _pct(p: float) -> float:
        idx = min(len(values) - 1, int(len(values) * p))
        return round(values[idx], 1)

    return {"p50": _pct(0.5), "p95": _pct(0.95)}


async def guardrail_trigger_counts(session: AsyncSession, since: datetime | None = None) -> dict:
    stmt = (
        select(AuditLogModel.event_type, func.count(AuditLogModel.id))
        .where(AuditLogModel.event_type.like("GUARDRAIL_%"))
        .group_by(AuditLogModel.event_type)
    )
    if since:
        stmt = stmt.where(AuditLogModel.created_at >= since.isoformat())
    return dict((await session.execute(stmt)).all())
