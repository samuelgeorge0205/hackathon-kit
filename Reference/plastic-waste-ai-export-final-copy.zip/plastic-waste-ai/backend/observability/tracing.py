from __future__ import annotations

import functools
import json
import time
import uuid
from datetime import UTC, datetime

import structlog
import tiktoken

from infrastructure.config.settings import get_settings
from observability import live_progress
from observability.langfuse_runtime import get_langfuse_status

logger = structlog.get_logger(__name__)

_ENCODING = None

# Best-effort $/1k-token estimates for known gateway models — informational
# only, not a billing source of truth. Local Ollama models are free (0.0).
_COST_PER_1K_TOKENS = {
    "azure/genailab-maas-gpt-4o": 0.005,
    "azure/genailab-maas-gpt-4o-mini": 0.0006,
    "azure/genailab-maas-text-embedding-3-large": 0.00013,
}


def _encoding():
    global _ENCODING
    if _ENCODING is None:
        _ENCODING = tiktoken.get_encoding("cl100k_base")
    return _ENCODING


def estimate_tokens(value) -> int:
    if value is None:
        return 0
    try:
        text = value if isinstance(value, str) else json.dumps(value, default=str)
    except Exception:
        text = str(value)
    return len(_encoding().encode(text))


def _summarize(value, max_str: int = 400, max_items: int = 5, _depth: int = 0):
    """Truncate a value for display/storage — full state dicts can carry large
    retrieved-context text or historical-data lists; this keeps live events and
    trace rows small while still showing the shape of what an agent saw/produced."""
    if _depth > 3:
        return "…"
    if isinstance(value, str):
        return value if len(value) <= max_str else value[:max_str] + "…"
    if isinstance(value, dict):
        items = list(value.items())[:max_items]
        out = {k: _summarize(v, max_str, max_items, _depth + 1) for k, v in items}
        if len(value) > max_items:
            out["…"] = f"+{len(value) - max_items} more keys"
        return out
    if isinstance(value, (list, tuple)):
        out = [_summarize(v, max_str, max_items, _depth + 1) for v in list(value)[:max_items]]
        if len(value) > max_items:
            out.append(f"…+{len(value) - max_items} more")
        return out
    if isinstance(value, (int, float, bool)) or value is None:
        return value
    return _summarize(str(value), max_str, max_items, _depth)


def _estimate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    rate = _COST_PER_1K_TOKENS.get(model)
    if not rate:
        return 0.0
    return round((input_tokens + output_tokens) / 1000 * rate, 6)


def _diff_keys(before: dict, after: dict) -> dict:
    return {k: v for k, v in after.items() if k not in before or before.get(k) != v}


def _run_id(state: dict) -> str | None:
    return state.get("run_id") or state.get("workflow_id") or state.get("session_id")


async def _persist_trace(trace_id: str, **fields) -> None:
    try:
        from data.databases import get_session_factory
        from data.models.models import AITraceModel

        session_factory = get_session_factory()
        async with session_factory() as session:
            session.add(AITraceModel(id=trace_id, **fields))
            await session.commit()
    except Exception as exc:  # observability must never break the request path
        logger.warning("trace_persist_failed", error=str(exc))


def trace_agent(agent_name: str):
    """Wrap an agent node/function: always records latency/tokens/status to the
    local `ai_traces` table (with truncated input/output summaries for
    drill-down), publishes live start/complete events to `live_progress` for
    SSE streaming, and also emits a Langfuse `@observe` span when Langfuse is
    configured — same decorator either way, so adding real Langfuse keys later
    requires no code change."""

    def decorator(fn):
        wrapped = fn
        try:
            from langfuse.decorators import observe

            if get_langfuse_status().get("configured"):
                wrapped = observe(name=agent_name)(fn)
        except Exception:
            wrapped = fn

        @functools.wraps(fn)
        async def inner(*args, **kwargs):
            settings = get_settings()
            first_arg = args[0] if args else None
            state = first_arg if isinstance(first_arg, dict) else {}
            run_id = _run_id(state)
            trace_id = str(uuid.uuid4())

            live_progress.publish(run_id, {
                "type": "agent_start",
                "agent": agent_name,
                "trace_id": trace_id,
                "input": _summarize(state),
            })

            started = time.perf_counter()
            started_at = datetime.now(UTC).isoformat()
            status = "ok"
            error_message = None
            result = None

            try:
                result = await wrapped(*args, **kwargs)
                return result
            except Exception as exc:
                status = "error"
                error_message = str(exc)
                logger.warning("agent_error", agent=agent_name, error=error_message)
                raise
            finally:
                latency_ms = round((time.perf_counter() - started) * 1000, 2)
                if isinstance(result, dict):
                    output_value = _diff_keys(state, result)
                    output_tokens = estimate_tokens(output_value)
                    confidence = result.get("confidence_score")
                else:
                    output_value = result
                    output_tokens = estimate_tokens(result)
                    confidence = None
                input_tokens = estimate_tokens(state or first_arg)
                model = settings.active_llm_primary_model
                input_summary = _summarize(state or first_arg)
                output_summary = _summarize(output_value)

                await _persist_trace(
                    trace_id,
                    correlation_id=run_id,
                    workflow_id=state.get("workflow_id"),
                    agent_name=agent_name,
                    started_at=started_at,
                    ended_at=datetime.now(UTC).isoformat(),
                    latency_ms=latency_ms,
                    model=model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    cost_usd=_estimate_cost(model, input_tokens, output_tokens),
                    status=status,
                    confidence_score=confidence,
                    error_message=error_message,
                    input_summary=json.dumps(input_summary, default=str),
                    output_summary=json.dumps(output_summary, default=str),
                )

                live_progress.publish(run_id, {
                    "type": "agent_error" if status == "error" else "agent_complete",
                    "agent": agent_name,
                    "trace_id": trace_id,
                    "status": status,
                    "latency_ms": latency_ms,
                    "confidence_score": confidence,
                    "error": error_message,
                    "input": input_summary,
                    "output": output_summary,
                })

        return inner

    return decorator
