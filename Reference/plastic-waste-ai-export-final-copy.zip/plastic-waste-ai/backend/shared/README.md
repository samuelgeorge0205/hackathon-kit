# Shared

Cross-cutting modules used by multiple backend layers.
