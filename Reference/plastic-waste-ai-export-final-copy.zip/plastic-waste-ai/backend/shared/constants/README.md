# Shared Constants

Stable cross-module constants and well-known names.
