# Shared Exceptions

Application-wide exception taxonomy and mapping guidance.
