# Shared Middleware

Cross-layer middleware utilities (request context, correlation IDs, tracing helpers).
