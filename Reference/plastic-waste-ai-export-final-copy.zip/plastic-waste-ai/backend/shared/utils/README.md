# Shared Utils

Generic helper utilities with no business-domain behavior.
