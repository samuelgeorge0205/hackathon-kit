from __future__ import annotations

from uuid import uuid4

from sqlalchemy.ext.asyncio import AsyncSession

from data.models.models import AuditLogModel


async def write_audit_event(
    session: AsyncSession,
    *,
    event_type: str,
    actor_user_id: str | None,
    entity_type: str | None = None,
    entity_id: str | None = None,
    before_json: str | None = None,
    after_json: str | None = None,
    correlation_id: str | None = None,
) -> None:
    """Persist an audit-trail row. Caller is responsible for session.commit()."""
    session.add(
        AuditLogModel(
            id=str(uuid4()),
            event_type=event_type,
            user_id=actor_user_id,
            entity_type=entity_type,
            entity_id=entity_id,
            before_json=before_json,
            after_json=after_json,
            correlation_id=correlation_id,
        )
    )
