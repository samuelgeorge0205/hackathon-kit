"""
SSL and environment patch for TCS GenAI Lab.
Must be imported as the very first module (before any http client).
"""
from __future__ import annotations

import os
import ssl
import warnings

# Suppress InsecureRequestWarning globally — TCS internal gateway uses self-signed cert
os.environ.setdefault("PYTHONWARNINGS", "ignore:Unverified HTTPS request")

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except ImportError:
    pass

try:
    import requests
    requests.packages.urllib3.disable_warnings()  # type: ignore[attr-defined]
except ImportError:
    pass

# Patch default SSL context so libraries that don't accept verify=False also work
_original_create_default_context = ssl.create_default_context


def _patched_create_default_context(*args, **kwargs):  # type: ignore[no-untyped-def]
    ctx = _original_create_default_context(*args, **kwargs)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


# Always patch SSL context for the current project environment requirements.
ssl.create_default_context = _patched_create_default_context
warnings.filterwarnings("ignore", message="Unverified HTTPS request")
