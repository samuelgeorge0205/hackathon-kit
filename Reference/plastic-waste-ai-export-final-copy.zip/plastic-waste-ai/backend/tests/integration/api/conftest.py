from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker

from data.models.models import Base
from data.databases import get_db_session
from api.v1.dependencies import hash_password
from data.repositories.sqlite.user_repository import SQLiteUserRepository
from domain.entities.user import User


# Use a shared temp file so all connections see the same in-memory state
_TMP_DB = Path(tempfile.gettempdir()) / "test_plastic_waste.db"
_TEST_DB_URL = f"sqlite+aiosqlite:///{_TMP_DB}"

_engine = create_async_engine(_TEST_DB_URL, echo=False)
_TestSessionFactory = async_sessionmaker(_engine, expire_on_commit=False)


@pytest_asyncio.fixture(scope="session", autouse=True)
async def create_test_db():
    # Point settings at the test DB before app is created
    os.environ["DATABASE_URL"] = _TEST_DB_URL
    from infrastructure.config.settings import get_settings
    get_settings.cache_clear()

    # A prior run that didn't reach teardown (crash, kill, interrupted debug
    # session) can leave a stale populated file at this fixed temp path —
    # start every session from a guaranteed-empty schema, not just "exists".
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    if _TMP_DB.exists():
        _TMP_DB.unlink()


@pytest_asyncio.fixture
async def db_session() -> AsyncSession:
    async with _TestSessionFactory() as session:
        yield session


@pytest_asyncio.fixture
async def client(db_session: AsyncSession) -> AsyncClient:
    import ssl_patch  # noqa: F401

    from main import create_app

    app = create_app()

    # Remove lifespan so seed_database() doesn't run against wrong DB
    app.router.lifespan_context = None  # type: ignore[assignment]

    async def _override_db():
        yield db_session

    app.dependency_overrides[get_db_session] = _override_db

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac


@pytest_asyncio.fixture
async def analyst_token(db_session: AsyncSession, client: AsyncClient) -> str:
    repo = SQLiteUserRepository(db_session)
    existing = await repo.get_by_email("analyst@test.com")
    if not existing:
        user = User(
            email="analyst@test.com",
            hashed_password=hash_password("password123"),
            full_name="Test Analyst",
            role="analyst",
        )
        await repo.save(user)
        await db_session.commit()

    resp = await client.post("/api/v1/auth/login", json={"email": "analyst@test.com", "password": "password123"})
    return resp.json()["data"]["access_token"]

