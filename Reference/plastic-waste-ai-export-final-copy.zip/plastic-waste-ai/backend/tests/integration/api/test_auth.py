from __future__ import annotations

import pytest
from httpx import AsyncClient


pytestmark = pytest.mark.asyncio


async def test_login_success(client: AsyncClient, analyst_token: str):
    assert isinstance(analyst_token, str)
    assert len(analyst_token) > 10


async def test_login_wrong_password(client: AsyncClient):
    resp = await client.post(
        "/api/v1/auth/login",
        json={"email": "analyst@test.com", "password": "wrongpassword"},
    )
    assert resp.status_code == 401


async def test_login_unknown_user(client: AsyncClient):
    resp = await client.post(
        "/api/v1/auth/login",
        json={"email": "ghost@nowhere.com", "password": "any"},
    )
    assert resp.status_code == 401


async def test_refresh_with_access_token_rejected(client: AsyncClient, analyst_token: str):
    resp = await client.post(
        "/api/v1/auth/refresh",
        json={"refresh_token": analyst_token},
    )
    assert resp.status_code == 401


async def test_logout_always_succeeds(client: AsyncClient):
    resp = await client.post("/api/v1/auth/logout")
    assert resp.status_code == 200
