from __future__ import annotations

from uuid import uuid4

import pytest
from httpx import AsyncClient

from api.v1.routers import chat as chat_router


pytestmark = pytest.mark.asyncio


class _InMemorySessionCache:
    _store: dict[str, dict] = {}

    async def get(self, session_id: str) -> dict | None:
        return self._store.get(session_id)

    async def set(self, session_id: str, data: dict) -> None:
        self._store[session_id] = data

    async def delete(self, session_id: str) -> None:
        self._store.pop(session_id, None)


class _FakeChatWorkflow:
    def __init__(self) -> None:
        self.calls = 0

    async def ainvoke(self, state: dict) -> dict:
        self.calls += 1
        return {
            "response": f"answer:{state.get('user_message', '')}",
            "citations": [{"index": 1, "title": "KB", "relevance": 0.91}],
            "confidence_score": 0.88,
        }


@pytest.fixture(autouse=True)
def _reset_fake_cache_store():
    _InMemorySessionCache._store = {}


@pytest.fixture(autouse=True)
def _mock_guardrail_classifier(monkeypatch: pytest.MonkeyPatch):
    # These tests exercise caching/memory-merge behavior, not the guardrail
    # classifier itself — stub tier 2 so results don't depend on a live LLM.
    from ai.guardrails import input_guardrails

    async def _fake_classify(text: str) -> dict:
        return {"injection": False, "off_topic": False, "reason": "test-mock"}

    monkeypatch.setattr(input_guardrails, "classify_message", _fake_classify)


@pytest.fixture
def fake_chat_workflow(monkeypatch: pytest.MonkeyPatch) -> _FakeChatWorkflow:
    from ai.workflows import prediction_workflow

    fake = _FakeChatWorkflow()
    monkeypatch.setattr(prediction_workflow, "chat_workflow", fake)
    return fake


@pytest.fixture
def fake_session_cache(monkeypatch: pytest.MonkeyPatch) -> None:
    from infrastructure.cache import redis_cache

    monkeypatch.setattr(redis_cache, "SessionCache", _InMemorySessionCache)


async def _auth_headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


async def test_chat_cache_miss_returns_fresh_response(
    client: AsyncClient,
    analyst_token: str,
    fake_chat_workflow: _FakeChatWorkflow,
    fake_session_cache: None,
):
    resp = await client.post(
        "/api/v1/chat",
        headers=await _auth_headers(analyst_token),
        json={"message": "How can we reduce PET waste?"},
    )

    assert resp.status_code == 200
    data = resp.json()["data"]
    assert data["cache_hit"] is False
    assert data["response"] == "answer:How can we reduce PET waste?"
    assert fake_chat_workflow.calls == 1


async def test_chat_cache_hit_skips_workflow(
    client: AsyncClient,
    analyst_token: str,
    fake_chat_workflow: _FakeChatWorkflow,
    fake_session_cache: None,
):
    session_id = f"sess_cache_hit_{uuid4().hex[:8]}"
    payload = chat_router.ChatRequest(
        session_id=session_id,
        message="Show suppliers with highest waste intensity",
        context=None,
    )
    normalized_memory = {
        "attachments": [],
        "image_descriptions": [],
        "source": "chat",
    }
    cache_key = chat_router._cache_key(payload, [], normalized_memory)
    _InMemorySessionCache._store[session_id] = {
        "multimodal_memory": {},
        "responses": {
            cache_key: {
                "response": "cached answer",
                "citations": [{"index": 1, "title": "KB", "relevance": 0.95}],
                "suggested_follow_ups": ["next"],
                "confidence_score": 0.93,
            }
        },
    }

    second = await client.post(
        "/api/v1/chat",
        headers=await _auth_headers(analyst_token),
        json={
            "session_id": session_id,
            "message": "Show suppliers with highest waste intensity",
        },
    )

    assert second.status_code == 200
    second_data = second.json()["data"]
    assert second_data["cache_hit"] is True
    assert second_data["response"] == "cached answer"
    assert fake_chat_workflow.calls == 0


async def test_chat_multimodal_memory_merges_across_turns(
    client: AsyncClient,
    analyst_token: str,
    fake_chat_workflow: _FakeChatWorkflow,
    fake_session_cache: None,
):
    first = await client.post(
        "/api/v1/chat",
        headers=await _auth_headers(analyst_token),
        json={
            "message": "Analyze this package image",
            "context": {
                "source": "copilot_ui",
                "attachments": [
                    {"name": "pkg-front.png", "type": "image/png", "size": 21000, "last_modified": 1700000000}
                ],
                "image_descriptions": ["Bottle and cap on white background"],
            },
        },
    )
    assert first.status_code == 200
    session_id = first.json()["data"]["session_id"]

    second = await client.post(
        "/api/v1/chat",
        headers=await _auth_headers(analyst_token),
        json={
            "session_id": session_id,
            "message": "Also include this back label",
            "context": {
                "source": "copilot_ui",
                "attachments": [
                    {"name": "pkg-back.png", "type": "image/png", "size": 19800, "last_modified": 1700000100}
                ],
                "image_descriptions": ["Recycling symbol and material code"],
            },
        },
    )

    assert second.status_code == 200
    memory = second.json()["data"]["multimodal_memory"]
    names = [item["name"] for item in memory["attachments"]]
    assert "pkg-front.png" in names
    assert "pkg-back.png" in names
    assert "Bottle and cap on white background" in memory["image_descriptions"]
    assert "Recycling symbol and material code" in memory["image_descriptions"]


async def test_cache_key_consistency_helper():
    payload = chat_router.ChatRequest(message="same", context={"source": "x"})
    history = [{"role": "user", "content": "q"}, {"role": "assistant", "content": "a"}]
    memory = {"attachments": [], "image_descriptions": [], "source": "x"}

    left = chat_router._cache_key(payload, history, memory)
    right = chat_router._cache_key(payload, history, memory)

    assert left == right
