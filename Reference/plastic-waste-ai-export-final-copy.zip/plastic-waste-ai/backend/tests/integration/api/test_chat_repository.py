from __future__ import annotations

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from data.repositories.sqlite.chat_repository import SQLiteChatRepository


pytestmark = pytest.mark.asyncio


async def test_chat_repository_roundtrip_citations_and_memory(db_session: AsyncSession):
    repo = SQLiteChatRepository(db_session)
    session_id = "repo_roundtrip_session"

    memory = {
        "attachments": [
            {"name": "invoice.png", "type": "image/png", "size": 12345, "last_modified": 1700000000}
        ],
        "image_descriptions": ["Packaging photo with PET label"],
        "source": "copilot_ui",
    }
    citations = [{"index": 1, "title": "Policy doc", "relevance": 0.92}]

    await repo.add_message(
        session_id=session_id,
        user_id="u_test",
        role="assistant",
        content="Use recyclable PET alternatives.",
        citations=citations,
        memory=memory,
    )

    history = await repo.get_history(session_id=session_id, limit=10)

    assert len(history) == 1
    row = history[0]
    assert row["role"] == "assistant"
    assert row["content"] == "Use recyclable PET alternatives."
    assert row["citations"] == citations
    assert row["memory"] == memory
