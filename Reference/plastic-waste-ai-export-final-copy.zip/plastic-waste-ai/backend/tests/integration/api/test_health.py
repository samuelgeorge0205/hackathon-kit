from __future__ import annotations

import pytest
from httpx import AsyncClient


pytestmark = pytest.mark.asyncio


async def test_health_returns_healthy(client: AsyncClient):
    resp = await client.get("/api/v1/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "healthy"


async def test_health_unauthenticated_allowed(client: AsyncClient):
    resp = await client.get("/api/v1/health")
    assert resp.status_code == 200
