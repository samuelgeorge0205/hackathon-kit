from __future__ import annotations

import pytest
from httpx import AsyncClient


pytestmark = pytest.mark.asyncio


async def test_create_prediction_requires_auth(client: AsyncClient):
    resp = await client.post(
        "/api/v1/predictions/waste",
        json={"period_start": "2025-01-01", "period_end": "2025-03-31"},
    )
    assert resp.status_code == 403


async def test_create_prediction_authenticated(client: AsyncClient, analyst_token: str):
    resp = await client.post(
        "/api/v1/predictions/waste",
        headers={"Authorization": f"Bearer {analyst_token}"},
        json={"period_start": "2025-01-01", "period_end": "2025-03-31"},
    )
    assert resp.status_code == 202
    data = resp.json()["data"]
    assert "prediction_id" in data
    assert data["status"] == "PROCESSING"


async def test_get_prediction_not_found(client: AsyncClient, analyst_token: str):
    resp = await client.get(
        "/api/v1/predictions/waste/00000000-0000-0000-0000-000000000000",
        headers={"Authorization": f"Bearer {analyst_token}"},
    )
    assert resp.status_code == 404


async def test_get_created_prediction(client: AsyncClient, analyst_token: str):
    create_resp = await client.post(
        "/api/v1/predictions/waste",
        headers={"Authorization": f"Bearer {analyst_token}"},
        json={"period_start": "2025-04-01", "period_end": "2025-06-30"},
    )
    prediction_id = create_resp.json()["data"]["prediction_id"]

    get_resp = await client.get(
        f"/api/v1/predictions/waste/{prediction_id}",
        headers={"Authorization": f"Bearer {analyst_token}"},
    )
    assert get_resp.status_code == 200
    assert get_resp.json()["data"]["prediction_id"] == prediction_id
