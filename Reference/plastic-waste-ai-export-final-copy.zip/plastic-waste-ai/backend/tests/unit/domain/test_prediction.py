from __future__ import annotations

import pytest
from uuid import uuid4

from domain.entities.prediction import Prediction


def _valid(**kwargs) -> Prediction:
    defaults = dict(
        user_id=uuid4(),
        prediction_type="WASTE_VOLUME",
        input_params={"period_start": "2025-01-01"},
        output_json={},
        confidence_score=0.8,
        model_version="gpt-4o",
    )
    return Prediction(**{**defaults, **kwargs})


class TestPredictionCreation:
    def test_valid_prediction_created(self):
        p = _valid()
        assert p.prediction_type == "WASTE_VOLUME"

    def test_id_auto_generated(self):
        a, b = _valid(), _valid()
        assert a.id != b.id

    def test_optional_fields_default_none(self):
        p = _valid()
        assert p.predicted_value is None
        assert p.explanation is None
        assert p.feedback_rating is None


class TestPredictionValidation:
    def test_invalid_type_raises(self):
        with pytest.raises(ValueError, match="prediction_type"):
            _valid(prediction_type="ENERGY_USE")

    def test_confidence_above_1_raises(self):
        with pytest.raises(ValueError, match="confidence_score"):
            _valid(confidence_score=1.01)

    def test_confidence_below_0_raises(self):
        with pytest.raises(ValueError, match="confidence_score"):
            _valid(confidence_score=-0.01)

    def test_confidence_boundary_values_valid(self):
        assert _valid(confidence_score=0.0).confidence_score == 0.0
        assert _valid(confidence_score=1.0).confidence_score == 1.0

    def test_invalid_feedback_rating_raises(self):
        with pytest.raises(ValueError, match="feedback_rating"):
            _valid(feedback_rating=5)

    @pytest.mark.parametrize("rating", [1, -1])
    def test_valid_feedback_ratings(self, rating):
        p = _valid(feedback_rating=rating)
        assert p.feedback_rating == rating

    @pytest.mark.parametrize("ptype", ["WASTE_VOLUME", "HANDLING_COST"])
    def test_all_valid_prediction_types(self, ptype):
        p = _valid(prediction_type=ptype)
        assert p.prediction_type == ptype
