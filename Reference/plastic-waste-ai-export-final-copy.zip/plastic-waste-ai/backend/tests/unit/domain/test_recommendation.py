from __future__ import annotations

import pytest

from domain.entities.recommendation import Recommendation


def _valid(**kwargs) -> Recommendation:
    defaults = dict(
        product_id="prod-001",
        recommendation_type="MATERIAL_CHANGE",
        description="Switch from PET to rPET",
        rationale="Reduces virgin plastic by 30%",
        confidence_score=0.85,
    )
    return Recommendation(**{**defaults, **kwargs})


class TestRecommendationCreation:
    def test_valid_recommendation_created(self):
        r = _valid()
        assert r.status == "PENDING"
        assert r.implementation_effort == "MEDIUM"

    def test_id_auto_generated(self):
        a, b = _valid(), _valid()
        assert a.id != b.id


class TestRecommendationValidation:
    def test_invalid_type_raises(self):
        with pytest.raises(ValueError, match="recommendation_type"):
            _valid(recommendation_type="COST_REDUCTION")

    def test_invalid_status_raises(self):
        with pytest.raises(ValueError, match="status"):
            _valid(status="UNKNOWN_STATUS")

    def test_confidence_out_of_range_raises(self):
        with pytest.raises(ValueError, match="confidence_score"):
            _valid(confidence_score=1.5)

    @pytest.mark.parametrize("rtype", ["MATERIAL_CHANGE", "WEIGHT_REDUCTION", "RECYCLABILITY", "CONSOLIDATION"])
    def test_all_valid_types(self, rtype):
        r = _valid(recommendation_type=rtype)
        assert r.recommendation_type == rtype


class TestRecommendationWorkflow:
    def test_accept_sets_status_and_user(self):
        r = _valid()
        r.accept("user-123", "Good idea")
        assert r.status == "ACCEPTED"
        assert r.status_changed_by == "user-123"
        assert r.status_reason == "Good idea"

    def test_reject_sets_status_and_user(self):
        r = _valid()
        r.reject("user-456", "Not feasible now")
        assert r.status == "REJECTED"
        assert r.status_changed_by == "user-456"

    def test_accept_without_reason(self):
        r = _valid()
        r.accept("user-001")
        assert r.status == "ACCEPTED"
        assert r.status_reason is None
