from __future__ import annotations

import pytest
from uuid import uuid4

from domain.entities.user import User


def _valid(**kwargs) -> User:
    defaults = dict(
        email="analyst@example.com",
        hashed_password="$2b$12$hashed",
        full_name="Test User",
        role="analyst",
    )
    return User(**{**defaults, **kwargs})


class TestUserCreation:
    def test_valid_user_created(self):
        u = _valid()
        assert u.email == "analyst@example.com"
        assert u.is_active is True

    def test_id_auto_generated(self):
        a, b = _valid(), _valid()
        assert a.id != b.id

    def test_default_role_is_viewer(self):
        u = _valid(role="viewer")
        assert u.role == "viewer"


class TestUserValidation:
    def test_invalid_role_raises(self):
        with pytest.raises(ValueError, match="role"):
            _valid(role="superuser")

    def test_empty_email_raises(self):
        with pytest.raises(ValueError, match="email"):
            _valid(email="   ")

    @pytest.mark.parametrize("role", ["viewer", "analyst", "manager", "admin"])
    def test_all_valid_roles(self, role):
        u = _valid(role=role)
        assert u.role == role


class TestUserPermissions:
    def test_active_user_can_matching_role(self):
        u = _valid(role="analyst")
        assert u.can("analyst", "manager") is True

    def test_active_user_cannot_higher_role(self):
        u = _valid(role="viewer")
        assert u.can("analyst") is False

    def test_inactive_user_cannot(self):
        u = _valid(role="admin", is_active=False)
        assert u.can("admin") is False

    def test_increment_failed_attempts(self):
        u = _valid()
        u.increment_failed_attempts()
        u.increment_failed_attempts()
        assert u.failed_login_attempts == 2

    def test_reset_failed_attempts(self):
        u = _valid()
        u.increment_failed_attempts()
        u.reset_failed_attempts()
        assert u.failed_login_attempts == 0
