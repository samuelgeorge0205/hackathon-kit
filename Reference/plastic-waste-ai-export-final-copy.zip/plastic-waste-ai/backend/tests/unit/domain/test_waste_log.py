from __future__ import annotations

import pytest
from datetime import date, timedelta

from domain.entities.waste_log import WasteLog


def _valid(**kwargs) -> WasteLog:
    defaults = dict(
        source_type="WAREHOUSE",
        source_id="sup-001",
        log_date=date.today(),
        plastic_type="PET",
        weight_kg=10.0,
        disposal_method="RECYCLED",
    )
    return WasteLog(**{**defaults, **kwargs})


class TestWasteLogCreation:
    def test_valid_waste_log_created(self):
        log = _valid()
        assert log.weight_kg == 10.0
        assert log.plastic_type == "PET"

    def test_id_auto_generated(self):
        a, b = _valid(), _valid()
        assert a.id != b.id

    def test_optional_fields_default_none(self):
        log = _valid()
        assert log.product_id is None
        assert log.packaging_id is None
        assert log.unit_count is None
        assert log.notes is None


class TestWasteLogValidation:
    def test_negative_weight_raises(self):
        with pytest.raises(ValueError, match="weight_kg"):
            _valid(weight_kg=-1.0)

    def test_zero_weight_raises(self):
        with pytest.raises(ValueError, match="weight_kg"):
            _valid(weight_kg=0.0)

    def test_future_date_raises(self):
        with pytest.raises(ValueError, match="log_date"):
            _valid(log_date=date.today() + timedelta(days=1))

    def test_invalid_source_type_raises(self):
        with pytest.raises(ValueError, match="source_type"):
            _valid(source_type="FACTORY")

    def test_invalid_plastic_type_raises(self):
        with pytest.raises(ValueError, match="plastic_type"):
            _valid(plastic_type="PLASTIC")

    def test_invalid_disposal_method_raises(self):
        with pytest.raises(ValueError, match="disposal_method"):
            _valid(disposal_method="BURIED")

    @pytest.mark.parametrize("source_type", ["WAREHOUSE", "STORE", "SUPPLIER", "MANUFACTURING"])
    def test_all_valid_source_types(self, source_type):
        log = _valid(source_type=source_type)
        assert log.source_type == source_type

    @pytest.mark.parametrize("plastic_type", ["PET", "HDPE", "PVC", "LDPE", "PP", "PS", "MIXED"])
    def test_all_valid_plastic_types(self, plastic_type):
        log = _valid(plastic_type=plastic_type)
        assert log.plastic_type == plastic_type

    @pytest.mark.parametrize("method", ["RECYCLED", "LANDFILL", "INCINERATED", "UNKNOWN"])
    def test_all_valid_disposal_methods(self, method):
        log = _valid(disposal_method=method)
        assert log.disposal_method == method
