# Configuration Contract

## Purpose
This file defines where configuration changes should be made to avoid drift and duplicated keys.

## Authority
1. Runtime loader authority: backend/infrastructure/config/settings.py
2. Runtime value authority: config/runtime.env
3. Environment override authority: environment variables
4. Governance authority: config/*.yaml

## Edit Matrix
- Change runtime defaults: edit backend/infrastructure/config/settings.py
- Change environment-specific values/secrets: edit config/runtime.env or runtime env vars
- Change team policy/spec docs: edit config/*.yaml
- Add a new config variable:
  1. Add it to settings.py
  2. Add it to config/runtime.env.example if it can be overridden
  3. Document intent in the relevant YAML file (llm/database/security/etc.)

## Keep in Sync
When changing settings.py defaults, update matching YAML policy files so docs and runtime do not diverge.
When changing important runtime values, keep config/runtime.env as the single editable runtime file.

## Avoid
- Defining the same operational key in multiple YAML files unless one is explicitly marked as a non-runtime policy duplicate.
- Treating YAML files as runtime loaders unless the code explicitly reads them.
