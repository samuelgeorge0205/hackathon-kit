# Global Configuration

This directory contains global deciding factors and policy-oriented configuration artifacts.

## Runtime Source of Truth
- Runtime code reads config via `backend/infrastructure/config/settings.py` from `config/runtime.env`.
- Environment variables override values from `config/runtime.env`.
- YAML files in this folder are the human/governance contract and should be kept aligned with runtime settings.

## Precedence Model
1. Environment variables (highest precedence)
2. `config/runtime.env`
3. Runtime defaults in `backend/infrastructure/config/settings.py`
4. YAML guidance files in `config/` (design-time policy/spec)

## File Responsibilities
- `runtime.env.example`: canonical environment template and variable catalog.
- `application.yaml`: operational cross-module deciding factors (paths and feature flags).
- `llm.yaml`: LLM mode/profile policy and budget guardrails.
- `database.yaml`: relational/vector store operational defaults and seed policy.
- `redis.yaml`: cache defaults.
- `security.yaml`: authn/authz and guardrail policies.
- `observability.yaml`: logging/tracing/audit policy.
- `app.yaml`: broader product blueprint and domain policy reference (non-runtime contract document).

## Editing Rule of Thumb
- Change runtime behavior: update `backend/infrastructure/config/settings.py` first.
- Change deployment environment values: update `config/runtime.env` or environment variables.
- Keep documentation and governance aligned: update YAMLs in `config/`.
