# IMPLEMENTATION PLAN

## Purpose
This is the execution guide for coding agents. Each milestone is independently executable. Complete milestones in order — each has entry criteria, commands, deliverables and exit criteria.

---

## Quickest Start (All-in-one)

```bat
# From repo root — handles execution policy, SSL, uv, DB seed automatically
scripts/setup.bat run
```

Or from PowerShell (bypasses execution policy without admin rights):
```powershell
powershell -ExecutionPolicy Bypass -File scripts/setup.ps1 -Run
```

---

## Environment Setup (Pre-M1)

```bash
# Python version: 3.12.8 (as per TCS AI Lab)
# Use a single backend Python environment: backend/.venv
# uv is the package manager — no pip/venv commands needed
# SSL verification is disabled globally via ssl_patch.py (TCS internal gateway)
# Copy .env.example to .env and fill in:
#   LLM_API_KEY         = your TCS GenAI Lab API key
#   LLM_GATEWAY_URL     = https://genailab.tcs.in
#   SECRET_KEY          = 32-char random string
```

---

## Milestone 1 — Folder Structure + Environments

**Entry**: Empty repository cloned from Gogs
**Duration**: 0.5 day

### Commands
```bash
cd backend
uv sync

cd frontend
npm create vite@latest . -- --template react-ts
npm install tailwindcss recharts zustand @tanstack/react-query axios
npm install -D playwright @playwright/test
```

### Deliverables
- [ ] `backend/requirements.txt` with pinned versions
- [ ] `backend/.env.example` with all required variables
- [ ] `frontend/package.json` with all dependencies
- [ ] Both environments install clean with zero errors

### Exit Criteria
```bash
uv run python -c "import fastapi, langgraph, chromadb, langfuse; print('OK')"
npm run build  # exits 0
```

---

## Milestone 2 — Backend Domain + Application Layers

**Entry**: M1 complete; `backend/.venv` available via `uv`
**Duration**: 2 days
**Spec**: `.spec-kit/07_architecture.md` (Layers 3+4), `.spec-kit/09_database_design.md`

### What to Build

**Domain Layer** (`backend/domain/`):
- Entities: `WasteLog`, `Supplier`, `Product`, `Packaging`, `PurchaseOrder`, `POLineItem`, `Shipment`, `Warehouse`, `Store`, `HandlingCost`, `Prediction`, `Recommendation`, `AuditLog`, `User`
- Value objects: `PlasticType` (enum), `DisposalMethod` (enum), `Money` (float + currency), `ConfidenceScore` (float 0–1), `WasteIntensity` (float)
- Repository interfaces: `IWasteLogRepository`, `IProductRepository`, `ISupplierRepository`, `IPredictionRepository`, `IRecommendationRepository`

**Application Layer** (`backend/application/`):
- Use cases: `IngestProductsUseCase`, `IngestPackagingUseCase`, `IngestWasteLogsUseCase`, `RunWastePredictionUseCase`, `RunCostEstimationUseCase`, `GenerateRecommendationsUseCase`, `GenerateReportUseCase`, `ProcessChatMessageUseCase`
- DTOs: `PredictionInputDto`, `PredictionOutputDto`, `UploadResultDto`, `RecommendationDto`
- Interfaces: `IAIService`, `INotificationService`

### Key Pattern (copy exactly)
```python
# domain/entities/waste_log.py
from dataclasses import dataclass, field
from datetime import date
from uuid import UUID, uuid4

@dataclass
class WasteLog:
    source_type: str
    source_id: UUID
    log_date: date
    plastic_type: str
    weight_kg: float
    disposal_method: str
    id: UUID = field(default_factory=uuid4)
    product_id: UUID | None = None
    packaging_id: UUID | None = None

    def __post_init__(self) -> None:
        if self.weight_kg <= 0:
            raise ValueError("weight_kg must be greater than zero")
        if self.log_date > date.today():
            raise ValueError("log_date cannot be in the future")
```

### Exit Criteria
```bash
uv run pytest backend/tests/unit/domain/ -v --cov=backend/domain --cov-fail-under=90
uv run pytest backend/tests/unit/application/ -v --cov=backend/application --cov-fail-under=80
uv run mypy backend/domain backend/application --strict
```

---

## Milestone 3 — Database + Repositories

**Entry**: M2 complete
**Duration**: 1.5 days
**Spec**: `.spec-kit/09_database_design.md`

### What to Build

**SQLAlchemy ORM models** (`backend/data/models/`):
- One model per table (14 total)
- All columns, types, indexes, FK constraints as per database design spec

**Alembic migration**:
```bash
cd backend
alembic init data/migrations
# Edit alembic.ini: sqlalchemy.url = sqlite+aiosqlite:///./data/database_files/app.db
alembic revision --autogenerate -m "initial_schema"
alembic upgrade head
```

**Repository implementations** (`backend/data/repositories/sqlite/`):
- Implement every method in each IRepository interface
- Use `async with session` for all DB operations

**Seed script**:
```bash
python backend/data/seed_db.py
# Loads: input-data/structured/suppliers.json, products.json, packaging.json,
#        warehouses.json, waste_logs.json
```

**Redis cache** (`backend/infrastructure/cache/`):
- `LLMCache`: key=`llm:{model}:{hash}`, TTL=3600
- `SessionCache`: key=`session:{id}`, TTL=86400

**ChromaDB** (`backend/data/repositories/chroma/`):
- `DocumentRepository.ingest(text, metadata)` → chunks + embeds + stores
- `DocumentRepository.search(query, top_k)` → returns list of chunks

### Exit Criteria
```bash
uv run pytest backend/tests/integration/repositories/ -v
uv run python backend/data/seed_db.py  # exits 0, prints "Seeded N records"
```

---

## Milestone 4 — AI Layer (LangGraph + RAG)

**Entry**: M3 complete (ChromaDB seeded, DB seeded)
**Duration**: 3 days
**Spec**: `.spec-kit/11_ai_agents.md`, `.spec-kit/10_rag_design.md`, `.spec-kit/copilot.instructions.md`

### LLM Client Setup (MUST follow this exactly)
```python
# infrastructure/config/settings.py
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    llm_gateway_url: str = "https://genailab.tcs.in"
    llm_api_key: str
    llm_primary_model: str = "azure/genailab-maas-gpt-4o"
    llm_mini_model: str = "azure/genailab-maas-gpt-4o-mini"
    embedding_model: str = "azure/genailab-maas-text-embedding-3-large"
    model_config = {"env_file": ".env"}

# ai/agents/_base.py
import httpx
from langchain_openai import ChatOpenAI
from infrastructure.config.settings import get_settings

_async_http = httpx.AsyncClient(verify=False)  # Required for TCS internal gateway

def get_llm(mini: bool = False) -> ChatOpenAI:
    s = get_settings()
    return ChatOpenAI(
        base_url=s.llm_gateway_url,
        model=s.llm_mini_model if mini else s.llm_primary_model,
        api_key=s.llm_api_key,
        http_async_client=_async_http,
    )
```

### What to Build

**Agent nodes** (read `prompts/*.md` for each prompt):
1. `ai/agents/planner_agent.py` → reads `prompts/planner-agent.md`
2. `ai/agents/retriever_agent.py` → reads `prompts/retriever-agent.md`
3. `ai/agents/waste_prediction_agent.py` → reads `prompts/waste-prediction-agent.md`
4. `ai/agents/handling_cost_agent.py` → reads `prompts/handling-cost-agent.md`
5. `ai/agents/recommendation_agent.py` → reads `prompts/recommendation-agent.md`
6. `ai/agents/explanation_agent.py` → reads `prompts/explanation-agent.md`
7. `ai/agents/report_generator_agent.py` → reads `prompts/report-generator-agent.md`

**Workflows**:
```python
# ai/workflows/prediction_workflow.py
from langgraph.graph import StateGraph, END
from ai.state.workflow_state import PredictionWorkflowState

def build_prediction_workflow() -> StateGraph:
    graph = StateGraph(PredictionWorkflowState)
    graph.add_node("retriever", retriever_node)
    graph.add_node("waste_prediction", waste_prediction_node)
    graph.add_node("handling_cost", handling_cost_node)
    graph.add_node("explanation", explanation_node)
    graph.set_entry_point("retriever")
    graph.add_edge("retriever", "waste_prediction")
    graph.add_edge("waste_prediction", "handling_cost")
    graph.add_edge("handling_cost", "explanation")
    graph.add_edge("explanation", END)
    return graph.compile()
```

**RAG pipeline** (`ai/rag/`):
- `ingestion/document_loader.py` → PDF/DOCX/TXT → raw text
- `ingestion/text_chunker.py` → 512-token chunks, 50-token overlap
- `ingestion/embedder.py` → `azure/genailab-maas-text-embedding-3-large`
- `retrieval/dense_retriever.py` → ChromaDB similarity search
- `retrieval/sparse_retriever.py` → BM25 with `rank_bm25`
- `retrieval/reranker.py` → `cross-encoder/ms-marco-MiniLM-L-6-v2`
- `pipeline.py` → wires ingestion + retrieval end-to-end

**Langfuse tracing** (wrap every LLM call):
```python
from langfuse.decorators import observe

@observe(name="waste_prediction_agent")
async def waste_prediction_node(state):
    ...
```

### Exit Criteria
```bash
uv run pytest backend/tests/unit/ai/ -v
# Verify workflow compiles
uv run python -c "
from ai.workflows.prediction_workflow import build_prediction_workflow
wf = build_prediction_workflow()
print('Workflow compiled OK:', wf)
"
```

---

## Milestone 5 — API Layer

**Entry**: M4 complete
**Duration**: 2 days
**Spec**: `.spec-kit/14_api_contract.md`

### What to Build

```python
# main.py
from fastapi import FastAPI
from api.v1.middleware import setup_middleware
from api.v1.routers import auth, upload, predictions, recommendations, dashboard, reports, chat, feedback, health

app = FastAPI(title="Plastics Waste AI", version="1.0.0")
setup_middleware(app)
app.include_router(auth.router, prefix="/api/v1/auth", tags=["auth"])
app.include_router(upload.router, prefix="/api/v1/upload", tags=["upload"])
app.include_router(predictions.router, prefix="/api/v1/predictions", tags=["predictions"])
app.include_router(dashboard.router, prefix="/api/v1/dashboard", tags=["dashboard"])
app.include_router(recommendations.router, prefix="/api/v1/recommendations", tags=["recommendations"])
app.include_router(reports.router, prefix="/api/v1/reports", tags=["reports"])
app.include_router(chat.router, prefix="/api/v1/chat", tags=["chat"])
app.include_router(feedback.router, prefix="/api/v1/feedback", tags=["feedback"])
app.include_router(health.router, prefix="/api/v1", tags=["health"])
```

### Auth Pattern
```python
# api/v1/dependencies.py
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer

def require_role(*roles: str):
    def dependency(current_user = Depends(get_current_user)):
        if current_user.role not in roles:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        return current_user
    return dependency
```

### Exit Criteria
```bash
uv run uvicorn main:app --reload --port 8000 &
curl http://localhost:8000/api/v1/health
# → {"status": "healthy"}
uv run pytest backend/tests/integration/api/ -v
# Swagger UI: http://localhost:8000/docs
```

---

## Milestone 6 — Frontend

**Entry**: M5 complete (API running at localhost:8000)
**Duration**: 3 days
**Spec**: `.spec-kit/15_frontend_spec.md`

### Critical: API Client Setup
```typescript
// src/services/apiClient.ts
import axios from 'axios';

const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api/v1',
});

apiClient.interceptors.request.use(config => {
  const token = useAuthStore.getState().accessToken;
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Auto-refresh on 401
apiClient.interceptors.response.use(
  r => r,
  async error => {
    if (error.response?.status === 401) {
      await useAuthStore.getState().refresh();
      return apiClient(error.config);
    }
    return Promise.reject(error);
  }
);
```

### Page Build Order
1. Login page + auth store (unblocks everything)
2. Dashboard (validates API + charts working)
3. Predictions (validates AI workflow end-to-end)
4. Upload (validates data ingestion)
5. Analytics (charts)
6. Copilot (RAG + chat)
7. Reports (report generation)
8. Settings (admin features)

### Exit Criteria
```bash
npm run dev
# All 7 pages render without console errors
npx playwright test --project=Desktop
# All 7 E2E journeys pass
```

---

## Milestone 7 — Testing

**Entry**: M2–M6 complete
**Duration**: 2 days

```bash
# Full test suite
pytest backend/ -v --cov=backend --cov-report=html --cov-fail-under=75

# Type checking
mypy backend/domain backend/application --strict

# Linting
ruff check backend/

# Synthetic data validation
pytest backend/tests/synthetic/ -v

# E2E
cd frontend && npx playwright test

# Verify Langfuse traces exist
# Open https://cloud.langfuse.com → check traces dashboard
```

---

## Milestone 8 — Demo Prep

**Entry**: M7 complete
**Duration**: 1 day

```bash
# Seed realistic demo data
uv run python backend/data/seed_db.py

# Final start commands (or just run scripts/setup.bat run)
uv run uvicorn main:app --host 0.0.0.0 --port 8000
cd frontend && npm run dev
```

### Demo Checklist
- [ ] App starts from cold in < 30 seconds
- [ ] Prediction completes in < 5 seconds (cached on second run)
- [ ] Report generates in < 60 seconds
- [ ] Langfuse shows traces from test run
- [ ] All team members rehearsed their segment
- [ ] Slides ready (OpenOffice on AI Lab laptop)
- [ ] Code pushed to Gogs repository
- [ ] Zero hardcoded secrets (`git grep "api_key" --not .env.example`)

---

## Quick Reference

| Need | File |
|---|---|
| LLM client pattern | `.spec-kit/copilot.instructions.md` |
| All agent prompts | `prompts/*.md` |
| Database schema | `.spec-kit/09_database_design.md` |
| All API endpoints | `.spec-kit/14_api_contract.md` |
| Agent behaviour | `.spec-kit/11_ai_agents.md` |
| RAG pipeline | `.spec-kit/10_rag_design.md` |
| TCS models list | `config/app.yaml` → llm section |
| Definition of done | `.spec-kit/20_definition_of_done.md` |
