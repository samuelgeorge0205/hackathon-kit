# Setup Guide — Running This Project on a New Machine

This covers taking the exported project (zip or fresh clone) and getting it
running from scratch: prerequisites, quick setup, manual setup, configuring
the LLM backend, and troubleshooting. For repurposing this codebase toward a
different use case, see [`docs/REUSABLE_PATTERNS.md`](REUSABLE_PATTERNS.md)
instead — this doc is only about getting the *existing* app running.

---

## 1. Prerequisites

| Tool | Version | Check with | Get it |
|---|---|---|---|
| Python | 3.12.x | `python --version` | https://python.org |
| Node.js | 18+ | `node --version` | https://nodejs.org |
| uv (Python package manager) | any recent | `uv --version` | installed automatically by the setup script, or `pip install uv` |
| Ollama *(only if using local LLM mode)* | any recent | `ollama --version` | https://ollama.com |
| Docker *(optional — for real Redis instead of the automatic fallback)* | any recent | `docker --version` | https://docker.com |

You do **not** need PostgreSQL, a Redis server, or an OpenAI/Azure account —
the app runs entirely locally by default (SQLite, Chroma, and either a real
or in-process fallback Redis — see §5).

## 2. Quick setup (recommended)

From the project root, in PowerShell:

```powershell
scripts\setup.bat
```

This runs `scripts\setup.ps1`, which:
1. Checks your Python version
2. Installs `uv` if missing
3. Installs backend dependencies into `backend\.venv`
4. Copies `config\runtime.env.example` → `config\runtime.env` (and
   `frontend\.env.example` → `frontend\.env`) if they don't already exist
5. Creates and seeds the SQLite database (`backend\data\database_files\app.db`)
6. Checks whether Redis is reachable on `localhost:6379` and tells you what
   will happen either way (see §5 — nothing is required here)

Then, in two separate terminals:

```powershell
# Terminal 1 — backend
cd backend
uv run uvicorn main:app --reload --port 8000

# Terminal 2 — frontend
cd frontend
npm install
npm run dev
```

Open **http://localhost:5173**. Log in with one of the seeded demo accounts
(all use password `Demo1234!`):

| Email | Role |
|---|---|
| `analyst@demo.com` | analyst |
| `manager@demo.com` | manager |
| `admin@demo.com` | admin |
| `viewer@demo.com` | viewer |

Variants:
- `scripts\setup.bat run` — setup, then immediately start the backend
- `scripts\setup.bat frontend` — setup, then also run `npm install`
- On macOS/Linux, skip the `.bat`/`.ps1` scripts and just run the manual
  steps in §3 — everything after `uv sync` is OS-agnostic.

## 3. Manual setup (if you'd rather not use the script)

```bash
# Backend
cd backend
uv sync                                    # or: pip install -e ".[dev]"
cp ../config/runtime.env.example ../config/runtime.env
uv run python -c "import asyncio; from data.databases import create_tables; asyncio.run(create_tables())"
uv run python data/seed_db.py
uv run uvicorn main:app --reload --port 8000

# Frontend (separate terminal)
cd frontend
cp .env.example .env      # optional — default already points at /api/v1 via same-origin proxy
npm install
npm run dev
```

## 4. Configure the LLM backend

Everything reads from **`config/runtime.env`** (the file `backend/.env.example`
in the repo is a stale leftover — ignore it). The key switch is `LLM_MODE`:

**`LLM_MODE=local`** (default) — uses Ollama, fully offline:
```bash
ollama pull llama3.2
ollama pull nomic-embed-text
```
No API key needed (`LOCAL_LLM_API_KEY=ollama` is a placeholder Ollama ignores).

**`LLM_MODE=hackathon`** — uses a hosted OpenAI-compatible gateway (this
project was built against TCS's GenAI Lab gateway, but any OpenAI-compatible
endpoint works — just fill in `HACKATHON_LLM_GATEWAY_URL`,
`HACKATHON_LLM_API_KEY`, and the three `HACKATHON_*_MODEL` values in
`config/runtime.env`).

Every LLM/embedding call in the codebase goes through
`backend/llm/client.py`'s `get_llm()` / `get_embeddings()`, which read the
active profile via `infrastructure/config/settings.py` — there's no
model-specific code to change elsewhere.

## 5. Redis — nothing required

`backend/infrastructure/cache/redis_cache.py` tries a real Redis server at
`REDIS_URL` first; if none is reachable it transparently falls back to an
in-process `fakeredis` instance — same zero-setup experience as SQLite or
Chroma, no server, no Docker. `GET /api/v1/health` reports which one is
active (`checks.redis`: `"redis"` | `"fakeredis"` | `"unavailable"`).

If you want real Redis anyway (closer to a production setup):
```bash
docker run -d --name plastic-waste-redis -p 6379:6379 --restart unless-stopped redis:7-alpine
```

## 6. Verify it's working

```bash
curl http://localhost:8000/api/v1/health
```
Should return `"status": "healthy"` with `database: ok` and `chroma: ok` at
minimum (`llm_api` and `redis` degrade gracefully if unset up).

```bash
cd backend
uv run pytest
```
Should show `78 passed` (or more, if you've added tests) with no failures.

## 7. Troubleshooting

- **`uv sync` fails on SSL/certificate errors** — you're likely behind a
  corporate SSL-inspecting proxy. The setup script already passes
  `--native-tls` (uses the OS certificate store); if it still fails, try
  `uv sync --native-tls --trusted-host pypi.org --trusted-host files.pythonhosted.org`.
- **Embeddings fail with `invalid input type` against Ollama** — this was a
  real bug in earlier versions of this repo (langchain_openai pre-tokenizes
  input by default, which Ollama's endpoint rejects). It's fixed in
  `backend/llm/client.py` (`check_embedding_ctx_length=False`) — if you see
  this error, confirm that fix is present.
- **`ai_traces` / schema errors on an existing `app.db`** — this project has
  no migration system (`Base.metadata.create_all` only *creates* new tables,
  it never alters existing ones). If you pull an update that adds columns to
  an existing table and hit a `no such column` error, either delete
  `backend/data/database_files/app.db` and let it reseed on next startup, or
  manually `ALTER TABLE` the missing column in.
- **Frontend can't reach the backend** — check `frontend/.env`'s
  `VITE_API_BASE_URL`. Default (`/api/v1`) assumes same-origin proxying via
  Vite; if backend and frontend are on different hosts/ports without a
  proxy, set it to an absolute URL like `http://localhost:8000/api/v1`.
- **Port 8000 or 5173 already in use** — `uvicorn main:app --port <other>`
  / `npm run dev -- --port <other>` (and update `VITE_API_BASE_URL`
  accordingly).

## 8. Reusing this for a different use case

This app's AI layer (RAG pipeline, guardrails, prompt library, live-progress
tracing/streaming, evaluation harness) was built to be domain-agnostic — see
[`docs/REUSABLE_PATTERNS.md`](REUSABLE_PATTERNS.md) for a concrete,
file-by-file checklist of what to reuse as-is versus what to rewrite.
