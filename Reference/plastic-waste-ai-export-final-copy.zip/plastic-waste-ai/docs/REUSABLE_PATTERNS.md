# Reusable Patterns — Repointing This Codebase at a New Hackathon Use Case

This project was built as a plastics-waste use case, but almost none of the
infrastructure is actually about plastics waste. The domain-specific code is
a thin layer (`domain/entities`, a handful of prompts, a handful of routers).
Everything underneath — RAG, guardrails, prompt library, tracing/live-progress
streaming, evaluation harness, and every frontend piece that visualizes agent
execution — is generic and was deliberately built to be reusable. This is a
checklist for repointing it at an unknown new use case during the hackathon,
in the order you'd actually do the work.

Rule of thumb: if a file lives under `backend/ai/rag/`, `backend/ai/guardrails/`,
`backend/observability/`, `backend/ai/prompt_library/`, or
`frontend/src/hooks/useAgentStream.ts` / `frontend/src/components/ui/AgentPipeline.tsx`
/ `frontend/src/services/sseClient.ts` — **you should not need to touch it**.
Everything else is the part you rewrite per use case.

---

## 0. What stays, what changes

| Layer | Reuse as-is | Rewrite per use case |
|---|---|---|
| RAG pipeline | `backend/ai/rag/pipeline.py` (hybrid retrieval, reranking, chunking) | `input-data/knowledge-base/*.md` (swap the documents) |
| Guardrails | `backend/ai/guardrails/input_guardrails.py`, `groundedness.py` | The `ALLOWED_TOPICS`/`OFF_TOPIC_DOMAINS` constants (one edit) |
| Prompt loader | `backend/ai/prompt_library/loader.py` | `prompts/*.md` (new files per agent) |
| Tracing + live progress | `backend/observability/tracing.py`, `live_progress.py` | Nothing — just decorate your new agent functions |
| Eval harness | `backend/ai/evaluation/runner.py` | `backend/ai/evaluation/golden_queries.json` (new queries) |
| Frontend streaming | `useAgentStream.ts`, `AgentPipeline.tsx`, `sseClient.ts` | Nothing — pass a new `agentLabels` map, that's it |
| Observability/AI Evaluation pages | Both pages entirely | Nothing — they read `agent_name` strings dynamically |
| Domain model | — | `backend/domain/entities/*.py`, SQLAlchemy models |
| Agent logic | — | New files in `backend/ai/agents/` |
| Workflow graph | — | New `StateGraph` in `backend/ai/workflows/` |
| API routes | — | New router in `backend/api/v1/routers/` |

---

## 1. Define your domain entities + a WorkflowState

Look at `backend/domain/entities/waste_log.py` for the pattern (plain
dataclass-style entity, no framework coupling) and
`backend/data/models/models.py` for the matching SQLAlchemy model — add
tables there, `Base.metadata.create_all` picks them up automatically on next
startup (see `backend/data/databases/engine.py:37`), no Alembic migration
needed for a hackathon.

Define your workflow's state shape as a `TypedDict` in
`backend/ai/state/workflow_state.py` next to `PredictionWorkflowState` /
`ChatWorkflowState`. Include a `run_id` field (or reuse a natural per-request
ID like `workflow_id`) — this is what correlates trace rows and live-progress
events to one specific request. See the `_run_id()` resolution order in
`backend/observability/tracing.py`: `run_id → workflow_id → session_id`.

## 2. Write your agent prompts + agent functions

Prompt files live in `prompts/*.md`, each with a `## System Prompt` fenced
code block (that's the only part `get_prompt()` extracts — see
`backend/ai/prompt_library/loader.py`). Copy the structure of
`prompts/waste-prediction-agent.md` or `prompts/chat-response-agent.md`:
Role → Grounding/Refusal Rules → Output Schema → Confidence Calibration.
The grounding rules matter most — that's what keeps a new agent from
hallucinating just like the existing ones don't.

Each agent function follows this shape (see
`backend/ai/agents/waste_prediction_agent.py` as the fullest example):

```python
from ai.prompt_library.loader import get_prompt
from observability.tracing import trace_agent
from llm.providers import get_llm

_SYSTEM_PROMPT = get_prompt("your-new-agent")

@trace_agent("your_new_agent")
async def your_new_node(state: YourWorkflowState) -> YourWorkflowState:
    llm = get_llm(mini=True)  # or mini=False for the primary model
    messages = [{"role": "system", "content": _SYSTEM_PROMPT}, {"role": "user", "content": ...}]
    response = await llm.ainvoke(messages)
    ...
    return {**state, "your_output_key": result}
```

The `@trace_agent(...)` decorator is doing three things for free, with zero
extra code from you: persisting a row to `ai_traces` (latency, tokens, cost,
truncated input/output), publishing live `agent_start`/`agent_complete`
events for SSE streaming, and forwarding to Langfuse automatically if you
later configure it. This is the single most load-bearing pattern in the
whole reuse story — decorate every node with it and the rest of this guide
works with no further plumbing.

If your agent needs anti-hallucination grounding against retrieved context
(any RAG-answering agent), reuse `backend/ai/guardrails/groundedness.py`:
`verify_citations()`, `score_groundedness()`, `confidence_tier()`,
`check_numeric_plausibility()` — all domain-agnostic, work on any
`list[dict]` context + `[n]`-style citation text.

## 3. Wire a new StateGraph

Copy the pattern in `backend/ai/workflows/prediction_workflow.py`:

```python
def build_your_workflow():
    graph = StateGraph(YourWorkflowState)
    graph.add_node("step_a", step_a_node)
    graph.add_node("step_b", step_b_node)
    graph.set_entry_point("step_a")
    graph.add_edge("step_a", "step_b")
    graph.add_edge("step_b", END)
    return graph.compile()

your_workflow = build_your_workflow()
```

**Lesson learned this session**: a node registered with `add_node()` but
never connected with `add_edge()` silently never runs — LangGraph compiles
fine either way. Double-check every node you add actually has an edge in.

## 4. Point RAG at your new domain

`backend/ai/rag/pipeline.py`'s `RAGPipeline` is fully generic — hybrid dense
(Chroma) + sparse (BM25) retrieval, Reciprocal Rank Fusion, cross-encoder
rerank, minimum-relevance thresholding. Nothing in it references plastics.
To repoint it:

1. Drop new `.md` documents into `input-data/knowledge-base/` (or point
   `KNOWLEDGE_BASE_DIR` in `config/runtime.env` at a different folder).
2. `backend/data/seed_rag.py`'s `seed_rag_knowledge_base()` ingests every
   `.md` file there on startup automatically — no code change needed.
3. Optionally update `_SOURCE_CATEGORY_KEYWORDS` in `pipeline.py` if you want
   meaningful `source_category` metadata for your new documents (it's a
   simple filename-keyword classifier, purely cosmetic for citations).

Call `RAGPipeline().retrieve(query, top_k=5)` from any new retriever node —
identical to `ai/agents/retriever_agent.py`.

## 5. Guardrails — reuse as-is, edit one constant block

`backend/ai/guardrails/input_guardrails.py` is domain-agnostic except for:

```python
ALLOWED_TOPICS = ["supply_chain", "sustainability", "packaging", "plastic_waste", "regulations"]
OFF_TOPIC_DOMAINS = ["sports", "entertainment", "personal_finance"]
```

Change these two lists to your new domain's topics and the tier-2 LLM
classifier (`classify_message()`) automatically adapts — it interpolates
`ALLOWED_TOPICS` into its own prompt. Everything else (injection regex, PII
detection/masking, rate limiting) needs no changes.

## 6. Add a streaming endpoint — copy, don't reinvent

Copy the shape of `stream_waste_prediction` in
`backend/api/v1/routers/predictions.py` (background-task style, for
long-running work) or `chat_stream` in `backend/api/v1/routers/chat.py`
(single-request style, for immediate work):

```python
from observability import live_progress

@router.get("/your-thing/{id}/stream")
async def stream_your_thing(id: str, current_user: User = Depends(get_current_user)):
    async def event_generator():
        queue = live_progress.subscribe(id)
        try:
            while True:
                event = await queue.get()
                yield live_progress.format_sse(event)
                if event.get("type") in live_progress.TERMINAL_EVENT_TYPES:
                    break
        finally:
            live_progress.unregister(id)
    return StreamingResponse(event_generator(), media_type="text/event-stream")
```

Register the channel (`live_progress.register(id)`) *before* kicking off
background work, not inside it — closes the race where the workflow starts
before anyone's subscribed (see the comment in `create_waste_prediction`).
Publish a final `{"type": "workflow_complete", "data": {...}}` (or `"done"`
for the synchronous/chat style) when your workflow finishes — that's the
terminal event the frontend hook watches for.

## 7. Frontend — genuinely zero new code for the streaming UI

This is the payoff of the whole pattern. In your new page:

```tsx
import { useAgentStream } from '../hooks/useAgentStream'
import AgentPipeline from '../components/ui/AgentPipeline'

const YOUR_AGENT_LABELS = { step_a: 'Step A — doing the thing', step_b: 'Step B — doing the other thing' }

const { steps, order, streaming, run } = useAgentStream()

// on submit:
const result = await run('/your-thing/stream', { method: 'GET' })
// result.finalResult has your terminal event's `data` payload

// in JSX, while streaming:
<AgentPipeline order={order} steps={steps} streaming={streaming} agentLabels={YOUR_AGENT_LABELS} />
```

`AgentPipeline` already handles: live status per agent, latency/confidence
badges, expandable input/output (from the event payload directly, no extra
fetch), and a "View full trace" link that hits
`GET /observability/traces/{trace_id}` for the complete record. None of this
code knows what "waste prediction" or "chat" is — it's driven entirely by
the `agent_start`/`agent_complete`/`agent_error`/`done`/`workflow_complete`
event shape, which every `@trace_agent`-decorated node already emits for
free.

## 8. Evaluation — new golden set, same runner

Copy `backend/ai/evaluation/golden_queries.json`'s shape:

```json
[{"id": "q01", "query": "...", "expected_doc_id": "your-new-doc-slug"}, ...]
```

Include a couple of `"expected_doc_id": null, "expect_refusal": true` entries
(off-topic questions) to verify your guardrails/refusal path too. If your new
use case has a chat-style grounded-answer workflow, `backend/ai/evaluation/runner.py`
works unmodified — it just needs `from ai.workflows.your_workflow import your_chat_workflow`
swapped in for `chat_workflow`. The `/evaluation/run`, `/evaluation/runs`,
`/evaluation/runs/{id}` endpoints and the whole AI Evaluation frontend page
need no changes — they're driven by the `EvalRunModel` row shape, not by
what's being evaluated.

## 9. Observability page — already generic, don't touch it

`Observability.tsx` and its backend (`backend/observability/metrics.py`,
`backend/api/v1/routers/observability.py`) query `ai_traces` grouped by
`agent_name` — a string your new `@trace_agent("...")` calls populate
automatically. New agents just show up. Same for the health check
(`backend/observability/health.py`) — it pings DB/Chroma/Redis/LLM gateway,
none of which are domain-specific.

---

## Fastest path checklist (copy this, delete what you've done)

- [ ] New domain entities + SQLAlchemy models (`domain/entities/`, `data/models/models.py`)
- [ ] New `WorkflowState` TypedDict with a `run_id`-or-equivalent field (`ai/state/workflow_state.py`)
- [ ] New `prompts/*.md` files (Role / Grounding / Output Schema / Confidence)
- [ ] New agent functions using `get_prompt()` + `@trace_agent(...)` (`ai/agents/`)
- [ ] New `StateGraph` wiring every node with an edge (`ai/workflows/`) — double-check no orphaned nodes
- [ ] New API router: a create/trigger endpoint + a `/stream` SSE endpoint reusing `live_progress`
- [ ] Point `input-data/knowledge-base/` at new domain docs (or a new `KNOWLEDGE_BASE_DIR`)
- [ ] Update `ALLOWED_TOPICS`/`OFF_TOPIC_DOMAINS` in `input_guardrails.py`
- [ ] New `golden_queries.json` for eval
- [ ] New frontend page: `useAgentStream()` + `<AgentPipeline>` + a labels map — that's the entire live-progress UI
- [ ] Everything under Observability/AI Evaluation pages: **no changes needed**
