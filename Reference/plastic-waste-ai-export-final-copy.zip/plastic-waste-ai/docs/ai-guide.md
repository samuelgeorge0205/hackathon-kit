# AI Guide

## LLM Client Setup (TCS GenAI Lab)

All LLM calls use the TCS GenAI Lab LiteLLM gateway at `https://genailab.tcs.in`.

```python
from langchain_openai import ChatOpenAI
import httpx

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-gpt-4o",
    api_key=settings.llm_api_key,
    http_async_client=httpx.AsyncClient(verify=False),  # TCS internal gateway
)
```

## Available Models (TCS GenAI Lab Season 2)

| Model | Use Case | Cost |
|---|---|---|
| `azure/genailab-maas-gpt-4o` | Predictions, Recommendations | Higher |
| `azure/genailab-maas-gpt-4o-mini` | Explanations, Formatting | Lower |
| `azure/genailab-maas-text-embedding-3-large` | RAG Embeddings | Low |
| `azure_ai/genailab-maas-DeepSeek-V3-0324` | Complex Reasoning | Medium |
| `gemini-2.5-flash` | Alternative fallback | Medium |

## Agent Architecture

7 agents in LangGraph StateGraph:

1. **Planner** — routes intent to correct subgraph
2. **Retriever** — hybrid RAG (ChromaDB + BM25 + reranker)
3. **WastePrediction** — AI waste volume prediction
4. **HandlingCost** — cost estimation (deterministic fallback)
5. **Recommendation** — packaging optimisation (grounded in RAG)
6. **Explanation** — plain-English XAI output
7. **ReportGenerator** — section-by-section report compilation

## RAG Quick Start

```python
from ai.rag.pipeline import RAGPipeline

# Ingest a document
pipeline = RAGPipeline()
await pipeline.ingest("path/to/document.pdf", metadata={"source_category": "regulations"})

# Retrieve
results = await pipeline.retrieve("PET packaging recycling requirements UK", top_k=5)
```

## Budget Management

- Team budget: $25 (TCS AI Fridays Season 2)
- Use `gpt-4o-mini` for non-critical agents
- Redis cache prevents duplicate LLM calls (TTL 1 hour)
- Monitor spend in Langfuse dashboard
