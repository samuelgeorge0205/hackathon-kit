# AI Architecture

## Scope
The AI platform in `backend/ai/` is modular and reusable across domains.

## Modules
- `agents/`: Task-specific agent nodes.
- `coordinator/`: Workflow orchestration and routing policy.
- `retrieval/`: Retrieval strategy composition.
- `rag/`: Ingestion and retrieval pipeline.
- `memory/`: Conversational and workflow memory policies.
- `guardrails/`: Safety, confidence, and policy checks.
- `evaluation/`: Offline and online quality evaluation.
- `prompt_library/`: Prompt assets and registry.
- `workflows/`: LangGraph state graphs.

## Current Compatibility
Existing workflows and agent interfaces remain unchanged; added module namespaces define enterprise target boundaries.
