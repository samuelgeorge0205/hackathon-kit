# API Architecture

## Responsibilities
- Route declaration and request/response validation.
- Authentication and authorization dependencies.
- Transport-level error handling.

## Non-Responsibilities
- No domain orchestration logic in routers.
- No direct repository wiring in route handlers.

## Versioning
- API remains under `/api/v1`.
- Contract compatibility is maintained while refactoring internals.

## Contract Sources
- Functional contract: `.spec-kit/14_api_contract.md`.
- Schema assets: `schemas/` with migration target `docs/contracts/api/`.
