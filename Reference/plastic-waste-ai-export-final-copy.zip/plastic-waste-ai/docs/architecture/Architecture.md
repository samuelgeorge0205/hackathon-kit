# Enterprise Architecture

## Purpose
This repository is organized as a reusable Enterprise AI Application Framework.

## Architectural Style
- Clean Architecture with inward dependency flow.
- Domain-Driven Design boundaries for business capabilities.
- Spec-Driven Development aligned to `.spec-kit`.
- AI engineering modules separated from API and persistence concerns.

## Layers
1. Frontend: User interaction only.
2. API: HTTP transport, validation, authn/authz, dependency injection.
3. Application: Use-case orchestration and workflow coordination.
4. Domain: Business entities, value objects, policies, repository interfaces.
5. AI: Agent orchestration, retrieval, prompting, evaluation, guardrails.
6. Data: Repository implementations, mappers, schema persistence adapters.
7. Infrastructure: External systems (DB, Redis, LLM providers, storage).
8. Observability: Logging, tracing, metrics, audit.

## Dependency Rules
- API can depend on Application and boundary interfaces only.
- Application can depend on Domain abstractions and AI/Data interfaces.
- Domain cannot depend on framework or infrastructure code.
- Infrastructure implements interfaces defined inward.

## Runtime Compatibility
Current production behavior is preserved. This restructure introduces a clear target blueprint and migration-safe module boundaries without changing API behavior.
