# Coding Standards

## Principles
- SOLID, DRY, KISS, YAGNI.
- Explicit type hints on public functions.
- Async-first for I/O paths.

## Backend Rules
- Domain layer has no framework imports.
- Application orchestrates use cases and workflow composition.
- API layer performs validation, auth, and transport mapping only.
- Repository pattern for persistence access.

## AI Engineering Rules
- Encapsulate prompts and model calls behind module boundaries.
- Keep workflow state typed and explicit.
- Add guardrail checks around groundedness, confidence, and output schema.

## Test Rules
- Unit tests for domain and application behavior.
- Integration tests for repositories and HTTP routes.
- AI tests for schema validity and safety checks.
