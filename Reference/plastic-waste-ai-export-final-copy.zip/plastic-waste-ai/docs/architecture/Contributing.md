# Contributing

## Workflow
1. Keep functional behavior unchanged unless explicitly approved.
2. Prefer incremental refactors with compatibility wrappers.
3. Add or update tests with every structural change.

## Pull Request Checklist
- Architecture boundary respected.
- No API contract drift.
- No domain-framework coupling introduced.
- Docs updated in `docs/architecture/` and relevant guides.

## Commit Grouping
- Group by concern: structure, adapters, tests, docs.
