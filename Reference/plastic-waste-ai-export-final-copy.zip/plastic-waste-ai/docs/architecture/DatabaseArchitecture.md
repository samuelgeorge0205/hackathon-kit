# Database Architecture

## Current Runtime
- SQLite async runtime for development/demo.
- SQLAlchemy models in `backend/data/models/`.

## Target Enterprise Direction
- Migrations-first lifecycle.
- Repository implementations in data layer only.
- Domain model remains persistence-agnostic.

## Data Boundaries
- Operational records: relational database.
- Retrieval vectors: vector store.
- Cache/session: Redis.

## Contract Mapping
- Relational shape reference in `.spec-kit/09_database_design.md`.
- Migration target contracts in `docs/contracts/database/`.
