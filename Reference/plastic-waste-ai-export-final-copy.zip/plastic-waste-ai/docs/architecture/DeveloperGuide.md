# Developer Guide

## First Run
1. Backend: `cd backend && uv sync && uv run uvicorn main:app --reload`.
2. Frontend: `cd frontend && npm install && npm run dev`.

## Interpreter Policy
- Use one Python environment at `backend/.venv`.
- Workspace interpreter is pinned in `.vscode/settings.json`.

## Design Policy
- Add business behavior in `domain/` and `application/` first.
- Keep routers thin: no orchestration or repository logic in route handlers.
- Place AI behavior in `ai/` with explicit workflow/state boundaries.

## Configuration Policy
- Runtime values come from environment and `infrastructure/config/settings.py`.
- Specification defaults and non-runtime guidance live in `config/*.yaml`.

## Migration Policy
- Favor additive refactors with compatibility shims.
- Keep endpoint paths and payload contracts stable unless explicitly approved.
