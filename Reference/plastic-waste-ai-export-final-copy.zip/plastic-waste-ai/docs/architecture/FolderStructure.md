# Folder Structure

## Repository Root
- `.spec-kit/`: Source-of-truth specifications.
- `docs/architecture/`: Canonical architecture and standards.
- `docs/decision-records/`: Architecture Decision Records (ADRs).
- `docs/contracts/`: API, database, event, and agent contracts.
- `config/`: Environment-agnostic configuration specs.
- `docs/deployment/`: Operational deployment documentation.
- `docs/scripts/`: Automation scripts and operational wrappers.
- `docs/datasets/`: Dataset governance and catalog.
- `src/`: Executable application code.

## Backend
- `backend/api/`: Routers, dependencies, transport models.
- `backend/application/`: Use cases and orchestration.
- `backend/domain/`: Entities, repository interfaces, business rules.
- `backend/ai/`: Agents, workflows, retrieval, memory, guardrails, evaluation.
- `backend/data/`: Persistence models and repository implementations.
- `backend/infrastructure/`: External adapters and config runtime.
- `backend/shared/`: Cross-cutting utils, constants, middleware, exceptions.
- `backend/tests/`: Unit, integration, api, ai, performance, security tests.

## Frontend
- `frontend/src/`: Pages, components, services, store, and app shell.

## Transitional Notes
- Existing folders `input-data/structured/`, `input-data/knowledge-base/`, and `schemas/` remain authoritative for current runtime.
- `docs/datasets/` and `docs/contracts/` provide enterprise-grade indexing and migration targets.
