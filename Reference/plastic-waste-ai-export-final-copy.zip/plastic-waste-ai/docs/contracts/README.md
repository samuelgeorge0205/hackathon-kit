# Contracts

This directory contains enterprise contract surfaces.

Subfolders:
- `api/`: HTTP request/response schemas and envelope contracts.
- `database/`: logical data model contracts and migration references.
- `events/`: domain and integration event contracts.
- `agents/`: agent input/output contracts.
- `prompts/`: prompt contract definitions and constraints.

Compatibility note:
Current runtime schemas remain under `schemas/`; this folder is the enterprise contract target and index.
