# Agent Contracts

Authoritative references:
- `.spec-kit/11_ai_agents.md`
- `schemas/ai/agent-output.json`

Planned canonical assets:
- workflow state contracts
- per-agent input/output schemas
- confidence and citation constraints
