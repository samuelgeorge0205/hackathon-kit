# API Contracts

Authoritative references:
- `.spec-kit/14_api_contract.md`
- `schemas/api/`

Planned canonical assets:
- request schemas
- response schemas
- error envelope schema
- pagination and metadata contracts
