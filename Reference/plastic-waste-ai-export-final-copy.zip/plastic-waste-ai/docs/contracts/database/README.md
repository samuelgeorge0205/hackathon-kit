# Database Contracts

Authoritative references:
- `.spec-kit/09_database_design.md`
- `config/database.yaml`

Planned canonical assets:
- table contracts
- relationship contracts
- migration compatibility contracts
