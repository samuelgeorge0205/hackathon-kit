# Event Contracts

Authoritative references:
- `.spec-kit/07_architecture.md`
- `.spec-kit/13_observability.md`

Planned canonical assets:
- domain event schemas
- audit event schemas
- integration event routing contracts
