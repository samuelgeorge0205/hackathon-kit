# Prompt Contracts

Authoritative references:
- `prompts/`
- `.spec-kit/12_guardrails.md`

Planned canonical assets:
- prompt templates with version tags
- prompt safety constraints
- output format guarantees
