# Datasets

Dataset governance and catalog directory.

Current runtime datasets remain in:
- `input-data/structured/`
- `input-data/knowledge-base/`

This folder provides enterprise-grade indexing and lifecycle documentation for future dataset packs.
