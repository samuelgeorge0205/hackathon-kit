# Demo Guide

## Pre-Demo Checklist (30 minutes before)

```bash
# 1. Start backend
cd backend
uv run uvicorn main:app --host 0.0.0.0 --port 8000

# 2. Start frontend
cd frontend
npm run dev

# 3. Verify health
curl http://localhost:8000/api/v1/health
# Expected: {"status": "healthy", ...}

# 4. Open browser to http://localhost:3000
# 5. Log in as: analyst@demo.com / Demo1234!
```

## Demo Script (5 minutes)

### [0:00] Introduction
- Introduce team + problem: "Retailers can't predict plastic waste or measure handling costs"

### [0:30] Problem  
- Show architecture diagram slide

### [1:00] Solution Overview
- Show 8-layer architecture + LangGraph agent diagram

### [2:00] Live Demo

**Dashboard** (30 sec):
1. Open http://localhost:3000
2. Show KPI cards: total waste, cost, recommendations value

**Prediction** (1 min):
1. Navigate to Predictions
2. Fill: Supplier=GlobalFoods, Period=Aug 2026, Volume=15000
3. Click Run → wait ~5s → show result card
4. Point out: confidence badge (green), XAI explanation, plastic breakdown

**AI Copilot** (30 sec):
1. Navigate to Copilot
2. Type: "Which supplier has the highest waste intensity?"
3. Show cited response

**Report** (30 sec):
1. Navigate to Reports → configure → Generate
2. Show "Generating..." → preview loads

### [4:00] Results & Metrics
- Show metrics table: prediction accuracy, report time, cost

### [4:30] Conclusion
- Modular framework: "Any domain, swap the domain module"
- Roadmap: ERP integration, IoT sensors, multi-tenant

## Backup Screenshots
Save screenshots of each screen in case of connectivity issues.
Location: `docs/demo-screenshots/`
