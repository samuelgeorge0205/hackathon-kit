# Deployment Guide

## Local Development (Hackathon Environment)

Python environment policy for this repo:
- Use a single Python environment at `backend/.venv`
- Do not create or use a root-level `.venv`

### Prerequisites
- Python 3.12.8 (pre-installed on TCS AI Lab laptops)
- Node.js 20+ (available via open internet on AI Lab)
- Redis (install via `winget install Redis.Redis` or use local Docker image)

### Quick Start

```bash
# 1. Prepare central runtime config file
cp config/runtime.env.example config/runtime.env
# Fill in: LLM_API_KEY (provided on event day), SECRET_KEY (generate random 32 chars)

# 2. Backend
cd backend
uv sync
uv run alembic upgrade head
uv run python data/seed_db.py
uv run uvicorn main:app --reload --port 8000

# 3. Frontend (new terminal)
cd frontend
npm install
npm run dev

# 4. Access
# API: http://localhost:8000/docs
# App: http://localhost:3000
```

### Environment Variables

```bash
# config/runtime.env
LLM_API_KEY=<from_event_day>
LLM_GATEWAY_URL=https://genailab.tcs.in
LLM_PRIMARY_MODEL=azure/genailab-maas-gpt-4o
LLM_MINI_MODEL=azure/genailab-maas-gpt-4o-mini
EMBEDDING_MODEL=azure/genailab-maas-text-embedding-3-large
SECRET_KEY=<32_random_chars>
DATABASE_URL=sqlite+aiosqlite:///./data/database_files/app.db
REDIS_URL=redis://localhost:6379/0
LANGFUSE_PUBLIC_KEY=<optional>
LANGFUSE_SECRET_KEY=<optional>
```

## Gogs Repository (TCS AI Lab)

```bash
# Set remote to Gogs (not GitHub — per Handbook §8.5)
git remote add origin http://<gogs_url>/<team>/<repo>.git
git push -u origin main
```

## Production (Future)

For production deployment, change only:
```bash
DATABASE_URL=postgresql+asyncpg://user:pass@host:5432/plasticwaste
```
No application code changes required.
