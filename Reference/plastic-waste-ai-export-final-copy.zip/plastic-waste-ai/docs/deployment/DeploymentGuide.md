# Deployment Guide

## Environments
- Local: single-node SQLite + local frontend.
- Hackathon: TCS gateway profile via environment mode switch.
- Enterprise target: externalized DB/cache/observability.

## Startup
- Backend: `cd backend && uv sync && uv run uvicorn main:app --reload --port 8000`.
- Frontend: `cd frontend && npm install && npm run dev`.

## Operational Checks
- API docs: `http://localhost:8000/docs`.
- Frontend: `http://localhost:3000`.

## Configuration
- Runtime env model in `backend/infrastructure/config/settings.py`.
- Non-runtime configuration references in `config/*.yaml`.
