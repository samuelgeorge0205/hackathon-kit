# Scripts

This directory is reserved for operational and developer automation scripts.

Current executable setup scripts are in this folder:
- `scripts/setup.bat`
- `scripts/setup.ps1`

Future additions:
- lint/test automation wrappers
- data bootstrap helpers
- migration utilities
