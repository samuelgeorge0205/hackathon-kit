# Agent Implementation Template

## Usage
Copy this template when implementing a new LangGraph agent node.

```python
# ai/agents/{agent_name}_agent.py
from __future__ import annotations

from langfuse.decorators import observe, langfuse_context
from pydantic import BaseModel

from ai.agents._base import get_llm
from ai.prompts.prompt_registry import get_prompt
from ai.state.workflow_state import PredictionWorkflowState


class {AgentName}Output(BaseModel):
    """Structured output — matches prompt output schema exactly."""
    # Define fields from prompts/{agent-name}-agent.md output schema
    confidence_score: float
    # ... other fields


@observe(name="{agent_name}_agent")
async def {agent_name}_node(state: PredictionWorkflowState) -> PredictionWorkflowState:
    """LangGraph node — reads state, calls LLM, writes result back to state."""
    langfuse_context.update_current_trace(
        user_id=state.get("user_id"),
        session_id=state.get("workflow_id"),
    )

    llm = get_llm(mini=False)  # use mini=True for cost-sensitive agents
    prompt = get_prompt("{agent_name}", **_build_prompt_args(state))

    for attempt in range(3):
        try:
            response = await llm.ainvoke(prompt)
            result = {AgentName}Output.model_validate_json(response.content)
            break
        except Exception as e:
            if attempt == 2:
                return {**state, "errors": state.get("errors", []) + [str(e)]}
            prompt = prompt + "\n\nIMPORTANT: Return ONLY valid JSON."

    return {
        **state,
        "{agent_output_key}": result.model_dump(),
        "confidence_score": result.confidence_score,
    }


def _build_prompt_args(state: PredictionWorkflowState) -> dict:
    return {
        "historical_data_json": state.get("historical_data", []),
        "retrieved_context": state.get("retrieved_context", []),
        # ... map state fields to prompt variables
    }
```
