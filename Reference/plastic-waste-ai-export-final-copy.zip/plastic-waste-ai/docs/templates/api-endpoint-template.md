# API Endpoint Template

## Usage
Copy this template when implementing a new FastAPI endpoint.

```python
# api/v1/routers/{resource}.py
from fastapi import APIRouter, Depends, status
from api.v1.dependencies import get_current_user, require_role, get_{resource}_service
from api.v1.models.requests.{resource}_request import {Resource}Request
from api.v1.models.responses.{resource}_response import {Resource}Response
from application.services.{resource}_service import {Resource}Service
from domain.entities.user import User

router = APIRouter()


@router.post(
    "/",
    response_model={Resource}Response,
    status_code=status.HTTP_201_CREATED,
    summary="Create {resource}",
    description="Create a new {resource}. Requires analyst role or above.",
)
async def create_{resource}(
    payload: {Resource}Request,
    current_user: User = Depends(require_role("analyst")),
    service: {Resource}Service = Depends(get_{resource}_service),
) -> {Resource}Response:
    result = await service.create(payload.to_dto(), current_user.id)
    return {Resource}Response.from_domain(result)


@router.get(
    "/{id}",
    response_model={Resource}Response,
    summary="Get {resource} by ID",
)
async def get_{resource}(
    id: str,
    current_user: User = Depends(get_current_user),
    service: {Resource}Service = Depends(get_{resource}_service),
) -> {Resource}Response:
    result = await service.get_by_id(id, current_user)
    return {Resource}Response.from_domain(result)
```
