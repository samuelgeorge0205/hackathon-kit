# Repository Implementation Template

## Usage
Copy this template when implementing a new SQLite repository.

```python
# data/repositories/sqlite/{entity}_repository.py
from __future__ import annotations

from uuid import UUID
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from domain.entities.{entity} import {Entity}
from domain.repositories.i_{entity}_repository import I{Entity}Repository
from data.models.{entity}_model import {Entity}Model
from data.mappers.{entity}_mapper import {Entity}Mapper


class SQLite{Entity}Repository(I{Entity}Repository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, entity: {Entity}) -> {Entity}:
        existing = await self._session.get({Entity}Model, entity.id)
        if existing:
            for k, v in {Entity}Mapper.to_model_dict(entity).items():
                setattr(existing, k, v)
        else:
            self._session.add({Entity}Mapper.to_model(entity))
        await self._session.flush()
        return entity

    async def get_by_id(self, id: UUID) -> {Entity} | None:
        model = await self._session.get({Entity}Model, id)
        return {Entity}Mapper.to_entity(model) if model else None

    async def list(self, limit: int = 20, offset: int = 0) -> list[{Entity}]:
        result = await self._session.execute(
            select({Entity}Model).limit(limit).offset(offset)
        )
        return [{Entity}Mapper.to_entity(m) for m in result.scalars()]
```
