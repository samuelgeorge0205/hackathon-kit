# Test Template

## Unit Test Template (Domain Entity)

```python
# tests/unit/domain/test_{entity}.py
import pytest
from datetime import date
from {entity module path} import {Entity}


class Test{Entity}:
    def test_creates_valid_entity(self):
        entity = {Entity}(
            # required fields with valid values
        )
        assert entity.id is not None

    def test_rejects_invalid_{field}(self):
        with pytest.raises(ValueError, match="<expected message>"):
            {Entity}(invalid_field_value=...)

    def test_{business_rule}(self):
        entity = {Entity}(...)
        # assert business rule outcome
```

## Integration Test Template (API Endpoint)

```python
# tests/integration/api/test_{resource}.py
import pytest
from httpx import AsyncClient
from main import app


@pytest.fixture
async def client():
    async with AsyncClient(app=app, base_url="http://test") as c:
        yield c


@pytest.fixture
def analyst_token(client):
    resp = client.post("/api/v1/auth/login", json={"email": "test@test.com", "password": "test"})
    return resp.json()["data"]["access_token"]


class Test{Resource}Endpoints:
    async def test_create_returns_201(self, client, analyst_token):
        response = await client.post(
            "/api/v1/{resource}",
            json={valid_payload},
            headers={"Authorization": f"Bearer {analyst_token}"},
        )
        assert response.status_code == 201
        assert "id" in response.json()["data"]

    async def test_unauthenticated_returns_401(self, client):
        response = await client.post("/api/v1/{resource}", json={valid_payload})
        assert response.status_code == 401

    async def test_viewer_role_returns_403(self, client, viewer_token):
        response = await client.post(
            "/api/v1/{resource}",
            json={valid_payload},
            headers={"Authorization": f"Bearer {viewer_token}"},
        )
        assert response.status_code == 403
```
