# Frontend Architecture

Purpose:
- Presentation layer only.

Boundaries:
- Consumes backend contracts through HTTP APIs.
- Holds UI state, routing, and view composition.
- Does not contain backend business logic.

Primary modules:
- pages/
- components/
- services/
- store/
- hooks/
