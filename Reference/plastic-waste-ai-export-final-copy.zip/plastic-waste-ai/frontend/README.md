# Frontend Module Structure

This module is the presentation layer of the framework.

Responsibilities:
- Render views and dashboards.
- Manage UI state and route transitions.
- Consume backend APIs through typed service clients.

Non-responsibilities:
- No backend business logic.
- No direct database/LLM access.

## Target Structure (created in M6)

```
frontend/
├── index.html
├── vite.config.ts
├── tailwind.config.ts
├── tsconfig.json
├── package.json
│
├── src/
│   ├── main.tsx                   # App entry point
│   ├── App.tsx                    # Router setup
│   │
│   ├── pages/                     # One folder per route
│   │   ├── Dashboard/
│   │   │   └── index.tsx
│   │   ├── Upload/
│   │   │   └── index.tsx
│   │   ├── Predictions/
│   │   │   └── index.tsx
│   │   ├── Analytics/
│   │   │   └── index.tsx
│   │   ├── Copilot/
│   │   │   └── index.tsx
│   │   ├── Reports/
│   │   │   └── index.tsx
│   │   └── Settings/
│   │       └── index.tsx
│   │
│   ├── components/
│   │   ├── charts/                # Recharts wrappers
│   │   ├── forms/                 # Reusable form elements
│   │   ├── layout/                # NavBar, Sidebar, PageWrapper
│   │   └── ui/                    # Button, Badge, Card, Modal
│   │
│   ├── hooks/
│   │   ├── usePredictions.ts
│   │   ├── useRecommendations.ts
│   │   └── useAuth.ts
│   │
│   ├── services/                  # API client functions
│   │   ├── apiClient.ts           # Axios instance with auth interceptor
│   │   ├── predictionService.ts
│   │   ├── uploadService.ts
│   │   ├── chatService.ts
│   │   └── reportService.ts
│   │
│   ├── store/                     # Zustand state stores
│   │   ├── authStore.ts
│   │   └── appStore.ts
│   │
│   └── types/                     # TypeScript type definitions
│       ├── prediction.ts
│       ├── recommendation.ts
│       └── api.ts
│
└── tests/
    └── e2e/                       # Playwright tests
        ├── dashboard.spec.ts
        ├── upload.spec.ts
        ├── predictions.spec.ts
        ├── copilot.spec.ts
        ├── reports.spec.ts
        └── auth.spec.ts
```

## Environment Variables

```bash
# frontend/.env
VITE_API_BASE_URL=http://localhost:8000/api/v1
```

See [ARCHITECTURE.md](ARCHITECTURE.md) for frontend boundary details.
