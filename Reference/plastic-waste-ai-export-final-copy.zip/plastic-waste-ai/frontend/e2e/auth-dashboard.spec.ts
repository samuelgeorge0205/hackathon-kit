import { test, expect } from '@playwright/test'

test('login and dashboard data render', async ({ page }) => {
  await page.goto('/login')

  await page.getByLabel(/email/i).fill('analyst@demo.com')
  await page.getByLabel(/password/i).fill('Demo1234!')
  await page.getByRole('button', { name: /sign in/i }).click()

  await expect(page).toHaveURL('/')
  await expect(page.getByText(/dashboard/i).first()).toBeVisible()
  await expect(page.getByText(/total waste/i)).toBeVisible()
  await expect(page.getByText(/handling cost/i)).toBeVisible()
})
