import { test, expect, Page } from '@playwright/test'

const ANALYST = { email: 'analyst@demo.com', password: 'Demo1234!' }

async function login(page: Page) {
  await page.goto('/login')
  await page.getByLabel(/email/i).fill(ANALYST.email)
  await page.getByLabel(/password/i).fill(ANALYST.password)
  await page.getByRole('button', { name: /sign in/i }).click()
  await expect(page).toHaveURL('/')
}

test.describe('Authentication', () => {
  test('redirects unauthenticated users to /login', async ({ page }) => {
    await page.goto('/')
    await expect(page).toHaveURL('/login')
  })

  test('shows error on wrong credentials', async ({ page }) => {
    await page.goto('/login')
    await page.getByLabel(/email/i).fill('wrong@example.com')
    await page.getByLabel(/password/i).fill('wrongpass')
    await page.getByRole('button', { name: /sign in/i }).click()
    await expect(page.getByText(/invalid|incorrect|unauthorized/i)).toBeVisible()
  })

  test('logs in successfully and lands on dashboard', async ({ page }) => {
    await login(page)
    await expect(page.getByRole('heading', { name: 'Dashboard' }).first()).toBeVisible()
  })
})

test.describe('Dashboard', () => {
  test.beforeEach(async ({ page }) => { await login(page) })

  test('shows KPI cards', async ({ page }) => {
    await expect(page.getByText(/total waste/i)).toBeVisible()
    await expect(page.getByText(/handling cost/i)).toBeVisible()
    await expect(page.getByText(/prediction accuracy/i)).toBeVisible()
  })

  test('shows waste trend chart', async ({ page }) => {
    await expect(page.locator('.recharts-wrapper').first()).toBeVisible()
  })
})

test.describe('Waste Predictions', () => {
  test.beforeEach(async ({ page }) => { await login(page); await page.goto('/predictions') })

  test('prediction form renders with date inputs', async ({ page }) => {
    await expect(page.getByLabel(/period start/i)).toBeVisible()
    await expect(page.getByLabel(/period end/i)).toBeVisible()
    await expect(page.getByRole('button', { name: /predict|run/i })).toBeVisible()
  })

  test('submitting prediction shows loading state', async ({ page }) => {
    await page.getByRole('button', { name: /predict|run/i }).click()
    await expect(page.getByRole('button', { name: /running ai/i })).toBeVisible({ timeout: 7000 })
  })
})

test.describe('Upload', () => {
  test.beforeEach(async ({ page }) => { await login(page); await page.goto('/upload') })

  test('upload page renders file drop zones', async ({ page }) => {
    await expect(page.getByText(/drag|drop|browse|upload/i).first()).toBeVisible()
  })
})

test.describe('Recommendations', () => {
  test.beforeEach(async ({ page }) => { await login(page); await page.goto('/recommendations') })

  test('recommendations page loads without error', async ({ page }) => {
    await expect(page.getByRole('heading', { name: 'Recommendations' }).first()).toBeVisible()
    await expect(page.getByText(/error|failed/i)).not.toBeVisible()
  })
})

test.describe('AI Copilot', () => {
  test.beforeEach(async ({ page }) => { await login(page); await page.goto('/copilot') })

  test('chat input renders', async ({ page }) => {
    await expect(page.getByPlaceholder(/ask about waste/i)).toBeVisible()
    await expect(page.getByRole('button', { name: /send/i })).toBeVisible()
  })

  test('sending a message shows response area', async ({ page }) => {
    const message = 'What is our largest source of plastic waste?'
    await page.getByPlaceholder(/ask about waste/i).fill(message)
    await page.getByRole('button', { name: /send/i }).click()
    await expect(page.getByText(message)).toBeVisible({ timeout: 10000 })
  })
})

test.describe('Reports', () => {
  test.beforeEach(async ({ page }) => { await login(page); await page.goto('/reports') })

  test('reports page renders generate button', async ({ page }) => {
    await expect(page.getByRole('button', { name: /generate/i })).toBeVisible()
  })

  test('generated report can be downloaded as pdf', async ({ page }) => {
    test.setTimeout(120000)
    await page.getByRole('button', { name: /generate/i }).click()
    await expect(page.getByRole('heading', { name: /Plastic Waste Sustainability Report/i })).toBeVisible({ timeout: 90000 })

    const responsePromise = page.waitForResponse(
      (response) => response.url().includes('/reports/') && response.url().includes('/download') && response.status() === 200,
      { timeout: 20000 }
    )
    await page.getByRole('button', { name: /download pdf/i }).click()
    const response = await responsePromise
    expect((response.headers()['content-type'] || '').toLowerCase()).toContain('application/pdf')
  })
})

test.describe('Navigation', () => {
  test.beforeEach(async ({ page }) => { await login(page) })

  test('sidebar links navigate to all pages', async ({ page }) => {
    const links: [string, string][] = [
      ['/predictions', 'prediction'],
      ['/analytics', 'analytic'],
      ['/recommendations', 'recommendation'],
      ['/upload', 'upload'],
      ['/copilot', 'copilot'],
      ['/reports', 'report'],
    ]
    for (const [path, keyword] of links) {
      await page.goto(path)
      await expect(page.getByText(new RegExp(keyword, 'i')).first()).toBeVisible()
    }
  })
})
