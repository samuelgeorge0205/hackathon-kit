import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useAuthStore } from './store/authStore'
import Layout from './components/layout/Layout'
import LoginPage from './pages/Login'
import DashboardPage from './pages/Dashboard'
import PredictionsPage from './pages/Predictions'
import AnalyticsPage from './pages/Analytics'
import RecommendationsPage from './pages/Recommendations'
import UploadPage from './pages/Upload'
import CopilotPage from './pages/Copilot'
import ReportsPage from './pages/Reports'
import SettingsPage from './pages/Settings'
import KnowledgeCenterPage from './pages/KnowledgeCenter'
import AdministrationPage from './pages/Administration'
import UsersPage from './pages/Users'
import PromptLibraryPage from './pages/PromptLibrary'
import AIEvaluationPage from './pages/AIEvaluation'
import ObservabilityPage from './pages/Observability'
import AuditPage from './pages/Audit'
import NotificationsPage from './pages/Notifications'
import ProfilePage from './pages/Profile'
import HelpPage from './pages/Help'

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const token = useAuthStore(s => s.accessToken)
  return token ? <>{children}</> : <Navigate to="/login" replace />
}

function RoleRoute({
  children,
  allowed,
}: {
  children: React.ReactNode
  allowed: string[]
}) {
  const role = (useAuthStore(s => s.user?.role) ?? '').toLowerCase()
  return allowed.includes(role) ? <>{children}</> : <Navigate to="/" replace />
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/" element={<PrivateRoute><Layout /></PrivateRoute>}>
          <Route index element={<DashboardPage />} />
          <Route path="predictions" element={<PredictionsPage />} />
          <Route path="analytics" element={<AnalyticsPage />} />
          <Route path="recommendations" element={<RecommendationsPage />} />
          <Route path="upload" element={<UploadPage />} />
          <Route path="copilot" element={<CopilotPage />} />
          <Route path="reports" element={<ReportsPage />} />
          <Route path="settings" element={<SettingsPage />} />
          <Route path="knowledge-center" element={<KnowledgeCenterPage />} />
          <Route path="administration" element={<RoleRoute allowed={['manager', 'admin']}><AdministrationPage /></RoleRoute>} />
          <Route path="users" element={<RoleRoute allowed={['admin']}><UsersPage /></RoleRoute>} />
          <Route path="prompt-library" element={<RoleRoute allowed={['manager', 'admin']}><PromptLibraryPage /></RoleRoute>} />
          <Route path="ai-evaluation" element={<RoleRoute allowed={['manager', 'admin']}><AIEvaluationPage /></RoleRoute>} />
          <Route path="observability" element={<RoleRoute allowed={['admin']}><ObservabilityPage /></RoleRoute>} />
          <Route path="audit" element={<RoleRoute allowed={['admin']}><AuditPage /></RoleRoute>} />
          <Route path="notifications" element={<NotificationsPage />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="help" element={<HelpPage />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}
