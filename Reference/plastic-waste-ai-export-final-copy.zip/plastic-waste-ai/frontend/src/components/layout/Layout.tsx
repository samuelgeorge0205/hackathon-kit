import { useEffect, useMemo, useState } from 'react'
import { Outlet, NavLink, useNavigate, useLocation } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'
import { authService } from '../../services/services'
import {
  LayoutDashboard, TrendingUp, Upload, Bot, FileBarChart,
  Settings, LogOut, Leaf, BarChart3, Lightbulb, Menu, X, Search,
  ChevronLeft, ChevronRight, Sparkles, Bell, UserCircle2, Command,
  BookOpen, Shield, LifeBuoy
} from 'lucide-react'
import clsx from 'clsx'
import { useAppStore } from '../../store/appStore'
import { ToastCenter } from '../ui/components'

interface NavItem {
  to: string
  label: string
  icon: React.ComponentType<{ className?: string }>
  section: 'Core' | 'Intelligence' | 'Administration'
}

const NAV: NavItem[] = [
  { to: '/',               label: 'Dashboard',       icon: LayoutDashboard },
  { to: '/predictions',    label: 'Predictions',     icon: TrendingUp },
  { to: '/analytics',      label: 'Analytics',       icon: BarChart3 },
  { to: '/recommendations', label: 'Recommendations', icon: Lightbulb },
  { to: '/upload',         label: 'Upload Data',     icon: Upload },
  { to: '/copilot',        label: 'AI Copilot',      icon: Bot },
  { to: '/reports',        label: 'Reports',         icon: FileBarChart },
  { to: '/knowledge-center', label: 'Knowledge Center', icon: BookOpen },
  { to: '/notifications',  label: 'Notifications',   icon: Bell },
  { to: '/profile',        label: 'Profile',         icon: UserCircle2 },
  { to: '/administration', label: 'Administration',  icon: Shield },
  { to: '/users',          label: 'Users',           icon: UserCircle2 },
  { to: '/prompt-library', label: 'Prompt Library',  icon: BookOpen },
  { to: '/ai-evaluation',  label: 'AI Evaluation',   icon: Sparkles },
  { to: '/observability',  label: 'Observability',   icon: BarChart3 },
  { to: '/audit',          label: 'Audit',           icon: Shield },
  { to: '/settings',       label: 'Settings',        icon: Settings },
  { to: '/help',           label: 'Help',            icon: LifeBuoy },
].map((item) => {
  if (['/knowledge-center', '/notifications', '/profile'].includes(item.to)) {
    return { ...item, section: 'Intelligence' as const }
  }
  if (['/administration', '/users', '/prompt-library', '/ai-evaluation', '/observability', '/audit', '/settings', '/help'].includes(item.to)) {
    return { ...item, section: 'Administration' as const }
  }
  return { ...item, section: 'Core' as const }
})

const NAV_SECTIONS: Array<NavItem['section']> = ['Core', 'Intelligence', 'Administration']

const QUICK_ACTIONS = [
  { to: '/reports', label: 'Generate report' },
  { to: '/copilot', label: 'Open AI copilot' },
  { to: '/notifications', label: 'Review notifications' },
]

export default function Layout() {
  const { user, refreshToken, clearAuth } = useAuthStore()
  const navigate = useNavigate()
  const location = useLocation()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [query, setQuery] = useState('')
  const [paletteOpen, setPaletteOpen] = useState(false)
  const [profileOpen, setProfileOpen] = useState(false)
  const [notificationOpen, setNotificationOpen] = useState(false)
  const notifications = useAppStore(s => s.notifications)
  const unread = notifications.filter(n => !n.read).length
  const markRead = useAppStore(s => s.markNotificationRead)
  const addAuditEvent = useAppStore(s => s.addAuditEvent)

  const activeLabel = NAV.find(item => item.to === '/'
    ? location.pathname === '/'
    : location.pathname.startsWith(item.to))?.label ?? 'Dashboard'

  const breadcrumbs = useMemo(() => {
    const chunks = location.pathname.split('/').filter(Boolean)
    if (chunks.length === 0) return ['Dashboard']
    const trail = ['Dashboard']
    let current = ''
    for (const chunk of chunks) {
      current += `/${chunk}`
      const match = NAV.find(item => item.to === current)
      trail.push(match?.label ?? chunk.replace(/-/g, ' '))
    }
    return trail
  }, [location.pathname])

  const quickNav = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return []
    return NAV.filter(item => item.label.toLowerCase().includes(q)).slice(0, 6)
  }, [query])

  const paletteItems = useMemo(() => {
    const q = query.trim().toLowerCase()
    const scope = q
      ? NAV.filter(item => item.label.toLowerCase().includes(q))
      : NAV.slice(0, 10)
    return [...scope, ...QUICK_ACTIONS.map((a) => ({ ...a, icon: Command, section: 'Core' as const }))]
  }, [query])

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault()
        setPaletteOpen(v => !v)
      }
      if (event.key === 'Escape') {
        setPaletteOpen(false)
        setProfileOpen(false)
        setNotificationOpen(false)
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [])

  const handleLogout = async () => {
    try { await authService.logout(refreshToken!) } catch {}
    addAuditEvent({ action: 'AUTH_LOGOUT', actor: user?.email ?? 'unknown', target: 'session' })
    clearAuth()
    navigate('/login')
  }

  const handleNavigate = (to: string) => {
    addAuditEvent({ action: 'NAVIGATE', actor: user?.email ?? 'unknown', target: to })
    navigate(to)
    setQuery('')
    setMobileOpen(false)
    setPaletteOpen(false)
    setProfileOpen(false)
    setNotificationOpen(false)
  }

  return (
    <div className="h-screen w-full p-3 md:p-4">
      <div className="shell-panel flex h-full overflow-hidden fade-up">
        <button
          type="button"
          className="md:hidden fixed bottom-5 right-5 z-50 h-12 w-12 rounded-full bg-primary-600 text-white shadow-lg"
          onClick={() => setMobileOpen(v => !v)}
          aria-label="Toggle navigation"
        >
          {mobileOpen ? <X className="h-5 w-5 mx-auto" /> : <Menu className="h-5 w-5 mx-auto" />}
        </button>

        <aside className={clsx(
          'border-r border-gray-200/80 bg-white/95 flex flex-col transition-all duration-200',
          sidebarCollapsed ? 'w-[88px]' : 'w-72',
          'fixed inset-y-3 left-3 z-40 md:static md:inset-auto',
          mobileOpen ? 'translate-x-0' : '-translate-x-[110%] md:translate-x-0'
        )}>
          <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-200/80">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 text-white flex items-center justify-center">
              <Leaf className="h-5 w-5" />
            </div>
            {!sidebarCollapsed && (
              <div>
                <p className="font-semibold text-gray-900 text-sm">Plastic Waste AI</p>
                <p className="text-[11px] text-gray-500">Enterprise Control Plane</p>
              </div>
            )}

            <button
              type="button"
              onClick={() => setSidebarCollapsed(v => !v)}
              className="hidden md:flex ml-auto text-gray-500 hover:text-gray-800"
              aria-label="Collapse sidebar"
            >
              {sidebarCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
            </button>
          </div>

          <nav className="flex-1 px-3 py-4 space-y-3 overflow-y-auto">
            {NAV_SECTIONS.map((section) => (
              <div key={section}>
                {!sidebarCollapsed && <p className="text-[10px] uppercase tracking-[0.16em] text-gray-400 px-3 mb-1">{section}</p>}
                <div className="space-y-1">
                  {NAV.filter(item => item.section === section).map(({ to, label, icon: Icon }) => (
                    <NavLink
                      key={to}
                      to={to}
                      end={to === '/'}
                      onClick={() => setMobileOpen(false)}
                      className={({ isActive }) => clsx(
                        'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors',
                        isActive
                          ? 'bg-primary-50 text-primary-700 border border-primary-100'
                          : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900',
                        sidebarCollapsed && 'justify-center'
                      )}
                      title={label}
                    >
                      <Icon className="h-4 w-4 flex-shrink-0" />
                      {!sidebarCollapsed && <span>{label}</span>}
                    </NavLink>
                  ))}
                </div>
              </div>
            ))}
          </nav>

          <div className="px-3 py-4 border-t border-gray-200/80">
            <div className={clsx('flex items-center gap-3 px-3 py-2 mb-2', sidebarCollapsed && 'justify-center')}>
              <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 text-xs font-bold">
                {user?.full_name?.[0] ?? '?'}
              </div>
              {!sidebarCollapsed && (
                <div className="min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">{user?.full_name}</p>
                  <p className="text-xs text-gray-500 capitalize">{user?.role}</p>
                </div>
              )}
            </div>
            <button
              onClick={handleLogout}
              className={clsx(
                'flex items-center gap-3 w-full px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-gray-100 transition-colors',
                sidebarCollapsed && 'justify-center'
              )}
              title="Sign out"
            >
              <LogOut className="h-4 w-4" />
              {!sidebarCollapsed && <span>Sign out</span>}
            </button>
          </div>
        </aside>

        <main className="flex-1 overflow-y-auto md:ml-0 bg-transparent">
          <div className="sticky top-0 z-30 border-b border-gray-200/70 bg-white/90 backdrop-blur px-4 md:px-8 py-3">
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-xs uppercase tracking-[0.16em] text-gray-500">Operations Workspace</p>
                <h1 className="text-lg font-semibold text-gray-900">{activeLabel}</h1>
                <p className="text-xs text-gray-500 mt-0.5">
                  {breadcrumbs.join(' / ')}
                </p>
              </div>

              <div className="relative w-full md:w-[420px]">
                <Search className="h-4 w-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  value={query}
                  onChange={e => setQuery(e.target.value)}
                  placeholder="Quick navigate: dashboard, reports, copilot..."
                  className="input pl-9"
                />
                {quickNav.length > 0 && (
                  <div className="absolute mt-2 w-full rounded-xl border border-gray-200 bg-white shadow-lg overflow-hidden">
                    {quickNav.map(item => (
                      <button
                        key={item.to}
                        type="button"
                        onClick={() => handleNavigate(item.to)}
                        className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-primary-50"
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  className="btn-secondary text-xs inline-flex items-center gap-1"
                  onClick={() => setPaletteOpen(true)}
                >
                  <Command className="h-3.5 w-3.5" />
                  Command
                </button>

                <div className="relative">
                  <button type="button" className="btn-secondary text-xs inline-flex items-center gap-1" onClick={() => setNotificationOpen(v => !v)}>
                    <Bell className="h-3.5 w-3.5" />
                    {unread > 0 ? `Alerts (${unread})` : 'Alerts'}
                  </button>
                  {notificationOpen && (
                    <div className="absolute right-0 mt-2 w-80 rounded-xl border border-gray-200 bg-white shadow-lg p-2 z-40">
                      <p className="text-xs uppercase tracking-[0.12em] text-gray-500 px-2 py-1">Notifications</p>
                      <div className="max-h-72 overflow-y-auto space-y-1">
                        {notifications.slice(0, 8).map((n) => (
                          <button
                            key={n.id}
                            type="button"
                            onClick={() => markRead(n.id)}
                            className={clsx('w-full text-left rounded-lg px-2 py-2 hover:bg-gray-50', !n.read && 'bg-primary-50')}
                          >
                            <p className="text-xs font-semibold text-gray-900">{n.title}</p>
                            <p className="text-xs text-gray-500 mt-0.5">{n.description}</p>
                          </button>
                        ))}
                      </div>
                      <button type="button" onClick={() => handleNavigate('/notifications')} className="w-full text-xs text-primary-700 hover:underline py-2">
                        View all notifications
                      </button>
                    </div>
                  )}
                </div>

                <div className="relative">
                  <button type="button" className="btn-secondary text-xs inline-flex items-center gap-1" onClick={() => setProfileOpen(v => !v)}>
                    <UserCircle2 className="h-3.5 w-3.5" />
                    {user?.full_name?.split(' ')[0] ?? 'Profile'}
                  </button>
                  {profileOpen && (
                    <div className="absolute right-0 mt-2 w-56 rounded-xl border border-gray-200 bg-white shadow-lg p-1 z-40">
                      <button type="button" onClick={() => handleNavigate('/profile')} className="w-full text-left text-sm px-3 py-2 rounded-lg hover:bg-gray-50">Profile</button>
                      <button type="button" onClick={() => handleNavigate('/settings')} className="w-full text-left text-sm px-3 py-2 rounded-lg hover:bg-gray-50">Settings</button>
                      <button type="button" onClick={() => handleNavigate('/help')} className="w-full text-left text-sm px-3 py-2 rounded-lg hover:bg-gray-50">Help</button>
                      <button type="button" onClick={handleLogout} className="w-full text-left text-sm px-3 py-2 rounded-lg hover:bg-red-50 text-danger-600">Sign out</button>
                    </div>
                  )}
                </div>

                <div className="hidden xl:flex items-center gap-2 text-xs text-primary-700 bg-primary-50 border border-primary-100 px-3 py-2 rounded-full">
                  <Sparkles className="h-3.5 w-3.5" />
                  AI decision support active
                </div>
              </div>
            </div>
          </div>

          <div className="xl:flex xl:items-start">
            <div className="flex-1 min-w-0">
              <Outlet />
              <footer className="px-6 py-4 text-xs text-gray-500 flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                <span>Plastic Waste AI Platform v1.0.0</span>
                <span>Accessibility: WCAG-minded layout, keyboard-first navigation, reduced motion support.</span>
              </footer>
            </div>

            <aside className="hidden xl:block w-80 px-4 py-5 space-y-3 sticky top-20 self-start">
              <div className="card p-4">
                <p className="text-xs uppercase tracking-[0.14em] text-gray-500 mb-2">AI Workflow</p>
                <div className="space-y-2 text-xs text-gray-600">
                  <div className="flex items-center justify-between"><span>Planning</span><span className="badge-green">Ready</span></div>
                  <div className="flex items-center justify-between"><span>Retrieval</span><span className="badge-green">Ready</span></div>
                  <div className="flex items-center justify-between"><span>Reasoning</span><span className="badge-amber">Monitored</span></div>
                  <div className="flex items-center justify-between"><span>Evaluation</span><span className="badge-green">Ready</span></div>
                </div>
              </div>

              <div className="card p-4">
                <p className="text-xs uppercase tracking-[0.14em] text-gray-500 mb-2">Quick Actions</p>
                <div className="space-y-2">
                  <button type="button" onClick={() => handleNavigate('/copilot')} className="btn-secondary w-full text-xs">Open AI Copilot</button>
                  <button type="button" onClick={() => handleNavigate('/reports')} className="btn-secondary w-full text-xs">Generate Report</button>
                  <button type="button" onClick={() => handleNavigate('/ai-evaluation')} className="btn-secondary w-full text-xs">Review AI Evaluation</button>
                </div>
              </div>

              <div className="card p-4">
                <p className="text-xs uppercase tracking-[0.14em] text-gray-500 mb-2">Run Context</p>
                <p className="text-xs text-gray-600">Prompt set: enterprise-v1</p>
                <p className="text-xs text-gray-600">Model profile: production</p>
                <p className="text-xs text-gray-600">Active user role: {user?.role ?? 'unknown'}</p>
              </div>
            </aside>
          </div>
        </main>
      </div>

      {paletteOpen && (
        <div className="fixed inset-0 z-50 bg-black/30 p-4 md:p-10" onClick={() => setPaletteOpen(false)}>
          <div className="max-w-2xl mx-auto card p-3" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-2 mb-2 px-1">
              <Command className="h-4 w-4 text-primary-600" />
              <p className="text-sm font-semibold text-gray-900">Command Palette</p>
              <span className="text-xs text-gray-500 ml-auto">Ctrl/Cmd + K</span>
            </div>
            <input
              autoFocus
              className="input mb-2"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search pages and actions"
            />
            <div className="max-h-[52vh] overflow-y-auto space-y-1">
              {paletteItems.map((item) => (
                <button
                  key={`${item.to}-${item.label}`}
                  type="button"
                  onClick={() => handleNavigate(item.to)}
                  className="w-full text-left rounded-lg px-3 py-2 hover:bg-primary-50"
                >
                  <p className="text-sm text-gray-800">{item.label}</p>
                  <p className="text-xs text-gray-500">{item.to}</p>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {mobileOpen && (
        <div className="md:hidden fixed inset-0 bg-black/25 z-30" onClick={() => setMobileOpen(false)} />
      )}

      <ToastCenter />
    </div>
  )
}
