import { useState } from 'react'
import clsx from 'clsx'
import { CheckCircle2, ChevronDown, ChevronRight, Loader2, XCircle, ExternalLink } from 'lucide-react'
import { AgentStepState } from '../../hooks/useAgentStream'
import { observabilityService } from '../../services/services'
import { AITraceDetail } from '../../types/api'

interface AgentPipelineProps {
  order: string[]
  steps: Record<string, AgentStepState>
  streaming: boolean
  error?: string | null
  agentLabels?: Record<string, string>
  className?: string
}

function StatusIcon({ status }: { status: AgentStepState['status'] }) {
  if (status === 'running') return <Loader2 className="h-4 w-4 text-primary-600 animate-spin" />
  if (status === 'error') return <XCircle className="h-4 w-4 text-danger-600" />
  return <CheckCircle2 className="h-4 w-4 text-success-600" />
}

function JsonBlock({ value }: { value: unknown }) {
  if (value === undefined) return <p className="text-xs text-gray-400 italic">Not available</p>
  return (
    <pre className="text-[11px] leading-relaxed bg-gray-50 border border-gray-200 rounded-md p-2 overflow-x-auto whitespace-pre-wrap break-words">
      {JSON.stringify(value, null, 2)}
    </pre>
  )
}

function TraceDetailPanel({ traceId }: { traceId: string }) {
  const [detail, setDetail] = useState<AITraceDetail | null>(null)
  const [loading, setLoading] = useState(false)
  const [fetched, setFetched] = useState(false)

  const load = async () => {
    setLoading(true)
    try {
      const res = await observabilityService.getTraceDetail(traceId)
      setDetail(res.available ? res.data : null)
    } finally {
      setLoading(false)
      setFetched(true)
    }
  }

  if (!fetched) {
    return (
      <button
        type="button"
        onClick={load}
        disabled={loading}
        className="text-xs text-primary-600 hover:underline inline-flex items-center gap-1"
      >
        <ExternalLink className="h-3 w-3" />
        {loading ? 'Loading full trace…' : 'View full trace'}
      </button>
    )
  }

  if (!detail) {
    return <p className="text-xs text-gray-400">Full trace unavailable (requires manager/admin role).</p>
  }

  return (
    <div className="space-y-2 mt-2">
      <div className="grid grid-cols-2 gap-2 text-[11px] text-gray-600">
        <span>Started: {detail.started_at ? new Date(detail.started_at).toLocaleTimeString() : '—'}</span>
        <span>Ended: {detail.ended_at ? new Date(detail.ended_at).toLocaleTimeString() : '—'}</span>
        <span>Tokens: {(detail.input_tokens ?? 0) + (detail.output_tokens ?? 0)}</span>
        <span>Cost: ${(detail.cost_usd ?? 0).toFixed(4)}</span>
      </div>
      <div>
        <p className="text-[11px] font-semibold text-gray-500 mb-1">Full input</p>
        <JsonBlock value={detail.input_summary} />
      </div>
      <div>
        <p className="text-[11px] font-semibold text-gray-500 mb-1">Full output</p>
        <JsonBlock value={detail.output_summary} />
      </div>
    </div>
  )
}

/**
 * Reusable, domain-agnostic live agent-pipeline visualizer. Renders whatever
 * `order`/`steps` a useAgentStream() call has accumulated so far — knows
 * nothing about waste prediction or chat specifically, so it drops into any
 * future streaming workflow unchanged.
 */
export default function AgentPipeline({ order, steps, streaming, error, agentLabels, className }: AgentPipelineProps) {
  const [expanded, setExpanded] = useState<Set<string>>(new Set())

  const toggle = (agent: string) => {
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(agent)) next.delete(agent)
      else next.add(agent)
      return next
    })
  }

  if (order.length === 0 && !streaming && !error) return null

  return (
    <div className={clsx('space-y-2', className)}>
      {order.map((agent) => {
        const step = steps[agent]
        if (!step) return null
        const isOpen = expanded.has(agent)
        const label = agentLabels?.[agent] ?? agent.replace(/_/g, ' ')
        return (
          <div key={agent} className="rounded-lg border border-gray-200 bg-white">
            <button
              type="button"
              onClick={() => toggle(agent)}
              className="w-full flex items-center justify-between gap-2 px-3 py-2 text-left"
            >
              <div className="flex items-center gap-2 min-w-0">
                <StatusIcon status={step.status} />
                <span className="text-sm font-medium text-gray-800 capitalize truncate">{label}</span>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                {step.latencyMs !== undefined && (
                  <span className="text-[11px] text-gray-400">{Math.round(step.latencyMs)} ms</span>
                )}
                {step.confidenceScore != null && (
                  <span className="badge-amber text-[10px]">{Math.round(step.confidenceScore * 100)}%</span>
                )}
                {isOpen ? <ChevronDown className="h-3.5 w-3.5 text-gray-400" /> : <ChevronRight className="h-3.5 w-3.5 text-gray-400" />}
              </div>
            </button>

            {isOpen && (
              <div className="px-3 pb-3 space-y-2 border-t border-gray-100 pt-2">
                {step.error && <p className="text-xs text-danger-600">{step.error}</p>}
                <div>
                  <p className="text-[11px] font-semibold text-gray-500 mb-1">Input (summarized)</p>
                  <JsonBlock value={step.input} />
                </div>
                {step.status !== 'running' && (
                  <div>
                    <p className="text-[11px] font-semibold text-gray-500 mb-1">Output (summarized)</p>
                    <JsonBlock value={step.output} />
                  </div>
                )}
                {step.traceId && <TraceDetailPanel traceId={step.traceId} />}
              </div>
            )}
          </div>
        )
      })}

      {streaming && order.length === 0 && (
        <div className="flex items-center gap-2 text-sm text-gray-400 px-1 py-2">
          <Loader2 className="h-4 w-4 animate-spin" /> Starting agent pipeline…
        </div>
      )}

      {error && <p className="text-xs text-danger-600 px-1">{error}</p>}
    </div>
  )
}
