import clsx from 'clsx'
import { ReactNode, useEffect } from 'react'
import { X } from 'lucide-react'
import { useAppStore } from '../../store/appStore'

interface ConfidenceBadgeProps {
  score: number
  className?: string
}

export function ConfidenceBadge({ score, className }: ConfidenceBadgeProps) {
  const pct = Math.round(score * 100)
  const cls = score >= 0.8 ? 'badge-green' : score >= 0.5 ? 'badge-amber' : 'badge-red'
  const label = score >= 0.8 ? 'High' : score >= 0.5 ? 'Medium' : 'Low'
  return (
    <span className={clsx(cls, className)}>
      {label} confidence ({pct}%)
    </span>
  )
}

interface KPICardProps {
  title: string
  value: string | number
  change?: number
  unit?: string
  loading?: boolean
  onClick?: () => void
}

export function KPICard({ title, value, change, unit, loading, onClick }: KPICardProps) {
  const Wrapper = onClick ? 'button' : 'div'
  return (
    <Wrapper
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      className={clsx('card w-full text-left', onClick && 'hover:border-primary-300 hover:shadow-sm transition-all cursor-pointer')}
    >
      <div className="flex items-start justify-between">
        <p className="text-sm text-gray-500 font-medium">{title}</p>
        {onClick && <span className="text-xs text-primary-500">Details →</span>}
      </div>
      {loading ? (
        <div className="mt-2 h-8 w-24 bg-gray-200 animate-pulse rounded" />
      ) : (
        <p className="mt-1 text-2xl font-bold text-gray-900">
          {typeof value === 'number' ? value.toLocaleString() : value}
          {unit && <span className="text-sm font-normal text-gray-500 ml-1">{unit}</span>}
        </p>
      )}
      {change !== undefined && !loading && (
        <p className={clsx('mt-1 text-sm', change < 0 ? 'text-success-600' : 'text-danger-600')}>
          {change > 0 ? '+' : ''}{change.toFixed(1)}% vs prior period
        </p>
      )}
    </Wrapper>
  )
}

export function PageHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-6">
      <h1 className="text-xl font-bold text-gray-900">{title}</h1>
      {subtitle && <p className="mt-1 text-sm text-gray-500">{subtitle}</p>}
    </div>
  )
}

export function ErrorBanner({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="rounded-lg bg-danger-100 border border-red-200 p-4 flex items-center justify-between">
      <p className="text-sm text-danger-600">{message}</p>
      {onRetry && <button onClick={onRetry} className="text-sm text-primary-600 font-medium hover:underline ml-4">Retry</button>}
    </div>
  )
}

export function Spinner({ className }: { className?: string }) {
  return (
    <div className={clsx('flex items-center justify-center', className)}>
      <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary-600 border-t-transparent" />
    </div>
  )
}

export function LoadingOverlay({ show, label = 'Loading...' }: { show: boolean; label?: string }) {
  if (!show) return null
  return (
    <div className="fixed inset-0 bg-black/30 z-[90] flex items-center justify-center p-4">
      <div className="card w-full max-w-sm text-center">
        <Spinner className="h-10" />
        <p className="text-sm text-gray-700 mt-2">{label}</p>
      </div>
    </div>
  )
}

export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  onConfirm,
  onCancel,
}: {
  open: boolean
  title: string
  description: string
  confirmLabel?: string
  cancelLabel?: string
  onConfirm: () => void
  onCancel: () => void
}) {
  if (!open) return null

  return (
    <div className="fixed inset-0 bg-black/30 z-[95] flex items-center justify-center p-4" onClick={onCancel}>
      <div className="card w-full max-w-md" onClick={(e) => e.stopPropagation()}>
        <h3 className="text-base font-semibold text-gray-900">{title}</h3>
        <p className="text-sm text-gray-600 mt-2">{description}</p>
        <div className="flex justify-end gap-2 mt-5">
          <button type="button" className="btn-secondary" onClick={onCancel}>{cancelLabel}</button>
          <button type="button" className="btn-primary" onClick={onConfirm}>{confirmLabel}</button>
        </div>
      </div>
    </div>
  )
}

export function ToastCenter() {
  const toasts = useAppStore((s) => s.toasts)
  const removeToast = useAppStore((s) => s.removeToast)

  useEffect(() => {
    if (toasts.length === 0) return
    const timers = toasts.map((t) => setTimeout(() => removeToast(t.id), 3000))
    return () => timers.forEach(clearTimeout)
  }, [toasts, removeToast])

  return (
    <div className="fixed top-4 right-4 z-[100] space-y-2 w-80">
      {toasts.map((toast) => (
        <div key={toast.id} className={clsx(
          'rounded-xl border px-4 py-3 text-sm shadow-md bg-white',
          toast.severity === 'success' && 'border-green-200 text-green-700',
          toast.severity === 'warning' && 'border-amber-200 text-amber-700',
          toast.severity === 'error' && 'border-red-200 text-red-700',
          toast.severity === 'info' && 'border-blue-200 text-blue-700',
        )}>
          <div className="flex items-start justify-between gap-2">
            <p>{toast.message}</p>
            <button type="button" className="text-xs opacity-70 hover:opacity-100" onClick={() => removeToast(toast.id)}>Dismiss</button>
          </div>
        </div>
      ))}
    </div>
  )
}

/** Generic slide-over detail panel — reusable anywhere a "click to drill
 * into this value" pattern is needed (KPI tiles, list rows, etc). */
export function DetailDrawer({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean
  title: string
  onClose: () => void
  children: ReactNode
}) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-[95] flex justify-end">
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />
      <div className="relative w-full max-w-md bg-white h-full shadow-xl p-5 overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-semibold text-gray-900">{title}</h3>
          <button type="button" onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="h-4 w-4" />
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}
