import { useCallback, useState } from 'react'
import { streamSSE, StreamOptions } from '../services/sseClient'

export interface AgentStepState {
  agent: string
  status: 'running' | 'complete' | 'error'
  traceId?: string
  input?: unknown
  output?: unknown
  latencyMs?: number
  confidenceScore?: number | null
  error?: string | null
}

export interface AgentStreamResult {
  finalResult: any
  steps: Record<string, AgentStepState>
  order: string[]
  error: string | null
}

/**
 * Generic multi-agent SSE consumer. Knows nothing about "chat" or
 * "predictions" specifically — it only understands the event shape emitted
 * by backend/observability/live_progress.py + tracing.py:
 *   agent_start / agent_complete / agent_error  -> per-agent step state
 *   done / workflow_complete                    -> finalResult
 *   error / workflow_error                      -> error
 * Reusable for any future streaming workflow endpoint that emits this shape.
 *
 * `steps`/`order`/`finalResult`/`streaming` (state) are for live rendering
 * while a stream is in flight. `run()` also *returns* the definitive final
 * snapshot directly (not just via state) so callers that need the result
 * right after `await run(...)` don't hit React's stale-closure trap.
 */
export function useAgentStream() {
  const [steps, setSteps] = useState<Record<string, AgentStepState>>({})
  const [order, setOrder] = useState<string[]>([])
  const [finalResult, setFinalResult] = useState<any>(null)
  const [streaming, setStreaming] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const reset = useCallback(() => {
    setSteps({})
    setOrder([])
    setFinalResult(null)
    setError(null)
  }, [])

  const run = useCallback(
    async (path: string, options: StreamOptions, signal?: AbortSignal): Promise<AgentStreamResult> => {
      reset()
      setStreaming(true)

      let localSteps: Record<string, AgentStepState> = {}
      let localOrder: string[] = []
      let localFinal: any = null
      let localError: string | null = null

      try {
        await streamSSE(
          path,
          options,
          (evt: any) => {
            switch (evt.type) {
              case 'agent_start':
                if (!localOrder.includes(evt.agent)) localOrder = [...localOrder, evt.agent]
                localSteps = {
                  ...localSteps,
                  [evt.agent]: { agent: evt.agent, status: 'running', traceId: evt.trace_id, input: evt.input },
                }
                setOrder(localOrder)
                setSteps(localSteps)
                break
              case 'agent_complete':
              case 'agent_error':
                localSteps = {
                  ...localSteps,
                  [evt.agent]: {
                    ...(localSteps[evt.agent] ?? { agent: evt.agent }),
                    status: evt.type === 'agent_error' ? 'error' : 'complete',
                    traceId: evt.trace_id ?? localSteps[evt.agent]?.traceId,
                    input: evt.input ?? localSteps[evt.agent]?.input,
                    output: evt.output,
                    latencyMs: evt.latency_ms,
                    confidenceScore: evt.confidence_score,
                    error: evt.error,
                  },
                }
                setSteps(localSteps)
                break
              case 'done':
              case 'workflow_complete':
                localFinal = evt.data
                setFinalResult(localFinal)
                break
              case 'workflow_error':
              case 'error':
                localError = evt.error ?? 'Something went wrong while running the agent pipeline'
                setError(localError)
                break
              default:
                break
            }
          },
          signal
        )
      } catch (err) {
        localError = err instanceof Error ? err.message : 'Stream failed'
        setError(localError)
      } finally {
        setStreaming(false)
      }

      return { finalResult: localFinal, steps: localSteps, order: localOrder, error: localError }
    },
    [reset]
  )

  return { steps, order, finalResult, streaming, error, run, reset }
}
