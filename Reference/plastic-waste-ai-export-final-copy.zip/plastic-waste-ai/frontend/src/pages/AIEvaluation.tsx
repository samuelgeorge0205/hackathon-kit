import { Fragment, useState } from 'react'
import { PageHeader, Spinner, ErrorBanner } from '../components/ui/components'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { evaluationService } from '../services/services'
import { useAppStore } from '../store/appStore'
import { EvalRunSummary } from '../types/api'
import { ChevronDown, ChevronRight } from 'lucide-react'
import clsx from 'clsx'

export default function AIEvaluationPage() {
  const [running, setRunning] = useState(false)
  const [expandedRun, setExpandedRun] = useState<string | null>(null)
  const [runDetail, setRunDetail] = useState<EvalRunSummary | null>(null)
  const [runDetailLoading, setRunDetailLoading] = useState(false)
  const addToast = useAppStore((s) => s.addToast)
  const queryClient = useQueryClient()

  const toggleRun = async (id: string) => {
    if (expandedRun === id) {
      setExpandedRun(null)
      return
    }
    setExpandedRun(id)
    setRunDetail(null)
    setRunDetailLoading(true)
    const res = await evaluationService.getRunDetail(id)
    setRunDetail(res.available ? res.data : null)
    setRunDetailLoading(false)
  }

  const { data: runsResult, isLoading } = useQuery({
    queryKey: ['eval-runs'],
    queryFn: () => evaluationService.getRuns(20),
  })
  const { data: goldenSetResult } = useQuery({
    queryKey: ['eval-golden-set'],
    queryFn: () => evaluationService.getGoldenSet(),
  })

  const runs = runsResult?.data ?? []
  const latest = runs[0]

  const runEvaluation = async () => {
    setRunning(true)
    try {
      await evaluationService.run()
      await queryClient.invalidateQueries({ queryKey: ['eval-runs'] })
      addToast({ message: 'Evaluation run complete', severity: 'success' })
    } catch {
      addToast({ message: 'Evaluation run failed — check that you have manager/admin access', severity: 'error' })
    } finally {
      setRunning(false)
    }
  }

  const METRICS = latest
    ? [
        { label: 'Retrieval precision@5', value: `${Math.round(latest.avg_retrieval_precision * 100)}%` },
        { label: 'Groundedness score', value: latest.avg_groundedness.toFixed(2) },
        { label: 'Avg response latency', value: `${Math.round(latest.avg_latency_ms)} ms` },
        { label: 'Pass rate', value: `${Math.round(latest.pass_rate * 100)}%` },
      ]
    : []

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <PageHeader title="AI Evaluation" subtitle="RAG retrieval quality and groundedness, measured against a golden query set" />

      <div className="card flex items-center justify-between flex-wrap gap-3">
        <div>
          <p className="text-sm font-semibold text-gray-800">
            Golden query set: {goldenSetResult?.data?.length ?? '—'} queries
          </p>
          <p className="text-xs text-gray-500">Covers every knowledge-base document plus off-topic refusal checks.</p>
        </div>
        <button type="button" className="btn-primary" onClick={runEvaluation} disabled={running}>
          {running ? 'Running…' : 'Run Evaluation'}
        </button>
      </div>

      {isLoading ? (
        <Spinner className="h-16" />
      ) : !runsResult?.available ? (
        <ErrorBanner message="Evaluation data isn't available right now — the backend endpoint may be unreachable." />
      ) : !latest ? (
        <div className="card text-sm text-gray-500">No evaluation runs yet — click "Run Evaluation" to score the RAG pipeline against the golden query set.</div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {METRICS.map((m) => (
              <div key={m.label} className="card">
                <p className="text-xs text-gray-500">{m.label}</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{m.value}</p>
              </div>
            ))}
          </div>

          <div className="card">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">Run history</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-left text-gray-500 border-b border-gray-200">
                    <th className="py-2 pr-4"></th>
                    <th className="py-2 pr-4">Run time</th>
                    <th className="py-2 pr-4">Queries</th>
                    <th className="py-2 pr-4">Precision@5</th>
                    <th className="py-2 pr-4">Groundedness</th>
                    <th className="py-2 pr-4">Avg latency</th>
                    <th className="py-2 pr-4">Pass rate</th>
                  </tr>
                </thead>
                <tbody>
                  {runs.map((run) => (
                    <Fragment key={run.id}>
                      <tr
                        onClick={() => toggleRun(run.id)}
                        className="border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors"
                      >
                        <td className="py-2 pl-1 text-gray-400">
                          {expandedRun === run.id ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
                        </td>
                        <td className="py-2 pr-4 text-gray-500">{run.created_at ? new Date(run.created_at).toLocaleString() : '—'}</td>
                        <td className="py-2 pr-4">{run.n_queries}</td>
                        <td className="py-2 pr-4">{Math.round(run.avg_retrieval_precision * 100)}%</td>
                        <td className="py-2 pr-4">{run.avg_groundedness.toFixed(2)}</td>
                        <td className="py-2 pr-4">{Math.round(run.avg_latency_ms)} ms</td>
                        <td className="py-2 pr-4">
                          <span className={clsx(run.pass_rate >= 0.8 ? 'badge-green' : run.pass_rate >= 0.5 ? 'badge-amber' : 'badge-red')}>
                            {Math.round(run.pass_rate * 100)}%
                          </span>
                        </td>
                      </tr>
                      {expandedRun === run.id && (
                        <tr className="border-b border-gray-100 bg-gray-50/50">
                          <td colSpan={7} className="p-3">
                            {runDetailLoading ? (
                              <Spinner className="h-8" />
                            ) : !runDetail?.results?.length ? (
                              <p className="text-xs text-gray-400">No per-query detail available for this run.</p>
                            ) : (
                              <div className="overflow-x-auto">
                                <table className="w-full text-[11px]">
                                  <thead>
                                    <tr className="text-left text-gray-500 border-b border-gray-200">
                                      <th className="py-1.5 pr-3">Query</th>
                                      <th className="py-1.5 pr-3">Expected doc</th>
                                      <th className="py-1.5 pr-3">Retrieved docs</th>
                                      <th className="py-1.5 pr-3">Hit</th>
                                      <th className="py-1.5 pr-3">Groundedness</th>
                                      <th className="py-1.5 pr-3">Latency</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {runDetail.results.map((r) => (
                                      <tr key={r.id} className="border-b border-gray-100">
                                        <td className="py-1.5 pr-3 max-w-xs truncate" title={r.query}>{r.query}</td>
                                        <td className="py-1.5 pr-3 text-gray-500">{r.expected_doc_id ?? '(none — refusal expected)'}</td>
                                        <td className="py-1.5 pr-3 text-gray-500">{r.retrieved_doc_ids.join(', ') || '—'}</td>
                                        <td className="py-1.5 pr-3">
                                          <span className={r.precision_hit ? 'badge-green' : 'badge-red'}>
                                            {r.precision_hit ? '✓' : '✗'}
                                          </span>
                                        </td>
                                        <td className="py-1.5 pr-3">{r.groundedness.toFixed(2)}</td>
                                        <td className="py-1.5 pr-3">{Math.round(r.latency_ms)} ms</td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
