import { Link } from 'react-router-dom'
import { ClipboardList, Cpu, Database, FileClock, Library, Users } from 'lucide-react'
import { PageHeader } from '../components/ui/components'

const MODULES = [
  { title: 'Users', to: '/users', icon: Users, note: 'Role assignment and account lifecycle' },
  { title: 'Prompt Library', to: '/prompt-library', icon: Library, note: 'Prompt versions, templates, and safety notes' },
  { title: 'Knowledge Base', to: '/knowledge-center', icon: Database, note: 'Document ingestion and retrieval assets' },
  { title: 'AI Evaluation', to: '/ai-evaluation', icon: Cpu, note: 'Quality and cost scorecards' },
  { title: 'Audit', to: '/audit', icon: FileClock, note: 'Change history and review trails' },
  { title: 'Observability', to: '/observability', icon: ClipboardList, note: 'Runtime health and signals' },
]

export default function AdministrationPage() {
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <PageHeader title="Administration" subtitle="Enterprise controls for operations, governance, and AI safety" />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {MODULES.map((m) => (
          <Link key={m.title} to={m.to} className="card hover:border-primary-300 transition-colors">
            <m.icon className="h-5 w-5 text-primary-600 mb-2" />
            <h3 className="text-sm font-semibold text-gray-900">{m.title}</h3>
            <p className="text-xs text-gray-500 mt-1">{m.note}</p>
          </Link>
        ))}
      </div>
    </div>
  )
}
