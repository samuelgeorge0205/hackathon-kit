import { formatDistanceToNow } from 'date-fns'
import { PageHeader } from '../components/ui/components'
import { useAppStore } from '../store/appStore'
import { useQuery } from '@tanstack/react-query'
import { adminService } from '../services/services'

export default function AuditPage() {
  const localEvents = useAppStore((s) => s.auditEvents)
  const { data } = useQuery({
    queryKey: ['audit-events'],
    queryFn: () => adminService.listAudit(),
  })

  const events = data?.data?.length
    ? data.data.map((event) => ({
        id: event.id,
        action: event.action,
        actor: event.actor,
        target: event.target,
        createdAt: event.created_at,
      }))
    : localEvents

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader title="Audit" subtitle="Recent platform actions and governance trail" />

      {!data?.available && (
        <div className="card mb-4 border-amber-200 bg-yellow-50">
          <p className="text-sm text-amber-800">
            Backend audit endpoint is not available yet. Showing local audit trail from this session.
          </p>
        </div>
      )}

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-500 border-b border-gray-200">
              <th className="py-2 pr-3">Action</th>
              <th className="py-2 pr-3">Actor</th>
              <th className="py-2 pr-3">Target</th>
              <th className="py-2">When</th>
            </tr>
          </thead>
          <tbody>
            {events.map((event) => (
              <tr key={event.id} className="border-b border-gray-100 last:border-0">
                <td className="py-3 pr-3 font-medium text-gray-900">{event.action}</td>
                <td className="py-3 pr-3 text-gray-600">{event.actor}</td>
                <td className="py-3 pr-3 text-gray-600">{event.target}</td>
                <td className="py-3 text-gray-500">{formatDistanceToNow(new Date(event.createdAt), { addSuffix: true })}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {events.length === 0 && (
          <div className="text-center text-gray-500 py-8">No audit events recorded yet.</div>
        )}
      </div>
    </div>
  )
}
