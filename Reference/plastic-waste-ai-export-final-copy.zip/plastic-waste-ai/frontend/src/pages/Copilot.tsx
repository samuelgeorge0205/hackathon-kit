import { useState, useRef, useEffect } from 'react'
import { PageHeader, ConfidenceBadge } from '../components/ui/components'
import AgentPipeline from '../components/ui/AgentPipeline'
import { Send, Bot, User, BookOpen, Download, Share2, ThumbsUp, ThumbsDown, Activity } from 'lucide-react'
import clsx from 'clsx'
import { ChatAttachment, ChatCitation, ChatTokenUsage } from '../types/api'
import { useAppStore } from '../store/appStore'
import { useAgentStream, AgentStepState } from '../hooks/useAgentStream'

const CHAT_AGENT_LABELS: Record<string, string> = {
  chat_retriever_agent: 'Retriever — searching knowledge base',
  chat_explanation_agent: 'Explanation — generating grounded answer',
}

interface Message {
  role: 'user' | 'assistant'
  content: string
  citations?: ChatCitation[]
  confidence?: number
  followUps?: string[]
  model?: string
  promptVersion?: string
  latencyMs?: number
  tokenUsage?: ChatTokenUsage
  groundedness?: number
  confidenceTier?: string
  cacheHit?: boolean
  agentTrace?: { order: string[]; steps: Record<string, AgentStepState> }
}

export default function CopilotPage() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'Hi! I can answer supply chain sustainability questions about your waste data, packaging standards and regulations. What would you like to know?' }
  ])
  const [input, setInput] = useState('')
  const [sessionId, setSessionId] = useState<string | undefined>()
  const [showCitations, setShowCitations] = useState<number | null>(null)
  const [showTraceFor, setShowTraceFor] = useState<number | null>(null)
  const [feedbackByMessage, setFeedbackByMessage] = useState<Record<number, 'up' | 'down'>>({})
  const [pendingAttachments, setPendingAttachments] = useState<ChatAttachment[]>([])
  const [imageDescription, setImageDescription] = useState('')
  const bottomRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const addToast = useAppStore((s) => s.addToast)
  const { steps, order, streaming, run } = useAgentStream()
  const loading = streaming

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages, steps])

  const send = async (text: string) => {
    if (!text.trim() || loading) return
    const userMsg: Message = { role: 'user', content: text }
    setMessages(m => [...m, userMsg])
    setInput('')
    const started = performance.now()
    const context = {
      source: 'copilot_ui',
      attachments: pendingAttachments,
      image_descriptions: imageDescription.trim() ? [imageDescription.trim()] : [],
    }

    const result = await run('/chat/stream', {
      method: 'POST',
      body: { message: text, session_id: sessionId, context },
    })
    const latencyMs = Math.round(performance.now() - started)

    if (result.finalResult) {
      const res = result.finalResult
      setSessionId(res.session_id)
      setMessages(m => [...m, {
        role: 'assistant',
        content: res.response,
        citations: res.citations,
        confidence: res.confidence_score,
        followUps: res.suggested_follow_ups,
        model: res.model ?? 'N/A',
        promptVersion: res.prompt_version ?? 'N/A',
        latencyMs,
        tokenUsage: res.token_usage,
        groundedness: res.groundedness_score,
        confidenceTier: res.confidence_tier,
        cacheHit: res.cache_hit ?? false,
        agentTrace: { order: result.order, steps: result.steps },
      }])
      setPendingAttachments([])
      setImageDescription('')
    } else {
      setMessages(m => [...m, {
        role: 'assistant',
        content: result.error ?? 'Sorry, I\'m unable to respond right now. Please try again.',
        agentTrace: result.order.length > 0 ? { order: result.order, steps: result.steps } : undefined,
      }])
    }
  }

  const onFilesSelected = (files: FileList | null) => {
    if (!files || files.length === 0) return
    const mapped: ChatAttachment[] = Array.from(files).map((file) => ({
      name: file.name,
      type: file.type || 'application/octet-stream',
      size: file.size,
      last_modified: file.lastModified,
    }))
    setPendingAttachments((prev) => [...prev, ...mapped].slice(-10))
  }

  const exportConversation = () => {
    const content = JSON.stringify({ sessionId, messages }, null, 2)
    const blob = new Blob([content], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `copilot-session-${sessionId ?? 'local'}.json`
    a.click()
    URL.revokeObjectURL(url)
    addToast({ message: 'Conversation exported', severity: 'success' })
  }

  const shareConversation = async () => {
    const text = messages.map((m) => `${m.role.toUpperCase()}: ${m.content}`).join('\n\n')
    await navigator.clipboard.writeText(text)
    addToast({ message: 'Conversation copied to clipboard', severity: 'info' })
  }

  return (
    <div className="flex flex-col h-full p-6 max-w-4xl mx-auto">
      <PageHeader title="AI Copilot" subtitle="Natural language Q&A grounded in your supply chain data" />

      <div className="card mb-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-xs text-gray-600">Copilot session: {sessionId ?? 'new session'}</p>
          <div className="flex items-center gap-2">
            <button type="button" className="btn-secondary text-xs inline-flex items-center gap-1" onClick={exportConversation}>
              <Download className="h-3.5 w-3.5" /> Export
            </button>
            <button type="button" className="btn-secondary text-xs inline-flex items-center gap-1" onClick={shareConversation}>
              <Share2 className="h-3.5 w-3.5" /> Share
            </button>
          </div>
        </div>
      </div>

      <div className="card flex-1 flex flex-col min-h-0">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto space-y-4 p-1 mb-4">
          {messages.map((msg, i) => (
            <div key={i} className={clsx('flex gap-3', msg.role === 'user' ? 'flex-row-reverse' : '')}>
              <div className={clsx('h-8 w-8 rounded-full flex-shrink-0 flex items-center justify-center',
                msg.role === 'assistant' ? 'bg-primary-100 text-primary-600' : 'bg-gray-200 text-gray-600')}>
                {msg.role === 'assistant' ? <Bot className="h-4 w-4" /> : <User className="h-4 w-4" />}
              </div>

              <div className={clsx('max-w-[80%] space-y-2', msg.role === 'user' ? 'items-end' : '')}>
                <div className={clsx('rounded-xl px-4 py-3 text-sm leading-relaxed',
                  msg.role === 'assistant' ? 'bg-gray-100 text-gray-800' : 'bg-primary-600 text-white')}>
                  {msg.content}
                </div>

                {msg.role === 'assistant' && (
                  <div className="flex items-center gap-3 flex-wrap">
                    {msg.confidence !== undefined && <ConfidenceBadge score={msg.confidence} />}
                    {msg.groundedness !== undefined && (
                      <span className="badge-amber">
                        Groundedness {Math.round(msg.groundedness * 100)}%{msg.confidenceTier ? ` (${msg.confidenceTier})` : ''}
                      </span>
                    )}
                    {msg.citations && msg.citations.length > 0 && (
                      <button onClick={() => setShowCitations(showCitations === i ? null : i)}
                        className="flex items-center gap-1 text-xs text-primary-600 hover:underline">
                        <BookOpen className="h-3 w-3" />
                        {msg.citations.length} sources
                      </button>
                    )}
                  </div>
                )}

                {msg.role === 'assistant' && (
                  <div className="rounded-lg border border-gray-200 bg-white px-3 py-2 text-xs text-gray-600 grid grid-cols-2 md:grid-cols-5 gap-2">
                    <span>Model: {msg.model ?? 'N/A'}</span>
                    <span>Prompt: {msg.promptVersion ?? 'N/A'}</span>
                    <span>Latency: {msg.latencyMs ?? 0} ms</span>
                    <span>
                      Tokens: {msg.tokenUsage ? (msg.tokenUsage.prompt_tokens ?? 0) + (msg.tokenUsage.completion_tokens ?? 0) : 'N/A'}
                    </span>
                    <span>Evidence: {msg.citations?.length ?? 0} sources</span>
                    {msg.cacheHit !== undefined && (
                      <span className={clsx('font-medium', msg.cacheHit ? 'text-success-700' : 'text-gray-500')}>
                        Cache: {msg.cacheHit ? 'HIT' : 'MISS'}
                      </span>
                    )}
                  </div>
                )}

                {msg.role === 'assistant' && msg.agentTrace && msg.agentTrace.order.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setShowTraceFor(showTraceFor === i ? null : i)}
                    className="flex items-center gap-1 text-xs text-primary-600 hover:underline"
                  >
                    <Activity className="h-3 w-3" />
                    {showTraceFor === i ? 'Hide agent trace' : 'Show agent trace'}
                  </button>
                )}
                {showTraceFor === i && msg.agentTrace && (
                  <AgentPipeline
                    order={msg.agentTrace.order}
                    steps={msg.agentTrace.steps}
                    streaming={false}
                    agentLabels={CHAT_AGENT_LABELS}
                  />
                )}

                {msg.role === 'assistant' && i > 0 && (
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-500">Helpful?</span>
                    <button
                      type="button"
                      onClick={() => setFeedbackByMessage((s) => ({ ...s, [i]: 'up' }))}
                      className={clsx('p-1.5 rounded', feedbackByMessage[i] === 'up' ? 'bg-success-100 text-success-600' : 'text-gray-400 hover:bg-success-100')}
                    >
                      <ThumbsUp className="h-3.5 w-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setFeedbackByMessage((s) => ({ ...s, [i]: 'down' }))}
                      className={clsx('p-1.5 rounded', feedbackByMessage[i] === 'down' ? 'bg-danger-100 text-danger-600' : 'text-gray-400 hover:bg-danger-100')}
                    >
                      <ThumbsDown className="h-3.5 w-3.5" />
                    </button>
                  </div>
                )}

                {/* Citations panel */}
                {showCitations === i && msg.citations && (
                  <div className="bg-white border border-gray-200 rounded-lg p-3 text-xs text-gray-600 space-y-1.5">
                    {msg.citations.map(c => (
                      <div key={c.index} className="flex items-start gap-2">
                        <span className="text-primary-500 font-medium">[{c.index}]</span>
                        <span>
                          {c.title}
                          {c.section ? ` — ${c.section}` : ''} — relevance {Math.round(c.relevance * 100)}%
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Follow-up suggestions */}
                {msg.role === 'assistant' && msg.followUps && i === messages.length - 1 && (
                  <div className="flex flex-wrap gap-2">
                    {msg.followUps.map((f, fi) => (
                      <button key={fi} onClick={() => send(f)}
                        className="text-xs px-3 py-1 rounded-full border border-primary-200 text-primary-600 hover:bg-primary-50 transition-colors">
                        {f}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex gap-3">
              <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center">
                <Bot className="h-4 w-4 text-primary-600 animate-pulse" />
              </div>
              <div className="flex-1 max-w-[80%]">
                <AgentPipeline order={order} steps={steps} streaming={streaming} agentLabels={CHAT_AGENT_LABELS} />
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div className="flex gap-2 border-t border-gray-100 pt-4">
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => onFilesSelected(e.target.files)}
          />
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send(input)}
            placeholder="Ask about waste, packaging, suppliers, regulations..."
            className="input flex-1"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="btn-secondary"
          >
            Attach
          </button>
          <button onClick={() => send(input)} disabled={loading || !input.trim()} className="btn-primary flex items-center gap-2">
            <span className="sr-only">Send message</span>
            <Send className="h-4 w-4" />
          </button>
        </div>

        <div className="pt-3 space-y-2">
          <input
            value={imageDescription}
            onChange={(e) => setImageDescription(e.target.value)}
            placeholder="Optional: add image/attachment notes for multimodal memory"
            className="input"
          />
          {pendingAttachments.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {pendingAttachments.map((file, idx) => (
                <span key={`${file.name}-${idx}`} className="badge-blue">
                  {file.name} ({Math.ceil(file.size / 1024)} KB)
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
