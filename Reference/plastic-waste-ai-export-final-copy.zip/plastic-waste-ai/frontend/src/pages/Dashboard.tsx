import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { dashboardService } from '../services/services'
import { KPICard, PageHeader, ErrorBanner, Spinner, DetailDrawer } from '../components/ui/components'
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  PieChart, Pie, Cell, ResponsiveContainer
} from 'recharts'
import { format, parseISO } from 'date-fns'
import { ArrowRight, Sparkles } from 'lucide-react'

const COLORS = ['#3b82f6','#10b981','#f59e0b','#ef4444','#8b5cf6','#06b6d4','#64748b']
const PLASTIC_TYPES = ['PET','HDPE','LDPE','PP','PS','PVC','MIXED']

type DrawerKey = 'waste' | 'cost' | 'recommendations' | 'accuracy' | null

export default function DashboardPage() {
  const [openDrawer, setOpenDrawer] = useState<DrawerKey>(null)
  const { data: summary, isLoading: loadingS, error: errS, refetch: refetchS } = useQuery({
    queryKey: ['dashboard-summary'],
    queryFn: () => dashboardService.getSummary(),
  })
  const { data: trends, isLoading: loadingT } = useQuery({
    queryKey: ['dashboard-trends'],
    queryFn: () => dashboardService.getTrends('month'),
  })

  const pieData = summary
    ? PLASTIC_TYPES.map(t => ({ name: t, value: Math.round((summary.waste_by_plastic_type?.[t] ?? 0) * 10) / 10 })).filter(d => d.value > 0)
    : []

  const bestPerformer = pieData.length > 0
    ? [...pieData].sort((a, b) => a.value - b.value)[0]
    : null

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto space-y-5">
      <PageHeader title="Dashboard" subtitle="Supply chain plastic waste overview — last 30 days" />

      {errS && <div className="mb-4"><ErrorBanner message="Failed to load dashboard" onRetry={refetchS} /></div>}

      <section className="card bg-gradient-to-r from-primary-50 to-white border-primary-100 fade-up">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.16em] text-primary-700 mb-2">Executive Snapshot</p>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Waste control is trending in the right direction</h2>
            <p className="text-sm text-gray-600 max-w-2xl">
              {(summary?.active_recommendations ?? 0) > 0
                ? `${summary?.active_recommendations ?? 0} recommendations are available for immediate action with projected savings of £${((summary?.recommendations_value ?? 0) / 1000).toFixed(0)}k.`
                : 'Run new predictions to identify the next wave of optimization opportunities.'}
            </p>
          </div>

          <div className="flex gap-3">
            <a href="/recommendations" className="btn-primary inline-flex items-center gap-2">
              Review actions <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      </section>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Waste" value={summary?.total_waste_kg ?? 0} unit="kg" change={summary?.waste_change_pct ?? undefined} loading={loadingS} onClick={() => setOpenDrawer('waste')} />
        <KPICard title="Handling Cost" value={summary ? `£${(summary.total_handling_cost/1000).toFixed(1)}k` : '—'} change={summary?.cost_change_pct ?? undefined} loading={loadingS} onClick={() => setOpenDrawer('cost')} />
        <KPICard title="Active Recommendations" value={summary?.active_recommendations ?? 0} loading={loadingS} onClick={() => setOpenDrawer('recommendations')} />
        <KPICard
          title="Prediction Accuracy"
          value={summary?.prediction_accuracy_pct != null ? `${summary.prediction_accuracy_pct}%` : 'No feedback yet'}
          loading={loadingS}
          onClick={() => setOpenDrawer('accuracy')}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Trend Chart */}
        <div className="card lg:col-span-2 fade-up" style={{ animationDelay: '60ms' }}>
          <h3 className="text-sm font-semibold text-gray-700 mb-4">Waste Trend (Monthly)</h3>
          {loadingT ? <Spinner className="h-48" /> : (
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={trends?.series ?? []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tickFormatter={d => format(parseISO(d), 'MMM')} tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip formatter={(v: number) => [`${v.toLocaleString()} kg`, 'Waste']} labelFormatter={d => format(parseISO(d), 'MMMM yyyy')} />
                <Line type="monotone" dataKey="total_waste_kg" stroke="#3b82f6" strokeWidth={2} dot={false} name="Waste (kg)" />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Plastic Type Breakdown */}
        <div className="card fade-up" style={{ animationDelay: '120ms' }}>
          <h3 className="text-sm font-semibold text-gray-700 mb-4">By Plastic Type</h3>
          {loadingS ? <Spinner className="h-48" /> : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={2} dataKey="value">
                  {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(v: number) => [`${v.toLocaleString()} kg`]} />
                <Legend iconSize={10} wrapperStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      <section className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card fade-up" style={{ animationDelay: '180ms' }}>
          <h3 className="text-sm font-semibold text-gray-700 mb-2">Action Priority</h3>
          <p className="text-sm text-gray-600">
            Prioritize supplier and packaging lines contributing to {bestPerformer ? `${bestPerformer.name}` : 'high-volume plastics'} variance. Track recommendation closure weekly for compounding reduction.
          </p>
        </div>
        <div className="card fade-up" style={{ animationDelay: '240ms' }}>
          <div className="flex items-center gap-2 mb-2 text-primary-700">
            <Sparkles className="h-4 w-4" />
            <h3 className="text-sm font-semibold">AI Guidance</h3>
          </div>
          <p className="text-sm text-gray-600">
            Use the Copilot for root-cause analysis by store, supplier, or polymer type, then validate with the report workflow before final decision sign-off.
          </p>
        </div>
      </section>

      {/* Recommendations savings callout */}
      {(summary?.recommendations_value ?? 0) > 0 && (
        <div className="card" style={{ background: 'var(--ok-100)', borderColor: '#bfeccc' }}>
          <p className="text-sm font-semibold text-success-600">
            £{((summary?.recommendations_value ?? 0) / 1000).toFixed(0)}k savings identified across {summary?.active_recommendations ?? 0} pending recommendations.
            <a href="/reports" className="ml-2 underline">View report →</a>
          </p>
        </div>
      )}

      <DetailDrawer open={openDrawer === 'waste'} title="Total Waste" onClose={() => setOpenDrawer(null)}>
        <p className="text-xs text-gray-500 mb-4">
          Sum of <code className="text-[11px] bg-gray-100 px-1 rounded">weight_kg</code> across <code className="text-[11px] bg-gray-100 px-1 rounded">plastic_waste_logs</code> for {summary?.period ?? 'the selected period'}.
        </p>
        <p className="text-2xl font-bold text-gray-900 mb-4">{(summary?.total_waste_kg ?? 0).toLocaleString()} kg</p>
        <h4 className="text-xs font-semibold text-gray-600 mb-2">Breakdown by plastic type</h4>
        <div className="space-y-1.5 mb-4">
          {pieData.map((d) => (
            <div key={d.name} className="flex items-center justify-between text-xs">
              <span className="text-gray-600">{d.name}</span>
              <span className="font-medium text-gray-800">{d.value.toLocaleString()} kg</span>
            </div>
          ))}
          {pieData.length === 0 && <p className="text-xs text-gray-400">No breakdown data for this period.</p>}
        </div>
        <a href="/predictions" className="text-xs text-primary-600 hover:underline inline-flex items-center gap-1">
          Run a new prediction <ArrowRight className="h-3 w-3" />
        </a>
      </DetailDrawer>

      <DetailDrawer open={openDrawer === 'cost'} title="Handling Cost" onClose={() => setOpenDrawer(null)}>
        <p className="text-xs text-gray-500 mb-4">
          Estimated labor, disposal, and transport cost for the waste logged/predicted in {summary?.period ?? 'the selected period'} (handling-cost agent, deterministic rate calculation).
        </p>
        <p className="text-2xl font-bold text-gray-900 mb-1">£{(summary?.total_handling_cost ?? 0).toLocaleString()}</p>
        {summary?.cost_change_pct != null && (
          <p className={summary.cost_change_pct < 0 ? 'text-xs text-success-600' : 'text-xs text-danger-600'}>
            {summary.cost_change_pct > 0 ? '+' : ''}{summary.cost_change_pct.toFixed(1)}% vs prior period
          </p>
        )}
        <a href="/reports" className="text-xs text-primary-600 hover:underline inline-flex items-center gap-1 mt-4">
          View detailed cost report <ArrowRight className="h-3 w-3" />
        </a>
      </DetailDrawer>

      <DetailDrawer open={openDrawer === 'recommendations'} title="Active Recommendations" onClose={() => setOpenDrawer(null)}>
        <p className="text-xs text-gray-500 mb-4">
          Packaging recommendations from the AI recommendation agent with status <code className="text-[11px] bg-gray-100 px-1 rounded">PENDING</code>, awaiting manager review.
        </p>
        <p className="text-2xl font-bold text-gray-900 mb-1">{summary?.active_recommendations ?? 0}</p>
        <p className="text-sm text-success-600 mb-4">£{(summary?.recommendations_value ?? 0).toLocaleString()} estimated annual savings if accepted</p>
        <a href="/recommendations" className="text-xs text-primary-600 hover:underline inline-flex items-center gap-1">
          Review recommendations <ArrowRight className="h-3 w-3" />
        </a>
      </DetailDrawer>

      <DetailDrawer open={openDrawer === 'accuracy'} title="Prediction Accuracy" onClose={() => setOpenDrawer(null)}>
        <p className="text-xs text-gray-500 mb-4">
          Percentage of past predictions rated accurate via 👍/👎 feedback on the Predictions page.
        </p>
        <p className="text-2xl font-bold text-gray-900 mb-1">
          {summary?.prediction_accuracy_pct != null ? `${summary.prediction_accuracy_pct}%` : 'No feedback yet'}
        </p>
        <p className="text-xs text-gray-500 mb-4">{summary?.prediction_feedback_count ?? 0} feedback ratings received</p>
        <a href="/predictions" className="text-xs text-primary-600 hover:underline inline-flex items-center gap-1">
          Run predictions <ArrowRight className="h-3 w-3" />
        </a>
      </DetailDrawer>
    </div>
  )
}
