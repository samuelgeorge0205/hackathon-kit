import { ExternalLink, LifeBuoy } from 'lucide-react'
import { PageHeader } from '../components/ui/components'

const LINKS = [
  { title: 'Local Setup Guide', href: 'http://localhost:8000/docs', note: 'Backend API and setup validation entry point' },
  { title: 'Troubleshooting Guide', href: 'http://localhost:8000/docs', note: 'Operational troubleshooting reference' },
  { title: 'Architecture Guide', href: 'http://localhost:8000/docs', note: 'System and API architecture touchpoints' },
]

export default function HelpPage() {
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader title="Help" subtitle="Documentation and support references" />

      <div className="space-y-3">
        {LINKS.map((link) => (
          <a key={link.title} href={link.href} target="_blank" rel="noreferrer" className="card block hover:border-primary-300 transition-colors">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-sm font-semibold text-gray-900 flex items-center gap-2"><LifeBuoy className="h-4 w-4 text-primary-600" /> {link.title}</p>
                <p className="text-xs text-gray-500 mt-1">{link.note}</p>
              </div>
              <ExternalLink className="h-4 w-4 text-gray-400" />
            </div>
          </a>
        ))}
      </div>
    </div>
  )
}
