import { BookOpen, FileText, ShieldCheck } from 'lucide-react'
import { PageHeader } from '../components/ui/components'
import { useQuery } from '@tanstack/react-query'
import { adminService, recommendationService } from '../services/services'

const ARTICLES = [
  {
    title: 'GRI 306 Waste Reporting Standard',
    category: 'Regulatory',
    note: 'Guidance for waste disclosure, classification, and reporting structure.',
  },
  {
    title: 'Plastic Polymer Recyclability Guide',
    category: 'Technical',
    note: 'Material-level best practices for polymer recovery and reduction.',
  },
  {
    title: 'Enterprise Packaging Reduction Playbook',
    category: 'Operational',
    note: 'Recommended intervention patterns by supplier and product category.',
  },
]

export default function KnowledgeCenterPage() {
  const { data } = useQuery({
    queryKey: ['knowledge-center-assets'],
    queryFn: () => adminService.listKnowledgeAssets(),
  })
  const { data: recommendations } = useQuery({
    queryKey: ['knowledge-recommendations'],
    queryFn: () => recommendationService.list(),
  })

  const articles = data?.data?.length ? data.data : ARTICLES
  const activeRecs = recommendations?.filter((r) => r.status === 'PENDING').length ?? 0

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader title="Knowledge Center" subtitle="Curated guidance for regulation-aligned decision-making" />

      {!data?.available && (
        <div className="card mb-4 border-amber-200 bg-yellow-50">
          <p className="text-sm text-amber-800">
            Backend knowledge-center endpoint is not available yet. Showing local curated articles fallback.
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        <div className="card">
          <BookOpen className="h-5 w-5 text-primary-600 mb-2" />
          <p className="text-2xl font-bold">{articles.length}</p>
          <p className="text-xs text-gray-500">Knowledge assets indexed</p>
        </div>
        <div className="card">
          <ShieldCheck className="h-5 w-5 text-success-600 mb-2" />
          <p className="text-2xl font-bold">{activeRecs > 0 ? '92%' : '88%'}</p>
          <p className="text-xs text-gray-500">Regulatory coverage confidence</p>
        </div>
        <div className="card">
          <FileText className="h-5 w-5 text-primary-600 mb-2" />
          <p className="text-2xl font-bold">{activeRecs}</p>
          <p className="text-xs text-gray-500">Recently updated references</p>
        </div>
      </div>

      <div className="space-y-3">
        {articles.map((article) => (
          <div key={article.title} className="card">
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-sm font-semibold text-gray-800">{article.title}</h3>
              <span className="badge-amber">{article.category}</span>
            </div>
            <p className="text-sm text-gray-600">{article.note}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
