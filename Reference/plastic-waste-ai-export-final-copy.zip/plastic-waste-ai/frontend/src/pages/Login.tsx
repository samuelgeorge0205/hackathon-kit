import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Leaf, Loader2, ShieldCheck, Sparkles, BarChart3 } from 'lucide-react'
import { authService } from '../services/services'
import { useAuthStore } from '../store/authStore'

const schema = z.object({
  email: z.string().email('Invalid email'),
  password: z.string().min(1, 'Password required'),
})
type Form = z.infer<typeof schema>

export default function LoginPage() {
  const [error, setError] = useState('')
  const navigate = useNavigate()
  const setTokens = useAuthStore(s => s.setTokens)
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<Form>({
    resolver: zodResolver(schema),
  })

  const onSubmit = async ({ email, password }: Form) => {
    setError('')
    try {
      const result = await authService.login(email, password)
      setTokens(result.access_token, result.refresh_token, result.user)
      navigate('/')
    } catch {
      setError('Invalid email or password')
    }
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto min-h-[calc(100vh-2rem)] md:min-h-[calc(100vh-4rem)] grid grid-cols-1 lg:grid-cols-2 rounded-3xl overflow-hidden border border-emerald-100 bg-white/85 backdrop-blur">
        <div className="hidden lg:flex flex-col justify-between p-10 bg-gradient-to-br from-emerald-900 via-teal-800 to-cyan-700 text-white">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full px-3 py-1 bg-white/15 border border-white/20 text-xs">
              <Sparkles className="h-3.5 w-3.5" />
              Enterprise Sustainability Intelligence
            </div>
            <h1 className="text-4xl font-semibold mt-6 leading-tight">Turn packaging waste signals into measurable business outcomes.</h1>
            <p className="mt-4 text-sm text-white/85 max-w-md">
              Centralized predictions, recommendation workflows, and regulatory-grade reporting for supply chain teams.
            </p>
          </div>

          <div className="space-y-3 text-sm">
            <div className="flex items-center gap-2"><ShieldCheck className="h-4 w-4" /> Secure role-based access</div>
            <div className="flex items-center gap-2"><BarChart3 className="h-4 w-4" /> Unified operational analytics</div>
            <div className="flex items-center gap-2"><Leaf className="h-4 w-4" /> AI-driven waste reduction actions</div>
          </div>
        </div>

        <div className="flex items-center justify-center p-6 md:p-10">
          <div className="w-full max-w-sm">
            <div className="flex items-center gap-2 mb-8">
              <Leaf className="h-8 w-8 text-primary-600" />
              <span className="text-xl font-bold text-gray-900">Plastic Waste AI</span>
            </div>

            <div className="card">
              <h2 className="text-lg font-semibold text-gray-900 mb-1">Sign in</h2>
              <p className="text-sm text-gray-500 mb-6">Access your enterprise operations workspace</p>
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                <div>
                  <label htmlFor="login_email" className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <input id="login_email" {...register('email')} type="email" className="input" placeholder="analyst@demo.com" />
                  {errors.email && <p className="mt-1 text-xs text-danger-600">{errors.email.message}</p>}
                </div>
                <div>
                  <label htmlFor="login_password" className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                  <input id="login_password" {...register('password')} type="password" className="input" placeholder="Demo1234!" />
                  {errors.password && <p className="mt-1 text-xs text-danger-600">{errors.password.message}</p>}
                </div>
                {error && <p className="text-sm text-danger-600">{error}</p>}
                <button type="submit" disabled={isSubmitting} className="btn-primary w-full flex items-center justify-center gap-2">
                  {isSubmitting && <Loader2 className="h-4 w-4 animate-spin" />}
                  Sign in
                </button>
              </form>
              <div className="mt-4 pt-4 border-t border-gray-100">
                <p className="text-xs text-gray-500">Demo accounts: analyst@demo.com / manager@demo.com / admin@demo.com</p>
                <p className="text-xs text-gray-500 mt-0.5">Password: Demo1234!</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
