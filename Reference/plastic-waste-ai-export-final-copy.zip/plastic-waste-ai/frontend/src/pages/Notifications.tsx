import { Bell, CheckCircle2, Info, TriangleAlert } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import clsx from 'clsx'
import { PageHeader } from '../components/ui/components'
import { useAppStore } from '../store/appStore'
import { useQuery } from '@tanstack/react-query'
import { dashboardService, recommendationService } from '../services/services'

export default function NotificationsPage() {
  const notifications = useAppStore((s) => s.notifications)
  const markRead = useAppStore((s) => s.markNotificationRead)
  const addNotification = useAppStore((s) => s.addNotification)

  const { data: summary } = useQuery({
    queryKey: ['notifications-summary'],
    queryFn: () => dashboardService.getSummary(),
  })

  const { data: recommendations } = useQuery({
    queryKey: ['notifications-recommendations'],
    queryFn: () => recommendationService.list(),
  })

  const syncSignals = () => {
    const pendingCount = recommendations?.filter((r) => r.status === 'PENDING').length ?? 0
    if (pendingCount > 0) {
      addNotification({
        title: 'Pending recommendations updated',
        description: `${pendingCount} recommendations require review action.`,
        severity: 'warning',
      })
    }
    if ((summary?.recommendations_value ?? 0) > 0) {
      addNotification({
        title: 'Savings opportunity refreshed',
        description: `Estimated annual savings £${(summary?.recommendations_value ?? 0).toLocaleString()} available.`,
        severity: 'info',
      })
    }
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader title="Notifications" subtitle="Operational alerts and AI workflow updates" />

      <div className="card mb-4">
        <div className="flex items-center justify-between gap-3">
          <p className="text-sm text-gray-600">
            Sync operational notifications from live dashboard and recommendation signals.
          </p>
          <button type="button" onClick={syncSignals} className="btn-secondary text-xs">Sync signals</button>
        </div>
      </div>

      <div className="space-y-3">
        {notifications.map((n) => (
          <div key={n.id} className={clsx('card', !n.read && 'border-primary-200')}>
            <div className="flex items-start gap-3">
              {n.severity === 'success' && <CheckCircle2 className="h-4 w-4 mt-0.5 text-success-600" />}
              {n.severity === 'warning' && <TriangleAlert className="h-4 w-4 mt-0.5 text-warning-600" />}
              {n.severity === 'info' && <Info className="h-4 w-4 mt-0.5 text-primary-600" />}

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-3">
                  <p className="text-sm font-semibold text-gray-900">{n.title}</p>
                  <span className="text-xs text-gray-400">
                    {formatDistanceToNow(new Date(n.createdAt), { addSuffix: true })}
                  </span>
                </div>
                <p className="text-sm text-gray-600 mt-1">{n.description}</p>
              </div>

              {!n.read && (
                <button className="btn-secondary text-xs" onClick={() => markRead(n.id)}>Mark read</button>
              )}
            </div>
          </div>
        ))}

        {notifications.length === 0 && (
          <div className="card text-center text-gray-500 py-10">
            <Bell className="h-5 w-5 mx-auto mb-2" />
            No notifications.
          </div>
        )}
      </div>
    </div>
  )
}
