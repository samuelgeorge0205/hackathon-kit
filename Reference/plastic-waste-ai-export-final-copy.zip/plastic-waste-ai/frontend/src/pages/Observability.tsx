import { Fragment, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { PageHeader, KPICard, Spinner, ErrorBanner } from '../components/ui/components'
import { observabilityService } from '../services/services'
import { AITraceDetail } from '../types/api'
import { ChevronDown, ChevronRight, X } from 'lucide-react'
import clsx from 'clsx'

function JsonBlock({ value }: { value: unknown }) {
  if (value === undefined || value === null) return <p className="text-xs text-gray-400 italic">Not available</p>
  return (
    <pre className="text-[11px] leading-relaxed bg-gray-50 border border-gray-200 rounded-md p-2 overflow-x-auto whitespace-pre-wrap break-words">
      {JSON.stringify(value, null, 2)}
    </pre>
  )
}

export default function ObservabilityPage() {
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null)
  const [expandedTrace, setExpandedTrace] = useState<string | null>(null)
  const [traceDetail, setTraceDetail] = useState<AITraceDetail | null>(null)
  const [traceDetailLoading, setTraceDetailLoading] = useState(false)

  const { data: healthResult, isLoading: healthLoading } = useQuery({
    queryKey: ['observability-health'],
    queryFn: () => observabilityService.getHealth(),
    refetchInterval: 30_000,
  })

  const { data: summaryResult, isLoading: summaryLoading, refetch } = useQuery({
    queryKey: ['observability-summary'],
    queryFn: () => observabilityService.getSummary(24),
    refetchInterval: 30_000,
  })

  const { data: tracesResult } = useQuery({
    queryKey: ['observability-traces', selectedAgent],
    queryFn: () => observabilityService.getTraces({ agent: selectedAgent ?? undefined, limit: 25 }),
    refetchInterval: 30_000,
  })

  const health = healthResult?.data
  const summary = summaryResult?.data
  const traces = tracesResult?.data ?? []

  const toggleTrace = async (id: string) => {
    if (expandedTrace === id) {
      setExpandedTrace(null)
      return
    }
    setExpandedTrace(id)
    setTraceDetail(null)
    setTraceDetailLoading(true)
    const res = await observabilityService.getTraceDetail(id)
    setTraceDetail(res.available ? res.data : null)
    setTraceDetailLoading(false)
  }

  if (summaryLoading || healthLoading) {
    return (
      <div className="p-6 max-w-6xl mx-auto">
        <PageHeader title="Observability" subtitle="Live AI system health, latency, cost, and guardrail activity" />
        <Spinner className="h-16" />
      </div>
    )
  }

  if (!summaryResult?.available || !summary) {
    return (
      <div className="p-6 max-w-6xl mx-auto">
        <PageHeader title="Observability" subtitle="Live AI system health, latency, cost, and guardrail activity" />
        <ErrorBanner message="Observability data isn't available right now — the backend endpoint may be unreachable." onRetry={() => refetch()} />
      </div>
    )
  }

  const checks = (health?.checks ?? {}) as Record<string, unknown>
  const langfuse = summary.langfuse

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <PageHeader title="Observability" subtitle="Live AI system health, latency, cost, and guardrail activity" />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <KPICard title="AI calls (24h)" value={summary.total_calls} />
        <KPICard title="Errors (24h)" value={summary.total_errors} />
        <KPICard title="Est. LLM cost (24h)" value={`$${summary.total_cost_usd.toFixed(4)}`} />
        <KPICard title="p95 latency" value={summary.latency_ms.p95} unit="ms" />
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-gray-800">System health</h3>
          <span className={health?.status === 'healthy' ? 'badge-green' : 'badge-amber'}>
            {(health?.status ?? 'unknown').toUpperCase()}
          </span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-xs">
          {Object.entries(checks).map(([name, value]) => {
            const status = typeof value === 'string' ? value : (value as { status?: string })?.status ?? 'unknown'
            // "redis" / "fakeredis" are healthy states for the cache check (which backend
            // is serving requests) — only "unavailable"/"error" mean something's actually down.
            const healthy = ['ok', 'redis', 'fakeredis'].includes(status)
            return (
              <div key={name} className="rounded-lg border border-gray-200 p-2 bg-white">
                <p className="text-gray-500 capitalize">{name.replace(/_/g, ' ')}</p>
                <p className={clsx('font-medium mt-0.5', healthy ? 'text-success-600' : 'text-amber-600')}>
                  {status}
                </p>
              </div>
            )
          })}
        </div>
        <p className="text-xs text-gray-500 mt-3">
          Tracing: {langfuse.configured ? (langfuse.initialized ? 'Langfuse connected' : 'Langfuse configured but not initialized') : 'Self-contained (no Langfuse keys set — add them to config/runtime.env to also stream traces to Langfuse)'}
        </p>
      </div>

      <div className="card">
        <h3 className="text-sm font-semibold text-gray-800 mb-3">Per-agent performance (24h) — click a row to filter traces below</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-left text-gray-500 border-b border-gray-200">
                <th className="py-2 pr-4">Agent</th>
                <th className="py-2 pr-4">Calls</th>
                <th className="py-2 pr-4">Errors</th>
                <th className="py-2 pr-4">Avg latency</th>
                <th className="py-2 pr-4">Tokens</th>
                <th className="py-2 pr-4">Cost</th>
              </tr>
            </thead>
            <tbody>
              {summary.agents.length === 0 && (
                <tr><td colSpan={6} className="py-4 text-center text-gray-400">No AI calls recorded yet — use the Copilot or run a prediction to generate traces.</td></tr>
              )}
              {summary.agents.map((a) => (
                <tr
                  key={a.agent_name}
                  onClick={() => setSelectedAgent(selectedAgent === a.agent_name ? null : a.agent_name)}
                  className={clsx(
                    'border-b border-gray-100 cursor-pointer hover:bg-primary-50/50 transition-colors',
                    selectedAgent === a.agent_name && 'bg-primary-50'
                  )}
                >
                  <td className="py-2 pr-4 font-medium text-gray-800">{a.agent_name}</td>
                  <td className="py-2 pr-4">{a.calls}</td>
                  <td className={clsx('py-2 pr-4', a.errors > 0 ? 'text-danger-600' : '')}>{a.errors}</td>
                  <td className="py-2 pr-4">{a.avg_latency_ms} ms</td>
                  <td className="py-2 pr-4">{a.total_tokens.toLocaleString()}</td>
                  <td className="py-2 pr-4">${a.total_cost_usd.toFixed(4)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card">
        <h3 className="text-sm font-semibold text-gray-800 mb-3">Guardrail triggers (24h)</h3>
        {Object.keys(summary.guardrail_triggers).length === 0 ? (
          <p className="text-xs text-gray-400">No guardrail events in this window.</p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {Object.entries(summary.guardrail_triggers).map(([event, count]) => (
              <span key={event} className="badge-amber">{event.replace('GUARDRAIL_', '').replace(/_/g, ' ')}: {count}</span>
            ))}
          </div>
        )}
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-gray-800">
            Recent traces{selectedAgent ? ` — ${selectedAgent}` : ''}
          </h3>
          {selectedAgent && (
            <button
              type="button"
              onClick={() => setSelectedAgent(null)}
              className="text-xs text-gray-500 hover:text-gray-700 inline-flex items-center gap-1"
            >
              <X className="h-3 w-3" /> Clear filter
            </button>
          )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-left text-gray-500 border-b border-gray-200">
                <th className="py-2 pr-4"></th>
                <th className="py-2 pr-4">Agent</th>
                <th className="py-2 pr-4">Status</th>
                <th className="py-2 pr-4">Latency</th>
                <th className="py-2 pr-4">Model</th>
                <th className="py-2 pr-4">Confidence</th>
                <th className="py-2 pr-4">Time</th>
              </tr>
            </thead>
            <tbody>
              {traces.length === 0 && (
                <tr><td colSpan={7} className="py-4 text-center text-gray-400">No traces yet.</td></tr>
              )}
              {traces.map((t) => (
                <Fragment key={t.id}>
                  <tr
                    onClick={() => toggleTrace(t.id)}
                    className="border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors"
                  >
                    <td className="py-2 pl-1 text-gray-400">
                      {expandedTrace === t.id ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
                    </td>
                    <td className="py-2 pr-4 font-medium text-gray-800">{t.agent_name}</td>
                    <td className="py-2 pr-4">
                      <span className={t.status === 'ok' ? 'badge-green' : t.status === 'blocked' ? 'badge-amber' : 'badge-red'}>
                        {t.status}
                      </span>
                    </td>
                    <td className="py-2 pr-4">{t.latency_ms ?? '—'} ms</td>
                    <td className="py-2 pr-4">{t.model ?? '—'}</td>
                    <td className="py-2 pr-4">{t.confidence_score != null ? `${Math.round(t.confidence_score * 100)}%` : '—'}</td>
                    <td className="py-2 pr-4 text-gray-500">{t.created_at ? new Date(t.created_at).toLocaleTimeString() : '—'}</td>
                  </tr>
                  {expandedTrace === t.id && (
                    <tr className="border-b border-gray-100 bg-gray-50/50">
                      <td colSpan={7} className="p-3">
                        {traceDetailLoading ? (
                          <Spinner className="h-8" />
                        ) : !traceDetail ? (
                          <p className="text-xs text-gray-400">Full trace detail requires manager/admin role.</p>
                        ) : (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                              <p className="text-[11px] font-semibold text-gray-500 mb-1">Input</p>
                              <JsonBlock value={traceDetail.input_summary} />
                            </div>
                            <div>
                              <p className="text-[11px] font-semibold text-gray-500 mb-1">Output</p>
                              <JsonBlock value={traceDetail.output_summary} />
                            </div>
                          </div>
                        )}
                      </td>
                    </tr>
                  )}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
