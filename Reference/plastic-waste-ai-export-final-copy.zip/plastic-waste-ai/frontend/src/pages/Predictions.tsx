import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { predictionService, feedbackService } from '../services/services'
import { PageHeader, ConfidenceBadge, ErrorBanner } from '../components/ui/components'
import AgentPipeline from '../components/ui/AgentPipeline'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { ThumbsUp, ThumbsDown, Play, Lightbulb, Loader2 } from 'lucide-react'
import { format } from 'date-fns'
import { PredictionResult } from '../types/api'
import { useAgentStream } from '../hooks/useAgentStream'

const schema = z.object({
  period_start: z.string().min(1),
  period_end:   z.string().min(1),
  supplier_id:  z.string().optional(),
  order_volume: z.preprocess(
    v => (v === '' ? undefined : v),
    z.coerce.number().int().positive().optional()
  ),
})
type Form = z.infer<typeof schema>

const PREDICTION_AGENT_LABELS: Record<string, string> = {
  planner_agent: 'Planner — routing the request',
  retriever_agent: 'Retriever — searching knowledge base',
  waste_prediction_agent: 'Waste Prediction — forecasting volume',
  handling_cost_agent: 'Handling Cost — calculating costs',
  recommendation_agent: 'Recommendation — generating packaging suggestions',
  explanation_agent: 'Explanation — writing plain-English summary',
}

export default function PredictionsPage() {
  const [result, setResult] = useState<PredictionResult | null>(null)
  const [error, setError] = useState('')
  const { steps, order, streaming, run } = useAgentStream()
  const loading = streaming

  const { register, handleSubmit, formState: { errors } } = useForm<Form>({
    resolver: zodResolver(schema),
    defaultValues: {
      period_start: format(new Date(), 'yyyy-MM-01'),
      period_end:   format(new Date(), 'yyyy-MM-') + new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate(),
    },
  })

  const onSubmit = async (form: Form) => {
    setError('')
    setResult(null)
    try {
      const { prediction_id } = await predictionService.create(form)
      const streamResult = await run(`/predictions/waste/${prediction_id}/stream`, { method: 'GET' })
      if (streamResult.finalResult) {
        setResult(streamResult.finalResult)
      } else {
        // Defensive fallback (e.g. dropped connection) — the prediction may
        // still have completed server-side even if the stream didn't deliver it.
        try {
          const data = await predictionService.get(prediction_id)
          setResult(data)
        } catch {
          setError(streamResult.error ?? 'Prediction failed')
        }
      }
    } catch {
      setError('Failed to start prediction')
    }
  }

  const pieData = result?.plastic_type_breakdown
    ? Object.entries(result.plastic_type_breakdown)
        .filter(([, v]) => v > 0)
        .map(([k, v]) => ({ type: k, kg: Math.round(v * 10) / 10 }))
    : []

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader title="Waste Predictions" subtitle="AI-powered plastic waste volume forecasting" />

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Form */}
        <div className="card lg:col-span-2">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">Prediction Parameters</h3>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
            <div>
              <label htmlFor="period_start" className="block text-xs font-medium text-gray-600 mb-1">Period Start</label>
              <input id="period_start" {...register('period_start')} type="date" className="input" />
              {errors.period_start && <p className="text-xs text-danger-600 mt-1">Required</p>}
            </div>
            <div>
              <label htmlFor="period_end" className="block text-xs font-medium text-gray-600 mb-1">Period End</label>
              <input id="period_end" {...register('period_end')} type="date" className="input" />
            </div>
            <div>
              <label htmlFor="order_volume" className="block text-xs font-medium text-gray-600 mb-1">Order Volume (units)</label>
              <input id="order_volume" {...register('order_volume')} type="number" className="input" placeholder="e.g. 15000" />
            </div>
            {error && <ErrorBanner message={error} />}
            <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
              {loading ? 'Running AI...' : 'Run Prediction'}
            </button>
          </form>
        </div>

        {/* Result */}
        <div className="lg:col-span-3 space-y-4">
          {loading && !result && (
            <div className="card">
              <h4 className="text-sm font-semibold text-gray-700 mb-3">Agent Pipeline — live progress</h4>
              <AgentPipeline order={order} steps={steps} streaming={streaming} agentLabels={PREDICTION_AGENT_LABELS} />
            </div>
          )}

          {result && result.status === 'COMPLETE' && (
            <>
              <div className="card">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="text-3xl font-bold text-gray-900">
                      {(result.predicted_waste_kg ?? 0).toLocaleString()} kg
                    </p>
                    <p className="text-sm text-gray-500 mt-1">Predicted plastic waste</p>
                  </div>
                  <ConfidenceBadge score={result.confidence_score as number} />
                </div>

                {result.prediction_interval && (
                  <p className="text-xs text-gray-500">
                    Range: {result.prediction_interval.low.toLocaleString()} – {result.prediction_interval.high.toLocaleString()} kg
                  </p>
                )}

                {/* Feedback */}
                <div className="flex items-center gap-2 mt-4 pt-4 border-t border-gray-100">
                  <span className="text-xs text-gray-500">Was this accurate?</span>
                  <button onClick={() => feedbackService.submit('PREDICTION', result.prediction_id, 1)} className="p-1.5 rounded hover:bg-success-100 transition-colors">
                    <ThumbsUp className="h-4 w-4 text-gray-400 hover:text-success-600" />
                  </button>
                  <button onClick={() => feedbackService.submit('PREDICTION', result.prediction_id, -1)} className="p-1.5 rounded hover:bg-danger-100 transition-colors">
                    <ThumbsDown className="h-4 w-4 text-gray-400 hover:text-danger-600" />
                  </button>
                </div>
              </div>

              {/* Breakdown chart */}
              {pieData.length > 0 && (
                <div className="card">
                  <h4 className="text-sm font-semibold text-gray-700 mb-3">Plastic Type Breakdown</h4>
                  <ResponsiveContainer width="100%" height={160}>
                    <BarChart data={pieData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                      <XAxis type="number" tick={{ fontSize: 11 }} />
                      <YAxis type="category" dataKey="type" tick={{ fontSize: 11 }} width={40} />
                      <Tooltip formatter={(v: number) => [`${v} kg`]} />
                      <Bar dataKey="kg" fill="#3b82f6" radius={[0, 3, 3, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}

              {/* Explanation */}
              {result.explanation && (
                <div className="card border-l-4 border-primary-500">
                  <h4 className="text-sm font-semibold text-gray-700 mb-2">AI Explanation</h4>
                  <p className="text-sm text-gray-600 leading-relaxed">{result.explanation as string}</p>
                  {result.key_factors && result.key_factors.length > 0 && (
                    <ul className="mt-3 space-y-1">
                      {result.key_factors.map((f, i) => (
                        <li key={i} className="text-xs text-gray-500 flex items-start gap-1.5">
                          <span className="text-primary-400 mt-0.5">•</span>{f}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              )}

              {/* Recommendations — live output of this run's recommendation agent */}
              {result.recommendations && result.recommendations.length > 0 && (
                <div className="card">
                  <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-1.5">
                    <Lightbulb className="h-4 w-4 text-amber-500" /> Packaging Recommendations
                  </h4>
                  <div className="space-y-2">
                    {result.recommendations.map((rec, i) => (
                      <div key={i} className="rounded-lg border border-gray-200 p-3">
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <span className="text-xs font-medium text-primary-600">{rec.recommendation_type}</span>
                          <ConfidenceBadge score={rec.confidence_score} />
                        </div>
                        <p className="text-sm text-gray-800 mt-1">{rec.description}</p>
                        {rec.rationale && <p className="text-xs text-gray-500 mt-1">{rec.rationale}</p>}
                        <div className="flex items-center gap-4 mt-2">
                          {Boolean(rec.estimated_waste_reduction_kg) && (
                            <span className="text-xs text-success-600">↓ {rec.estimated_waste_reduction_kg?.toLocaleString()} kg/year</span>
                          )}
                          {Boolean(rec.estimated_cost_saving) && (
                            <span className="text-xs text-primary-600">£{rec.estimated_cost_saving?.toLocaleString()}/year</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Agent pipeline drill-down (still available after completion) */}
              {order.length > 0 && (
                <div className="card">
                  <h4 className="text-sm font-semibold text-gray-700 mb-3">Agent Pipeline</h4>
                  <AgentPipeline order={order} steps={steps} streaming={false} agentLabels={PREDICTION_AGENT_LABELS} />
                </div>
              )}
            </>
          )}

          {!loading && !result && (
            <div className="card flex items-center justify-center h-48 text-gray-400">
              <p className="text-sm">Fill in parameters and run a prediction</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
