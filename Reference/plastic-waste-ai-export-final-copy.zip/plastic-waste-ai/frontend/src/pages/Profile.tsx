import { BadgeCheck, Mail, User } from 'lucide-react'
import { PageHeader } from '../components/ui/components'
import { useAuthStore } from '../store/authStore'

export default function ProfilePage() {
  const user = useAuthStore((s) => s.user)

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <PageHeader title="Profile" subtitle="Identity and role context" />

      <div className="card">
        <div className="flex items-center gap-4 mb-5">
          <div className="h-14 w-14 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center text-xl font-bold">
            {user?.full_name?.[0] ?? '?'}
          </div>
          <div>
            <p className="text-lg font-semibold text-gray-900">{user?.full_name ?? 'Unknown user'}</p>
            <p className="text-sm text-gray-500 capitalize">{user?.role ?? 'Unknown role'}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
          <div className="rounded-lg border border-gray-200 p-3">
            <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><Mail className="h-3.5 w-3.5" /> Email</p>
            <p className="font-medium text-gray-900">{user?.email ?? 'n/a'}</p>
          </div>
          <div className="rounded-lg border border-gray-200 p-3">
            <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><BadgeCheck className="h-3.5 w-3.5" /> Access level</p>
            <p className="font-medium text-gray-900 capitalize">{user?.role ?? 'n/a'}</p>
          </div>
          <div className="rounded-lg border border-gray-200 p-3 md:col-span-2">
            <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><User className="h-3.5 w-3.5" /> User ID</p>
            <p className="font-medium text-gray-900">{user?.id ?? 'n/a'}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
