import { useMemo, useState } from 'react'
import { Search } from 'lucide-react'
import { PageHeader } from '../components/ui/components'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { adminService, PromptAsset } from '../services/services'
import { formatDistanceToNow } from 'date-fns'

const PROMPTS = [
  { name: 'planner-agent', version: 'v1.0', owner: 'AI Team', status: 'active' },
  { name: 'retriever-agent', version: 'v1.1', owner: 'AI Team', status: 'active' },
  { name: 'waste-prediction-agent', version: 'v1.2', owner: 'Data Science', status: 'active' },
  { name: 'handling-cost-agent', version: 'v1.0', owner: 'Data Science', status: 'active' },
  { name: 'recommendation-agent', version: 'v1.0', owner: 'Sustainability Ops', status: 'active' },
  { name: 'explanation-agent', version: 'v1.0', owner: 'AI Team', status: 'active' },
  { name: 'chat-response-agent', version: 'v1.0', owner: 'AI Team', status: 'active' },
  { name: 'report-generator-agent', version: 'v1.1', owner: 'Reporting', status: 'active' },
]

export default function PromptLibraryPage() {
  const qc = useQueryClient()
  const [query, setQuery] = useState('')
  const [selectedPrompt, setSelectedPrompt] = useState<string | null>(null)
  const [drafts, setDrafts] = useState<Record<string, { version: string; owner: string; status: string }>>({})
  const [message, setMessage] = useState('')
  const { data } = useQuery({
    queryKey: ['prompt-library'],
    queryFn: () => adminService.listPrompts(),
  })

  const { mutate: savePrompt, isPending } = useMutation({
    mutationFn: ({ name, payload }: { name: string; payload: { version: string; owner: string; status: string } }) =>
      adminService.updatePrompt(name, payload),
    onSuccess: () => {
      setMessage('Prompt metadata updated')
      qc.invalidateQueries({ queryKey: ['prompt-library'] })
    },
    onError: () => setMessage('Failed to update prompt metadata'),
  })

  const { data: history } = useQuery({
    queryKey: ['prompt-history', selectedPrompt],
    queryFn: () => adminService.listAudit({ entity_type: 'prompt', entity_id: selectedPrompt ?? undefined, limit: 20 }),
    enabled: Boolean(selectedPrompt),
  })

  const promptAssets: PromptAsset[] = data?.data?.length ? data.data : PROMPTS

  const editableAssets = useMemo(
    () =>
      promptAssets.map((p) => ({
        ...p,
        version: drafts[p.name]?.version ?? p.version,
        owner: drafts[p.name]?.owner ?? p.owner,
        status: drafts[p.name]?.status ?? p.status,
      })),
    [promptAssets, drafts]
  )

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return editableAssets
    return editableAssets.filter((p) => p.name.includes(q) || p.owner.toLowerCase().includes(q))
  }, [query, editableAssets])

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader title="Prompt Library" subtitle="Versioned AI prompt assets and ownership" />

      {!data?.available && (
        <div className="card mb-4 border-amber-200 bg-yellow-50">
          <p className="text-sm text-amber-800">
            Backend prompt library endpoint is not available yet. Showing local prompt catalog fallback.
          </p>
        </div>
      )}

      {message && (
        <div className="card mb-4 border-primary-200 bg-primary-50">
          <p className="text-sm text-primary-800">{message}</p>
        </div>
      )}

      <div className="card mb-4">
        <div className="relative max-w-md">
          <Search className="h-4 w-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            className="input pl-9"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search prompts by name or owner"
          />
        </div>
      </div>

      <div className="space-y-3">
        {filtered.map((prompt) => (
          <div key={prompt.name} className="card">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-sm font-semibold text-gray-900">{prompt.name}</p>
                {prompt.content_preview && (
                  <p className="text-xs text-gray-500 mt-1 line-clamp-2 max-w-xl">{prompt.content_preview}</p>
                )}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-2">
                  <input
                    className="input text-xs"
                    value={prompt.owner}
                    onChange={(e) =>
                      setDrafts((s) => ({
                        ...s,
                        [prompt.name]: {
                          version: prompt.version,
                          owner: e.target.value,
                          status: prompt.status,
                        },
                      }))
                    }
                    placeholder="Owner"
                  />
                  <input
                    className="input text-xs"
                    value={prompt.version}
                    onChange={(e) =>
                      setDrafts((s) => ({
                        ...s,
                        [prompt.name]: {
                          version: e.target.value,
                          owner: prompt.owner,
                          status: prompt.status,
                        },
                      }))
                    }
                    placeholder="Version"
                  />
                  <select
                    className="input text-xs"
                    value={prompt.status}
                    onChange={(e) =>
                      setDrafts((s) => ({
                        ...s,
                        [prompt.name]: {
                          version: prompt.version,
                          owner: prompt.owner,
                          status: e.target.value,
                        },
                      }))
                    }
                  >
                    <option value="active">active</option>
                    <option value="inactive">inactive</option>
                    <option value="draft">draft</option>
                    <option value="archived">archived</option>
                  </select>
                </div>
              </div>
              <div className="text-right space-y-2">
                <span className="badge-green">{prompt.status}</span>
                <div>
                  <button
                    type="button"
                    className="btn-secondary text-xs"
                    disabled={isPending || !data?.available}
                    onClick={() =>
                      savePrompt({
                        name: prompt.name,
                        payload: { version: prompt.version, owner: prompt.owner, status: prompt.status },
                      })
                    }
                  >
                    Save
                  </button>
                  <button
                    type="button"
                    className="btn-secondary text-xs ml-2"
                    onClick={() => setSelectedPrompt(prompt.name)}
                  >
                    History
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {selectedPrompt && (
        <div className="card mt-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold text-gray-900">Prompt History: {selectedPrompt}</h3>
            <button type="button" className="btn-secondary text-xs" onClick={() => setSelectedPrompt(null)}>Close</button>
          </div>

          {!history?.available && (
            <p className="text-xs text-gray-500">History endpoint unavailable for current role or backend state.</p>
          )}

          {history?.available && history.data.length === 0 && (
            <p className="text-xs text-gray-500">No prompt metadata history recorded yet.</p>
          )}

          <div className="space-y-2">
            {history?.data.map((entry) => (
              <div key={entry.id} className="rounded-lg border border-gray-200 p-3">
                <p className="text-xs font-semibold text-gray-800">{entry.action}</p>
                <p className="text-xs text-gray-500 mt-0.5">{formatDistanceToNow(new Date(entry.created_at), { addSuffix: true })}</p>
                {entry.after_json && <p className="text-xs text-gray-600 mt-1">After: {entry.after_json}</p>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
