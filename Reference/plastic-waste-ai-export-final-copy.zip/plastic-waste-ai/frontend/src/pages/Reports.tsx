import { useState } from 'react'
import { reportService } from '../services/services'
import { PageHeader, Spinner, ErrorBanner } from '../components/ui/components'
import { FileText, Download } from 'lucide-react'
import { ReportData } from '../types/api'

export default function ReportsPage() {
  const [loading, setLoading] = useState(false)
  const [downloading, setDownloading] = useState(false)
  const [report, setReport] = useState<ReportData | null>(null)
  const [error, setError] = useState('')
  const [periodStart, setPeriodStart] = useState('2026-01-01')
  const [periodEnd, setPeriodEnd] = useState('2026-07-30')

  const generate = async () => {
    setLoading(true); setError(''); setReport(null)
    try {
      const { report_id } = await reportService.generate({
        report_type: 'SUSTAINABILITY_WASTE',
        period_start: periodStart,
        period_end: periodEnd,
        scope: 'ORGANISATION',
        include_recommendations: true,
        regulatory_framework: 'GRI_306',
      })
      // Poll
      let attempts = 0
      while (attempts < 30) {
        await new Promise(r => setTimeout(r, 2000))
        const data = await reportService.get(report_id)
        if (data.status === 'COMPLETE' || data.status === 'ERROR') { setReport(data); break }
        attempts++
      }
    } catch { setError('Failed to generate report') }
    finally { setLoading(false) }
  }

  const metrics = report?.key_metrics
  const wasteByType = report?.waste_by_type ?? {}

  const downloadPdf = async () => {
    if (!report?.report_id) return
    setDownloading(true)
    try {
      const blob = await reportService.download(report.report_id)
      const url = window.URL.createObjectURL(blob)
      const anchor = document.createElement('a')
      anchor.href = url
      anchor.download = `plastic-waste-report-${report.report_id}.pdf`
      document.body.appendChild(anchor)
      anchor.click()
      document.body.removeChild(anchor)
      window.URL.revokeObjectURL(url)
    } catch {
      setError('Failed to download PDF report')
    } finally {
      setDownloading(false)
    }
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader title="Reports" subtitle="AI-generated sustainability waste reports" />

      <div className="card mb-6">
        <h3 className="text-sm font-semibold text-gray-700 mb-4">Report Builder</h3>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label htmlFor="report_period_start" className="block text-xs font-medium text-gray-600 mb-1">Period Start</label>
            <input id="report_period_start" type="date" value={periodStart} onChange={e => setPeriodStart(e.target.value)} className="input" />
          </div>
          <div>
            <label htmlFor="report_period_end" className="block text-xs font-medium text-gray-600 mb-1">Period End</label>
            <input id="report_period_end" type="date" value={periodEnd} onChange={e => setPeriodEnd(e.target.value)} className="input" />
          </div>
        </div>
        {error && <div className="mb-3"><ErrorBanner message={error} /></div>}
        <button onClick={generate} disabled={loading} className="btn-primary flex items-center gap-2">
          {loading ? <><Spinner className="h-4" /> Generating report...</> : <><FileText className="h-4 w-4" /> Generate GRI 306 Report</>}
        </button>
        {loading && <p className="text-xs text-gray-400 mt-2">Typically 30–60 seconds…</p>}
      </div>

      {report && report.status === 'COMPLETE' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-gray-900">{report.title as string}</h2>
            <button onClick={downloadPdf} disabled={downloading} className="btn-secondary flex items-center gap-2 text-xs disabled:opacity-60">
              <Download className="h-3.5 w-3.5" /> {downloading ? 'Downloading...' : 'Download PDF'}
            </button>
          </div>

          {metrics && (
            <div className="grid grid-cols-3 gap-3">
              <div className="card text-center">
                <p className="text-2xl font-bold text-gray-900">{(metrics.total_waste_kg ?? 0).toLocaleString()}</p>
                <p className="text-xs text-gray-500 mt-1">kg Total Waste</p>
              </div>
              <div className="card text-center">
                {metrics.period_over_period_change_pct == null ? (
                  <p className="text-2xl font-bold text-gray-400">N/A</p>
                ) : (
                  <p className={`text-2xl font-bold ${metrics.period_over_period_change_pct < 0 ? 'text-success-600' : 'text-danger-600'}`}>
                    {metrics.period_over_period_change_pct > 0 ? '+' : ''}{metrics.period_over_period_change_pct.toFixed(1)}%
                  </p>
                )}
                <p className="text-xs text-gray-500 mt-1">vs Prior Period</p>
              </div>
              <div className="card text-center">
                <p className="text-2xl font-bold text-primary-600">{metrics.recycling_rate_pct?.toFixed(1) ?? 0}%</p>
                <p className="text-xs text-gray-500 mt-1">Recycling Rate</p>
              </div>
            </div>
          )}

          {Boolean(report.executive_summary) && (
            <div className="card border-l-4 border-primary-500">
              <h4 className="text-sm font-semibold text-gray-700 mb-2">Executive Summary</h4>
              <p className="text-sm text-gray-600 leading-relaxed">{report.executive_summary as string}</p>
            </div>
          )}

          {Object.keys(wasteByType).length > 0 && (
            <div className="card">
              <h4 className="text-sm font-semibold text-gray-700 mb-3">Waste by Plastic Type</h4>
              <div className="space-y-2">
                {Object.entries(wasteByType)
                  .sort(([, a], [, b]) => b - a)
                  .map(([type, kg]) => {
                    const total = Object.values(wasteByType).reduce((a, b) => a + b, 0)
                    const pct = total > 0 ? (kg / total) * 100 : 0
                    return (
                      <div key={type} className="flex items-center gap-3">
                        <span className="w-12 text-xs font-medium text-gray-600">{type}</span>
                        <div className="flex-1 bg-gray-100 rounded-full h-2">
                          <div className="bg-primary-500 h-2 rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                        <span className="text-xs text-gray-500 w-20 text-right">{kg.toLocaleString()} kg</span>
                      </div>
                    )
                  })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
