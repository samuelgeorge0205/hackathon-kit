import { useAuthStore } from '../store/authStore'
import { PageHeader } from '../components/ui/components'
import { User, Shield, Database } from 'lucide-react'

export default function SettingsPage() {
  const user = useAuthStore(s => s.user)

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <PageHeader title="Settings" subtitle="Platform configuration and account management" />

      <div className="space-y-4">
        <div className="card">
          <div className="flex items-center gap-3 mb-4">
            <User className="h-5 w-5 text-primary-600" />
            <h3 className="text-sm font-semibold text-gray-700">Your Profile</h3>
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div><p className="text-gray-500">Name</p><p className="font-medium">{user?.full_name}</p></div>
            <div><p className="text-gray-500">Email</p><p className="font-medium">{user?.email}</p></div>
            <div><p className="text-gray-500">Role</p><p className="font-medium capitalize">{user?.role}</p></div>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="h-5 w-5 text-primary-600" />
            <h3 className="text-sm font-semibold text-gray-700">Access Control</h3>
          </div>
          <div className="space-y-2 text-xs text-gray-500">
            {[
              { role: 'viewer',   perms: 'Read-only: dashboard, analytics, copilot' },
              { role: 'analyst',  perms: 'viewer + upload, predictions, reports' },
              { role: 'manager',  perms: 'analyst + recommendations approval' },
              { role: 'admin',    perms: 'Full access including user management' },
            ].map(r => (
              <div key={r.role} className={`flex gap-3 p-2 rounded ${user?.role === r.role ? 'bg-primary-50' : ''}`}>
                <span className="font-medium capitalize w-20">{r.role}</span>
                <span>{r.perms}</span>
                {user?.role === r.role && <span className="ml-auto text-primary-600 font-medium">← you</span>}
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="flex items-center gap-3 mb-4">
            <Database className="h-5 w-5 text-primary-600" />
            <h3 className="text-sm font-semibold text-gray-700">System</h3>
          </div>
          <div className="text-xs text-gray-500 space-y-1">
            <p>Backend: <a href="http://localhost:8000/docs" target="_blank" rel="noreferrer" className="text-primary-600 hover:underline">API Docs (Swagger)</a></p>
            <p>Version: 1.0.0</p>
            <p>LLM Gateway: TCS GenAI Lab (https://genailab.tcs.in)</p>
          </div>
        </div>
      </div>
    </div>
  )
}
