import { useState, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { uploadService } from '../services/services'
import { PageHeader, Spinner, ErrorBanner } from '../components/ui/components'
import { Upload, CheckCircle, XCircle, FileText } from 'lucide-react'
import clsx from 'clsx'

type UploadType = 'products' | 'packaging' | 'wasteLogs'

const TYPES: { key: UploadType; label: string; desc: string; fields: string }[] = [
  { key: 'products',   label: 'Products',    desc: 'Product catalogue',       fields: 'sku, name, category, supplier_id, weight_kg' },
  { key: 'packaging',  label: 'Packaging',   desc: 'Packaging specifications', fields: 'product_id, material_type, weight_g, recyclable' },
  { key: 'wasteLogs',  label: 'Waste Logs',  desc: 'Plastic waste records',    fields: 'source_type, source_id, log_date, plastic_type, weight_kg' },
]

interface UploadResult { status: string; rows_processed?: number; rows_created?: number; rows_failed?: number; errors?: { row: number; message: string }[] }

export default function UploadPage() {
  const [type, setType] = useState<UploadType>('wasteLogs')
  const [result, setResult] = useState<UploadResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [file, setFile] = useState<File | null>(null)

  const onDrop = useCallback((accepted: File[]) => {
    if (accepted[0]) { setFile(accepted[0]); setResult(null); setError('') }
  }, [])
  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop, accept: { 'text/csv': ['.csv'] }, maxSize: 10_485_760 })

  const upload = async () => {
    if (!file) return
    setLoading(true); setError(''); setResult(null)
    try {
      const job = await uploadService[type](file)
      // Poll for completion
      let attempts = 0
      while (attempts < 20) {
        await new Promise(r => setTimeout(r, 1000))
        const status = await uploadService.getStatus(job.upload_id)
        if (status.status === 'COMPLETE' || status.status === 'ERROR') { setResult(status); break }
        attempts++
      }
    } catch { setError('Upload failed. Check file format and try again.') }
    finally { setLoading(false) }
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <PageHeader title="Upload Data" subtitle="Import CSV files to update the platform data" />

      {/* Type selector */}
      <div className="flex gap-2 mb-6">
        {TYPES.map(t => (
          <button key={t.key} onClick={() => { setType(t.key); setFile(null); setResult(null) }}
            className={clsx('flex-1 py-3 px-4 rounded-lg border text-sm font-medium transition-colors',
              type === t.key ? 'bg-primary-50 border-primary-300 text-primary-700' : 'border-gray-200 text-gray-600 hover:border-gray-300')}>
            <div className="font-semibold">{t.label}</div>
            <div className="text-xs opacity-70 mt-0.5">{t.desc}</div>
          </button>
        ))}
      </div>

      {/* Drop zone */}
      <div className="card mb-4">
        <p className="text-xs text-gray-500 mb-3">Required fields: <code className="bg-gray-100 px-1 rounded">{TYPES.find(t => t.key === type)?.fields}</code></p>
        <div {...getRootProps()} className={clsx(
          'border-2 border-dashed rounded-xl p-10 text-center cursor-pointer transition-colors',
          isDragActive ? 'border-primary-400 bg-primary-50' : 'border-gray-300 hover:border-primary-300 hover:bg-gray-50'
        )}>
          <input {...getInputProps()} />
          <Upload className="h-8 w-8 text-gray-400 mx-auto mb-3" />
          {file ? (
            <div className="flex items-center justify-center gap-2 text-sm text-gray-700">
              <FileText className="h-4 w-4" />
              {file.name} ({(file.size / 1024).toFixed(1)} KB)
            </div>
          ) : (
            <p className="text-sm text-gray-500">Drop CSV file here or click to browse (max 10MB)</p>
          )}
        </div>

        {error && <div className="mt-3"><ErrorBanner message={error} /></div>}

        <button onClick={upload} disabled={!file || loading}
          className="btn-primary mt-4 flex items-center justify-center gap-2 w-full">
          {loading ? <><Spinner className="h-4" /> Processing...</> : <><Upload className="h-4 w-4" /> Upload</>}
        </button>
      </div>

      {/* Result */}
      {result && (
        <div className={clsx('card', result.status === 'COMPLETE' ? 'border-green-200' : 'border-red-200')}>
          <div className="flex items-center gap-2 mb-3">
            {result.status === 'COMPLETE'
              ? <CheckCircle className="h-5 w-5 text-success-600" />
              : <XCircle className="h-5 w-5 text-danger-600" />}
            <span className={clsx('font-semibold text-sm', result.status === 'COMPLETE' ? 'text-success-600' : 'text-danger-600')}>
              {result.status === 'COMPLETE' ? 'Upload complete' : 'Upload failed'}
            </span>
          </div>
          {result.rows_processed !== undefined && (
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="bg-gray-50 rounded-lg p-2"><p className="text-lg font-bold">{result.rows_processed}</p><p className="text-xs text-gray-500">Processed</p></div>
              <div className="bg-success-100 rounded-lg p-2"><p className="text-lg font-bold text-success-600">{result.rows_created ?? 0}</p><p className="text-xs text-gray-500">Created</p></div>
              <div className="bg-danger-100 rounded-lg p-2"><p className="text-lg font-bold text-danger-600">{result.rows_failed ?? 0}</p><p className="text-xs text-gray-500">Failed</p></div>
            </div>
          )}
          {result.errors && result.errors.length > 0 && (
            <div className="mt-3 text-xs text-danger-600 space-y-1">
              {result.errors.slice(0, 5).map((e, i) => <p key={i}>Row {e.row}: {e.message}</p>)}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
