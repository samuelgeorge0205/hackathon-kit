import { useMemo, useState } from 'react'
import { Shield, User2 } from 'lucide-react'
import { ConfirmDialog, LoadingOverlay, PageHeader } from '../components/ui/components'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { adminService, AdminUser } from '../services/services'
import { useAuthStore } from '../store/authStore'
import { useAppStore } from '../store/appStore'

export default function UsersPage() {
  const qc = useQueryClient()
  const currentUser = useAuthStore((s) => s.user)
  const addToast = useAppStore((s) => s.addToast)
  const [drafts, setDrafts] = useState<Record<string, { role: string; status: string }>>({})
  const [message, setMessage] = useState('')
  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [sortBy, setSortBy] = useState<'name' | 'email' | 'role'>('name')
  const [page, setPage] = useState(1)
  const [confirmDeactivateId, setConfirmDeactivateId] = useState<string | null>(null)
  const [newUser, setNewUser] = useState({
    full_name: '',
    email: '',
    role: 'viewer',
    department: '',
    password: 'Demo1234!',
  })
  const { data } = useQuery({
    queryKey: ['admin-users'],
    queryFn: () => adminService.listUsers(),
  })

  const { mutate: saveUser, isPending } = useMutation({
    mutationFn: ({ id, payload }: { id: string; payload: { role: string; status: string } }) => adminService.updateUser(id, payload),
    onSuccess: () => {
      setMessage('User updated successfully')
      addToast({ message: 'User permissions updated', severity: 'success' })
      qc.invalidateQueries({ queryKey: ['admin-users'] })
    },
    onError: () => {
      setMessage('Failed to update user')
      addToast({ message: 'Update failed', severity: 'error' })
    },
  })

  const { mutate: createUser, isPending: isCreating } = useMutation({
    mutationFn: () => adminService.createUser(newUser),
    onSuccess: () => {
      setMessage('User created successfully')
      addToast({ message: 'User created', severity: 'success' })
      setNewUser({ full_name: '', email: '', role: 'viewer', department: '', password: 'Demo1234!' })
      qc.invalidateQueries({ queryKey: ['admin-users'] })
    },
    onError: () => {
      setMessage('Failed to create user')
      addToast({ message: 'Create user failed', severity: 'error' })
    },
  })

  const { mutate: removeUser, isPending: isDeleting } = useMutation({
    mutationFn: (id: string) => adminService.deleteUser(id),
    onSuccess: () => {
      setMessage('User deactivated successfully')
      addToast({ message: 'User deactivated', severity: 'warning' })
      qc.invalidateQueries({ queryKey: ['admin-users'] })
    },
    onError: () => {
      setMessage('Failed to deactivate user')
      addToast({ message: 'Deactivate failed', severity: 'error' })
    },
  })

  const users: AdminUser[] = data?.data?.length
    ? data.data
    : currentUser
      ? [{ ...currentUser, status: 'active' }]
      : []

  const mergedUsers = useMemo(() => {
    const items = users
      .map((u) => ({ ...u, role: drafts[u.id]?.role ?? u.role, status: drafts[u.id]?.status ?? u.status }))
      .filter((u) => {
        const q = search.trim().toLowerCase()
        const searchOk = !q || u.full_name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q)
        const roleOk = roleFilter === 'all' || u.role === roleFilter
        const statusOk = statusFilter === 'all' || u.status === statusFilter
        return searchOk && roleOk && statusOk
      })

    items.sort((a, b) => {
      if (sortBy === 'email') return a.email.localeCompare(b.email)
      if (sortBy === 'role') return a.role.localeCompare(b.role)
      return a.full_name.localeCompare(b.full_name)
    })

    return items
  }, [users, drafts, search, roleFilter, statusFilter, sortBy])

  const pageSize = 8
  const totalPages = Math.max(1, Math.ceil(mergedUsers.length / pageSize))
  const pagedUsers = mergedUsers.slice((page - 1) * pageSize, page * pageSize)

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader title="Users" subtitle="User identity, role mapping, and access governance" />

      {!data?.available && (
        <div className="card mb-4 border-amber-200 bg-yellow-50">
          <p className="text-sm text-amber-800">
            Backend endpoint for user administration is not available yet. Showing authenticated session user fallback.
          </p>
        </div>
      )}

      {message && (
        <div className="card mb-4 border-primary-200 bg-primary-50">
          <p className="text-sm text-primary-800">{message}</p>
        </div>
      )}

      <div className="card mb-4">
        <h3 className="text-sm font-semibold text-gray-900 mb-3">Create User</h3>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
          <input className="input text-xs" placeholder="Full name" value={newUser.full_name} onChange={(e) => setNewUser((s) => ({ ...s, full_name: e.target.value }))} />
          <input className="input text-xs" placeholder="Email" value={newUser.email} onChange={(e) => setNewUser((s) => ({ ...s, email: e.target.value }))} />
          <select className="input text-xs" value={newUser.role} onChange={(e) => setNewUser((s) => ({ ...s, role: e.target.value }))}>
            <option value="viewer">viewer</option>
            <option value="analyst">analyst</option>
            <option value="manager">manager</option>
            <option value="admin">admin</option>
          </select>
          <input className="input text-xs" placeholder="Department" value={newUser.department} onChange={(e) => setNewUser((s) => ({ ...s, department: e.target.value }))} />
          <button type="button" className="btn-primary text-xs" disabled={!data?.available || isCreating || !newUser.email || !newUser.full_name} onClick={() => createUser()}>
            Create
          </button>
        </div>
      </div>

      <div className="card mb-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
          <input className="input text-xs" placeholder="Search by name or email" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1) }} />
          <select className="input text-xs" value={roleFilter} onChange={(e) => { setRoleFilter(e.target.value); setPage(1) }}>
            <option value="all">All roles</option>
            <option value="viewer">viewer</option>
            <option value="analyst">analyst</option>
            <option value="manager">manager</option>
            <option value="admin">admin</option>
          </select>
          <select className="input text-xs" value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setPage(1) }}>
            <option value="all">All statuses</option>
            <option value="active">active</option>
            <option value="inactive">inactive</option>
          </select>
          <select className="input text-xs" value={sortBy} onChange={(e) => setSortBy(e.target.value as 'name' | 'email' | 'role')}>
            <option value="name">Sort: Name</option>
            <option value="email">Sort: Email</option>
            <option value="role">Sort: Role</option>
          </select>
        </div>
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-500 border-b border-gray-200">
              <th className="py-2 pr-3">User</th>
              <th className="py-2 pr-3">Email</th>
              <th className="py-2 pr-3">Role</th>
              <th className="py-2 pr-3">Status</th>
              <th className="py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {pagedUsers.map((user) => (
              <tr key={user.id} className="border-b border-gray-100 last:border-0">
                <td className="py-3 pr-3">
                  <div className="flex items-center gap-2">
                    <User2 className="h-4 w-4 text-primary-600" />
                    <span className="font-medium text-gray-900">{user.full_name}</span>
                  </div>
                </td>
                <td className="py-3 pr-3 text-gray-600">{user.email}</td>
                <td className="py-3 pr-3">
                  <div className="flex items-center gap-2">
                    <Shield className="h-3 w-3 text-primary-700" />
                    <select
                      className="input py-1 text-xs"
                      value={user.role}
                      onChange={(e) => setDrafts((s) => ({ ...s, [user.id]: { role: e.target.value, status: user.status } }))}
                    >
                      <option value="viewer">viewer</option>
                      <option value="analyst">analyst</option>
                      <option value="manager">manager</option>
                      <option value="admin">admin</option>
                    </select>
                  </div>
                </td>
                <td className="py-3 pr-3">
                  <select
                    className="input py-1 text-xs"
                    value={user.status}
                    onChange={(e) => setDrafts((s) => ({ ...s, [user.id]: { role: user.role, status: e.target.value } }))}
                  >
                    <option value="active">active</option>
                    <option value="inactive">inactive</option>
                  </select>
                </td>
                <td className="py-3">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      className="btn-secondary text-xs"
                      disabled={isPending || !data?.available}
                      onClick={() => saveUser({ id: user.id, payload: { role: user.role, status: user.status } })}
                    >
                      Save
                    </button>
                    <button
                      type="button"
                      className="btn-secondary text-xs"
                      disabled={isDeleting || !data?.available || user.id === currentUser?.id}
                      onClick={() => setConfirmDeactivateId(user.id)}
                    >
                      Deactivate
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="flex items-center justify-between mt-4 text-xs text-gray-600">
          <span>Showing {(page - 1) * pageSize + 1}-{Math.min(page * pageSize, mergedUsers.length)} of {mergedUsers.length}</span>
          <div className="flex items-center gap-2">
            <button className="btn-secondary text-xs" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Prev</button>
            <span>Page {page}/{totalPages}</span>
            <button className="btn-secondary text-xs" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>Next</button>
          </div>
        </div>
      </div>

      <ConfirmDialog
        open={Boolean(confirmDeactivateId)}
        title="Deactivate user?"
        description="This will mark the user as inactive and revoke access until reactivated."
        confirmLabel="Deactivate"
        onCancel={() => setConfirmDeactivateId(null)}
        onConfirm={() => {
          if (confirmDeactivateId) removeUser(confirmDeactivateId)
          setConfirmDeactivateId(null)
        }}
      />

      <LoadingOverlay show={isPending || isCreating || isDeleting} label="Applying user administration changes..." />
    </div>
  )
}
