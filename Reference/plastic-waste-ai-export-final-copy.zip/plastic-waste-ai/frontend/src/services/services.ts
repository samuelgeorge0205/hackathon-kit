import api from './apiClient'
import {
  ApiEnvelope,
  AITrace,
  AITraceDetail,
  ChatResponse,
  DashboardSummary,
  DashboardTrends,
  EvalRunSummary,
  GoldenQuery,
  HealthCheckResponse,
  LoginResponse,
  ObservabilitySummary,
  PredictionCreateResponse,
  PredictionResult,
  RecommendationItem,
  ReportData,
  ReportGenerateResponse,
  UploadStartResponse,
  UploadStatusResponse,
  UserInfo,
} from '../types/api'

export const authService = {
  login: async (email: string, password: string) => {
    const { data } = await api.post<ApiEnvelope<LoginResponse>>('/auth/login', { email, password })
    return data.data
  },
  logout: async (refreshToken: string) => {
    await api.post('/auth/logout', { refresh_token: refreshToken })
  },
}

export const dashboardService = {
  getSummary: async (period = 'last_30_days') => {
    const { data } = await api.get<ApiEnvelope<DashboardSummary>>('/dashboard/summary', { params: { period } })
    return data.data
  },
  getTrends: async (granularity = 'week') => {
    const { data } = await api.get<ApiEnvelope<DashboardTrends>>('/dashboard/trends', { params: { granularity } })
    return data.data
  },
}

export const predictionService = {
  create: async (params: Record<string, unknown>): Promise<PredictionCreateResponse> => {
    const { data } = await api.post<ApiEnvelope<PredictionCreateResponse>>('/predictions/waste', params)
    return data.data
  },
  get: async (id: string): Promise<PredictionResult> => {
    const { data } = await api.get<ApiEnvelope<PredictionResult>>(`/predictions/waste/${id}`)
    return data.data
  },
}

export const recommendationService = {
  list: async (status?: string): Promise<RecommendationItem[]> => {
    const { data } = await api.get<ApiEnvelope<RecommendationItem[]>>('/recommendations', { params: status ? { status } : {} })
    return data.data
  },
  updateStatus: async (id: string, status: string, reason?: string) => {
    const { data } = await api.post<ApiEnvelope<{ id: string; status: string }>>(`/recommendations/${id}/feedback`, { status, reason })
    return data.data
  },
}

export const uploadService = {
  products: async (file: File): Promise<UploadStartResponse> => {
    const fd = new FormData(); fd.append('file', file)
    const { data } = await api.post<ApiEnvelope<UploadStartResponse>>('/upload/products', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
    return data.data
  },
  packaging: async (file: File): Promise<UploadStartResponse> => {
    const fd = new FormData(); fd.append('file', file)
    const { data } = await api.post<ApiEnvelope<UploadStartResponse>>('/upload/packaging', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
    return data.data
  },
  wasteLogs: async (file: File): Promise<UploadStartResponse> => {
    const fd = new FormData(); fd.append('file', file)
    const { data } = await api.post<ApiEnvelope<UploadStartResponse>>('/upload/waste-logs', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
    return data.data
  },
  getStatus: async (uploadId: string): Promise<UploadStatusResponse> => {
    const { data } = await api.get<ApiEnvelope<UploadStatusResponse>>(`/upload/${uploadId}/status`)
    return data.data
  },
}

export const chatService = {
  send: async (message: string, sessionId?: string, context?: Record<string, unknown>): Promise<ChatResponse> => {
    const { data } = await api.post<ApiEnvelope<ChatResponse>>('/chat', { message, session_id: sessionId, context })
    return data.data
  },
}

export const reportService = {
  generate: async (params: Record<string, unknown>): Promise<ReportGenerateResponse> => {
    const { data } = await api.post<ApiEnvelope<ReportGenerateResponse>>('/reports/generate', params)
    return data.data
  },
  get: async (id: string): Promise<ReportData> => {
    const { data } = await api.get<ApiEnvelope<ReportData>>(`/reports/${id}`)
    return data.data
  },
  download: async (id: string): Promise<Blob> => {
    const { data } = await api.get(`/reports/${id}/download`, { responseType: 'blob' })
    return data as Blob
  },
}

export const feedbackService = {
  submit: async (entityType: string, entityId: string, rating: number, comment?: string) => {
    const { data } = await api.post<ApiEnvelope<{ feedback_id: string; recorded: boolean }>>('/feedback', { entity_type: entityType, entity_id: entityId, rating, comment })
    return data.data
  },
}

export interface OptionalEndpointResult<T> {
  available: boolean
  data: T
}

export interface AdminUser {
  id: string
  full_name: string
  email: string
  role: string
  status: string
}

export interface PromptAsset {
  name: string
  version: string
  owner: string
  status: string
  content_preview?: string
}

export interface UpdateUserPayload {
  role?: string
  status?: string
}

export interface UpdatePromptPayload {
  version?: string
  owner?: string
  status?: string
}

export interface CreateUserPayload {
  email: string
  full_name: string
  role: string
  department?: string
  password?: string
}

export interface AuditRecord {
  id: string
  action: string
  actor: string
  target: string
  created_at: string
  before_json?: string | null
  after_json?: string | null
}

export interface KnowledgeAsset {
  title: string
  category: string
  note: string
}

async function optionalGet<T>(
  url: string,
  fallback: T,
  params?: Record<string, unknown>
): Promise<OptionalEndpointResult<T>> {
  try {
    const { data } = await api.get<ApiEnvelope<T>>(url, { params })
    return { available: true, data: data.data }
  } catch {
    return { available: false, data: fallback }
  }
}

export const adminService = {
  listUsers: async () => optionalGet<AdminUser[]>('/admin/users', []),
  listPrompts: async () => optionalGet<PromptAsset[]>('/admin/prompt-library', []),
  listAudit: async (params?: { entity_type?: string; entity_id?: string; limit?: number }) => {
    try {
      const { data } = await api.get<ApiEnvelope<AuditRecord[]>>('/admin/audit', { params })
      return { available: true, data: data.data }
    } catch {
      return { available: false, data: [] as AuditRecord[] }
    }
  },
  listKnowledgeAssets: async () => optionalGet<KnowledgeAsset[]>('/admin/knowledge-center', []),
  createUser: async (payload: CreateUserPayload) => {
    const { data } = await api.post<ApiEnvelope<AdminUser>>('/admin/users', payload)
    return data.data
  },
  updateUser: async (id: string, payload: UpdateUserPayload) => {
    const { data } = await api.patch<ApiEnvelope<AdminUser>>(`/admin/users/${id}`, payload)
    return data.data
  },
  deleteUser: async (id: string) => {
    const { data } = await api.delete<ApiEnvelope<{ id: string; status: string }>>(`/admin/users/${id}`)
    return data.data
  },
  updatePrompt: async (name: string, payload: UpdatePromptPayload) => {
    const { data } = await api.patch<ApiEnvelope<PromptAsset>>(`/admin/prompt-library/${name}`, payload)
    return data.data
  },
}

export const observabilityService = {
  getSummary: async (sinceHours = 24) => optionalGet<ObservabilitySummary | null>(
    '/observability/summary', null, { since_hours: sinceHours }
  ),
  getTraces: async (params?: { agent?: string; status?: string; limit?: number }) =>
    optionalGet<AITrace[]>('/observability/traces', [], params),
  getTraceDetail: async (traceId: string) => optionalGet<AITraceDetail | null>(`/observability/traces/${traceId}`, null),
  getHealth: async () => optionalGet<HealthCheckResponse | null>('/health', null),
}

export const evaluationService = {
  getGoldenSet: async () => optionalGet<GoldenQuery[]>('/evaluation/golden-set', []),
  getRuns: async (limit = 20) => optionalGet<EvalRunSummary[]>('/evaluation/runs', [], { limit }),
  getRunDetail: async (runId: string) => optionalGet<EvalRunSummary | null>(`/evaluation/runs/${runId}`, null),
  run: async (): Promise<EvalRunSummary> => {
    const { data } = await api.post<ApiEnvelope<EvalRunSummary>>('/evaluation/run')
    return data.data
  },
}
