import { API_BASE_URL } from './apiClient'
import { useAuthStore } from '../store/authStore'

export interface StreamOptions {
  method?: 'GET' | 'POST'
  body?: unknown
}

/**
 * Server-Sent Events over fetch()'s streaming body — used instead of the
 * native EventSource because EventSource only supports GET with no custom
 * headers, and this API needs POST (for /chat/stream) plus a Bearer auth
 * header on every request.
 *
 * Generic and endpoint-agnostic: pass any `path` under API_BASE_URL that
 * returns `text/event-stream` frames (`data: {...}\n\n`), and each parsed
 * JSON payload is handed to `onEvent`. Reusable for any future streaming
 * endpoint, not just chat/predictions.
 */
export async function streamSSE(
  path: string,
  options: StreamOptions,
  onEvent: (data: any) => void,
  signal?: AbortSignal
): Promise<void> {
  const token = useAuthStore.getState().accessToken
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: options.method ?? 'GET',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
    signal,
  })

  if (!response.ok) {
    let detail = `Stream request failed (${response.status})`
    try {
      const errJson = await response.json()
      detail = errJson?.detail ?? detail
    } catch {
      /* ignore — use default detail */
    }
    throw new Error(detail)
  }
  if (!response.body) {
    throw new Error('Streaming not supported: response has no body')
  }

  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''

  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })

    const frames = buffer.split('\n\n')
    buffer = frames.pop() ?? ''
    for (const frame of frames) {
      const line = frame.trim()
      if (!line.startsWith('data:')) continue
      const raw = line.slice(5).trim()
      if (!raw) continue
      try {
        onEvent(JSON.parse(raw))
      } catch {
        // malformed frame — skip rather than crash the stream
      }
    }
  }
}
