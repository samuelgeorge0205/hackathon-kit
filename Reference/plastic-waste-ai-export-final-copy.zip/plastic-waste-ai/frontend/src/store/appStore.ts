import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface AppNotification {
  id: string
  title: string
  description: string
  severity: 'info' | 'warning' | 'success'
  createdAt: string
  read: boolean
}

export interface AuditEvent {
  id: string
  action: string
  actor: string
  target: string
  createdAt: string
}

export interface AppToast {
  id: string
  message: string
  severity: 'info' | 'warning' | 'success' | 'error'
}

interface AppState {
  notifications: AppNotification[]
  auditEvents: AuditEvent[]
  toasts: AppToast[]
  addNotification: (notification: Omit<AppNotification, 'id' | 'createdAt' | 'read'>) => void
  markNotificationRead: (id: string) => void
  addAuditEvent: (event: Omit<AuditEvent, 'id' | 'createdAt'>) => void
  addToast: (toast: Omit<AppToast, 'id'>) => void
  removeToast: (id: string) => void
}

const uid = () => Math.random().toString(36).slice(2, 10)

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      notifications: [
        {
          id: uid(),
          title: 'Report generation complete',
          description: 'GRI 306 summary report is ready for download.',
          severity: 'success',
          createdAt: new Date().toISOString(),
          read: false,
        },
        {
          id: uid(),
          title: 'Recommendation review pending',
          description: '7 recommendations need manager approval.',
          severity: 'warning',
          createdAt: new Date().toISOString(),
          read: false,
        },
      ],
      auditEvents: [],
      toasts: [],
      addNotification: (notification) => set((state) => ({
        notifications: [
          {
            ...notification,
            id: uid(),
            createdAt: new Date().toISOString(),
            read: false,
          },
          ...state.notifications,
        ],
      })),
      markNotificationRead: (id) => set((state) => ({
        notifications: state.notifications.map((n) => n.id === id ? { ...n, read: true } : n),
      })),
      addAuditEvent: (event) => set((state) => ({
        auditEvents: [
          {
            ...event,
            id: uid(),
            createdAt: new Date().toISOString(),
          },
          ...state.auditEvents,
        ].slice(0, 100),
      })),
      addToast: (toast) => set((state) => ({
        toasts: [...state.toasts, { ...toast, id: uid() }],
      })),
      removeToast: (id) => set((state) => ({
        toasts: state.toasts.filter((t) => t.id !== id),
      })),
    }),
    { name: 'app-state' }
  )
)
