export interface ApiEnvelope<T> {
  data: T
}

export interface UserInfo {
  id: string
  email: string
  full_name: string
  role: string
}

export interface LoginResponse {
  access_token: string
  refresh_token: string
  token_type?: string
  expires_in?: number
  user: UserInfo
}

export interface DashboardSummary {
  total_waste_kg: number
  total_handling_cost: number
  waste_change_pct?: number | null
  cost_change_pct?: number | null
  active_recommendations: number
  recommendations_value: number
  recycling_rate_pct: number
  waste_by_plastic_type: Record<string, number>
  prediction_accuracy_pct?: number | null
  prediction_feedback_count?: number
  period: string
}

export interface DashboardTrendPoint {
  date: string
  total_waste_kg: number
  breakdown: Record<string, number>
}

export interface DashboardTrends {
  series: DashboardTrendPoint[]
  granularity: string
}

export interface PredictionCreateResponse {
  prediction_id: string
  status: string
  estimated_seconds?: number
}

export interface PredictionResult {
  prediction_id: string
  status: string
  predicted_waste_kg?: number
  plastic_type_breakdown?: Record<string, number>
  prediction_interval?: { low: number; high: number }
  confidence_score: number
  explanation?: string
  key_factors?: string[]
  handling_cost?: number
  recommendations?: LiveRecommendation[]
  sources?: unknown[]
  error?: string
}

/** Fresh output of the recommendation agent for a single prediction run —
 * not yet a persisted `recommendations` table row (no id/status/product_id),
 * unlike RecommendationItem below which is what GET /recommendations returns. */
export interface LiveRecommendation {
  recommendation_type: string
  description: string
  rationale?: string
  estimated_waste_reduction_kg?: number
  estimated_cost_saving?: number
  confidence_score: number
  implementation_effort?: string
  groundedness_score?: number
  sources?: Array<{ title?: string; section?: string }>
}

export interface RecommendationItem {
  id: string
  product_id: string
  product_name: string
  recommendation_type: string
  description: string
  rationale?: string
  estimated_waste_reduction_kg?: number
  estimated_cost_saving?: number
  confidence_score: number
  status: string
  implementation_effort?: string
}

export interface UploadStartResponse {
  upload_id: string
  status: string
  filename: string
}

export interface UploadStatusResponse {
  upload_id: string
  status: string
  filename?: string
  rows_processed?: number
  rows_created?: number
  rows_failed?: number
  errors?: Array<{ row: number; message: string }>
  error?: string
}

export interface ChatCitation {
  index: number
  title: string
  relevance: number
  doc_id?: string
  section?: string
  source_category?: string
}

export interface ChatTokenUsage {
  prompt_tokens?: number
  completion_tokens?: number
}

export interface ChatAttachment {
  name: string
  type: string
  size: number
  last_modified?: number
}

export interface ChatMultimodalMemory {
  attachments: ChatAttachment[]
  image_descriptions: string[]
  source: string
}

export interface ChatResponse {
  session_id: string
  message_id: string
  response: string
  citations: ChatCitation[]
  suggested_follow_ups: string[]
  confidence_score: number
  groundedness_score?: number
  confidence_tier?: 'HIGH' | 'MEDIUM' | 'LOW' | 'VERY_LOW'
  model?: string
  prompt_version?: string
  token_usage?: ChatTokenUsage
  cache_hit?: boolean
  multimodal_memory?: ChatMultimodalMemory
}

export interface AgentMetric {
  agent_name: string
  calls: number
  errors: number
  avg_latency_ms: number
  total_cost_usd: number
  total_tokens: number
}

export interface LangfuseStatus {
  configured: boolean
  enabled: boolean
  initialized: boolean
  host: string
  last_error?: string | null
}

export interface ObservabilitySummary {
  since_hours: number
  agents: AgentMetric[]
  total_calls: number
  total_errors: number
  total_cost_usd: number
  total_tokens: number
  latency_ms: { p50: number; p95: number }
  guardrail_triggers: Record<string, number>
  langfuse: LangfuseStatus
}

export interface AITrace {
  id: string
  agent_name: string
  workflow_id?: string | null
  correlation_id?: string | null
  latency_ms?: number | null
  model?: string | null
  input_tokens?: number | null
  output_tokens?: number | null
  cost_usd?: number | null
  status: string
  confidence_score?: number | null
  error_message?: string | null
  created_at: string
}

export interface AITraceDetail extends AITrace {
  started_at?: string
  ended_at?: string
  input_summary?: unknown
  output_summary?: unknown
}

export interface HealthCheckResponse {
  status: string
  version: string
  checks: Record<string, unknown>
}

export interface GoldenQuery {
  id: string
  query: string
  expected_doc_id: string | null
  expect_refusal?: boolean
}

export interface EvalRunResult {
  id: string
  query: string
  expected_doc_id: string | null
  retrieved_doc_ids: string[]
  precision_hit: boolean
  groundedness: number
  latency_ms: number
}

export interface EvalRunSummary {
  id: string
  started_at?: string
  finished_at?: string
  n_queries: number
  avg_retrieval_precision: number
  avg_groundedness: number
  avg_latency_ms: number
  pass_rate: number
  triggered_by?: string | null
  created_at?: string
  results?: EvalRunResult[]
}

export interface ReportGenerateResponse {
  report_id: string
  status: string
  estimated_seconds?: number
}

export interface ReportData {
  report_id: string
  status: string
  title?: string
  executive_summary?: string
  key_metrics?: {
    total_waste_kg: number
    period_over_period_change_pct?: number | null
    recycling_rate_pct: number
  }
  waste_by_type?: Record<string, number>
  sections?: Array<Record<string, unknown>>
  error?: string
}
