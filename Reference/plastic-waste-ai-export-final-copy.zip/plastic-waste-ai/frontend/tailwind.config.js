/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: { 50: '#e5f6f1', 500: '#0f766e', 600: '#0b5f59', 700: '#0a4f4b' },
        success: { 100: '#ddf7e7', 600: '#0f8f4b' },
        warning: { 100: '#fff4d5', 600: '#a16a00' },
        danger:  { 100: '#ffe1dd', 600: '#c1342f' },
      },
    },
  },
  plugins: [],
}
