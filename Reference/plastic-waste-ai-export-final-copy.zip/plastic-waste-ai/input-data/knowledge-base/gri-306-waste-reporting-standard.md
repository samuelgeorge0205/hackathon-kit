# GRI 306: Waste — Reporting Standard Overview

GRI 306 is the Global Reporting Initiative's standard for disclosing an
organisation's waste-related impacts. It is the most widely used voluntary
framework for corporate sustainability waste reporting, including plastic
packaging waste.

## Key disclosures required
- **306-1**: Waste generation and significant waste-related impacts.
- **306-2**: Management of significant waste-related impacts (how waste is
  minimised, and how materials are diverted from disposal).
- **306-3**: Waste generated, broken down by composition (e.g. by polymer
  type for plastics) and by weight.
- **306-4**: Waste diverted from disposal (recycled, reused, or otherwise
  recovered), broken down by recovery operation.
- **306-5**: Waste directed to disposal (landfill, incineration), broken
  down by disposal operation.

## Reporting expectations
- Report waste by weight (kg or tonnes), not by unit count.
- Distinguish between hazardous and non-hazardous waste (plastic packaging
  waste is typically non-hazardous).
- Disclose the methodology used to calculate or estimate waste figures
  (e.g. weighbridge data, supplier-declared packaging weights, sampling).
- Year-over-year comparability requires consistent scope and methodology;
  changes in scope should be disclosed and, where feasible, restated.
- Acknowledge data gaps and estimation methods explicitly rather than
  presenting estimated figures as verified actuals.

## Common pitfalls in plastic waste reporting
- Reporting unit counts instead of weight, which understates the impact of
  heavier packaging formats.
- Omitting upstream (supplier/manufacturing) waste and reporting only
  retail/store-level waste.
- Failing to disclose recycling *rate* alongside absolute waste figures,
  which can mask an increase in both waste and recycling simultaneously.
