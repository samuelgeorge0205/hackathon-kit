# Packaging Weight Reduction Best Practices

Weight reduction ("lightweighting") is typically the fastest and
lowest-effort category of packaging waste recommendation, since it usually
requires no change of material or supplier — only a redesign of the
existing format.

## Common lightweighting techniques
- **Tray optimisation**: reducing wall thickness in rigid trays (e.g.
  chilled ready-meal trays, meat/fish trays) via improved mould design,
  typically achieving 15–40% weight reduction with no loss of structural
  integrity.
- **Film downgauging**: reducing the thickness of flexible flow-wrap and
  shrink film, typically achieving 10–20% weight reduction.
- **Cap and closure lightweighting**: reducing bottle cap weight, a
  well-established technique across the bottled-goods industry.
- **Removing unnecessary layers**: multi-layer laminates are sometimes
  over-specified for barrier properties the product does not need;
  reducing layer count reduces both weight and recyclability complexity.

## Implementation effort guide
- **LOW effort**: drop-in replacement using the same supplier and
  production line, no re-certification needed (e.g. minor film downgauge).
- **MEDIUM effort**: requires supplier negotiation or a new mould/tooling
  investment, but no product reformulation (e.g. tray redesign).
- **HIGH effort**: requires product redesign, new packaging line
  qualification, or shelf-life re-validation (e.g. moving to a
  fundamentally different pack format).

## Interaction with recyclability
Weight reduction and recyclability improvements are complementary but
distinct levers: a lighter PVC tray is still non-recyclable, so weight
reduction recommendations should not be treated as a substitute for
material-change recommendations where the underlying polymer is
problematic (PVC, PS, mixed laminates).
