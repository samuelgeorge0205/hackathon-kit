# Plastic Polymer Recyclability Guide (UK Retail Context)

## PET (Polyethylene Terephthalate)
Widely accepted in UK kerbside collection. Used for trays, bottles, and clear
film. Recycled PET (rPET) is readily available as a substitute for virgin
PET and is the most common lightweighting target for ready-meal and produce
trays. Typical collection rate in UK retail supply chains: high.

## HDPE (High-Density Polyethylene)
Widely accepted in UK kerbside collection. Common in milk bottles and
detergent containers. Recycles well into new bottles (bottle-to-bottle) and
non-food containers. Considered one of the easiest polymers to recycle at
scale.

## PVC (Polyvinyl Chloride)
NOT accepted in UK kerbside collection. Contaminates PET recycling streams
if mixed in. Common legacy use: cling film and some blister packs. Retailers
are actively phasing out PVC in favour of PP or PE alternatives due to its
poor recyclability and contamination risk.

## LDPE (Low-Density Polyethylene)
Accepted at select kerbside schemes and widely at supermarket front-of-store
collection points (carrier bags, bread bags, film). Not universally
recyclable via kerbside; retailer take-back schemes are the primary route.

## PP (Polypropylene)
Increasingly accepted in UK kerbside collection as sorting infrastructure
improves. Used for yoghurt pots, ready-meal trays, and flexible flow-wrap.
A common substitute material when phasing out PVC or PS.

## PS (Polystyrene, including EPS foam)
NOT widely accepted in UK kerbside collection. Foam trays (meat, fish) are
difficult to recycle economically due to low density and contamination.
Retailers are moving toward PET or PP trays as a replacement.

## MIXED / Multi-material laminates
Generally NOT recyclable through standard streams. Common in crisp packets
and pouches (foil/plastic laminate). The only durable fix is redesigning to
a mono-material structure.

## Summary recyclability ranking (best to worst, UK kerbside)
1. HDPE
2. PET
3. PP
4. LDPE (via take-back schemes)
5. PVC (not recyclable — phase out)
6. PS (not recyclable — phase out)
7. MIXED laminates (not recyclable — redesign required)
