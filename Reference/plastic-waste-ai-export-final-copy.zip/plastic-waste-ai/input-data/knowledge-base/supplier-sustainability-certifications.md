# Supplier Sustainability Certification Standards

A reference guide to the packaging-relevant certifications used to assess
supplier sustainability performance in this supply chain.

## ISO 14001
An internationally recognised environmental management system standard.
Indicates a supplier has a structured process for identifying and reducing
environmental impact, but does not certify any specific recycled-content
or recyclability outcome on its own.

## WRAP Plastics Pact
Indicates the supplier is a signatory to the UK Plastics Pact and reports
progress against its targets (100% reusable/recyclable/compostable
packaging, 70% effective recycling rate, 30% average recycled content).
Suppliers with this mark are aligned with the retailer's own EPR and GRI
306 reporting obligations.

## Cradle to Cradle
A product-level certification assessing material health, recyclability,
renewable energy use, water stewardship, and social fairness. Considered a
stronger and more rigorous signal than ISO 14001 for packaging-specific
sustainability claims.

## FSC (Forest Stewardship Council)
Applies to fibre-based packaging components (e.g. cardboard secondary
packaging, paper labels), not directly to plastic polymers. Relevant when
assessing mixed-material packaging systems.

## EU Ecolabel
A broader product-level environmental certification; when held by a
packaging supplier it typically indicates above-average performance across
material sourcing, recyclability, and production impact.

## SEDEX
Primarily a social/ethical compliance audit platform (labour standards,
health and safety) rather than an environmental certification. Relevant for
overall supplier risk assessment but not a direct signal of packaging
sustainability performance.

## Interpreting tier and certification together
Tier-1 suppliers with multiple strong certifications (WRAP Plastics Pact,
Cradle to Cradle, ISO 14001) represent the lowest-risk, most
collaboration-ready partners for packaging redesign initiatives. Tier-3
suppliers with no certifications represent higher execution risk for
material-change recommendations and may need a supplier development
conversation before a redesign can proceed.
