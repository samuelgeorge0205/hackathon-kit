# UK Extended Producer Responsibility (EPR) for Packaging — Summary

The UK's Extended Producer Responsibility (EPR) scheme for packaging shifts
the cost of managing packaging waste from local authorities/taxpayers onto
the businesses that place packaging on the market.

## Who is in scope
Businesses with turnover above the regulatory threshold that supply or
import packaging (or packaged goods) into the UK market — this includes
retailers, brand owners, and importers, not only manufacturers.

## Core obligations
- **Data reporting**: businesses must report the amount and type of
  packaging they place on the market, split by material (including plastic
  polymer type where applicable) and by packaging category (primary,
  secondary, tertiary, transit).
- **EPR fees**: fees are calculated based on reported packaging tonnage and
  are intended to cover the full net cost of collecting, sorting, and
  recycling that packaging.
- **Modulated fees**: fee rates vary by recyclability — packaging that is
  harder to recycle (e.g. PVC, PS foam, multi-material laminates) attracts
  a higher fee than readily recyclable formats (e.g. HDPE, PET, PP),
  creating a financial incentive to redesign packaging toward recyclable
  materials.

## Relationship to recyclability labelling
Packaging is expected to carry "Recycle" or "Do Not Recycle" labelling
based on whether the packaging is collected for recycling by at least 75%
of UK local authorities. This directly maps to the same polymer
recyclability distinctions used in GRI 306 waste-composition reporting.

## Practical implication for packaging decisions
Because EPR fees are modulated by recyclability, packaging changes that
improve recyclability (e.g. replacing PVC or PS with PET, HDPE, or PP) can
simultaneously reduce EPR fee exposure, reduce landfill/incineration
disposal costs, and improve GRI 306 waste-diversion metrics.
