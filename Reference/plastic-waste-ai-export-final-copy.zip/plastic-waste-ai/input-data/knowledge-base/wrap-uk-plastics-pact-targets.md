# WRAP UK Plastics Pact — Target Overview

The UK Plastics Pact is a voluntary industry commitment, coordinated by
WRAP, bringing together retailers, brand owners, and packaging suppliers
around shared plastic packaging targets.

## Headline targets
1. **100% of plastic packaging to be reusable, recyclable, or compostable.**
2. **70% of plastic packaging effectively recycled or composted.**
3. **30% average recycled content across all plastic packaging.**
4. **Eliminate problematic or unnecessary single-use packaging** through
   redesign or elimination — this specifically targets PVC, PS foam, and
   non-recyclable multi-material laminates.

## Relevance to packaging recommendations
- Material-change recommendations that move away from PVC/PS/laminates
  toward PET, HDPE, or PP directly support target 1 and target 4.
- Recommendations that introduce recycled content (e.g. rPET trays instead
  of virgin PET trays) directly support target 3.
- Weight-reduction recommendations do not directly map to a Plastics Pact
  target but support the broader "reduce before recycle" waste hierarchy
  principle referenced throughout Pact guidance.

## Suppliers and certification signals
Suppliers holding certifications such as the "WRAP Plastics Pact" mark,
ISO 14001 (environmental management), or Cradle to Cradle indicate
independently verified commitment to these targets, and are generally
preferred partners for packaging redesign initiatives aimed at reducing
plastic waste.
