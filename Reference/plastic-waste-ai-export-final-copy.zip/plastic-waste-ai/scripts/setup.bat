@echo off
REM ============================================================
REM  Plastic Waste AI — one-shot setup (Windows)
REM  Usage:
REM    scripts\setup.bat            setup only
REM    scripts\setup.bat run        setup, then start backend on :8000
REM    scripts\setup.bat frontend   setup, then npm install in frontend/
REM  This just calls scripts\setup.ps1 with the right execution policy —
REM  see that file for the actual setup logic.
REM ============================================================

set SCRIPT_DIR=%~dp0
set ARGS=

IF /I "%1"=="run" set ARGS=-Run
IF /I "%1"=="frontend" set ARGS=-Frontend

powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%setup.ps1" %ARGS%
