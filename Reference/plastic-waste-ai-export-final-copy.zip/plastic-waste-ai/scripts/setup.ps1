# ============================================================
#  Plastic Waste AI — one-shot setup (Windows PowerShell)
#  Usage:
#    powershell -ExecutionPolicy Bypass -File scripts/setup.ps1
#    powershell -ExecutionPolicy Bypass -File scripts/setup.ps1 -Frontend   # also npm install
#    powershell -ExecutionPolicy Bypass -File scripts/setup.ps1 -Run        # setup + start backend
#  OR just run:  scripts/setup.bat  (calls this with the right execution policy)
# ============================================================
param(
    [switch]$Run,
    [switch]$Frontend
)

$ErrorActionPreference = "Stop"
$ROOT = Split-Path $PSScriptRoot -Parent
$BACKEND = Join-Path $ROOT "backend"
$FRONTEND = Join-Path $ROOT "frontend"

Write-Host "`n[1/6] Python version check..." -ForegroundColor Cyan
$pyver = & python --version 2>&1
if ($pyver -notmatch "3\.12") {
    Write-Host "WARNING: Expected Python 3.12. Found: $pyver" -ForegroundColor Yellow
}

Write-Host "`n[2/6] Ensuring uv is installed..." -ForegroundColor Cyan
try { uv --version | Out-Null }
catch {
    Write-Host "Installing uv..." -ForegroundColor Yellow
    & pip install uv --trusted-host pypi.org --trusted-host files.pythonhosted.org --quiet
}
Write-Host "uv: $(uv --version)"

Set-Location $BACKEND

Write-Host "`n[3/6] Syncing backend dependencies with uv..." -ForegroundColor Cyan
# --native-tls uses the OS certificate store — needed behind corporate SSL-inspecting proxies
& uv sync --native-tls 2>&1 | Tee-Object -Variable uvOutput
if ($LASTEXITCODE -ne 0) {
    Write-Host "uv sync failed — trying pip fallback..." -ForegroundColor Yellow
    & uv run python -m pip install -e ".[dev]" `
        --trusted-host pypi.org `
        --trusted-host files.pythonhosted.org `
        --quiet
}

Write-Host "`n[4/6] Environment file..." -ForegroundColor Cyan
$runtimeEnv = Join-Path $ROOT "config/runtime.env"
$runtimeEnvTemplate = Join-Path $ROOT "config/runtime.env.example"
if (-not (Test-Path $runtimeEnv)) {
    Copy-Item $runtimeEnvTemplate $runtimeEnv
    Write-Host "config/runtime.env created from template." -ForegroundColor Yellow
    Write-Host "  Default LLM_MODE=local expects Ollama running locally with:" -ForegroundColor Yellow
    Write-Host "    ollama pull llama3.2" -ForegroundColor White
    Write-Host "    ollama pull nomic-embed-text" -ForegroundColor White
    Write-Host "  To use a hosted gateway instead, set LLM_MODE=hackathon and fill in" -ForegroundColor Yellow
    Write-Host "  HACKATHON_LLM_API_KEY in config/runtime.env." -ForegroundColor Yellow
} else {
    Write-Host "config/runtime.env already exists — leaving as-is." -ForegroundColor Green
}

$frontendEnv = Join-Path $FRONTEND ".env"
$frontendEnvTemplate = Join-Path $FRONTEND ".env.example"
if ((Test-Path $frontendEnvTemplate) -and (-not (Test-Path $frontendEnv))) {
    Copy-Item $frontendEnvTemplate $frontendEnv
    Write-Host "frontend/.env created from template." -ForegroundColor Yellow
}

Write-Host "`n[5/6] Database setup + seed..." -ForegroundColor Cyan
& uv run python -c "import asyncio; from data.databases import create_tables; asyncio.run(create_tables())"
& uv run python data/seed_db.py

Write-Host "`n[6/6] Redis check..." -ForegroundColor Cyan
$redisUp = $false
try {
    $tcp = New-Object System.Net.Sockets.TcpClient
    $tcp.Connect("127.0.0.1", 6379)
    $redisUp = $tcp.Connected
    $tcp.Close()
} catch { $redisUp = $false }
if ($redisUp) {
    Write-Host "Redis detected on localhost:6379 — caching/rate-limiting will use it." -ForegroundColor Green
} else {
    Write-Host "No Redis on localhost:6379 — the app will automatically fall back to an" -ForegroundColor Yellow
    Write-Host "in-process fakeredis (no server needed, same zero-setup experience as" -ForegroundColor Yellow
    Write-Host "SQLite/Chroma). To use real Redis instead, run:" -ForegroundColor Yellow
    Write-Host "  docker run -d --name plastic-waste-redis -p 6379:6379 --restart unless-stopped redis:7-alpine" -ForegroundColor White
}

if ($Frontend) {
    Write-Host "`nInstalling frontend dependencies..." -ForegroundColor Cyan
    Set-Location $FRONTEND
    & npm install
}

Write-Host "`n============================================================" -ForegroundColor Green
Write-Host " Setup complete!" -ForegroundColor Green
Write-Host " Backend:   cd backend && uv run uvicorn main:app --reload --port 8000" -ForegroundColor White
Write-Host " Frontend:  cd frontend && npm install && npm run dev" -ForegroundColor White
Write-Host " Then open: http://localhost:5173  (login: analyst@demo.com / Demo1234!)" -ForegroundColor White
Write-Host " Full guide: docs/LOCAL_SETUP.md" -ForegroundColor White
Write-Host "============================================================`n" -ForegroundColor Green

if ($Run) {
    Write-Host "Starting backend..." -ForegroundColor Cyan
    Set-Location $BACKEND
    & uv run uvicorn main:app --reload --host 0.0.0.0 --port 8000
}
