# Architecture Specification

## Purpose

Define the complete 8-layer architecture. Every layer specifies: purpose, responsibilities, allowed dependencies, forbidden dependencies, folder structure, naming conventions and examples. This is the master architectural reference for all implementation milestones.

---

## Architecture Principle

> Dependencies flow **inward only**. Outer layers may depend on inner layers. Inner layers must **never** depend on outer layers. The Domain Layer has **zero external dependencies**.

```
┌─────────────────────────────────────────────┐
│         Frontend  (React + TypeScript)       │  Layer 1
├─────────────────────────────────────────────┤
│         API Layer  (FastAPI)                 │  Layer 2
├─────────────────────────────────────────────┤
│         Application Layer                   │  Layer 3
│         (Use Cases · Services · DTOs)        │
├─────────────────────────────────────────────┤
│         Domain Layer                        │  Layer 4  ← Core
│         (Entities · Value Objects · Events) │
├─────────────────────────────────────────────┤
│         AI Layer                            │  Layer 5
│         (LangGraph Agents · RAG Pipeline)   │
├─────────────────────────────────────────────┤
│         Data Layer                          │  Layer 6
│         (Repositories · SQLite · ChromaDB)  │
├─────────────────────────────────────────────┤
│         Infrastructure Layer               │  Layer 7
│         (Redis · File I/O · External APIs)  │
├─────────────────────────────────────────────┤
│         Observability                       │  Layer 8
│         (Langfuse · Logging · Metrics · Audit) │
└─────────────────────────────────────────────┘
```

---

## Layer 1 — Frontend

### Purpose
Provide the user interface. Consume backend APIs. Render AI outputs in human-readable form.

### Responsibilities
- Display dashboard KPIs, charts and data tables
- Upload CSV/Excel data files with validation feedback
- Present AI predictions, confidence scores and explanations
- Host AI Copilot chat interface
- Generate and download reports
- Manage user settings and configuration

### Allowed Dependencies
- React 18, TypeScript 5, Vite
- Tailwind CSS (styling)
- Zustand (state management)
- React Query (server state + caching)
- Axios (HTTP client)
- Recharts (charts)
- React Hook Form + Zod (form validation)
- Playwright (E2E tests)

### Forbidden Dependencies
- No direct database access
- No direct LLM API calls
- No business logic (belongs in Application layer)
- No hardcoded API keys or secrets

### Folder Structure
```
src/frontend/
├── src/
│   ├── pages/           # One file per route
│   │   ├── Dashboard/
│   │   ├── Upload/
│   │   ├── Predictions/
│   │   ├── Analytics/
│   │   ├── Copilot/
│   │   ├── Reports/
│   │   └── Settings/
│   ├── components/      # Shared UI components
│   │   ├── charts/
│   │   ├── forms/
│   │   ├── layout/
│   │   └── ui/
│   ├── hooks/           # Custom React hooks
│   ├── services/        # API client functions
│   ├── store/           # Zustand state stores
│   ├── types/           # TypeScript type definitions
│   └── utils/           # Pure utility functions
├── tests/
│   ├── e2e/             # Playwright tests
│   └── unit/            # Vitest unit tests
├── public/
├── index.html
├── vite.config.ts
├── tailwind.config.ts
└── tsconfig.json
```

### Naming Conventions
- Pages: `PascalCase` (e.g., `PredictionsPage.tsx`)
- Components: `PascalCase` (e.g., `WasteTrendChart.tsx`)
- Hooks: `use` prefix (e.g., `usePredictions.ts`)
- Services: `camelCase` with `Service` suffix (e.g., `predictionService.ts`)
- Types: `PascalCase` with `T` prefix for types, `I` for interfaces (e.g., `TPrediction`, `IApiResponse`)
- Stores: `camelCase` with `Store` suffix (e.g., `predictionStore.ts`)

### Examples
```typescript
// Service call (services/predictionService.ts)
export const runWastePrediction = async (params: TPredictionRequest): Promise<TPredictionResponse> => {
  const { data } = await apiClient.post('/predictions/waste', params);
  return data;
};

// Hook (hooks/usePredictions.ts)
export const usePredictions = () => {
  return useQuery({ queryKey: ['predictions'], queryFn: predictionService.list });
};
```

---

## Layer 2 — API Layer

### Purpose
Expose the application's capabilities as a versioned REST API. Handle HTTP concerns only. Delegate all business logic to the Application Layer.

### Responsibilities
- Define FastAPI routes grouped by feature domain
- Validate request payloads using Pydantic v2 models
- Enforce authentication (JWT verification)
- Enforce authorisation (role check via dependency injection)
- Return standardised JSON responses
- Document endpoints via OpenAPI (auto-generated)
- Handle HTTP errors with RFC 7807 Problem Details format

### Allowed Dependencies
- FastAPI, Uvicorn
- Pydantic v2 (request/response models)
- python-jose (JWT verification)
- Application Layer services (via DI)
- Observability Layer (logging, tracing)

### Forbidden Dependencies
- No direct database access (must go via Application → Data layer)
- No direct LLM calls
- No business logic
- No domain entity manipulation

### Folder Structure
```
src/backend/
├── api/
│   ├── v1/
│   │   ├── routers/
│   │   │   ├── auth.py
│   │   │   ├── upload.py
│   │   │   ├── predictions.py
│   │   │   ├── recommendations.py
│   │   │   ├── dashboard.py
│   │   │   ├── reports.py
│   │   │   ├── chat.py
│   │   │   ├── feedback.py
│   │   │   └── health.py
│   │   ├── dependencies.py      # DI: get_current_user, require_role
│   │   └── middleware.py        # CORS, request logging, correlation ID
│   └── models/
│       ├── requests/            # Pydantic request schemas
│       └── responses/           # Pydantic response schemas
└── main.py
```

### Naming Conventions
- Routers: `snake_case` module name matching resource (e.g., `predictions.py`)
- Route functions: `verb_noun` (e.g., `create_prediction`, `list_recommendations`)
- Pydantic models: `PascalCase` with suffix `Request`/`Response` (e.g., `PredictionRequest`, `PredictionResponse`)
- Dependencies: `get_` prefix (e.g., `get_current_user`, `get_db_session`)

### Examples
```python
# api/v1/routers/predictions.py
@router.post("/waste", response_model=PredictionResponse, status_code=202)
async def create_waste_prediction(
    payload: PredictionRequest,
    current_user: User = Depends(require_role("analyst")),
    prediction_service: PredictionService = Depends(get_prediction_service),
) -> PredictionResponse:
    result = await prediction_service.run_waste_prediction(payload, current_user.id)
    return PredictionResponse.from_domain(result)
```

### Response Envelope
```json
{
  "data": { ... },
  "meta": { "correlation_id": "uuid", "timestamp": "ISO8601" },
  "error": null
}
```

### Error Response (RFC 7807)
```json
{
  "type": "https://api.plasticwaste.ai/errors/validation-error",
  "title": "Validation Error",
  "status": 422,
  "detail": "packaging_id must reference an existing packaging record",
  "correlation_id": "uuid"
}
```

---

## Layer 3 — Application Layer

### Purpose
Orchestrate use cases. Coordinate domain entities and services to fulfil business operations. This layer is the application's brain — it knows what to do but not how to store or display it.

### Responsibilities
- Implement use case handlers (one class per use case)
- Orchestrate calls to Domain services, AI Layer and Data Layer
- Map between domain objects and API DTOs
- Handle application-level transactions
- Enforce application-level business rules not captured in the domain

### Allowed Dependencies
- Domain Layer (entities, value objects, repository interfaces)
- AI Layer interfaces (not implementations)
- Data Layer interfaces (not implementations)
- Infrastructure Layer interfaces (not implementations)
- Observability Layer (logging, metrics)

### Forbidden Dependencies
- No FastAPI, Starlette or HTTP-specific imports
- No direct SQLite/database imports
- No direct Redis imports
- No frontend code

### Folder Structure
```
src/backend/
└── application/
    ├── use_cases/
    │   ├── upload/
    │   │   ├── ingest_products.py
    │   │   ├── ingest_packaging.py
    │   │   └── ingest_waste_logs.py
    │   ├── predictions/
    │   │   ├── run_waste_prediction.py
    │   │   └── run_cost_estimation.py
    │   ├── recommendations/
    │   │   ├── generate_recommendations.py
    │   │   └── update_recommendation_status.py
    │   ├── reports/
    │   │   └── generate_report.py
    │   └── chat/
    │       └── process_chat_message.py
    ├── services/
    │   ├── prediction_service.py
    │   ├── recommendation_service.py
    │   └── report_service.py
    ├── dtos/
    │   ├── prediction_dto.py
    │   └── recommendation_dto.py
    └── interfaces/
        ├── ai_service_interface.py
        └── notification_interface.py
```

### Naming Conventions
- Use case classes: `VerbNounUseCase` (e.g., `RunWastePredictionUseCase`)
- Services: `NounService` (e.g., `PredictionService`)
- DTOs: `NounDto` (e.g., `PredictionInputDto`, `PredictionOutputDto`)
- Interfaces: `INoun` or `NounInterface` (e.g., `IAIService`, `INotificationService`)

### Examples
```python
# application/use_cases/predictions/run_waste_prediction.py
class RunWastePredictionUseCase:
    def __init__(
        self,
        waste_repo: IWasteLogRepository,
        ai_service: IAIService,
        prediction_repo: IPredictionRepository,
    ) -> None:
        self._waste_repo = waste_repo
        self._ai_service = ai_service
        self._prediction_repo = prediction_repo

    async def execute(self, dto: PredictionInputDto, user_id: str) -> PredictionOutputDto:
        historical_data = await self._waste_repo.get_by_product(dto.product_id)
        result = await self._ai_service.predict_waste(historical_data, dto)
        await self._prediction_repo.save(result.to_entity(user_id))
        return PredictionOutputDto.from_domain(result)
```

---

## Layer 4 — Domain Layer

### Purpose
Represent core business concepts as pure Python objects. Contains all business rules and invariants. Has **zero external dependencies** — it can be tested without a database, API framework or AI library.

### Responsibilities
- Define domain entities (data + behaviour)
- Define value objects (immutable, equality by value)
- Define domain events
- Define repository interfaces (abstract base classes)
- Enforce domain invariants (e.g., waste weight must be > 0)
- Contain domain-specific calculations (e.g., waste intensity calculation)

### Allowed Dependencies
- Python standard library only
- Pydantic BaseModel (for schema/validation, not persistence)

### Forbidden Dependencies
- **Absolutely no**: FastAPI, SQLAlchemy, Redis, LangChain, LangGraph, ChromaDB, boto3, or any third-party library except Pydantic

### Folder Structure
```
src/backend/
└── domain/
    ├── entities/
    │   ├── supplier.py
    │   ├── product.py
    │   ├── packaging.py
    │   ├── purchase_order.py
    │   ├── shipment.py
    │   ├── warehouse.py
    │   ├── store.py
    │   ├── waste_log.py
    │   ├── handling_cost.py
    │   ├── recommendation.py
    │   ├── prediction.py
    │   ├── user.py
    │   └── audit_log.py
    ├── value_objects/
    │   ├── plastic_type.py
    │   ├── disposal_method.py
    │   ├── money.py
    │   ├── confidence_score.py
    │   └── waste_intensity.py
    ├── events/
    │   ├── waste_log_created.py
    │   ├── prediction_completed.py
    │   └── recommendation_generated.py
    └── repositories/
        ├── i_supplier_repository.py
        ├── i_product_repository.py
        ├── i_waste_log_repository.py
        ├── i_prediction_repository.py
        └── i_recommendation_repository.py
```

### Naming Conventions
- Entities: `PascalCase` (e.g., `WasteLog`, `Supplier`)
- Value Objects: `PascalCase` (e.g., `PlasticType`, `Money`)
- Repository Interfaces: `I` prefix (e.g., `IWasteLogRepository`)
- Domain Events: `PascalCase` past tense (e.g., `WasteLogCreated`)
- Factory methods: `create` prefix (e.g., `WasteLog.create(...)`)

### Examples
```python
# domain/entities/waste_log.py
from dataclasses import dataclass, field
from datetime import date
from uuid import UUID, uuid4
from domain.value_objects.plastic_type import PlasticType

@dataclass
class WasteLog:
    id: UUID = field(default_factory=uuid4)
    source_type: str  # WAREHOUSE | STORE | SUPPLIER
    source_id: str
    product_id: UUID
    packaging_id: UUID
    log_date: date
    plastic_type: PlasticType
    weight_kg: float
    disposal_method: str

    def __post_init__(self) -> None:
        if self.weight_kg <= 0:
            raise ValueError("weight_kg must be greater than zero")
        if self.log_date > date.today():
            raise ValueError("log_date cannot be in the future")

    @property
    def waste_intensity(self) -> float:
        return self.weight_kg  # extended by domain service with unit context
```

---

## Layer 5 — AI Layer

### Purpose
Implement AI-powered capabilities: multi-agent LangGraph workflows and the RAG pipeline. This layer translates domain questions into LLM interactions and returns structured, grounded responses.

### Responsibilities
- Implement LangGraph state machines for multi-agent workflows
- Implement the RAG pipeline (ingestion, retrieval, reranking)
- Define system prompts and prompt templates
- Return structured outputs (Pydantic models)
- Manage confidence scoring
- Implement retry and fallback strategies
- Emit Langfuse traces for every LLM call

### Allowed Dependencies
- Domain Layer (entities and value objects for input/output typing)
- LangGraph, LangChain
- ChromaDB (vector store)
- Langfuse (observability)
- Pydantic (structured output)
- Redis (workflow state cache)

### Forbidden Dependencies
- No FastAPI / HTTP concerns
- No SQLAlchemy / database drivers
- No UI or frontend code

### Folder Structure
```
src/backend/
└── ai/
    ├── agents/
    │   ├── planner_agent.py
    │   ├── retriever_agent.py
    │   ├── waste_prediction_agent.py
    │   ├── handling_cost_agent.py
    │   ├── recommendation_agent.py
    │   ├── explanation_agent.py
    │   └── report_generator_agent.py
    ├── workflows/
    │   ├── prediction_workflow.py
    │   ├── recommendation_workflow.py
    │   └── chat_workflow.py
    ├── rag/
    │   ├── ingestion/
    │   │   ├── document_loader.py
    │   │   ├── text_chunker.py
    │   │   └── embedder.py
    │   ├── retrieval/
    │   │   ├── dense_retriever.py
    │   │   ├── sparse_retriever.py
    │   │   └── reranker.py
    │   └── pipeline.py
    ├── prompts/
    │   └── prompt_registry.py      # loads prompts from prompts/ directory
    └── state/
        └── workflow_state.py       # LangGraph TypedDict state schemas
```

### Naming Conventions
- Agent classes: `PascalCaseAgent` (e.g., `WastePredictionAgent`)
- Workflow functions: `snake_case` matching use case (e.g., `run_prediction_workflow`)
- State schemas: `PascalCaseState` (e.g., `PredictionWorkflowState`)
- Prompt functions: `get_noun_prompt` (e.g., `get_waste_prediction_prompt`)

### Examples
```python
# ai/agents/waste_prediction_agent.py
class WastePredictionAgent:
    async def run(self, state: PredictionWorkflowState) -> PredictionWorkflowState:
        prompt = get_waste_prediction_prompt(state.historical_data, state.query)
        with langfuse.trace(name="waste_prediction_agent") as trace:
            response = await llm.ainvoke(prompt)
            result = WastePredictionOutput.model_validate_json(response.content)
        state.prediction = result
        state.confidence = result.confidence_score
        return state
```

---

## Layer 6 — Data Layer

### Purpose
Implement data persistence. Provide concrete implementations of the repository interfaces defined in the Domain Layer.

### Responsibilities
- Implement repository interfaces using SQLite (via aiosqlite)
- Implement ChromaDB repository for vector document storage
- Map between domain entities and database rows
- Manage database connections and connection pooling
- Implement query builders for complex filters
- Run Alembic database migrations

### Allowed Dependencies
- Domain Layer (entities, repository interfaces)
- aiosqlite, SQLAlchemy (ORM)
- ChromaDB (vector store)
- Alembic (migrations)
- Observability Layer (logging)

### Forbidden Dependencies
- No FastAPI or API concerns
- No LangChain or AI libraries (AI layer handles prompts; data layer handles storage)
- No Redis (infrastructure layer concern)

### Folder Structure
```
src/backend/
└── data/
    ├── repositories/
    │   ├── sqlite/
    │   │   ├── supplier_repository.py
    │   │   ├── product_repository.py
    │   │   ├── waste_log_repository.py
    │   │   ├── prediction_repository.py
    │   │   └── recommendation_repository.py
    │   └── chroma/
    │       └── document_repository.py
    ├── models/                    # SQLAlchemy ORM models
    │   ├── supplier_model.py
    │   ├── waste_log_model.py
    │   └── ...
    ├── migrations/
    │   └── versions/
    ├── mappers/                   # ORM model ↔ Domain entity mappers
    │   ├── supplier_mapper.py
    │   └── waste_log_mapper.py
    └── database.py                # Session factory and connection config
```

### Naming Conventions
- Repository implementations: `NounSQLiteRepository` or `NounChromaRepository`
- ORM models: `NounModel` (e.g., `WasteLogModel`)
- Mappers: `NounMapper` (e.g., `WasteLogMapper`)
- Migration files: Alembic auto-naming convention `{timestamp}_{description}.py`

---

## Layer 7 — Infrastructure Layer

### Purpose
Implement technical adapters for external services and cross-cutting infrastructure concerns.

### Responsibilities
- Redis client (caching, session management, LLM response cache)
- File storage adapter (local and S3-compatible)
- Email notification adapter
- External API clients (future: ERP integration)
- Environment variable and secrets loading
- Background task queue (future: Celery/ARQ)

### Allowed Dependencies
- Redis client (redis-py asyncio)
- boto3 / aiobotocore (future S3)
- Python standard library (os, pathlib)
- Domain Layer interfaces only (no implementations)

### Forbidden Dependencies
- No direct database access (Data Layer concern)
- No LLM/AI code
- No HTTP API / FastAPI code

### Folder Structure
```
src/backend/
└── infrastructure/
    ├── cache/
    │   ├── redis_client.py
    │   ├── llm_cache.py           # LLM response cache with TTL
    │   ├── session_cache.py
    │   └── workflow_cache.py
    ├── storage/
    │   ├── local_file_storage.py
    │   └── s3_file_storage.py     # Future
    ├── notifications/
    │   └── email_adapter.py
    └── config/
        └── settings.py            # Pydantic Settings model (reads .env)
```

### Cache TTL Conventions

| Cache Type | TTL | Key Pattern |
|---|---|---|
| LLM Response | 1 hour | `llm:{model}:{hash(prompt)}` |
| Session | 24 hours | `session:{session_id}` |
| Workflow State | 30 minutes | `workflow:{workflow_id}` |
| Dashboard Summary | 5 minutes | `dashboard:{org_id}:summary` |
| Prediction Result | 1 hour | `prediction:{prediction_id}` |

---

## Layer 8 — Observability

### Purpose
Provide visibility into system behaviour, AI performance, costs and audit trail across all layers.

### Responsibilities
- Structured JSON logging (structlog)
- Distributed tracing (correlation_id propagated across layers)
- LLM call tracing (Langfuse: input, output, tokens, cost, latency)
- Application metrics (request count, latency, error rate)
- Audit log writes (data mutations, auth events)
- Performance monitoring (slow query detection)
- Cost monitoring (LLM token spend per user/model/date)

### Allowed Dependencies
- structlog (logging)
- Langfuse (LLM tracing)
- Prometheus client (metrics export, future)
- Domain Layer (AuditLog entity for audit writes)

### Forbidden Dependencies
- No direct application business logic
- Not permitted to modify domain entities

### Folder Structure
```
src/backend/
└── observability/
    ├── logging.py           # structlog configuration
    ├── tracing.py           # correlation_id context var, Langfuse init
    ├── metrics.py           # Prometheus counters and histograms
    ├── audit.py             # audit log writer
    └── middleware.py        # FastAPI middleware: log + trace every request
```

### Structured Log Format
```json
{
  "timestamp": "2026-07-30T14:30:00.123Z",
  "level": "info",
  "correlation_id": "550e8400-e29b-41d4-a716-446655440000",
  "user_id": "usr_abc123",
  "layer": "application",
  "event": "prediction_completed",
  "prediction_id": "pred_xyz789",
  "duration_ms": 1240,
  "confidence": 0.87
}
```

---

## Dependency Injection Strategy

All layer dependencies are wired at application startup using FastAPI's dependency injection system. No global mutable state.

```python
# api/v1/dependencies.py
def get_waste_log_repository() -> IWasteLogRepository:
    return SQLiteWasteLogRepository(db_session=get_db_session())

def get_prediction_service() -> PredictionService:
    return PredictionService(
        waste_repo=get_waste_log_repository(),
        ai_service=get_ai_service(),
        prediction_repo=get_prediction_repository(),
    )
```

---

## Cross-Cutting Concerns

| Concern | Mechanism | Layer |
|---|---|---|
| Authentication | JWT middleware | API Layer |
| Authorisation | `require_role` dependency | API Layer |
| Correlation ID | Context variable (contextvars) | Observability |
| Input Validation | Pydantic v2 | API Layer + Domain Layer |
| Error Handling | FastAPI exception handlers | API Layer |
| Retry Logic | Tenacity (AI Layer only) | AI Layer |
| Cache | Redis decorators | Infrastructure Layer |
| Audit | AuditMiddleware | Observability |
