# Frontend Specification

## Pages

---

## Page 1 — Dashboard

**Route**: `/`  **Role**: All

### Purpose
Landing page providing at-a-glance KPIs, waste trends and quick navigation.

### Widgets
| Widget | Type | Data Source |
|---|---|---|
| Total Waste (30d) | KPI Card | `GET /dashboard/summary` |
| Handling Cost (30d) | KPI Card | `GET /dashboard/summary` |
| Active Recommendations | KPI Card | `GET /dashboard/summary` |
| Prediction Accuracy | KPI Card | `GET /dashboard/summary` |
| Waste Trend Chart | Line Chart (Recharts) | `GET /dashboard/trends` |
| Plastic Type Breakdown | Donut Chart | `GET /dashboard/summary` → `waste_by_plastic_type` |
| Top Waste Products | Table (top 10) | `GET /dashboard/trends?group_by=product` |
| Recent Alerts | Alert list | Client state |

### User Actions
- Change period filter (7d / 30d / 90d / YTD / custom) → re-fetches summary + trends
- Click KPI card → navigates to relevant page
- Click product in table → opens product detail drawer

### Loading States
- KPI cards: skeleton pulse animation
- Charts: spinner overlay with "Loading data..."

### Error States
- API error: inline error banner "Unable to load dashboard. Retry?"
- Empty data: empty state illustration with "Upload your first waste log to get started"

---

## Page 2 — Upload Data

**Route**: `/upload`  **Role**: analyst, manager, admin

### Purpose
Self-service data ingestion for suppliers, products, packaging and waste logs.

### Widgets
| Widget | Description |
|---|---|
| Upload Type Tabs | Products / Packaging / Purchase Orders / Waste Logs / Shipments |
| Drag-and-drop Zone | Accepts CSV/Excel, max 10MB, shows filename on drop |
| Field Mapping Panel | Auto-map columns; manual override dropdowns |
| Validation Preview | First 5 rows shown; red highlight for invalid cells |
| Upload Progress Bar | Shown during async processing |
| Results Summary | Rows created / updated / failed with download of error rows |

### API Calls
- `POST /upload/products` (multipart/form-data)
- `POST /upload/packaging`
- `POST /upload/waste-logs`
- `GET /upload/{upload_id}/status` (polling every 2s)

### User Actions
- Drop file or click to browse → file selected
- Review field mapping → confirm or remap
- Click "Upload" → async job started
- Download error report CSV

### Loading States
- Processing: animated progress bar with "Validating 342 rows..."
- Completion: green checkmark with summary counts

### Error States
- Invalid file type: "Please upload a CSV or Excel file"
- File too large: "File exceeds 10MB limit"
- All rows failed: "Upload failed — see error report"

---

## Page 3 — Predictions

**Route**: `/predictions`  **Role**: analyst, manager, admin (run); viewer (view own)

### Purpose
Run AI waste volume and handling cost predictions; review history.

### Widgets
| Widget | Description |
|---|---|
| Prediction Form | Supplier, Product, Location, Period, Order Volume inputs |
| Run Button | Triggers async prediction |
| Result Card | Predicted value, confidence badge, interval bar |
| XAI Explanation Panel | Plain-English explanation with key factors list |
| Plastic Breakdown Chart | Stacked horizontal bar by plastic type |
| Confidence Badge | Green ≥0.8 / Amber 0.5–0.8 / Red <0.5 |
| Prediction History Table | Paginated; filter by date, confidence, type |
| Feedback Thumbs | 👍 👎 per prediction row |

### API Calls
- `POST /predictions/waste`
- `GET /predictions/waste/{id}` (polling)
- `POST /predictions/handling-cost`
- `POST /feedback` (on thumbs)

### User Actions
- Fill prediction form → Run
- Review result + explanation
- Drill into history → view archived prediction
- Rate prediction accuracy

### Loading States
- "Running AI prediction... (typically 3–5 seconds)" with animated indicator

### Error States
- LLM unavailable: "AI service temporarily unavailable. Please try again."
- Low confidence: amber warning "Low confidence — limited historical data for this product"

---

## Page 4 — Analytics

**Route**: `/analytics`  **Role**: All

### Purpose
Trend analysis, supplier comparison and waste attribution.

### Widgets
| Widget | Description |
|---|---|
| Waste Trend Line Chart | 12-month history; granularity toggle (day/week/month) |
| Supplier Comparison Table | Ranked by waste intensity (kg/unit); sortable |
| Plastic Type Stacked Area Chart | Time-series breakdown by polymer type |
| Location Heatmap | Waste volume by warehouse/store (colour intensity) |
| YoY Comparison Bar Chart | Current vs prior year by month |
| Export Button | Download filtered data as CSV |

### API Calls
- `GET /dashboard/trends?granularity=week&group_by=supplier`
- `GET /dashboard/trends?granularity=month&group_by=plastic_type`

### User Actions
- Change date range and granularity
- Click supplier row → drill to supplier detail
- Export CSV

### Loading States
- Charts: skeleton bars

### Error States
- No data for filter: "No waste data found for this period. Try a wider date range."

---

## Page 5 — AI Copilot

**Route**: `/copilot`  **Role**: All

### Purpose
Natural language Q&A grounded in supply chain data and knowledge base.

### Widgets
| Widget | Description |
|---|---|
| Chat Thread | Message list; user right-aligned, AI left-aligned |
| Input Box | Text input with send button; Enter to submit |
| Citation Panel | Slide-out panel showing retrieved sources |
| Confidence Badge | Per-message confidence indicator |
| Suggested Follow-ups | 3 clickable suggestion chips per AI response |
| Session Clear Button | Start new conversation |
| Feedback Buttons | 👍 👎 per AI message |

### API Calls
- `POST /chat` (session_id maintained client-side)
- `POST /feedback` (on thumbs)

### User Actions
- Type question → send → receive grounded response
- Click citation → slide-out shows source excerpt
- Click suggested follow-up → auto-populates input
- Clear session

### Loading States
- AI typing indicator (three animated dots)

### Error States
- Prompt injection detected: "I can only answer supply chain and sustainability questions."
- LLM unavailable: "AI Copilot is temporarily offline. Non-AI features still available."
- Off-topic query: polite scope message shown inline

---

## Page 6 — Reports

**Route**: `/reports`  **Role**: analyst, manager, admin

### Purpose
Generate, view and download sustainability reports.

### Widgets
| Widget | Description |
|---|---|
| Report Builder Form | Type, period, scope, regulatory framework selection |
| Generate Button | Triggers async report generation |
| Report Preview | Rendered HTML sections with expandable accordion |
| Key Metrics Strip | Headline KPIs from report |
| Download Buttons | PDF / JSON |
| Report History Table | Previous reports with status and download links |

### API Calls
- `POST /reports/generate`
- `GET /reports/{id}` (polling)
- `GET /reports/{id}/download/pdf`

### User Actions
- Configure report parameters → Generate
- Review rendered report in-browser
- Download PDF
- Access previous reports

### Loading States
- "Generating report... (typically 30–60 seconds)" with step indicators: Gathering data → Analysing → Writing → Formatting

### Error States
- No data for period: "No waste records found for the selected period and scope."

---

## Page 7 — Settings

**Route**: `/settings`  **Role**: admin (full); analyst (view own profile)

### Tabs

#### Users Tab (admin only)
- User list table: email, name, role, last login, status
- Add User button → modal form
- Edit role inline
- Deactivate / reactivate toggle

#### Configuration Tab (admin only)
- Key-value config editor grouped by category (ai, costs, reports, security)
- Save button per group
- Change history visible

#### Knowledge Base Tab (admin only)
- Uploaded documents list: title, category, date_ingested, chunk_count
- Upload document button → drag-drop → category selection → ingest
- Delete document → confirms then removes from ChromaDB

#### Audit Log Tab (admin only)
- Filterable table: event_type, user, entity, date range
- Export CSV button

#### Profile Tab (all roles)
- Edit full_name, password change

### API Calls
- `GET/POST/PUT/DELETE /admin/users`
- `GET/PUT /configurations`
- `GET/POST/DELETE /knowledge-base/documents`
- `GET /admin/audit-logs`

### Loading States
- Table skeletons on load

### Error States
- Validation on user form: inline field errors
