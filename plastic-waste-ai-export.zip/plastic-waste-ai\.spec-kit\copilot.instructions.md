# GitHub Copilot Instructions

## Project Context
This is a **Spec-Driven Development** project for the TCS AI Fridays hackathon.
All application code must be generated from the specifications in `.spec-kit/`.
The project uses the **TCS GenAI Lab LiteLLM gateway** at `https://genailab.tcs.in`.

---

## Critical Rules

1. **Never hardcode API keys** — always use `os.getenv("LLM_API_KEY")` or Pydantic Settings
2. **Use `azure/genailab-maas-gpt-4o`** as the primary LLM (NOT openai/gpt-4o directly)
3. **Use `azure/genailab-maas-text-embedding-3-large`** for all embeddings
4. **LiteLLM base_url**: `https://genailab.tcs.in` — always set this
5. **Python 3.12.8** — use `match` statements, `|` union types, `TypedDict` for state
6. **Async first** — all I/O operations must be `async def`
7. **Pydantic v2** — use `model_validate`, not `parse_obj`; use `model_config` not `class Config`
8. **Repository Pattern** — no direct SQL in application or AI layer

---

## Code Patterns

### LLM Client (always use this pattern)
```python
from langchain_openai import ChatOpenAI
import httpx

# Disable SSL verification for TCS internal gateway
_http_client = httpx.AsyncClient(verify=False)

def get_llm(model: str = "azure/genailab-maas-gpt-4o") -> ChatOpenAI:
    return ChatOpenAI(
        base_url=settings.llm_gateway_url,  # https://genailab.tcs.in
        model=model,
        api_key=settings.llm_api_key,
        http_async_client=_http_client,
    )
```

### Embedding Client
```python
from langchain_openai import OpenAIEmbeddings

def get_embeddings() -> OpenAIEmbeddings:
    return OpenAIEmbeddings(
        base_url=settings.llm_gateway_url,
        model="azure/genailab-maas-text-embedding-3-large",
        api_key=settings.llm_api_key,
        http_client=httpx.Client(verify=False),
    )
```

### FastAPI Endpoint (always follow this shape)
```python
@router.post("/resource", response_model=ResourceResponse, status_code=201)
async def create_resource(
    payload: ResourceRequest,
    current_user: User = Depends(require_role("analyst")),
    service: ResourceService = Depends(get_resource_service),
) -> ResourceResponse:
    result = await service.create(payload.to_dto(), current_user.id)
    return ResourceResponse.from_domain(result)
```

### LangGraph Agent Node
```python
async def my_agent_node(state: WorkflowState) -> WorkflowState:
    llm = get_llm()
    prompt = get_my_prompt(state)
    with langfuse_context.observe(name="my_agent"):
        response = await llm.ainvoke(prompt)
    result = MyOutput.model_validate_json(response.content)
    return {**state, "my_output": result}
```

### Repository Implementation
```python
class SQLiteWasteLogRepository(IWasteLogRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, entity: WasteLog) -> WasteLog:
        model = WasteLogMapper.to_model(entity)
        self._session.add(model)
        await self._session.flush()
        return entity
```

### Pydantic Settings
```python
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    llm_gateway_url: str = "https://genailab.tcs.in"
    llm_api_key: str
    llm_primary_model: str = "azure/genailab-maas-gpt-4o"
    llm_mini_model: str = "azure/genailab-maas-gpt-4o-mini"
    embedding_model: str = "azure/genailab-maas-text-embedding-3-large"
    database_url: str = "sqlite+aiosqlite:///./data/app.db"
    redis_url: str = "redis://localhost:6379/0"

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}
```

---

## File Naming Conventions

| Type | Convention | Example |
|---|---|---|
| Python module | `snake_case.py` | `waste_log_repository.py` |
| FastAPI router | `snake_case.py` | `predictions.py` |
| Domain entity | `snake_case.py` | `waste_log.py` |
| Pydantic model | `PascalCase` + suffix | `WastePredictionRequest` |
| React page | `PascalCase/index.tsx` | `Predictions/index.tsx` |
| React component | `PascalCase.tsx` | `WasteConfidenceBadge.tsx` |
| React hook | `useNoun.ts` | `usePredictions.ts` |

---

## Modular Framework Rules

This codebase is designed to be **reused for any hackathon use case**:

1. **Domain module** is in `src/backend/domain/` — all domain-specific entities are here
2. **AI agents** are loaded dynamically from `src/backend/ai/agents/` — add a new agent file to extend
3. **Config is the source of truth** — `config/app.yaml` controls all domain parameters
4. **Prompts live in `prompts/`** — edit prompt files without touching code
5. **Synthetic data schema** in `schemas/` — generate new datasets for any domain

To adapt for a new use case:
1. Define new entities in `domain/entities/`
2. Add prompt files in `prompts/`
3. Register new agent in `ai/agents/`
4. Add API router in `api/v1/routers/`
5. Update `config/app.yaml` with domain parameters

---

## What NOT to Generate

- Do not add print() statements — use `logger.info()`
- Do not use `requests` library — use `httpx.AsyncClient`
- Do not use `time.sleep()` — use `asyncio.sleep()`
- Do not use `os.path` — use `pathlib.Path`
- Do not create circular imports — domain layer imports nothing from outer layers
- Do not write raw SQL — use SQLAlchemy ORM only
