# Continuing on your laptop

## 1. Push to GitHub

This export excludes `.venv/`, `node_modules/`, build output, the local
SQLite DB, and `.env` (it never contained a real secret — just the TCS
placeholder — but `.env` should never be committed regardless). A
`.gitignore` is already included at the project root.

```
git init
git add .
git commit -m "Import plastic-waste-ai from hackathon session"
git branch -M main
git remote add origin <your-empty-github-repo-url>
git push -u origin main
```

## 2. Reinstall dependencies

Backend (needs `uv`: https://docs.astral.sh/uv/getting-started/installation/):
```
cd src/backend
uv sync
copy .env.example .env
```

Frontend:
```
cd src/frontend
npm install
```

## 3. Switch from the TCS gateway to a local LLM (Ollama)

The code already reads the LLM endpoint from settings/`.env` via
`langchain_openai.ChatOpenAI`/`OpenAIEmbeddings` — no code changes needed,
just point it at Ollama's OpenAI-compatible API.

Install Ollama (https://ollama.com), then pull a chat model:
```
ollama pull llama3.1
```

In `src/backend/.env`:
```
LLM_GATEWAY_URL=http://localhost:11434/v1
LLM_API_KEY=ollama
LLM_PRIMARY_MODEL=llama3.1
LLM_MINI_MODEL=llama3.1
```

Notes:
- `LLM_API_KEY` can be any non-empty string — Ollama ignores it, but the
  client library requires the field to be set.
- Embeddings (`EMBEDDING_MODEL`, used by the RAG pipeline) are trickier:
  Ollama's `/v1/embeddings` support varies by version. If it doesn't work,
  the RAG retriever already degrades gracefully to an empty context on
  any embedding error (see `ai/rag/pipeline.py`), so the app still runs —
  you'll just lose grounded citations until embeddings are sorted out.
  `sentence-transformers` is already a backend dependency if you'd rather
  wire up local embeddings directly instead of through Ollama.
- Remove `ssl_patch.py`'s import from `main.py` once you're off the TCS
  network — it disables TLS verification, which was only needed for the
  corporate SSL-inspecting proxy.

## 4. Known state as of this export

See conversation history / commit for details, but in short: backend
persistence (predictions, recommendations, chat, users) is wired to
SQLite and verified end-to-end; frontend is fully scaffolded and
type-checks/builds cleanly; both were driven together in a real browser
successfully. Known gaps: no automated test suite (CI will fail without
one), no Redis caching, no Langfuse tracing wired in, no Alembic
migrations — `Base.metadata.create_all` is used instead.
