# Plastics Waste Prediction and Sustainability Insights Tool

> **Enterprise AI Platform** — Predicts plastics waste, handling effort, handling costs and sustainability insights across the retail supply chain.

---

## Overview

Retail supply chains generate significant volumes of plastic packaging waste across suppliers, manufacturing, warehouses and stores. This platform provides:

- **Waste Prediction** — AI-powered forecasting of plastic waste by product, supplier, location and period
- **Handling Cost Estimation** — Labor, disposal and transport cost modelling
- **Sustainability Insights** — Trend analysis, benchmarking and reduction opportunity identification
- **Packaging Recommendations** — AI-generated suggestions for packaging optimization
- **AI Copilot** — Natural language Q&A grounded in organizational data and regulations

---

## Status

```
Phase      Status
──────────────────────────────────────────────────────────
Architecture     ✅ Complete
Specifications   ✅ Complete
Schemas          ✅ Complete
Diagrams         ✅ Complete
Prompts          ✅ Complete
Synthetic Data   ✅ Complete
Implementation   🔲 Awaiting M1 kickoff
```

---

## Repository Structure

```
plastic-waste-ai/
├── README.md                        ← This file
├── IMPLEMENTATION_PLAN.md           ← Phased milestone guide for coding agents
│
├── .spec-kit/                       ← Complete specification library (22 files)
│   ├── 00_project.yaml              ← Project metadata and tech stack
│   ├── 01_problem.md                ← Problem statement and business context
│   ├── 02_business_requirements.md  ← BR-001..BR-020
│   ├── 03_functional_requirements.md← FR-001..FR-030
│   ├── 04_non_functional_requirements.md ← NFR: performance, security, scale
│   ├── 05_personas.md               ← 5 user personas
│   ├── 06_user_journeys.md          ← 5 end-to-end journey flows
│   ├── 07_architecture.md           ← 8-layer architecture (master spec)
│   ├── 08_data_architecture.md      ← Data flows and lineage
│   ├── 09_database_design.md        ← 14 tables, all columns, indexes, relationships
│   ├── 10_rag_design.md             ← RAG pipeline architecture
│   ├── 11_ai_agents.md              ← 7 AI agents with prompts and contracts
│   ├── 12_guardrails.md             ← Responsible AI and safety controls
│   ├── 13_observability.md          ← Langfuse, logging, metrics, audit
│   ├── 14_api_contract.md           ← 16 REST endpoints with full schemas
│   ├── 15_frontend_spec.md          ← 7 pages with widget and API specs
│   ├── 16_testing_strategy.md       ← Full testing pyramid specification
│   ├── 17_demo_plan.md              ← 5-minute demo script
│   ├── 18_judge_expectations.md     ← AI Friday scoring guide
│   ├── 19_build_tasks.md            ← Granular tasks per milestone
│   ├── 20_definition_of_done.md     ← DoD per layer and milestone
│   ├── copilot.instructions.md      ← GitHub Copilot code generation rules
│   └── ARCHITECT.md                 ← ADRs and architectural decisions
│
├── docs/                            ← Reference guides
│   ├── architecture-guide.md
│   ├── api-guide.md
│   ├── database-guide.md
│   ├── ai-guide.md
│   ├── deployment-guide.md
│   ├── demo-guide.md
│   └── troubleshooting-guide.md
│
├── config/                          ← Configuration specifications
│   ├── app.yaml
│   ├── ai.yaml
│   ├── database.yaml
│   ├── redis.yaml
│   ├── observability.yaml
│   └── security.yaml
│
├── templates/                       ← Reusable code templates for agents
│   ├── agent-template.md
│   ├── api-endpoint-template.md
│   ├── repository-template.md
│   └── test-template.md
│
├── diagrams/                        ← Mermaid architecture diagrams
│   ├── system-architecture.mermaid
│   ├── data-flow.mermaid
│   ├── ai-workflow.mermaid
│   ├── rag-pipeline.mermaid
│   ├── database-erd.mermaid
│   └── deployment-topology.mermaid
│
├── prompts/                         ← AI agent prompt specifications
│   ├── planner-agent.md
│   ├── retriever-agent.md
│   ├── waste-prediction-agent.md
│   ├── handling-cost-agent.md
│   ├── recommendation-agent.md
│   ├── explanation-agent.md
│   └── report-generator-agent.md
│
├── synthetic-data/                  ← Realistic retail supply chain data
│   ├── schema/
│   │   └── synthetic-data-schema.json
│   ├── suppliers.json
│   ├── products.json
│   ├── packaging.json
│   ├── purchase_orders.json
│   ├── shipments.json
│   ├── warehouses.json
│   ├── stores.json
│   ├── waste_logs.json
│   ├── handling_costs.json
│   └── README.md
│
├── schemas/                         ← JSON Schema definitions
│   ├── api/
│   │   ├── upload-request.json
│   │   ├── prediction-request.json
│   │   └── recommendation-request.json
│   ├── domain/
│   │   ├── supplier.json
│   │   ├── product.json
│   │   ├── packaging.json
│   │   └── waste-log.json
│   └── ai/
│       ├── agent-input.json
│       └── agent-output.json
│
├── src/                             ← Structural stubs only (no code)
│   ├── frontend/
│   │   └── README.md
│   └── backend/
│       └── README.md
│
└── .github/                         ← CI/CD workflow specifications
    ├── workflows/
    │   ├── ci.yaml
    │   └── spec-validation.yaml
    └── CODEOWNERS
```

---

## Technology Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, TypeScript 5, Vite, Tailwind CSS |
| Backend | FastAPI, Python 3.12, Pydantic v2 |
| AI Orchestration | LangGraph, LangChain |
| RAG / Vector Store | ChromaDB, text-embedding-3-small |
| Database | SQLite (dev/demo), PostgreSQL migration path |
| Cache | Redis 7 |
| Observability | Langfuse, structlog |
| Testing | Pytest, Playwright, HTTPX |
| Auth | JWT (python-jose), bcrypt |

---

## Architecture Principle

```
Frontend → API → Application → Domain → AI → Data → Infrastructure → Observability
```

Dependencies flow **inward only**. The Domain Layer has **zero external dependencies**.

See [.spec-kit/07_architecture.md](.spec-kit/07_architecture.md) for the full specification.

---

## Quick Start (Post-Implementation)

```bash
# Clone and enter
git clone <repo> plastic-waste-ai
cd plastic-waste-ai

# Backend
cd src/backend
python -m venv .venv && .venv/Scripts/activate
pip install -r requirements.txt
uvicorn main:app --reload

# Frontend
cd src/frontend
npm install && npm run dev
```

---

## Milestones

| # | Milestone | Est. Effort |
|---|---|---|
| M1 | Folder Structure + Environments | 0.5 day |
| M2 | Backend Domain + Application Layers | 2 days |
| M3 | Database + Repositories | 1.5 days |
| M4 | AI Layer (LangGraph + RAG) | 3 days |
| M5 | API Layer (FastAPI) | 2 days |
| M6 | Frontend (React + TypeScript) | 3 days |
| M7 | Testing | 2 days |
| M8 | Documentation + Deployment | 1 day |

See [IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md) for full details.

---

## Key Documents

| Need | Go to |
|---|---|
| Understand the problem | [.spec-kit/01_problem.md](.spec-kit/01_problem.md) |
| Understand the architecture | [.spec-kit/07_architecture.md](.spec-kit/07_architecture.md) |
| Understand the data model | [.spec-kit/09_database_design.md](.spec-kit/09_database_design.md) |
| Understand the AI agents | [.spec-kit/11_ai_agents.md](.spec-kit/11_ai_agents.md) |
| Understand the APIs | [.spec-kit/14_api_contract.md](.spec-kit/14_api_contract.md) |
| Start coding | [IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md) |
| Configure GitHub Copilot | [.spec-kit/copilot.instructions.md](.spec-kit/copilot.instructions.md) |

---

*This repository is a Spec-Driven Development blueprint. All application code is generated from these specifications in subsequent milestones.*
