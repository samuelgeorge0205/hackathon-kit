# Deployment Guide

## Local Development (Hackathon Environment)

### Prerequisites
- Python 3.12.8 (pre-installed on TCS AI Lab laptops)
- Node.js 20+ (available via open internet on AI Lab)
- Redis (install via `winget install Redis.Redis` or use local Docker image)

### Quick Start

```bash
# 1. Copy environment file
cp .env.example .env
# Fill in: LLM_API_KEY (provided on event day), SECRET_KEY (generate random 32 chars)

# 2. Backend
cd src/backend
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
alembic upgrade head
python data/seed_db.py
uvicorn main:app --reload --port 8000

# 3. Frontend (new terminal)
cd src/frontend
npm install
npm run dev

# 4. Access
# API: http://localhost:8000/docs
# App: http://localhost:3000
```

### Environment Variables

```bash
# .env
LLM_API_KEY=<from_event_day>
LLM_GATEWAY_URL=https://genailab.tcs.in
LLM_PRIMARY_MODEL=azure/genailab-maas-gpt-4o
LLM_MINI_MODEL=azure/genailab-maas-gpt-4o-mini
EMBEDDING_MODEL=azure/genailab-maas-text-embedding-3-large
SECRET_KEY=<32_random_chars>
DATABASE_URL=sqlite+aiosqlite:///./data/app.db
REDIS_URL=redis://localhost:6379/0
LANGFUSE_PUBLIC_KEY=<optional>
LANGFUSE_SECRET_KEY=<optional>
```

## Gogs Repository (TCS AI Lab)

```bash
# Set remote to Gogs (not GitHub — per Handbook §8.5)
git remote add origin http://<gogs_url>/<team>/<repo>.git
git push -u origin main
```

## Production (Future)

For production deployment, change only:
```bash
DATABASE_URL=postgresql+asyncpg://user:pass@host:5432/plasticwaste
```
No application code changes required.
