# Troubleshooting Guide

## LLM API Issues

### "SSL verification failed" / "Certificate verify failed"
```python
# Ensure httpx client has verify=False
http_async_client=httpx.AsyncClient(verify=False)
```
This is required for the TCS GenAI Lab internal gateway.

### "401 Unauthorized" from LiteLLM gateway
- Check `LLM_API_KEY` in `.env` — must match the key provided on event day
- Verify `LLM_GATEWAY_URL=https://genailab.tcs.in`

### LLM returns empty or invalid JSON
- Check the agent prompt ends with: `Return ONLY a valid JSON object. No preamble.`
- Enable retry logic (agents retry up to 3 times on JSON parse error)
- Reduce `temperature` to 0.1 for more deterministic output

### "Budget exceeded" error
- Check total spend in Langfuse dashboard
- Switch to `gpt-4o-mini` for non-critical agents (`mini=True` in `get_llm()`)
- Verify Redis cache is working (cache hits = $0 cost)

---

## Database Issues

### "Table does not exist"
```bash
alembic upgrade head
python data/seed_db.py
```

### SQLite locked error
- Only one write operation at a time — ensure no concurrent test sessions

---

## ChromaDB Issues

### "Collection not found"
```bash
# Re-index knowledge documents
python src/backend/ai/rag/ingestion/index_documents.py
```

---

## Frontend Issues

### CORS error in browser console
- Ensure backend `CORS_ORIGINS` includes `http://localhost:3000`
- Verify `VITE_API_BASE_URL=http://localhost:8000/api/v1` in `src/frontend/.env`

### Auth token expired
- Access token expires in 15 minutes — the Axios interceptor auto-refreshes
- If refresh fails, user is redirected to login

---

## Common Mistakes

| Mistake | Fix |
|---|---|
| Using `requests` library | Use `httpx.AsyncClient` |
| Direct SQL in application layer | Use repository interface |
| Hardcoded API key in code | Use `settings.llm_api_key` from env |
| Sync function calling async | Ensure `async def` + `await` throughout |
| Pydantic v1 syntax | Use `model_validate()`, `model_config = {}` |
