@echo off
REM ============================================================
REM  Plastic Waste AI — One-shot setup for TCS AI Lab (Windows)
REM  Handles: PowerShell execution policy + uv + SSL
REM  Usage:  setup.bat
REM ============================================================

cd /d "%~dp0src\backend"

echo [1/5] Checking Python 3.12...
python --version 2>nul | findstr /R "3\.12" >nul
IF ERRORLEVEL 1 (
    echo ERROR: Python 3.12 not found. Select Python 3.12.8 in VS Code bottom bar.
    pause & exit /b 1
)

echo [2/5] Installing uv (if not present)...
pip install uv --quiet --trusted-host pypi.org --trusted-host files.pythonhosted.org 2>nul
uv --version

echo [3/5] Creating virtual environment and installing dependencies...
REM --native-tls uses Windows certificate store (handles TCS internal SSL)
uv sync --native-tls
IF ERRORLEVEL 1 (
    echo Retrying with pip fallback...
    python -m pip install -e ".[dev]" --trusted-host pypi.org --trusted-host files.pythonhosted.org
)

echo [4/5] Copying .env.example to .env (if not exists)...
IF NOT EXIST .env (
    copy .env.example .env
    echo .env created — add your LLM_API_KEY before running the app.
)

echo [5/5] Creating database tables and seeding data...
uv run python -c "import asyncio; from data.database import create_tables; asyncio.run(create_tables())"
uv run python data/seed_db.py

echo.
echo ============================================================
echo  Setup complete!
echo  Start backend:   setup.bat run
echo  Start frontend:  cd src\frontend ^&^& npm install ^&^& npm run dev
echo ============================================================

IF "%1"=="run" (
    echo Starting backend on http://localhost:8000 ...
    uv run uvicorn main:app --reload --host 0.0.0.0 --port 8000
)
