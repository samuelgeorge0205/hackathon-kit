# ============================================================
#  Plastic Waste AI — PowerShell setup (execution-policy safe)
#  Usage:  powershell -ExecutionPolicy Bypass -File setup.ps1
#       OR just run:  setup.bat  (which calls this correctly)
# ============================================================
param(
    [switch]$Run,
    [switch]$Frontend
)

$ErrorActionPreference = "Stop"
$ROOT = Split-Path $PSScriptRoot -Absolute
$BACKEND = Join-Path $ROOT "src\backend"

Write-Host "`n[1/5] Python version check..." -ForegroundColor Cyan
$pyver = & python --version 2>&1
if ($pyver -notmatch "3\.12") {
    Write-Host "WARNING: Expected Python 3.12 (TCS AI Lab). Found: $pyver" -ForegroundColor Yellow
}

Write-Host "`n[2/5] Ensuring uv is installed..." -ForegroundColor Cyan
try { uv --version | Out-Null }
catch {
    Write-Host "Installing uv..." -ForegroundColor Yellow
    & pip install uv --trusted-host pypi.org --trusted-host files.pythonhosted.org --quiet
}
Write-Host "uv: $(uv --version)"

Set-Location $BACKEND

Write-Host "`n[3/5] Syncing dependencies with uv..." -ForegroundColor Cyan
# --native-tls uses the Windows certificate store to handle TCS internal SSL
& uv sync --native-tls 2>&1 | Tee-Object -Variable uvOutput
if ($LASTEXITCODE -ne 0) {
    Write-Host "uv sync failed — trying pip fallback..." -ForegroundColor Yellow
    & python -m pip install -e ".[dev]" `
        --trusted-host pypi.org `
        --trusted-host files.pythonhosted.org `
        --quiet
}

Write-Host "`n[4/5] Environment file..." -ForegroundColor Cyan
if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host ".env created — fill in LLM_API_KEY before starting." -ForegroundColor Yellow
} else {
    Write-Host ".env already exists." -ForegroundColor Green
}

Write-Host "`n[5/5] Database setup + seed..." -ForegroundColor Cyan
& uv run python -c "import asyncio; from data.database import create_tables; asyncio.run(create_tables())"
& uv run python data/seed_db.py

Write-Host "`n============================================================" -ForegroundColor Green
Write-Host " Setup complete!" -ForegroundColor Green
Write-Host " Backend:   uv run uvicorn main:app --reload --port 8000" -ForegroundColor White
Write-Host " Frontend:  cd src/frontend && npm install && npm run dev" -ForegroundColor White
Write-Host "============================================================`n" -ForegroundColor Green

if ($Run) {
    Write-Host "Starting backend..." -ForegroundColor Cyan
    Set-Location $BACKEND
    & uv run uvicorn main:app --reload --host 0.0.0.0 --port 8000
}

if ($Frontend) {
    Write-Host "Starting frontend..." -ForegroundColor Cyan
    Set-Location (Join-Path $ROOT "src\frontend")
    & npm install
    & npm run dev
}
