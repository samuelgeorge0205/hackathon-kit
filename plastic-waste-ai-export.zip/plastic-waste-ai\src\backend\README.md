# Backend Module Structure

## DO NOT CREATE APPLICATION CODE HERE YET
## Follow IMPLEMENTATION_PLAN.md milestone by milestone
## Read .spec-kit/ specs before implementing each module

## Target Structure (created in M1–M5)

```
src/backend/
├── main.py                        # FastAPI app factory
├── requirements.txt               # Python dependencies
├── alembic.ini                    # Alembic migration config
├── .env.example                   # Environment variable template
│
├── api/
│   └── v1/
│       ├── routers/               # One file per resource
│       ├── dependencies.py        # DI: get_current_user, require_role
│       ├── middleware.py          # CORS, correlation ID, request logging
│       └── models/                # Pydantic request/response schemas
│           ├── requests/
│           └── responses/
│
├── application/
│   ├── use_cases/                 # One class per use case
│   ├── services/                  # Service interfaces + implementations
│   ├── dtos/                      # Data Transfer Objects
│   └── interfaces/                # AI service and notification interfaces
│
├── domain/
│   ├── entities/                  # 13 domain entities
│   ├── value_objects/             # PlasticType, Money, ConfidenceScore etc.
│   ├── events/                    # Domain events
│   └── repositories/              # Repository interfaces (ABCs)
│
├── ai/
│   ├── agents/                    # 7 LangGraph agent nodes
│   ├── workflows/                 # LangGraph StateGraphs
│   ├── rag/                       # RAG pipeline
│   │   ├── ingestion/
│   │   └── retrieval/
│   ├── prompts/
│   │   └── prompt_registry.py     # Loads prompts from prompts/ directory
│   └── state/
│       └── workflow_state.py      # TypedDict state schemas
│
├── data/
│   ├── repositories/
│   │   ├── sqlite/                # SQLite implementations
│   │   └── chroma/                # ChromaDB implementation
│   ├── models/                    # SQLAlchemy ORM models
│   ├── migrations/                # Alembic migrations
│   │   └── versions/
│   └── mappers/                   # ORM ↔ Domain entity mappers
│
├── infrastructure/
│   ├── cache/                     # Redis client + cache strategies
│   ├── storage/                   # File storage adapters
│   └── config/
│       └── settings.py            # Pydantic Settings (reads .env)
│
├── observability/
│   ├── logging.py                 # structlog JSON configuration
│   ├── tracing.py                 # Langfuse init + correlation ID
│   ├── metrics.py                 # Prometheus counters
│   └── audit.py                   # Audit log writer
│
└── tests/
    ├── unit/
    │   ├── domain/
    │   ├── application/
    │   └── ai/
    ├── integration/
    │   ├── repositories/
    │   └── api/
    └── synthetic/                 # Validates synthetic-data/ against schemas
```

## Key Implementation Files (read spec before implementing)

| File | Read spec first |
|---|---|
| `domain/entities/*.py` | `.spec-kit/09_database_design.md` |
| `ai/agents/*.py` | `.spec-kit/11_ai_agents.md` |
| `ai/rag/` | `.spec-kit/10_rag_design.md` |
| `api/v1/routers/*.py` | `.spec-kit/14_api_contract.md` |
| `infrastructure/config/settings.py` | `config/app.yaml` |
| All LLM calls | `.spec-kit/copilot.instructions.md` — LLM client pattern |

## Environment Variables Required

```bash
# .env (never commit — use .env.example as template)
LLM_API_KEY=your_tcs_genai_lab_api_key
LLM_GATEWAY_URL=https://genailab.tcs.in
LANGFUSE_PUBLIC_KEY=your_langfuse_key
LANGFUSE_SECRET_KEY=your_langfuse_secret
SECRET_KEY=your_jwt_secret_32chars_minimum
DATABASE_URL=sqlite+aiosqlite:///./data/app.db
REDIS_URL=redis://localhost:6379/0
```
