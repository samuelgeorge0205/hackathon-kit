from __future__ import annotations

import os

import httpx
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

from infrastructure.config.settings import get_settings

# Disable SSL verification for TCS GenAI Lab internal gateway in all environments
os.environ.setdefault("CURL_CA_BUNDLE", "")
os.environ.setdefault("REQUESTS_CA_BUNDLE", "")

_async_http_client = httpx.AsyncClient(verify=False)
_sync_http_client = httpx.Client(verify=False)


def get_llm(mini: bool = False) -> ChatOpenAI:
    s = get_settings()
    model = s.llm_mini_model if mini else s.llm_primary_model
    return ChatOpenAI(
        base_url=s.llm_gateway_url,
        model=model,
        api_key=s.llm_api_key,
        http_async_client=_async_http_client,
        temperature=0.2,
    )


def get_embeddings() -> OpenAIEmbeddings:
    s = get_settings()
    return OpenAIEmbeddings(
        base_url=s.llm_gateway_url,
        model=s.embedding_model,
        api_key=s.llm_api_key,
        http_client=_sync_http_client,
    )
