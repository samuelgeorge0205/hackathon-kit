from __future__ import annotations

import structlog
from langfuse.decorators import observe

from ai.agents._base import get_llm
from ai.state.workflow_state import PredictionWorkflowState, ChatWorkflowState

logger = structlog.get_logger(__name__)

_SYSTEM_PROMPT = """You are an AI Transparency Officer. Translate AI predictions into clear, honest explanations for business users.

BANNED WORDS: embedding, cosine similarity, temperature, token, vector, LLM, model inference, neural network.

Return JSON:
{
  "explanation": "<2-4 paragraphs in plain English>",
  "key_points": ["<bullet 1>", "<bullet 2>", "<bullet 3>"],
  "confidence_explanation": "<one sentence explaining confidence in everyday terms>",
  "data_gaps": ["<gap if any>"]
}"""


@observe(name="explanation_agent")
async def explanation_node(state: PredictionWorkflowState) -> PredictionWorkflowState:
    prediction = state.get("prediction", {})
    llm = get_llm(mini=True)  # Use mini model — cost-efficient for explanations

    user_prompt = (
        f"Prediction result: {prediction}\n"
        f"Key factors: {prediction.get('key_factors', [])}\n"
        "Explain this prediction in plain English for a Supply Chain Analyst."
    )

    messages = [{"role": "system", "content": _SYSTEM_PROMPT}, {"role": "user", "content": user_prompt}]

    try:
        response = await llm.ainvoke(messages)
        import json
        result = json.loads(response.content)
        explanation = result.get("explanation", "Prediction completed successfully.")
    except Exception as exc:
        logger.warning("explanation_fallback", error=str(exc))
        kg = prediction.get("predicted_waste_kg", 0)
        confidence = prediction.get("confidence_score", 0)
        explanation = (
            f"The AI predicts {kg:.1f} kg of plastic waste for this period. "
            f"Confidence level: {'high' if confidence > 0.7 else 'medium' if confidence > 0.4 else 'low'} ({confidence:.0%}). "
            f"Key drivers: {', '.join(prediction.get('key_factors', ['insufficient data'])[:2])}."
        )

    return {**state, "explanation": explanation}


@observe(name="chat_explanation_agent")
async def chat_explanation_node(state: ChatWorkflowState) -> ChatWorkflowState:
    """Explanation node for the chat workflow — generates grounded response."""
    llm = get_llm(mini=True)
    context = state.get("retrieved_context", [])
    context_text = "\n\n".join(
        f"[{i+1}] {doc.get('text', '')[:500]}" for i, doc in enumerate(context[:5])
    )

    messages = [
        {"role": "system", "content": (
            "You are a Supply Chain Sustainability AI assistant. "
            "Answer ONLY using the provided context. Cite sources as [1], [2] etc. "
            "If context is insufficient, say so honestly."
        )},
        {"role": "user", "content": f"Context:\n{context_text}\n\nQuestion: {state.get('user_message', '')}"},
    ]

    try:
        response = await llm.ainvoke(messages)
        text = response.content
    except Exception as exc:
        logger.warning("chat_explanation_fallback", error=str(exc))
        text = "I'm unable to answer right now. Please try again shortly."

    citations = [
        {"index": i + 1, "title": doc.get("metadata", {}).get("title", "Internal data"), "relevance": 0.8}
        for i, doc in enumerate(context[:3])
    ]

    return {**state, "response": text, "citations": citations}
