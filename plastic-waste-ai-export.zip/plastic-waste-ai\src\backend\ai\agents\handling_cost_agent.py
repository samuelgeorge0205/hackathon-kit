from __future__ import annotations

import json
import logging
from langfuse.decorators import observe

from pydantic import BaseModel

from ai.agents._base import get_llm
from ai.state.workflow_state import PredictionWorkflowState

logger = logging.getLogger(__name__)

# Default cost rates (GBP) — overridden by config/app.yaml at runtime
_DEFAULT_RATES = {
    "labor_rate_per_hour": 18.50,
    "handling_minutes_per_kg": {"PET": 2.5, "HDPE": 2.0, "PVC": 3.5, "LDPE": 1.5, "PP": 2.0, "PS": 3.0, "MIXED": 4.0},
    "disposal_rate_per_kg": {"PET": 0.45, "HDPE": 0.35, "PVC": 0.85, "LDPE": 0.40, "PP": 0.38, "PS": 0.72, "MIXED": 0.65},
    "transport_rate_per_kg": 0.12,
}


class HandlingCostOutput(BaseModel):
    labor_cost: float
    disposal_cost: float
    transport_cost: float
    total_cost: float
    cost_per_kg: float
    currency: str = "GBP"
    cost_breakdown_pct: dict
    confidence_score: float
    assumptions: list[str]


def _calculate_deterministic(prediction: dict, rates: dict) -> HandlingCostOutput:
    """Pure calculation — used as fallback when LLM is unavailable."""
    breakdown = prediction.get("plastic_type_breakdown", {})
    total_kg = prediction.get("predicted_waste_kg", 0.0)

    labor_hours = sum(
        kg * rates["handling_minutes_per_kg"].get(pt, 2.5) / 60
        for pt, kg in breakdown.items()
    )
    labor_cost = round(labor_hours * rates["labor_rate_per_hour"], 2)
    disposal_cost = round(sum(
        kg * rates["disposal_rate_per_kg"].get(pt, 0.50) for pt, kg in breakdown.items()
    ), 2)
    transport_cost = round(total_kg * rates["transport_rate_per_kg"], 2)
    total = labor_cost + disposal_cost + transport_cost
    cost_per_kg = round(total / max(total_kg, 0.001), 2)
    pct = lambda c: round(c / max(total, 0.001) * 100, 1)

    return HandlingCostOutput(
        labor_cost=labor_cost,
        disposal_cost=disposal_cost,
        transport_cost=transport_cost,
        total_cost=round(total, 2),
        cost_per_kg=cost_per_kg,
        cost_breakdown_pct={"labor": pct(labor_cost), "disposal": pct(disposal_cost), "transport": pct(transport_cost)},
        confidence_score=0.75,
        assumptions=["Default cost rates applied"],
    )


@observe(name="handling_cost_agent")
async def handling_cost_node(state: PredictionWorkflowState) -> PredictionWorkflowState:
    prediction = state.get("prediction")
    if not prediction:
        return state

    result = _calculate_deterministic(prediction, _DEFAULT_RATES)
    return {**state, "handling_cost": result.model_dump()}
