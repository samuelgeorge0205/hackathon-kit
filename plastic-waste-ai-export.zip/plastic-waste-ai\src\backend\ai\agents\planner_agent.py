from __future__ import annotations

import json
import logging
from langfuse.decorators import observe

from ai.agents._base import get_llm
from ai.state.workflow_state import PredictionWorkflowState

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = """You are a Supply Chain AI Planner. Route user requests to the correct agent sequence.

Available agents: retriever, waste_prediction, handling_cost, recommendation, explanation, report_generator

Routing rules:
1. Always start with retriever for knowledge-dependent tasks
2. waste_prediction before handling_cost
3. Always end prediction/recommendation tasks with explanation
4. report_generator needs waste_prediction and handling_cost first

Return ONLY JSON:
{
  "task_sequence": ["<agent1>", "<agent2>"],
  "routing_decision": "PREDICTION|CHAT|REPORT|RECOMMENDATION",
  "query_intent": "<one sentence>"
}"""


@observe(name="planner_agent")
async def planner_node(state: PredictionWorkflowState) -> PredictionWorkflowState:
    prediction_type = state.get("prediction_type", "WASTE_VOLUME")

    # Deterministic routing for known prediction types — no LLM call needed
    routes = {
        "WASTE_VOLUME": ["retriever", "waste_prediction", "handling_cost", "explanation"],
        "HANDLING_COST": ["retriever", "handling_cost", "explanation"],
        "RECOMMENDATION": ["retriever", "waste_prediction", "recommendation", "explanation"],
        "REPORT": ["retriever", "waste_prediction", "handling_cost", "recommendation", "report_generator"],
        "CHAT": ["retriever", "explanation"],
    }

    return {**state, "task_sequence": routes.get(prediction_type, routes["WASTE_VOLUME"])}
