from __future__ import annotations

import json
import structlog
from langfuse.decorators import observe

from ai.agents._base import get_llm
from ai.state.workflow_state import PredictionWorkflowState

logger = structlog.get_logger(__name__)

_SYSTEM_PROMPT = """You are a Packaging Sustainability Expert for retail supply chains.

Generate up to 5 specific, actionable packaging optimisation recommendations.
Rules:
- Be SPECIFIC: "Replace 45g virgin PET tray with 28g rPET tray" NOT "use better packaging"
- QUANTIFY: estimate waste_reduction_kg/year and cost_saving GBP/year from data
- GROUND: cite only documents present in retrieved context
- NO INVENTION: do not cite standards not in context

Return ONLY a JSON array:
[{
  "recommendation_type": "MATERIAL_CHANGE|WEIGHT_REDUCTION|RECYCLABILITY|CONSOLIDATION",
  "description": "<specific change>",
  "rationale": "<grounded in source>",
  "estimated_waste_reduction_kg": <float>,
  "estimated_cost_saving": <float>,
  "confidence_score": <float 0-1>,
  "implementation_effort": "LOW|MEDIUM|HIGH",
  "sources": [{"title": "<doc>", "section": "<section>"}]
}]"""


@observe(name="recommendation_agent")
async def recommendation_node(state: PredictionWorkflowState) -> PredictionWorkflowState:
    llm = get_llm(mini=False)
    context = state.get("retrieved_context", [])
    params = state.get("input_params", {})
    prediction = state.get("prediction", {})

    # Skip recommendations if retrieval quality is too low
    if not context:
        return {**state, "recommendations": []}

    context_text = "\n\n".join(
        f"[{doc.get('metadata', {}).get('title', 'Doc')}]: {doc.get('text', '')[:400]}"
        for doc in context[:5]
    )

    user_prompt = (
        f"Product: {params.get('product_name', 'Unknown')} (ID: {params.get('product_id', 'N/A')})\n"
        f"Historical waste: {prediction.get('predicted_waste_kg', 0):.1f}kg predicted\n"
        f"Plastic type breakdown: {json.dumps(prediction.get('plastic_type_breakdown', {}))}\n\n"
        f"Retrieved context:\n{context_text}\n\n"
        "Generate packaging optimisation recommendations."
    )

    messages = [{"role": "system", "content": _SYSTEM_PROMPT}, {"role": "user", "content": user_prompt}]

    for attempt in range(2):
        try:
            response = await llm.ainvoke(messages)
            recs = json.loads(response.content)
            if not isinstance(recs, list):
                raise ValueError("Expected JSON array")
            # Hallucination guard — verify citations exist in context
            source_titles = {doc.get("metadata", {}).get("title", "") for doc in context}
            verified = [
                r for r in recs
                if not r.get("sources") or any(s.get("title", "") in source_titles for s in r["sources"])
            ]
            return {**state, "recommendations": verified}
        except Exception as exc:
            logger.warning("recommendation_retry", attempt=attempt, error=str(exc))
            if attempt == 1:
                return {**state, "recommendations": []}
            messages[-1]["content"] += "\n\nReturn ONLY a valid JSON array."

    return state
