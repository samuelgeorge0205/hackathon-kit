from __future__ import annotations

import structlog
from langfuse.decorators import observe

from ai.state.workflow_state import PredictionWorkflowState, ChatWorkflowState

logger = structlog.get_logger(__name__)


@observe(name="retriever_agent")
async def retriever_node(state: PredictionWorkflowState) -> PredictionWorkflowState:
    """Retrieves from ChromaDB + historical DB. Returns populated context in state."""
    from ai.rag.pipeline import RAGPipeline

    query = state.get("user_query", "")
    params = state.get("input_params", {})

    if not query:
        query = _build_query_from_params(params)

    pipeline = RAGPipeline()
    try:
        context = await pipeline.retrieve(query, top_k=5)
    except Exception as exc:
        logger.warning("retriever_degraded", error=str(exc))
        context = []

    return {**state, "retrieved_context": context}


@observe(name="chat_retriever_agent")
async def chat_retriever_node(state: ChatWorkflowState) -> ChatWorkflowState:
    """Retriever node for the chat workflow."""
    from ai.rag.pipeline import RAGPipeline

    pipeline = RAGPipeline()
    try:
        context = await pipeline.retrieve(state.get("user_message", ""), top_k=5)
    except Exception as exc:
        logger.warning("chat_retriever_degraded", error=str(exc))
        context = []

    return {**state, "retrieved_context": context}


def _build_query_from_params(params: dict) -> str:
    parts = []
    if params.get("product_name"):
        parts.append(params["product_name"])
    if params.get("plastic_type"):
        parts.append(f"{params['plastic_type']} packaging")
    parts.append("plastic waste sustainability guidelines")
    return " ".join(parts)
