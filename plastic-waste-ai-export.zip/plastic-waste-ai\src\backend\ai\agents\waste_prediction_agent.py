from __future__ import annotations

import json
import structlog
from langfuse.decorators import observe

from pydantic import BaseModel

from ai.agents._base import get_llm
from ai.state.workflow_state import PredictionWorkflowState

logger = structlog.get_logger(__name__)

_SYSTEM_PROMPT = """You are an expert in plastic waste prediction for retail supply chains.

You will receive historical waste data and packaging context. Predict total plastic waste (kg) for the specified period.

Reasoning steps:
1. Calculate average historical waste per unit
2. Identify trend (increasing/decreasing)
3. Apply seasonal adjustment if prior-year data shows pattern
4. Scale by provided order_volume relative to historical volumes

Confidence scoring:
- 0.80-0.95: >=12 months complete data, verified packaging weights
- 0.60-0.80: 6-12 months data or partial packaging data
- 0.40-0.60: <6 months data or new product
- 0.20-0.40: no historical data

Return ONLY valid JSON matching this schema:
{
  "predicted_waste_kg": <float >= 0>,
  "prediction_interval": {"low": <float>, "high": <float>, "confidence_pct": <int 50-95>},
  "plastic_type_breakdown": {"PET": <float>, "HDPE": <float>, "PVC": <float>, "LDPE": <float>, "PP": <float>, "PS": <float>, "MIXED": <float>},
  "key_factors": [<string>, <string>, <string>],
  "confidence_score": <float 0.0-1.0>,
  "model_reasoning": <string>
}"""


class WastePredictionOutput(BaseModel):
    predicted_waste_kg: float
    prediction_interval: dict
    plastic_type_breakdown: dict
    key_factors: list[str]
    confidence_score: float
    model_reasoning: str


@observe(name="waste_prediction_agent")
async def waste_prediction_node(state: PredictionWorkflowState) -> PredictionWorkflowState:
    llm = get_llm(mini=False)
    params = state.get("input_params", {})
    historical = state.get("historical_data", [])
    context = state.get("retrieved_context", [])

    user_prompt = (
        f"Historical waste data:\n{json.dumps(historical[:20], default=str)}\n\n"
        f"Retrieved context summary: {len(context)} documents retrieved\n\n"
        f"Prediction parameters: {json.dumps(params, default=str)}\n\n"
        "Predict the plastic waste for this period."
    )

    messages = [{"role": "system", "content": _SYSTEM_PROMPT}, {"role": "user", "content": user_prompt}]

    for attempt in range(3):
        try:
            response = await llm.ainvoke(messages)
            result = WastePredictionOutput.model_validate_json(response.content)
            if result.predicted_waste_kg < 0:
                raise ValueError("predicted_waste_kg cannot be negative")
            return {**state, "prediction": result.model_dump(), "confidence_score": result.confidence_score}
        except Exception as exc:
            logger.warning("waste_prediction_retry", attempt=attempt, error=str(exc))
            if attempt == 2:
                # Deterministic fallback using historical average
                avg = sum(r.get("weight_kg", 0) for r in historical) / max(len(historical), 1)
                fallback = WastePredictionOutput(
                    predicted_waste_kg=round(avg * 4, 2),
                    prediction_interval={"low": round(avg * 3, 2), "high": round(avg * 5, 2), "confidence_pct": 50},
                    plastic_type_breakdown={"PET": 0, "HDPE": 0, "PVC": 0, "LDPE": 0, "PP": 0, "PS": 0, "MIXED": round(avg * 4, 2)},
                    key_factors=["Fallback: insufficient data for AI prediction"],
                    confidence_score=0.25,
                    model_reasoning="Deterministic fallback — LLM unavailable",
                )
                return {**state, "prediction": fallback.model_dump(), "confidence_score": 0.25}
            messages[-1]["content"] += "\n\nIMPORTANT: Return ONLY valid JSON. predicted_waste_kg must be >= 0."
    return state
