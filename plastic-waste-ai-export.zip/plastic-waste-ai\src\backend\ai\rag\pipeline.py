from __future__ import annotations

from pathlib import Path

import chromadb
import structlog
from chromadb.config import Settings as ChromaSettings

from ai.agents._base import get_embeddings

logger = structlog.get_logger(__name__)

_CHROMA_DIR = Path("./data/chroma")
_COLLECTION_NAME = "knowledge_base"


class RAGPipeline:
    def __init__(self) -> None:
        _CHROMA_DIR.mkdir(parents=True, exist_ok=True)
        self._client = chromadb.PersistentClient(
            path=str(_CHROMA_DIR),
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        self._collection = self._client.get_or_create_collection(
            name=_COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )
        self._embedder = get_embeddings()

    async def ingest(self, text: str, metadata: dict, doc_id: str | None = None) -> None:
        chunks = self._chunk(text)
        if not chunks:
            return
        embeddings = self._embedder.embed_documents(chunks)
        ids = [f"{doc_id or 'doc'}_{i}" for i in range(len(chunks))]
        metas = [{**metadata, "chunk_index": i} for i in range(len(chunks))]
        self._collection.upsert(ids=ids, embeddings=embeddings, documents=chunks, metadatas=metas)
        logger.info("rag_ingested", doc_id=doc_id, chunks=len(chunks))

    async def retrieve(self, query: str, top_k: int = 5) -> list[dict]:
        if self._collection.count() == 0:
            return []
        try:
            query_embedding = self._embedder.embed_query(query)
            results = self._collection.query(
                query_embeddings=[query_embedding],
                n_results=min(top_k, self._collection.count()),
                include=["documents", "metadatas", "distances"],
            )
            return [
                {"text": doc, "metadata": meta, "score": 1 - dist}
                for doc, meta, dist in zip(
                    results["documents"][0],
                    results["metadatas"][0],
                    results["distances"][0],
                )
            ]
        except Exception as exc:
            logger.warning("rag_retrieve_error", error=str(exc))
            return []

    def _chunk(self, text: str, size: int = 512) -> list[str]:
        words = text.split()
        chunks, current = [], []
        for word in words:
            current.append(word)
            if len(current) >= size:
                chunks.append(" ".join(current))
                current = current[-50:]  # 50-word overlap
        if current:
            chunks.append(" ".join(current))
        return [c for c in chunks if c.strip()]
