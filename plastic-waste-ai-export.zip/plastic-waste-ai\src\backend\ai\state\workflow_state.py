from __future__ import annotations

import json
from typing import Annotated, Any

from langgraph.graph.message import add_messages
from typing_extensions import TypedDict


class PredictionWorkflowState(TypedDict, total=False):
    # Input
    user_id: str
    workflow_id: str
    prediction_type: str
    input_params: dict[str, Any]
    user_query: str

    # Intermediate
    retrieved_context: list[dict]
    historical_data: list[dict]
    messages: Annotated[list, add_messages]

    # Agent outputs
    prediction: dict | None
    handling_cost: dict | None
    recommendations: list[dict]
    explanation: str | None
    report_sections: list[dict]

    # Metadata
    confidence_score: float
    sources: list[dict]
    retry_count: int
    errors: list[str]


class ChatWorkflowState(TypedDict, total=False):
    user_id: str
    session_id: str
    user_message: str
    retrieved_context: list[dict]
    response: str
    citations: list[dict]
    suggested_follow_ups: list[str]
    confidence_score: float
    errors: list[str]
    messages: Annotated[list, add_messages]
