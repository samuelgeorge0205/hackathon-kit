from __future__ import annotations

from langgraph.graph import END, StateGraph

from ai.agents.explanation_agent import explanation_node
from ai.agents.handling_cost_agent import handling_cost_node
from ai.agents.planner_agent import planner_node
from ai.agents.recommendation_agent import recommendation_node
from ai.agents.retriever_agent import chat_retriever_node, retriever_node
from ai.agents.waste_prediction_agent import waste_prediction_node
from ai.agents.explanation_agent import chat_explanation_node
from ai.state.workflow_state import ChatWorkflowState, PredictionWorkflowState


def build_prediction_workflow():
    # Node names must not collide with PredictionWorkflowState keys (LangGraph forbids
    # this) — "handling_cost" and "explanation" are both state keys, so the corresponding
    # nodes are registered under "*_step" names; the state keys they write are unaffected.
    graph = StateGraph(PredictionWorkflowState)

    graph.add_node("planner", planner_node)
    graph.add_node("retriever", retriever_node)
    graph.add_node("waste_prediction", waste_prediction_node)
    graph.add_node("handling_cost_step", handling_cost_node)
    graph.add_node("recommendation", recommendation_node)
    graph.add_node("explanation_step", explanation_node)

    graph.set_entry_point("planner")
    graph.add_edge("planner", "retriever")
    graph.add_edge("retriever", "waste_prediction")
    graph.add_edge("waste_prediction", "handling_cost_step")
    graph.add_edge("handling_cost_step", "explanation_step")
    graph.add_edge("explanation_step", END)

    return graph.compile()


def build_chat_workflow():
    graph = StateGraph(ChatWorkflowState)

    graph.add_node("retriever", chat_retriever_node)
    graph.add_node("explanation", chat_explanation_node)

    graph.set_entry_point("retriever")
    graph.add_edge("retriever", "explanation")
    graph.add_edge("explanation", END)

    return graph.compile()


# Compiled workflow singletons
prediction_workflow = build_prediction_workflow()
chat_workflow = build_chat_workflow()
