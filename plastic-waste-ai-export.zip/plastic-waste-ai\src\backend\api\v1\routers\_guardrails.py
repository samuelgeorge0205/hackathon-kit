from __future__ import annotations

import re

from fastapi import HTTPException, status

_INJECTION_PATTERNS = [
    r"ignore (previous|all|above) instructions",
    r"forget (your|the) (system|previous) prompt",
    r"you are now",
    r"act as (if you are|a|an)",
    r"jailbreak",
    r"pretend (you|that)",
    r"disregard (your|the)",
]

_PII_PATTERNS = [
    r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}",
    r"\b[A-Z]{2}\d{6}[A-Z]\b",  # UK NI number
]


def check_guardrails(text: str) -> None:
    lower = text.lower()
    for pattern in _INJECTION_PATTERNS:
        if re.search(pattern, lower):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Potentially harmful input detected",
            )


def mask_pii(text: str) -> str:
    for pattern in _PII_PATTERNS:
        text = re.sub(pattern, "[REDACTED]", text)
    return text
