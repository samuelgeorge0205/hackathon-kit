from __future__ import annotations

import uuid

from fastapi import APIRouter, BackgroundTasks, Depends
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from api.v1.dependencies import get_current_user, require_role
from data.database import get_db_session
from data.repositories.sqlite.chat_repository import SQLiteChatRepository
from domain.entities.user import User

router = APIRouter()


class ChatRequest(BaseModel):
    session_id: str | None = None
    message: str
    context: dict | None = None


@router.post("")
async def chat(
    payload: ChatRequest,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(get_current_user),
):
    from api.v1.routers._guardrails import check_guardrails

    session_id = payload.session_id or f"sess_{uuid.uuid4().hex[:8]}"
    check_guardrails(payload.message)

    from ai.workflows.prediction_workflow import chat_workflow

    chat_repo = SQLiteChatRepository(session)
    history = await chat_repo.get_history(session_id, limit=10)

    state = {
        "user_id": str(current_user.id),
        "session_id": session_id,
        "user_message": payload.message,
        "retrieved_context": [],
        "messages": history,
    }

    result = await chat_workflow.ainvoke(state)

    msg_id = f"msg_{uuid.uuid4().hex[:8]}"
    await chat_repo.add_message(session_id, str(current_user.id), "user", payload.message)
    await chat_repo.add_message(
        session_id, str(current_user.id), "assistant", result.get("response", ""), result.get("citations")
    )

    return {
        "data": {
            "session_id": session_id,
            "message_id": msg_id,
            "response": result.get("response", "I was unable to process your request."),
            "citations": result.get("citations", []),
            "suggested_follow_ups": [
                "Show me the top suppliers by waste intensity",
                "What packaging changes would reduce PET waste most?",
                "Generate a waste report for last month",
            ],
            "confidence_score": result.get("confidence_score", 0.7),
        }
    }
