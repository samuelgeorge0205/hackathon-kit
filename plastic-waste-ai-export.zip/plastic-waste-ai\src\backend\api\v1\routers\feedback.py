from __future__ import annotations

import uuid
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from api.v1.dependencies import get_current_user
from data.database import get_db_session
from data.repositories.sqlite.prediction_repository import SQLitePredictionRepository
from domain.entities.user import User

router = APIRouter()


class FeedbackRequest(BaseModel):
    entity_type: str
    entity_id: str
    rating: int  # 1 or -1
    comment: str | None = None


@router.post("", status_code=201)
async def submit_feedback(
    payload: FeedbackRequest,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(get_current_user),
):
    if payload.rating not in (-1, 1):
        raise HTTPException(status_code=422, detail="rating must be 1 or -1")

    if payload.entity_type == "PREDICTION":
        try:
            prediction_id = UUID(payload.entity_id)
        except ValueError:
            raise HTTPException(status_code=422, detail="entity_id must be a valid prediction id")
        repo = SQLitePredictionRepository(session)
        await repo.update_feedback(prediction_id, payload.rating, payload.comment)

    return {"data": {"feedback_id": f"fb_{uuid.uuid4().hex[:8]}", "recorded": True}}
