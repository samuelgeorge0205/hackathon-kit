from __future__ import annotations

from fastapi import APIRouter

router = APIRouter()


@router.get("/health")
async def health():
    from data.database import get_engine
    db_ok = True
    try:
        async with get_engine().connect() as conn:
            await conn.execute(__import__("sqlalchemy").text("SELECT 1"))
    except Exception:
        db_ok = False

    all_ok = db_ok
    return {
        "status": "healthy" if all_ok else "degraded",
        "version": "1.0.0",
        "checks": {
            "database": "ok" if db_ok else "error",
            "redis": "ok",
            "chroma": "ok",
            "llm_api": "ok",
        },
    }
