from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.v1.dependencies import get_current_user, require_role
from data.database import get_db_session
from data.models.models import ProductModel
from data.repositories.sqlite.recommendation_repository import SQLiteRecommendationRepository
from domain.entities.recommendation import Recommendation
from domain.entities.user import User

router = APIRouter()


async def _product_names(session: AsyncSession, product_ids: list[str]) -> dict[str, str]:
    if not product_ids:
        return {}
    result = await session.execute(select(ProductModel).where(ProductModel.id.in_(product_ids)))
    return {row.id: row.name for row in result.scalars().all()}


def _serialize(rec: Recommendation, product_names: dict[str, str]) -> dict:
    return {
        "id": rec.id,
        "product_id": rec.product_id,
        "product_name": product_names.get(rec.product_id, "Unknown product"),
        "recommendation_type": rec.recommendation_type,
        "description": rec.description,
        "rationale": rec.rationale,
        "estimated_waste_reduction_kg": rec.estimated_waste_reduction_kg,
        "estimated_cost_saving": rec.estimated_cost_saving,
        "confidence_score": rec.confidence_score,
        "status": rec.status,
        "implementation_effort": rec.implementation_effort,
    }


@router.get("")
async def list_recommendations(
    status: str | None = None,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(get_current_user),
):
    repo = SQLiteRecommendationRepository(session)
    recs = await repo.list(status=status, limit=100)
    product_names = await _product_names(session, [r.product_id for r in recs])
    result = [_serialize(r, product_names) for r in recs]
    return {"data": result, "meta": {"total": len(result)}}


class FeedbackRequest(BaseModel):
    status: str
    reason: str | None = None


@router.post("/{recommendation_id}/feedback")
async def update_recommendation(
    recommendation_id: str,
    payload: FeedbackRequest,
    session: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(require_role("manager", "admin")),
):
    repo = SQLiteRecommendationRepository(session)
    rec = await repo.get_by_id(recommendation_id)
    if not rec:
        raise HTTPException(status_code=404, detail="Recommendation not found")

    if payload.status == "ACCEPTED":
        rec.accept(str(current_user.id), payload.reason)
    elif payload.status == "REJECTED":
        rec.reject(str(current_user.id), payload.reason)
    else:
        rec.status = payload.status
        rec.status_changed_by = str(current_user.id)
        rec.status_reason = payload.reason

    await repo.update_status(rec)
    return {"data": {"id": recommendation_id, "status": rec.status}}
