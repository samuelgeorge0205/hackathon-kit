from __future__ import annotations

import uuid
from datetime import date, timedelta

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from pydantic import BaseModel

from api.v1.dependencies import get_current_user, require_role
from data.database import get_session_factory
from data.repositories.sqlite.recommendation_repository import SQLiteRecommendationRepository
from data.repositories.sqlite.waste_log_repository import SQLiteWasteLogRepository
from domain.entities.user import User

router = APIRouter()
_reports: dict[str, dict] = {}


class ReportRequest(BaseModel):
    report_type: str = "SUSTAINABILITY_WASTE"
    period_start: str
    period_end: str
    scope: str = "ORGANISATION"
    include_recommendations: bool = True
    regulatory_framework: str = "GRI_306"


async def _generate_report(report_id: str, params: dict) -> None:
    from ai.agents.report_generator_agent import generate_report_sections
    from ai.rag.pipeline import RAGPipeline

    _reports[report_id]["status"] = "GENERATING"

    try:
        period_start = date.fromisoformat(params["period_start"])
        period_end = date.fromisoformat(params["period_end"])
        period_days = (period_end - period_start).days + 1
        prior_end = period_start - timedelta(days=1)
        prior_start = prior_end - timedelta(days=period_days - 1)

        session_factory = get_session_factory()
        async with session_factory() as session:
            waste_repo = SQLiteWasteLogRepository(session)
            current = await waste_repo.get_summary(period_start, period_end)
            prior = await waste_repo.get_summary(prior_start, prior_end)

            rec_repo = SQLiteRecommendationRepository(session)
            pending_recs = await rec_repo.list(status="PENDING", limit=100)

        change_pct = None
        if prior["total_waste_kg"] > 0:
            change_pct = round(
                (current["total_waste_kg"] - prior["total_waste_kg"]) / prior["total_waste_kg"] * 100, 1
            )

        recommendations_value = sum(r.estimated_cost_saving or 0 for r in pending_recs)
        summary_data = {
            "total_waste_kg": current["total_waste_kg"],
            "change_pct": change_pct,
            "recycling_rate_pct": current["recycling_rate_pct"],
            "active_recommendations": len(pending_recs),
            "recommendations_value": recommendations_value,
        }

        try:
            pipeline = RAGPipeline()
            regs_context = await pipeline.retrieve(
                "GRI 306 UK EPR plastic packaging waste reporting", top_k=3
            )
        except Exception:
            regs_context = []

        sections = await generate_report_sections(
            summary_data,
            current["waste_by_type"],
            regs_context,
            {"period_start": params["period_start"], "period_end": params["period_end"]},
        )

        _reports[report_id].update({
            "status": "COMPLETE",
            "title": f"Plastic Waste Sustainability Report — {params['period_start']} to {params['period_end']}",
            "executive_summary": sections[0].get("content", ""),
            "key_metrics": {
                "total_waste_kg": current["total_waste_kg"],
                "period_over_period_change_pct": change_pct,
                "recycling_rate_pct": current["recycling_rate_pct"],
            },
            "waste_by_type": current["waste_by_type"],
            "sections": sections,
        })
    except Exception as exc:
        _reports[report_id]["status"] = "ERROR"
        _reports[report_id]["error"] = str(exc)


@router.post("/generate", status_code=202)
async def generate_report(
    payload: ReportRequest,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(require_role("analyst", "manager", "admin")),
):
    report_id = f"rpt_{uuid.uuid4().hex[:8]}"
    _reports[report_id] = {"status": "GENERATING", "report_id": report_id}
    background_tasks.add_task(_generate_report, report_id, payload.model_dump())
    return {"data": {"report_id": report_id, "status": "GENERATING", "estimated_seconds": 45}}


@router.get("/{report_id}")
async def get_report(report_id: str, current_user: User = Depends(get_current_user)):
    report = _reports.get(report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return {"data": report}
