from __future__ import annotations

import csv
import io
import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile

from api.v1.dependencies import get_current_user, require_role
from domain.entities.user import User

router = APIRouter()
_uploads: dict[str, dict] = {}


async def _process_csv_generic(upload_id: str, content: bytes) -> None:
    _uploads[upload_id]["status"] = "PROCESSING"
    try:
        text = content.decode("utf-8-sig")
        rows = list(csv.DictReader(io.StringIO(text)))
        _uploads[upload_id].update({"status": "COMPLETE", "rows_processed": len(rows), "rows_created": len(rows), "rows_failed": 0, "errors": []})
    except Exception as exc:
        _uploads[upload_id].update({"status": "ERROR", "error": str(exc)})


async def _process_waste_logs(upload_id: str, content: bytes, user_id: str) -> None:
    _uploads[upload_id]["status"] = "PROCESSING"
    try:
        from data.database import get_session_factory
        from data.repositories.sqlite.waste_log_repository import SQLiteWasteLogRepository
        from application.use_cases.ingest_waste_logs import IngestWasteLogsUseCase

        text = content.decode("utf-8-sig")
        records = list(csv.DictReader(io.StringIO(text)))

        async with get_session_factory()() as session:
            repo = SQLiteWasteLogRepository(session)
            result = await IngestWasteLogsUseCase(repo).execute(records, user_id)

        _uploads[upload_id].update({
            "status": "COMPLETE",
            "rows_processed": len(records),
            "rows_created": result.accepted,
            "rows_failed": result.rejected,
            "errors": result.errors[:20],
        })
    except Exception as exc:
        _uploads[upload_id].update({"status": "ERROR", "error": str(exc)})


@router.post("/products", status_code=202)
async def upload_products(
    file: UploadFile = File(...),
    current_user: User = Depends(require_role("analyst", "manager", "admin")),
):
    return await _handle_upload(file, "products", str(current_user.id))


@router.post("/packaging", status_code=202)
async def upload_packaging(
    file: UploadFile = File(...),
    current_user: User = Depends(require_role("analyst", "manager", "admin")),
):
    return await _handle_upload(file, "packaging", str(current_user.id))


@router.post("/waste-logs", status_code=202)
async def upload_waste_logs(
    file: UploadFile = File(...),
    current_user: User = Depends(require_role("analyst", "manager", "admin")),
):
    return await _handle_upload(file, "waste_logs", str(current_user.id))


@router.get("/{upload_id}/status")
async def get_upload_status(
    upload_id: str,
    current_user: User = Depends(get_current_user),
):
    upload = _uploads.get(upload_id)
    if not upload:
        raise HTTPException(status_code=404, detail="Upload not found")
    return {"data": upload}


async def _handle_upload(file: UploadFile, upload_type: str, user_id: str) -> dict:
    if not file.filename or not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=422, detail="Only CSV files are supported")
    content = await file.read()
    if len(content) > 10 * 1024 * 1024:
        raise HTTPException(status_code=422, detail="File exceeds 10MB limit")

    upload_id = f"upl_{uuid.uuid4().hex[:8]}"
    _uploads[upload_id] = {"upload_id": upload_id, "status": "QUEUED", "filename": file.filename}

    import asyncio
    if upload_type == "waste_logs":
        asyncio.create_task(_process_waste_logs(upload_id, content, user_id))
    else:
        asyncio.create_task(_process_csv_generic(upload_id, content))

    return {"data": {"upload_id": upload_id, "status": "PROCESSING", "filename": file.filename}}
