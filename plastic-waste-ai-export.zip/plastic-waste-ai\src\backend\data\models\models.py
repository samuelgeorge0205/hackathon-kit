from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, Column, Date, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import DeclarativeBase, relationship


class Base(DeclarativeBase):
    pass


class UserModel(Base):
    __tablename__ = "users"
    id = Column(String(36), primary_key=True)
    email = Column(String(255), unique=True, nullable=False)
    hashed_password = Column(Text, nullable=False)
    full_name = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False, default="viewer")
    department = Column(String(100))
    is_active = Column(Boolean, default=True)
    failed_login_attempts = Column(Integer, default=0)
    created_at = Column(String(30), default=lambda: datetime.utcnow().isoformat())


class SupplierModel(Base):
    __tablename__ = "suppliers"
    id = Column(String(36), primary_key=True)
    external_id = Column(String(100))
    name = Column(String(255), nullable=False)
    country = Column(String(2), nullable=False)
    region = Column(String(50))
    tier = Column(Integer, default=2)
    certifications = Column(Text)  # JSON string
    sustainability_score = Column(Float)
    contact_email = Column(String(255))
    created_at = Column(String(30), default=lambda: datetime.utcnow().isoformat())

    products = relationship("ProductModel", back_populates="supplier")


class ProductModel(Base):
    __tablename__ = "products"
    id = Column(String(36), primary_key=True)
    supplier_id = Column(String(36), ForeignKey("suppliers.id"), nullable=False)
    sku = Column(String(100), nullable=False)
    name = Column(String(255), nullable=False)
    category = Column(String(100), nullable=False)
    sub_category = Column(String(100))
    weight_kg = Column(Float)
    unit_of_measure = Column(String(20), default="EACH")
    is_active = Column(Boolean, default=True)
    created_at = Column(String(30), default=lambda: datetime.utcnow().isoformat())

    supplier = relationship("SupplierModel", back_populates="products")
    packaging = relationship("PackagingModel", back_populates="product")


class PackagingModel(Base):
    __tablename__ = "packaging"
    id = Column(String(36), primary_key=True)
    product_id = Column(String(36), ForeignKey("products.id"), nullable=False)
    material_type = Column(String(10), nullable=False)
    weight_g = Column(Float, nullable=False)
    description = Column(Text)
    recyclable = Column(Boolean, default=False)
    recycled_content_pct = Column(Float)
    layers = Column(Integer, default=1)
    is_primary = Column(Boolean, default=True)
    supplier_declared = Column(Boolean, default=False)
    created_at = Column(String(30), default=lambda: datetime.utcnow().isoformat())

    product = relationship("ProductModel", back_populates="packaging")


class WasteLogModel(Base):
    __tablename__ = "plastic_waste_logs"
    id = Column(String(36), primary_key=True)
    source_type = Column(String(20), nullable=False)
    source_id = Column(String(36), nullable=False)
    product_id = Column(String(36), ForeignKey("products.id"))
    packaging_id = Column(String(36), ForeignKey("packaging.id"))
    log_date = Column(String(10), nullable=False)  # ISO date string
    plastic_type = Column(String(10), nullable=False)
    weight_kg = Column(Float, nullable=False)
    unit_count = Column(Integer)
    disposal_method = Column(String(20), default="UNKNOWN")
    verified = Column(Boolean, default=False)
    notes = Column(Text)
    uploaded_by = Column(String(36), ForeignKey("users.id"))
    created_at = Column(String(30), default=lambda: datetime.utcnow().isoformat())


class PredictionModel(Base):
    __tablename__ = "predictions"
    id = Column(String(36), primary_key=True)
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False)
    prediction_type = Column(String(20), nullable=False)
    input_params = Column(Text, nullable=False)  # JSON
    output_json = Column(Text, nullable=False)    # JSON
    predicted_value = Column(Float)
    confidence_score = Column(Float, nullable=False)
    model_version = Column(String(100), nullable=False)
    explanation = Column(Text)
    feedback_rating = Column(Integer)
    feedback_comment = Column(Text)
    created_at = Column(String(30), default=lambda: datetime.utcnow().isoformat())


class RecommendationModel(Base):
    __tablename__ = "recommendations"
    id = Column(String(36), primary_key=True)
    product_id = Column(String(36), ForeignKey("products.id"), nullable=False)
    recommendation_type = Column(String(30), nullable=False)
    description = Column(Text, nullable=False)
    rationale = Column(Text, nullable=False)
    estimated_waste_reduction_kg = Column(Float)
    estimated_cost_saving = Column(Float)
    confidence_score = Column(Float, nullable=False)
    status = Column(String(20), default="PENDING")
    implementation_effort = Column(String(10), default="MEDIUM")
    status_changed_by = Column(String(36))
    status_reason = Column(Text)
    sources = Column(Text)  # JSON
    created_at = Column(String(30), default=lambda: datetime.utcnow().isoformat())


class AuditLogModel(Base):
    __tablename__ = "audit_logs"
    id = Column(String(36), primary_key=True)
    event_type = Column(String(50), nullable=False)
    user_id = Column(String(36))
    entity_type = Column(String(50))
    entity_id = Column(String(36))
    before_json = Column(Text)
    after_json = Column(Text)
    ip_address = Column(String(45))
    user_agent = Column(Text)
    correlation_id = Column(String(36))
    created_at = Column(String(30), default=lambda: datetime.utcnow().isoformat())


class WarehouseModel(Base):
    __tablename__ = "warehouses"
    id = Column(String(36), primary_key=True)
    external_id = Column(String(100))
    name = Column(String(255), nullable=False)
    location = Column(String(255), nullable=False)
    region = Column(String(100))
    country = Column(String(2), default="GB")
    capacity_m3 = Column(Float)
    is_active = Column(Boolean, default=True)


class StoreModel(Base):
    __tablename__ = "stores"
    id = Column(String(36), primary_key=True)
    external_id = Column(String(100))
    name = Column(String(255), nullable=False)
    format = Column(String(20), nullable=False)
    location = Column(String(255), nullable=False)
    region = Column(String(100))
    country = Column(String(2), default="GB")
    is_active = Column(Boolean, default=True)


class ChatMessageModel(Base):
    __tablename__ = "chat_messages"
    id = Column(String(36), primary_key=True)
    session_id = Column(String(36), nullable=False)
    user_id = Column(String(36), ForeignKey("users.id"))
    role = Column(String(20), nullable=False)
    content = Column(Text, nullable=False)
    citations = Column(Text)  # JSON string
    created_at = Column(String(30), default=lambda: datetime.utcnow().isoformat())


class ConfigurationModel(Base):
    __tablename__ = "configurations"
    id = Column(String(36), primary_key=True)
    key = Column(String(200), unique=True, nullable=False)
    value = Column(Text, nullable=False)
    value_type = Column(String(20), default="string")
    category = Column(String(50), nullable=False)
    description = Column(Text)
    updated_by = Column(String(36))
    updated_at = Column(String(30), default=lambda: datetime.utcnow().isoformat())
