from __future__ import annotations

import json
from pathlib import Path
from uuid import uuid4

_DATA_DIR = Path(__file__).parent.parent.parent.parent / "synthetic-data"


_DEMO_USERS = [
    {"id": "00000000-0000-0000-0000-000000000001", "email": "analyst@demo.com", "full_name": "Sarah Chen", "role": "analyst"},
    {"id": "00000000-0000-0000-0000-000000000002", "email": "manager@demo.com", "full_name": "James Okafor", "role": "manager"},
    {"id": "00000000-0000-0000-0000-000000000003", "email": "admin@demo.com", "full_name": "Rachel Kim", "role": "admin"},
    {"id": "00000000-0000-0000-0000-000000000004", "email": "viewer@demo.com", "full_name": "Store Manager", "role": "viewer"},
]
_DEMO_PASSWORD = "Demo1234!"


async def seed_database() -> None:
    """Load synthetic data JSON files into the database."""
    from api.v1.dependencies import hash_password
    from data.database import get_session_factory
    from data.models.models import (
        PackagingModel, ProductModel, RecommendationModel, StoreModel,
        SupplierModel, UserModel, WarehouseModel, WasteLogModel,
    )

    session_factory = get_session_factory()

    async with session_factory() as session:
        async with session.begin():
            # Demo users
            for row in _DEMO_USERS:
                existing = await session.get(UserModel, row["id"])
                if not existing:
                    session.add(UserModel(hashed_password=hash_password(_DEMO_PASSWORD), **row))

            # Recommendations
            data = json.loads((_DATA_DIR / "recommendations.json").read_text())
            for row in data:
                row["sources"] = json.dumps(row.get("sources", []))
                existing = await session.get(RecommendationModel, row["id"])
                if not existing:
                    session.add(RecommendationModel(**row))

            # Suppliers
            data = json.loads((_DATA_DIR / "suppliers.json").read_text())
            for row in data:
                row["certifications"] = json.dumps(row.get("certifications", []))
                existing = await session.get(SupplierModel, row["id"])
                if not existing:
                    session.add(SupplierModel(**row))

            # Products
            data = json.loads((_DATA_DIR / "products.json").read_text())
            for row in data:
                existing = await session.get(ProductModel, row["id"])
                if not existing:
                    session.add(ProductModel(**row))

            # Packaging
            data = json.loads((_DATA_DIR / "packaging.json").read_text())
            for row in data:
                row.pop("layers_detail", None)
                existing = await session.get(PackagingModel, row["id"])
                if not existing:
                    session.add(PackagingModel(**row))

            # Warehouses
            data = json.loads((_DATA_DIR / "warehouses.json").read_text())
            for row in data:
                existing = await session.get(WarehouseModel, row["id"])
                if not existing:
                    session.add(WarehouseModel(**row))

            # Stores
            data = json.loads((_DATA_DIR / "stores.json").read_text())
            for row in data:
                existing = await session.get(StoreModel, row["id"])
                if not existing:
                    session.add(StoreModel(**row))

            # Waste logs
            data = json.loads((_DATA_DIR / "waste_logs.json").read_text())
            for row in data:
                existing = await session.get(WasteLogModel, row["id"])
                if not existing:
                    session.add(WasteLogModel(**row))

    print(f"Seeded database from {_DATA_DIR}")


if __name__ == "__main__":
    import asyncio
    from data.database import create_tables
    asyncio.run(create_tables())
    asyncio.run(seed_database())
    print("Done.")
