from __future__ import annotations

import hashlib
import json
import structlog

from infrastructure.config.settings import get_settings

logger = structlog.get_logger(__name__)

_LLM_TTL = 3600      # 1 hour — LLM response cache
_SESSION_TTL = 86400  # 24 hours — user session cache


def _make_redis():
    """Lazily create Redis client; returns None when Redis is unavailable."""
    try:
        import redis.asyncio as aioredis  # type: ignore
        settings = get_settings()
        return aioredis.from_url(settings.redis_url, decode_responses=True, socket_connect_timeout=2)
    except Exception as exc:
        logger.warning("redis_unavailable", error=str(exc))
        return None


class LLMCache:
    """Cache LLM responses keyed by model + prompt hash to avoid repeat API calls."""

    def __init__(self) -> None:
        self._redis = _make_redis()

    def _key(self, model: str, prompt: str) -> str:
        digest = hashlib.sha256(prompt.encode()).hexdigest()[:16]
        return f"llm:{model}:{digest}"

    async def get(self, model: str, prompt: str) -> str | None:
        if self._redis is None:
            return None
        try:
            return await self._redis.get(self._key(model, prompt))
        except Exception as exc:
            logger.warning("llm_cache_get_error", error=str(exc))
            return None

    async def set(self, model: str, prompt: str, response: str) -> None:
        if self._redis is None:
            return
        try:
            await self._redis.setex(self._key(model, prompt), _LLM_TTL, response)
        except Exception as exc:
            logger.warning("llm_cache_set_error", error=str(exc))


class SessionCache:
    """Store conversation session state keyed by session ID."""

    def __init__(self) -> None:
        self._redis = _make_redis()

    def _key(self, session_id: str) -> str:
        return f"session:{session_id}"

    async def get(self, session_id: str) -> dict | None:
        if self._redis is None:
            return None
        try:
            raw = await self._redis.get(self._key(session_id))
            return json.loads(raw) if raw else None
        except Exception as exc:
            logger.warning("session_cache_get_error", error=str(exc))
            return None

    async def set(self, session_id: str, data: dict) -> None:
        if self._redis is None:
            return
        try:
            await self._redis.setex(self._key(session_id), _SESSION_TTL, json.dumps(data))
        except Exception as exc:
            logger.warning("session_cache_set_error", error=str(exc))

    async def delete(self, session_id: str) -> None:
        if self._redis is None:
            return
        try:
            await self._redis.delete(self._key(session_id))
        except Exception as exc:
            logger.warning("session_cache_delete_error", error=str(exc))
