from __future__ import annotations

from functools import lru_cache

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # LLM — TCS GenAI Lab LiteLLM gateway
    llm_gateway_url: str = "https://genailab.tcs.in"
    llm_api_key: str = "placeholder"
    llm_primary_model: str = "azure/genailab-maas-gpt-4o"
    llm_mini_model: str = "azure/genailab-maas-gpt-4o-mini"
    embedding_model: str = "azure/genailab-maas-text-embedding-3-large"

    # Budget guard (TCS AI Fridays: $25/team)
    budget_alert_usd: float = 20.0
    budget_limit_usd: float = 25.0

    # Auth
    secret_key: str = "dev-secret-key-replace-in-production"
    access_token_expire_minutes: int = 15
    refresh_token_expire_days: int = 7

    # Database
    database_url: str = "sqlite+aiosqlite:///./data/app.db"

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # Langfuse (optional)
    langfuse_public_key: str = ""
    langfuse_secret_key: str = ""
    langfuse_host: str = "https://cloud.langfuse.com"

    # App
    app_env: str = "development"
    app_debug: bool = True
    cors_origins: list[str] = ["http://localhost:3000", "http://127.0.0.1:3000"]

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8", "extra": "ignore"}


@lru_cache
def get_settings() -> Settings:
    return Settings()
