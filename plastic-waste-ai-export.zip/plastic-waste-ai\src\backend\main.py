from __future__ import annotations

import ssl_patch  # noqa: F401 — must be first; patches SSL for TCS internal gateway

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from infrastructure.config.settings import get_settings


@asynccontextmanager
async def lifespan(app: FastAPI):
    from data.database import create_tables
    from data.seed_db import seed_database
    await create_tables()
    await seed_database()
    yield


def create_app() -> FastAPI:
    settings = get_settings()

    app = FastAPI(
        title="Plastics Waste AI",
        version="1.0.0",
        description="Enterprise AI Platform for plastic waste prediction and sustainability insights",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    from api.v1.routers import auth, chat, dashboard, feedback, health, predictions, recommendations, reports, upload

    app.include_router(auth.router, prefix="/api/v1/auth", tags=["auth"])
    app.include_router(upload.router, prefix="/api/v1/upload", tags=["upload"])
    app.include_router(predictions.router, prefix="/api/v1/predictions", tags=["predictions"])
    app.include_router(dashboard.router, prefix="/api/v1/dashboard", tags=["dashboard"])
    app.include_router(recommendations.router, prefix="/api/v1/recommendations", tags=["recommendations"])
    app.include_router(reports.router, prefix="/api/v1/reports", tags=["reports"])
    app.include_router(chat.router, prefix="/api/v1/chat", tags=["chat"])
    app.include_router(feedback.router, prefix="/api/v1/feedback", tags=["feedback"])
    app.include_router(health.router, prefix="/api/v1", tags=["health"])

    return app


app = create_app()
