# Frontend Module Structure

## DO NOT CREATE APPLICATION CODE HERE YET
## Follow IMPLEMENTATION_PLAN.md milestone M6
## Read .spec-kit/15_frontend_spec.md before implementing each page

## Target Structure (created in M6)

```
src/frontend/
├── index.html
├── vite.config.ts
├── tailwind.config.ts
├── tsconfig.json
├── package.json
│
├── src/
│   ├── main.tsx                   # App entry point
│   ├── App.tsx                    # Router setup
│   │
│   ├── pages/                     # One folder per route
│   │   ├── Dashboard/
│   │   │   └── index.tsx
│   │   ├── Upload/
│   │   │   └── index.tsx
│   │   ├── Predictions/
│   │   │   └── index.tsx
│   │   ├── Analytics/
│   │   │   └── index.tsx
│   │   ├── Copilot/
│   │   │   └── index.tsx
│   │   ├── Reports/
│   │   │   └── index.tsx
│   │   └── Settings/
│   │       └── index.tsx
│   │
│   ├── components/
│   │   ├── charts/                # Recharts wrappers
│   │   ├── forms/                 # Reusable form elements
│   │   ├── layout/                # NavBar, Sidebar, PageWrapper
│   │   └── ui/                    # Button, Badge, Card, Modal
│   │
│   ├── hooks/
│   │   ├── usePredictions.ts
│   │   ├── useRecommendations.ts
│   │   └── useAuth.ts
│   │
│   ├── services/                  # API client functions
│   │   ├── apiClient.ts           # Axios instance with auth interceptor
│   │   ├── predictionService.ts
│   │   ├── uploadService.ts
│   │   ├── chatService.ts
│   │   └── reportService.ts
│   │
│   ├── store/                     # Zustand state stores
│   │   ├── authStore.ts
│   │   └── appStore.ts
│   │
│   └── types/                     # TypeScript type definitions
│       ├── prediction.ts
│       ├── recommendation.ts
│       └── api.ts
│
└── tests/
    └── e2e/                       # Playwright tests
        ├── dashboard.spec.ts
        ├── upload.spec.ts
        ├── predictions.spec.ts
        ├── copilot.spec.ts
        ├── reports.spec.ts
        └── auth.spec.ts
```

## Environment Variables

```bash
# src/frontend/.env
VITE_API_BASE_URL=http://localhost:8000/api/v1
```
