import { test, expect, Page } from '@playwright/test'

const ANALYST = { email: 'analyst@plasticwaste.ai', password: 'analyst123' }

async function login(page: Page) {
  await page.goto('/login')
  await page.getByLabel(/email/i).fill(ANALYST.email)
  await page.getByLabel(/password/i).fill(ANALYST.password)
  await page.getByRole('button', { name: /sign in/i }).click()
  await expect(page).toHaveURL('/')
}

test.describe('Authentication', () => {
  test('redirects unauthenticated users to /login', async ({ page }) => {
    await page.goto('/')
    await expect(page).toHaveURL('/login')
  })

  test('shows error on wrong credentials', async ({ page }) => {
    await page.goto('/login')
    await page.getByLabel(/email/i).fill('wrong@example.com')
    await page.getByLabel(/password/i).fill('wrongpass')
    await page.getByRole('button', { name: /sign in/i }).click()
    await expect(page.getByText(/invalid|incorrect|unauthorized/i)).toBeVisible()
  })

  test('logs in successfully and lands on dashboard', async ({ page }) => {
    await login(page)
    await expect(page.getByText(/dashboard/i)).toBeVisible()
  })
})

test.describe('Dashboard', () => {
  test.beforeEach(async ({ page }) => { await login(page) })

  test('shows KPI cards', async ({ page }) => {
    await expect(page.getByText(/total waste/i)).toBeVisible()
    await expect(page.getByText(/handling cost/i)).toBeVisible()
    await expect(page.getByText(/prediction accuracy/i)).toBeVisible()
  })

  test('shows waste trend chart', async ({ page }) => {
    await expect(page.locator('.recharts-wrapper').first()).toBeVisible()
  })
})

test.describe('Waste Predictions', () => {
  test.beforeEach(async ({ page }) => { await login(page); await page.goto('/predictions') })

  test('prediction form renders with date inputs', async ({ page }) => {
    await expect(page.getByLabel(/period start/i)).toBeVisible()
    await expect(page.getByLabel(/period end/i)).toBeVisible()
    await expect(page.getByRole('button', { name: /predict|run/i })).toBeVisible()
  })

  test('submitting prediction shows loading state', async ({ page }) => {
    await page.getByRole('button', { name: /predict|run/i }).click()
    await expect(page.getByText(/predicting|loading|processing/i)).toBeVisible({ timeout: 5000 })
  })
})

test.describe('Upload', () => {
  test.beforeEach(async ({ page }) => { await login(page); await page.goto('/upload') })

  test('upload page renders file drop zones', async ({ page }) => {
    await expect(page.getByText(/drag|drop|browse|upload/i).first()).toBeVisible()
  })
})

test.describe('Recommendations', () => {
  test.beforeEach(async ({ page }) => { await login(page); await page.goto('/recommendations') })

  test('recommendations page loads without error', async ({ page }) => {
    await expect(page.getByText(/recommendation/i)).toBeVisible()
    await expect(page.getByText(/error|failed/i)).not.toBeVisible()
  })
})

test.describe('AI Copilot', () => {
  test.beforeEach(async ({ page }) => { await login(page); await page.goto('/copilot') })

  test('chat input renders', async ({ page }) => {
    await expect(page.getByRole('textbox')).toBeVisible()
    await expect(page.getByRole('button', { name: /send/i })).toBeVisible()
  })

  test('sending a message shows response area', async ({ page }) => {
    await page.getByRole('textbox').fill('What is our largest source of plastic waste?')
    await page.getByRole('button', { name: /send/i }).click()
    // Either a loading indicator or a response should appear
    await expect(page.getByText(/thinking|loading|waste|plastic/i)).toBeVisible({ timeout: 10000 })
  })
})

test.describe('Reports', () => {
  test.beforeEach(async ({ page }) => { await login(page); await page.goto('/reports') })

  test('reports page renders generate button', async ({ page }) => {
    await expect(page.getByRole('button', { name: /generate/i })).toBeVisible()
  })
})

test.describe('Navigation', () => {
  test.beforeEach(async ({ page }) => { await login(page) })

  test('sidebar links navigate to all pages', async ({ page }) => {
    const links: [string, string][] = [
      ['/predictions', 'prediction'],
      ['/analytics', 'analytic'],
      ['/recommendations', 'recommendation'],
      ['/upload', 'upload'],
      ['/copilot', 'copilot'],
      ['/reports', 'report'],
    ]
    for (const [path, keyword] of links) {
      await page.goto(path)
      await expect(page.getByText(new RegExp(keyword, 'i')).first()).toBeVisible()
    }
  })
})
