import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'
import { authService } from '../../services/services'
import {
  LayoutDashboard, TrendingUp, Upload, Bot, FileBarChart,
  Settings, LogOut, Leaf, BarChart3, Lightbulb
} from 'lucide-react'
import clsx from 'clsx'

const NAV = [
  { to: '/',               label: 'Dashboard',       icon: LayoutDashboard },
  { to: '/predictions',    label: 'Predictions',     icon: TrendingUp },
  { to: '/analytics',      label: 'Analytics',       icon: BarChart3 },
  { to: '/recommendations', label: 'Recommendations', icon: Lightbulb },
  { to: '/upload',         label: 'Upload Data',     icon: Upload },
  { to: '/copilot',        label: 'AI Copilot',      icon: Bot },
  { to: '/reports',        label: 'Reports',         icon: FileBarChart },
  { to: '/settings',       label: 'Settings',        icon: Settings },
]

export default function Layout() {
  const { user, refreshToken, clearAuth } = useAuthStore()
  const navigate = useNavigate()

  const handleLogout = async () => {
    try { await authService.logout(refreshToken!) } catch {}
    clearAuth()
    navigate('/login')
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col">
        <div className="flex items-center gap-2 px-6 py-5 border-b border-gray-200">
          <Leaf className="h-6 w-6 text-primary-600" />
          <span className="font-semibold text-gray-900 text-sm">Plastic Waste AI</span>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {NAV.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              className={({ isActive }) => clsx(
                'flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
                isActive
                  ? 'bg-primary-50 text-primary-700'
                  : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
              )}
            >
              <Icon className="h-4 w-4 flex-shrink-0" />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="px-3 py-4 border-t border-gray-200">
          <div className="flex items-center gap-3 px-3 py-2 mb-1">
            <div className="h-7 w-7 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 text-xs font-bold">
              {user?.full_name?.[0] ?? '?'}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">{user?.full_name}</p>
              <p className="text-xs text-gray-500 capitalize">{user?.role}</p>
            </div>
          </div>
          <button onClick={handleLogout} className="flex items-center gap-3 w-full px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-gray-100 transition-colors">
            <LogOut className="h-4 w-4" />
            Sign out
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-y-auto">
        <Outlet />
      </main>
    </div>
  )
}
