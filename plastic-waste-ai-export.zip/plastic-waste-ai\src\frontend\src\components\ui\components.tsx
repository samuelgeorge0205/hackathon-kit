import clsx from 'clsx'

interface ConfidenceBadgeProps {
  score: number
  className?: string
}

export function ConfidenceBadge({ score, className }: ConfidenceBadgeProps) {
  const pct = Math.round(score * 100)
  const cls = score >= 0.8 ? 'badge-green' : score >= 0.5 ? 'badge-amber' : 'badge-red'
  const label = score >= 0.8 ? 'High' : score >= 0.5 ? 'Medium' : 'Low'
  return (
    <span className={clsx(cls, className)}>
      {label} confidence ({pct}%)
    </span>
  )
}

interface KPICardProps {
  title: string
  value: string | number
  change?: number
  unit?: string
  loading?: boolean
}

export function KPICard({ title, value, change, unit, loading }: KPICardProps) {
  return (
    <div className="card">
      <p className="text-sm text-gray-500 font-medium">{title}</p>
      {loading ? (
        <div className="mt-2 h-8 w-24 bg-gray-200 animate-pulse rounded" />
      ) : (
        <p className="mt-1 text-2xl font-bold text-gray-900">
          {typeof value === 'number' ? value.toLocaleString() : value}
          {unit && <span className="text-sm font-normal text-gray-500 ml-1">{unit}</span>}
        </p>
      )}
      {change !== undefined && !loading && (
        <p className={clsx('mt-1 text-sm', change < 0 ? 'text-success-600' : 'text-danger-600')}>
          {change > 0 ? '+' : ''}{change.toFixed(1)}% vs prior period
        </p>
      )}
    </div>
  )
}

export function PageHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-6">
      <h1 className="text-xl font-bold text-gray-900">{title}</h1>
      {subtitle && <p className="mt-1 text-sm text-gray-500">{subtitle}</p>}
    </div>
  )
}

export function ErrorBanner({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="rounded-lg bg-danger-100 border border-red-200 p-4 flex items-center justify-between">
      <p className="text-sm text-danger-600">{message}</p>
      {onRetry && <button onClick={onRetry} className="text-sm text-primary-600 font-medium hover:underline ml-4">Retry</button>}
    </div>
  )
}

export function Spinner({ className }: { className?: string }) {
  return (
    <div className={clsx('flex items-center justify-center', className)}>
      <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary-600 border-t-transparent" />
    </div>
  )
}
