import { useQuery } from '@tanstack/react-query'
import { dashboardService } from '../services/services'
import { PageHeader, Spinner } from '../components/ui/components'
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer
} from 'recharts'
import { format, parseISO } from 'date-fns'

const COLORS = ['#3b82f6','#10b981','#f59e0b','#ef4444','#8b5cf6','#06b6d4','#64748b']
const TYPES  = ['PET','HDPE','LDPE','PP','PS','PVC','MIXED']

export default function AnalyticsPage() {
  const { data: trends, isLoading } = useQuery({
    queryKey: ['trends-analytics'],
    queryFn: () => dashboardService.getTrends('month'),
  })

  const series = trends?.series ?? []
  const stackData = series.map((s: Record<string, unknown>) => ({
    date: s.date,
    ...((s.breakdown ?? {}) as Record<string, number>),
  }))

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <PageHeader title="Analytics" subtitle="Waste trends and supplier comparisons" />

      {isLoading ? <Spinner className="h-48" /> : (
        <div className="space-y-6">
          {/* Stacked area */}
          <div className="card">
            <h3 className="text-sm font-semibold text-gray-700 mb-4">Plastic Type Trend (Monthly)</h3>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={stackData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tickFormatter={d => format(parseISO(d as string), 'MMM')} tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip labelFormatter={d => format(parseISO(d as string), 'MMMM yyyy')} formatter={(v: number) => [`${v.toLocaleString()} kg`]} />
                <Legend iconSize={10} wrapperStyle={{ fontSize: '11px' }} />
                {TYPES.map((t, i) => (
                  <Area key={t} type="monotone" dataKey={t} stackId="1" stroke={COLORS[i]} fill={COLORS[i]} fillOpacity={0.7} />
                ))}
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Monthly totals bar */}
          <div className="card">
            <h3 className="text-sm font-semibold text-gray-700 mb-4">Monthly Waste Volume (kg)</h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={series}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tickFormatter={d => format(parseISO(d as string), 'MMM')} tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip labelFormatter={d => format(parseISO(d as string), 'MMMM yyyy')} formatter={(v: number) => [`${v.toLocaleString()} kg`, 'Total Waste']} />
                <Bar dataKey="total_waste_kg" name="Waste (kg)" fill="#3b82f6" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  )
}
