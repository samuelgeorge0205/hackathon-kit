import { useState, useRef, useEffect } from 'react'
import { chatService } from '../services/services'
import { PageHeader, ConfidenceBadge, Spinner } from '../components/ui/components'
import { Send, Bot, User, BookOpen } from 'lucide-react'
import clsx from 'clsx'

interface Message {
  role: 'user' | 'assistant'
  content: string
  citations?: unknown[]
  confidence?: number
  followUps?: string[]
}

export default function CopilotPage() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'Hi! I can answer supply chain sustainability questions about your waste data, packaging standards and regulations. What would you like to know?' }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [sessionId, setSessionId] = useState<string | undefined>()
  const [showCitations, setShowCitations] = useState<number | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  const send = async (text: string) => {
    if (!text.trim() || loading) return
    const userMsg: Message = { role: 'user', content: text }
    setMessages(m => [...m, userMsg])
    setInput('')
    setLoading(true)
    try {
      const res = await chatService.send(text, sessionId)
      setSessionId(res.session_id)
      setMessages(m => [...m, {
        role: 'assistant',
        content: res.response,
        citations: res.citations,
        confidence: res.confidence_score,
        followUps: res.suggested_follow_ups,
      }])
    } catch {
      setMessages(m => [...m, { role: 'assistant', content: 'Sorry, I\'m unable to respond right now. Please try again.' }])
    } finally {
      setLoading(false) }
  }

  return (
    <div className="flex flex-col h-full p-6 max-w-4xl mx-auto">
      <PageHeader title="AI Copilot" subtitle="Natural language Q&A grounded in your supply chain data" />

      <div className="card flex-1 flex flex-col min-h-0">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto space-y-4 p-1 mb-4">
          {messages.map((msg, i) => (
            <div key={i} className={clsx('flex gap-3', msg.role === 'user' ? 'flex-row-reverse' : '')}>
              <div className={clsx('h-8 w-8 rounded-full flex-shrink-0 flex items-center justify-center',
                msg.role === 'assistant' ? 'bg-primary-100 text-primary-600' : 'bg-gray-200 text-gray-600')}>
                {msg.role === 'assistant' ? <Bot className="h-4 w-4" /> : <User className="h-4 w-4" />}
              </div>

              <div className={clsx('max-w-[80%] space-y-2', msg.role === 'user' ? 'items-end' : '')}>
                <div className={clsx('rounded-xl px-4 py-3 text-sm leading-relaxed',
                  msg.role === 'assistant' ? 'bg-gray-100 text-gray-800' : 'bg-primary-600 text-white')}>
                  {msg.content}
                </div>

                {msg.role === 'assistant' && (
                  <div className="flex items-center gap-3 flex-wrap">
                    {msg.confidence !== undefined && <ConfidenceBadge score={msg.confidence} />}
                    {msg.citations && (msg.citations as unknown[]).length > 0 && (
                      <button onClick={() => setShowCitations(showCitations === i ? null : i)}
                        className="flex items-center gap-1 text-xs text-primary-600 hover:underline">
                        <BookOpen className="h-3 w-3" />
                        {(msg.citations as unknown[]).length} sources
                      </button>
                    )}
                  </div>
                )}

                {/* Citations panel */}
                {showCitations === i && msg.citations && (
                  <div className="bg-white border border-gray-200 rounded-lg p-3 text-xs text-gray-600 space-y-1.5">
                    {(msg.citations as { index: number; title: string; relevance: number }[]).map(c => (
                      <div key={c.index} className="flex items-start gap-2">
                        <span className="text-primary-500 font-medium">[{c.index}]</span>
                        <span>{c.title} — relevance {Math.round(c.relevance * 100)}%</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Follow-up suggestions */}
                {msg.role === 'assistant' && msg.followUps && i === messages.length - 1 && (
                  <div className="flex flex-wrap gap-2">
                    {msg.followUps.map((f, fi) => (
                      <button key={fi} onClick={() => send(f)}
                        className="text-xs px-3 py-1 rounded-full border border-primary-200 text-primary-600 hover:bg-primary-50 transition-colors">
                        {f}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex gap-3">
              <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center">
                <Bot className="h-4 w-4 text-primary-600" />
              </div>
              <div className="bg-gray-100 rounded-xl px-4 py-3">
                <Spinner className="h-5" />
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div className="flex gap-2 border-t border-gray-100 pt-4">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send(input)}
            placeholder="Ask about waste, packaging, suppliers, regulations..."
            className="input flex-1"
          />
          <button onClick={() => send(input)} disabled={loading || !input.trim()} className="btn-primary flex items-center gap-2">
            <Send className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  )
}
