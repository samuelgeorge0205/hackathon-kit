import { useQuery } from '@tanstack/react-query'
import { dashboardService } from '../services/services'
import { KPICard, PageHeader, ErrorBanner, Spinner } from '../components/ui/components'
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  PieChart, Pie, Cell, ResponsiveContainer
} from 'recharts'
import { format, parseISO } from 'date-fns'

const COLORS = ['#3b82f6','#10b981','#f59e0b','#ef4444','#8b5cf6','#06b6d4','#64748b']
const PLASTIC_TYPES = ['PET','HDPE','LDPE','PP','PS','PVC','MIXED']

export default function DashboardPage() {
  const { data: summary, isLoading: loadingS, error: errS, refetch: refetchS } = useQuery({
    queryKey: ['dashboard-summary'],
    queryFn: () => dashboardService.getSummary(),
  })
  const { data: trends, isLoading: loadingT } = useQuery({
    queryKey: ['dashboard-trends'],
    queryFn: () => dashboardService.getTrends('month'),
  })

  const pieData = summary
    ? PLASTIC_TYPES.map(t => ({ name: t, value: Math.round((summary.waste_by_plastic_type?.[t] ?? 0) * 10) / 10 })).filter(d => d.value > 0)
    : []

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="Dashboard" subtitle="Supply chain plastic waste overview — last 30 days" />

      {errS && <div className="mb-4"><ErrorBanner message="Failed to load dashboard" onRetry={refetchS} /></div>}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KPICard title="Total Waste" value={summary?.total_waste_kg ?? 0} unit="kg" change={summary?.waste_change_pct} loading={loadingS} />
        <KPICard title="Handling Cost" value={summary ? `£${(summary.total_handling_cost/1000).toFixed(1)}k` : '—'} change={summary?.cost_change_pct} loading={loadingS} />
        <KPICard title="Active Recommendations" value={summary?.active_recommendations ?? 0} loading={loadingS} />
        <KPICard
          title="Prediction Accuracy"
          value={summary?.prediction_accuracy_pct != null ? `${summary.prediction_accuracy_pct}%` : 'No feedback yet'}
          loading={loadingS}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {/* Trend Chart */}
        <div className="card lg:col-span-2">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">Waste Trend (Monthly)</h3>
          {loadingT ? <Spinner className="h-48" /> : (
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={trends?.series ?? []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tickFormatter={d => format(parseISO(d), 'MMM')} tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip formatter={(v: number) => [`${v.toLocaleString()} kg`, 'Waste']} labelFormatter={d => format(parseISO(d), 'MMMM yyyy')} />
                <Line type="monotone" dataKey="total_waste_kg" stroke="#3b82f6" strokeWidth={2} dot={false} name="Waste (kg)" />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Plastic Type Breakdown */}
        <div className="card">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">By Plastic Type</h3>
          {loadingS ? <Spinner className="h-48" /> : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={2} dataKey="value">
                  {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(v: number) => [`${v.toLocaleString()} kg`]} />
                <Legend iconSize={10} wrapperStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Recommendations savings callout */}
      {summary?.recommendations_value > 0 && (
        <div className="card bg-success-100 border-green-200">
          <p className="text-sm font-semibold text-success-600">
            £{(summary.recommendations_value / 1000).toFixed(0)}k savings identified across {summary.active_recommendations} pending recommendations.
            <a href="/reports" className="ml-2 underline">View report →</a>
          </p>
        </div>
      )}
    </div>
  )
}
