import { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { predictionService, feedbackService } from '../services/services'
import { PageHeader, ConfidenceBadge, Spinner, ErrorBanner } from '../components/ui/components'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { ThumbsUp, ThumbsDown, Play } from 'lucide-react'
import { format } from 'date-fns'

const schema = z.object({
  period_start: z.string().min(1),
  period_end:   z.string().min(1),
  supplier_id:  z.string().optional(),
  order_volume: z.preprocess(
    v => (v === '' ? undefined : v),
    z.coerce.number().int().positive().optional()
  ),
})
type Form = z.infer<typeof schema>

export default function PredictionsPage() {
  const [result, setResult] = useState<Record<string, unknown> | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError]   = useState('')
  const [pollId, setPollId] = useState<string | null>(null)

  const { register, handleSubmit, formState: { errors } } = useForm<Form>({
    resolver: zodResolver(schema),
    defaultValues: {
      period_start: format(new Date(), 'yyyy-MM-01'),
      period_end:   format(new Date(), 'yyyy-MM-') + new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate(),
    },
  })

  // Poll for result
  useEffect(() => {
    if (!pollId) return
    const interval = setInterval(async () => {
      try {
        const data = await predictionService.get(pollId)
        if (data.status === 'COMPLETE' || data.status === 'ERROR') {
          setResult(data)
          setLoading(false)
          setPollId(null)
          clearInterval(interval)
        }
      } catch { clearInterval(interval); setLoading(false) }
    }, 1500)
    return () => clearInterval(interval)
  }, [pollId])

  const onSubmit = async (form: Form) => {
    setError(''); setResult(null); setLoading(true)
    try {
      const { prediction_id } = await predictionService.create(form)
      setPollId(prediction_id)
    } catch { setError('Failed to start prediction'); setLoading(false) }
  }

  const pieData = result?.plastic_type_breakdown
    ? Object.entries(result.plastic_type_breakdown as Record<string, number>)
        .filter(([, v]) => v > 0)
        .map(([k, v]) => ({ type: k, kg: Math.round(v * 10) / 10 }))
    : []

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader title="Waste Predictions" subtitle="AI-powered plastic waste volume forecasting" />

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Form */}
        <div className="card lg:col-span-2">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">Prediction Parameters</h3>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Period Start</label>
              <input {...register('period_start')} type="date" className="input" />
              {errors.period_start && <p className="text-xs text-danger-600 mt-1">Required</p>}
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Period End</label>
              <input {...register('period_end')} type="date" className="input" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Order Volume (units)</label>
              <input {...register('order_volume')} type="number" className="input" placeholder="e.g. 15000" />
            </div>
            {error && <ErrorBanner message={error} />}
            <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
              {loading ? <Spinner className="h-4" /> : <Play className="h-4 w-4" />}
              {loading ? 'Running AI...' : 'Run Prediction'}
            </button>
          </form>
        </div>

        {/* Result */}
        <div className="lg:col-span-3 space-y-4">
          {loading && !result && (
            <div className="card flex flex-col items-center justify-center h-48 text-gray-400">
              <Spinner className="h-8 mb-3" />
              <p className="text-sm">AI prediction running... typically 3–5 seconds</p>
            </div>
          )}

          {result && result.status === 'COMPLETE' && (
            <>
              <div className="card">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="text-3xl font-bold text-gray-900">
                      {(result.predicted_waste_kg as number).toLocaleString()} kg
                    </p>
                    <p className="text-sm text-gray-500 mt-1">Predicted plastic waste</p>
                  </div>
                  <ConfidenceBadge score={result.confidence_score as number} />
                </div>

                {(result.prediction_interval as { low: number; high: number }) && (
                  <p className="text-xs text-gray-500">
                    Range: {(result.prediction_interval as { low: number; high: number }).low.toLocaleString()} – {(result.prediction_interval as { low: number; high: number }).high.toLocaleString()} kg
                  </p>
                )}

                {/* Feedback */}
                <div className="flex items-center gap-2 mt-4 pt-4 border-t border-gray-100">
                  <span className="text-xs text-gray-500">Was this accurate?</span>
                  <button onClick={() => feedbackService.submit('PREDICTION', result.prediction_id as string, 1)} className="p-1.5 rounded hover:bg-success-100 transition-colors">
                    <ThumbsUp className="h-4 w-4 text-gray-400 hover:text-success-600" />
                  </button>
                  <button onClick={() => feedbackService.submit('PREDICTION', result.prediction_id as string, -1)} className="p-1.5 rounded hover:bg-danger-100 transition-colors">
                    <ThumbsDown className="h-4 w-4 text-gray-400 hover:text-danger-600" />
                  </button>
                </div>
              </div>

              {/* Breakdown chart */}
              {pieData.length > 0 && (
                <div className="card">
                  <h4 className="text-sm font-semibold text-gray-700 mb-3">Plastic Type Breakdown</h4>
                  <ResponsiveContainer width="100%" height={160}>
                    <BarChart data={pieData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                      <XAxis type="number" tick={{ fontSize: 11 }} />
                      <YAxis type="category" dataKey="type" tick={{ fontSize: 11 }} width={40} />
                      <Tooltip formatter={(v: number) => [`${v} kg`]} />
                      <Bar dataKey="kg" fill="#3b82f6" radius={[0, 3, 3, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}

              {/* Explanation */}
              {result.explanation && (
                <div className="card border-l-4 border-primary-500">
                  <h4 className="text-sm font-semibold text-gray-700 mb-2">AI Explanation</h4>
                  <p className="text-sm text-gray-600 leading-relaxed">{result.explanation as string}</p>
                  {(result.key_factors as string[])?.length > 0 && (
                    <ul className="mt-3 space-y-1">
                      {(result.key_factors as string[]).map((f, i) => (
                        <li key={i} className="text-xs text-gray-500 flex items-start gap-1.5">
                          <span className="text-primary-400 mt-0.5">•</span>{f}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </>
          )}

          {!loading && !result && (
            <div className="card flex items-center justify-center h-48 text-gray-400">
              <p className="text-sm">Fill in parameters and run a prediction</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
