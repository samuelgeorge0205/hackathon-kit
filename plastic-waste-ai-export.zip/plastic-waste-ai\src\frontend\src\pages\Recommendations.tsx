import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { recommendationService } from '../services/services'
import { PageHeader, ConfidenceBadge, Spinner, ErrorBanner } from '../components/ui/components'
import { CheckCircle, XCircle, Clock, TrendingDown, DollarSign } from 'lucide-react'
import clsx from 'clsx'

const STATUS_COLORS: Record<string, string> = {
  PENDING:     'badge-amber',
  ACCEPTED:    'badge-green',
  REJECTED:    'badge-red',
  DEFERRED:    'badge-amber',
  IMPLEMENTED: 'badge-green',
  CANCELLED:   'badge-red',
}

const EFFORT_LABEL: Record<string, string> = {
  LOW: 'Drop-in replacement',
  MEDIUM: 'Supplier negotiation',
  HIGH: 'Product redesign',
}

export default function RecommendationsPage() {
  const qc = useQueryClient()
  const { data = [], isLoading, error, refetch } = useQuery({
    queryKey: ['recommendations'],
    queryFn: () => recommendationService.list(),
  })

  const { mutate: updateStatus } = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) =>
      recommendationService.updateStatus(id, status),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['recommendations'] }),
  })

  const totalSavings = (data as { estimated_cost_saving?: number }[]).reduce((s, r) => s + (r?.estimated_cost_saving ?? 0), 0)
  const totalReduction = (data as { estimated_waste_reduction_kg?: number }[]).reduce((s, r) => s + (r?.estimated_waste_reduction_kg ?? 0), 0)

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader title="Recommendations" subtitle="AI-generated packaging optimisation opportunities" />

      {error && <div className="mb-4"><ErrorBanner message="Failed to load recommendations" onRetry={refetch} /></div>}

      {/* Summary */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="card flex items-center gap-3">
          <TrendingDown className="h-8 w-8 text-success-600 flex-shrink-0" />
          <div>
            <p className="text-2xl font-bold text-gray-900">{totalReduction.toLocaleString()} kg</p>
            <p className="text-sm text-gray-500">Annual waste reduction potential</p>
          </div>
        </div>
        <div className="card flex items-center gap-3">
          <DollarSign className="h-8 w-8 text-primary-600 flex-shrink-0" />
          <div>
            <p className="text-2xl font-bold text-gray-900">£{totalSavings.toLocaleString()}</p>
            <p className="text-sm text-gray-500">Annual cost saving potential</p>
          </div>
        </div>
      </div>

      {isLoading ? <Spinner className="h-32" /> : (
        <div className="space-y-3">
          {(data as Record<string, unknown>[]).map(rec => (
            <div key={rec.id as string} className="card hover:border-primary-200 transition-colors">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className={STATUS_COLORS[rec.status as string] ?? 'badge-amber'}>
                      {rec.status as string}
                    </span>
                    <span className="text-xs text-gray-500">{rec.recommendation_type as string}</span>
                    {Boolean(rec.implementation_effort) && (
                      <span className="text-xs text-gray-400">· {EFFORT_LABEL[rec.implementation_effort as string]}</span>
                    )}
                  </div>
                  <p className="text-sm font-medium text-gray-900">{rec.description as string}</p>
                  {Boolean(rec.product_name) && (
                    <p className="text-xs text-gray-500 mt-0.5">{rec.product_name as string}</p>
                  )}
                  <div className="flex items-center gap-4 mt-2">
                    {Boolean(rec.estimated_waste_reduction_kg) && (
                      <span className="text-xs text-success-600">↓ {(rec.estimated_waste_reduction_kg as number).toLocaleString()} kg/year</span>
                    )}
                    {Boolean(rec.estimated_cost_saving) && (
                      <span className="text-xs text-primary-600">£{(rec.estimated_cost_saving as number).toLocaleString()}/year</span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-1 flex-shrink-0">
                  <ConfidenceBadge score={rec.confidence_score as number} />
                  {rec.status === 'PENDING' && (
                    <div className="flex gap-1 ml-2">
                      <button onClick={() => updateStatus({ id: rec.id as string, status: 'ACCEPTED' })}
                        className="p-1.5 rounded-lg hover:bg-success-100 transition-colors" title="Accept">
                        <CheckCircle className="h-4 w-4 text-success-600" />
                      </button>
                      <button onClick={() => updateStatus({ id: rec.id as string, status: 'REJECTED' })}
                        className="p-1.5 rounded-lg hover:bg-danger-100 transition-colors" title="Reject">
                        <XCircle className="h-4 w-4 text-danger-600" />
                      </button>
                      <button onClick={() => updateStatus({ id: rec.id as string, status: 'DEFERRED' })}
                        className="p-1.5 rounded-lg hover:bg-warning-100 transition-colors" title="Defer">
                        <Clock className="h-4 w-4 text-warning-600" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
          {data.length === 0 && (
            <div className="card text-center text-gray-400 py-12">
              No recommendations yet. Run a prediction to generate recommendations.
            </div>
          )}
        </div>
      )}
    </div>
  )
}
