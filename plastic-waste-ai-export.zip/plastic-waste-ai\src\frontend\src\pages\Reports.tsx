import { useState } from 'react'
import { reportService } from '../services/services'
import { PageHeader, Spinner, ErrorBanner } from '../components/ui/components'
import { FileText, Download, RefreshCw } from 'lucide-react'

export default function ReportsPage() {
  const [loading, setLoading] = useState(false)
  const [report, setReport] = useState<Record<string, unknown> | null>(null)
  const [error, setError] = useState('')
  const [periodStart, setPeriodStart] = useState('2026-01-01')
  const [periodEnd, setPeriodEnd] = useState('2026-07-30')

  const generate = async () => {
    setLoading(true); setError(''); setReport(null)
    try {
      const { report_id } = await reportService.generate({
        report_type: 'SUSTAINABILITY_WASTE',
        period_start: periodStart,
        period_end: periodEnd,
        scope: 'ORGANISATION',
        include_recommendations: true,
        regulatory_framework: 'GRI_306',
      })
      // Poll
      let attempts = 0
      while (attempts < 30) {
        await new Promise(r => setTimeout(r, 2000))
        const data = await reportService.get(report_id)
        if (data.status === 'COMPLETE' || data.status === 'ERROR') { setReport(data); break }
        attempts++
      }
    } catch { setError('Failed to generate report') }
    finally { setLoading(false) }
  }

  const metrics = report?.key_metrics as Record<string, number> | undefined

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader title="Reports" subtitle="AI-generated sustainability waste reports" />

      <div className="card mb-6">
        <h3 className="text-sm font-semibold text-gray-700 mb-4">Report Builder</h3>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Period Start</label>
            <input type="date" value={periodStart} onChange={e => setPeriodStart(e.target.value)} className="input" />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Period End</label>
            <input type="date" value={periodEnd} onChange={e => setPeriodEnd(e.target.value)} className="input" />
          </div>
        </div>
        {error && <div className="mb-3"><ErrorBanner message={error} /></div>}
        <button onClick={generate} disabled={loading} className="btn-primary flex items-center gap-2">
          {loading ? <><Spinner className="h-4" /> Generating report...</> : <><FileText className="h-4 w-4" /> Generate GRI 306 Report</>}
        </button>
        {loading && <p className="text-xs text-gray-400 mt-2">Typically 30–60 seconds…</p>}
      </div>

      {report && report.status === 'COMPLETE' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-gray-900">{report.title as string}</h2>
            <button className="btn-secondary flex items-center gap-2 text-xs">
              <Download className="h-3.5 w-3.5" /> Download PDF
            </button>
          </div>

          {metrics && (
            <div className="grid grid-cols-3 gap-3">
              <div className="card text-center">
                <p className="text-2xl font-bold text-gray-900">{(metrics.total_waste_kg ?? 0).toLocaleString()}</p>
                <p className="text-xs text-gray-500 mt-1">kg Total Waste</p>
              </div>
              <div className="card text-center">
                {metrics.period_over_period_change_pct == null ? (
                  <p className="text-2xl font-bold text-gray-400">N/A</p>
                ) : (
                  <p className={`text-2xl font-bold ${metrics.period_over_period_change_pct < 0 ? 'text-success-600' : 'text-danger-600'}`}>
                    {metrics.period_over_period_change_pct > 0 ? '+' : ''}{metrics.period_over_period_change_pct.toFixed(1)}%
                  </p>
                )}
                <p className="text-xs text-gray-500 mt-1">vs Prior Period</p>
              </div>
              <div className="card text-center">
                <p className="text-2xl font-bold text-primary-600">{metrics.recycling_rate_pct?.toFixed(1) ?? 0}%</p>
                <p className="text-xs text-gray-500 mt-1">Recycling Rate</p>
              </div>
            </div>
          )}

          {Boolean(report.executive_summary) && (
            <div className="card border-l-4 border-primary-500">
              <h4 className="text-sm font-semibold text-gray-700 mb-2">Executive Summary</h4>
              <p className="text-sm text-gray-600 leading-relaxed">{report.executive_summary as string}</p>
            </div>
          )}

          {Boolean(report.waste_by_type) && (
            <div className="card">
              <h4 className="text-sm font-semibold text-gray-700 mb-3">Waste by Plastic Type</h4>
              <div className="space-y-2">
                {Object.entries(report.waste_by_type as Record<string, number>)
                  .sort(([, a], [, b]) => b - a)
                  .map(([type, kg]) => {
                    const total = Object.values(report.waste_by_type as Record<string, number>).reduce((a, b) => a + b, 0)
                    const pct = total > 0 ? (kg / total) * 100 : 0
                    return (
                      <div key={type} className="flex items-center gap-3">
                        <span className="w-12 text-xs font-medium text-gray-600">{type}</span>
                        <div className="flex-1 bg-gray-100 rounded-full h-2">
                          <div className="bg-primary-500 h-2 rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                        <span className="text-xs text-gray-500 w-20 text-right">{kg.toLocaleString()} kg</span>
                      </div>
                    )
                  })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
