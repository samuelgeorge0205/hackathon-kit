import api from './apiClient'

export const authService = {
  login: async (email: string, password: string) => {
    const { data } = await api.post('/auth/login', { email, password })
    return data.data as { access_token: string; refresh_token: string; user: { id: string; email: string; full_name: string; role: string } }
  },
  logout: async (refreshToken: string) => {
    await api.post('/auth/logout', { refresh_token: refreshToken })
  },
}

export const dashboardService = {
  getSummary: async (period = 'last_30_days') => {
    const { data } = await api.get('/dashboard/summary', { params: { period } })
    return data.data
  },
  getTrends: async (granularity = 'week') => {
    const { data } = await api.get('/dashboard/trends', { params: { granularity } })
    return data.data
  },
}

export const predictionService = {
  create: async (params: Record<string, unknown>) => {
    const { data } = await api.post('/predictions/waste', params)
    return data.data as { prediction_id: string; status: string }
  },
  get: async (id: string) => {
    const { data } = await api.get(`/predictions/waste/${id}`)
    return data.data
  },
}

export const recommendationService = {
  list: async (status?: string) => {
    const { data } = await api.get('/recommendations', { params: status ? { status } : {} })
    return data.data as unknown[]
  },
  updateStatus: async (id: string, status: string, reason?: string) => {
    const { data } = await api.post(`/recommendations/${id}/feedback`, { status, reason })
    return data.data
  },
}

export const uploadService = {
  products: async (file: File) => {
    const fd = new FormData(); fd.append('file', file)
    const { data } = await api.post('/upload/products', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
    return data.data
  },
  packaging: async (file: File) => {
    const fd = new FormData(); fd.append('file', file)
    const { data } = await api.post('/upload/packaging', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
    return data.data
  },
  wasteLogs: async (file: File) => {
    const fd = new FormData(); fd.append('file', file)
    const { data } = await api.post('/upload/waste-logs', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
    return data.data
  },
  getStatus: async (uploadId: string) => {
    const { data } = await api.get(`/upload/${uploadId}/status`)
    return data.data
  },
}

export const chatService = {
  send: async (message: string, sessionId?: string, context?: Record<string, unknown>) => {
    const { data } = await api.post('/chat', { message, session_id: sessionId, context })
    return data.data as { session_id: string; message_id: string; response: string; citations: unknown[]; suggested_follow_ups: string[]; confidence_score: number }
  },
}

export const reportService = {
  generate: async (params: Record<string, unknown>) => {
    const { data } = await api.post('/reports/generate', params)
    return data.data as { report_id: string; status: string }
  },
  get: async (id: string) => {
    const { data } = await api.get(`/reports/${id}`)
    return data.data
  },
}

export const feedbackService = {
  submit: async (entityType: string, entityId: string, rating: number, comment?: string) => {
    const { data } = await api.post('/feedback', { entity_type: entityType, entity_id: entityId, rating, comment })
    return data.data
  },
}
