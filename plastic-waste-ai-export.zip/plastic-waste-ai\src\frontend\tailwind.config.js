/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: { 50: '#eff6ff', 500: '#3b82f6', 600: '#2563eb', 700: '#1d4ed8' },
        success: { 100: '#dcfce7', 600: '#16a34a' },
        warning: { 100: '#fef9c3', 600: '#ca8a04' },
        danger:  { 100: '#fee2e2', 600: '#dc2626' },
      },
    },
  },
  plugins: [],
}
