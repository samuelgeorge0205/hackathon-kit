# Synthetic Data

## Overview

Realistic retail supply chain dataset for the Plastics Waste Prediction platform.

## Files

| File | Records | Description |
|---|---|---|
| `suppliers.json` | 10 | Global packaging suppliers across 5 countries |
| `products.json` | 15 | Product catalogue across 6 categories |
| `packaging.json` | 15 | Packaging specs — all 7 plastic types represented |
| `warehouses.json` | 5 | UK distribution centres |
| `stores.json` | 20 | UK retail stores (4 formats) |
| `waste_logs.json` | 30 | Waste log records Jan–Jul 2026 |

## Plastic Type Coverage

| Type | Count in waste_logs | Notes |
|---|---|---|
| PET | 14 | Dominant type — ready meal trays, bottles |
| HDPE | 5 | Dairy bottles |
| PVC | 3 | Cling film, blister packs |
| LDPE | 3 | Shrink wrap, bread bags |
| PP | 3 | Tubs, flow-wrap |
| PS | 4 | Foam trays |
| MIXED | 3 | Multi-layer composite packaging |

## Referential Integrity

- All `product_id` in `waste_logs.json` exist in `products.json`
- All `packaging_id` in `waste_logs.json` exist in `packaging.json`
- All `supplier_id` in `products.json` exist in `suppliers.json`
- All `source_id` (WAREHOUSE) in `waste_logs.json` exist in `warehouses.json`
- All `source_id` (STORE) in `waste_logs.json` exist in `stores.json`

## Usage

```bash
# Load into the application database
python src/backend/data/seed_db.py

# Validate against JSON schemas
pytest src/backend/tests/synthetic/ -v
```

## Key Insights in Data

- **GlobalFoods (sup_001)** generates the most waste — uses virgin PET trays (pkg_001, pkg_015)
- **GreenWrap (sup_004)** has high sustainability score — uses rPET and recyclable packaging
- **Waste trend is rising** Jan→Jul 2026 — providing seasonal uplift signal for AI predictions
- **July 2026** has highest waste volumes — aligns with summer promotion period
- **RECYCLED disposal rate** is higher for HDPE and PP products (rPET packaging suppliers)
